from flask import Blueprint, request, render_template, session, redirect
from flask import send_file
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import func

import datetime

from models import db, User, Transaction, DepositType, Deposit
from helpers import login_required


api = Blueprint("api", __name__, url_prefix="")


@api.route("/")
def index():
    return redirect("/signin")


@api.route("/user/")
@login_required
def user_index():

    user = User.query.filter_by(id=session.get("user-id")).first()

    today = datetime.datetime.today()
    month = datetime.date(year=today.year, 
                            month=today.month,
                            day=1)
    
    deposits = DepositType.query.all()

    if Transaction.query.filter(Transaction.date >= month).filter_by(user_id=user.id, type="WITHDRAW").count() >= 5:
        return render_template("user/index.html", 
                               user=user, 
                               withdraw_limit=True, 
                               deposits=deposits)
    
    return render_template("user/index.html", user=user, deposits=deposits)


@api.route("/admin/")
@login_required
def admin_index():

    user = User.query.filter_by(id=session.get("user-id")).first()
    
    return render_template("admin/index.html", 
                           user=user,
                           data=admin_graph())


@api.route("/signin", methods=["GET", "POST"])
def signin():
    if request.method == "GET":
        return render_template("signin.html")
    
    elif request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")

        user = User.query.filter_by(email=email).first()

        if not user or not check_password_hash(user.password, password):
            return render_template("signin.html", 
                                   error=True,
                                   email=email)

        session["user-id"] = user.id
        session["user-role"] = user.role

        if user.role == "admin":
            return redirect("/admin/")
        else:
            return redirect("/user/")


@api.route("/signout")
def signout():
    session.clear()
    return redirect("/signin")


@api.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "GET":
        return render_template("register.html")
    
    elif request.method == "POST":
        firstname = request.form.get("firstname")
        lastname = request.form.get("lastname")
        email = request.form.get("email")
        password = request.form.get("password")
        repassword = request.form.get("repassword")

        firstname_error = False
        email_error = False
        password_error = None

        if firstname == "":
            firstname_error = True
        
        if email == "":
            email_error = True
        
        if password != repassword:
            password_error = "Password doesn't match"

        if password == "":
            password_error = "Password required!"
        
        if firstname_error or password_error or email_error:

            return render_template("register.html",
                                firstname=firstname,
                                lastname=lastname,
                                email=email,
                                password=password,
                                repassword=repassword, 
                                firstname_error=firstname_error,
                                email_error=email_error,
                                password_error=password_error)
    
        else:
            if lastname == "":
                lastname = None
            user = User(firstname=firstname,
                        lastname=lastname,
                        email=email,
                        password=generate_password_hash(password),
                        balance=1000,
                        role="user")
            db.session.add(user)
            db.session.flush()
            today = datetime.datetime.today()

            # if input is valid make the trasaction and update the database render page.
            transaction = Transaction(user_id=user.id,
                                    type="DEPOSIT",
                                    amount=1000,
                                    date=today)
            db.session.add(transaction)
            db.session.commit()

            return redirect("/signin")
            
        
@api.route("/user/add-money", methods=["POST"])
@login_required
def user_add_money():
    if request.method == "POST":
        
        # parse the amount as an integer
        amount = request.form.get("amount", type=int)
        user = User.query.filter_by(id=session["user-id"]).first()

        # Check if amount is invalid and return an error
        if not amount:
            return render_template("user/index.html", user=user, amount=True)
        
        today = datetime.datetime.today()

        # if input is valid make the trasaction and update the database render page.
        transaction = Transaction(user_id=user.id,
                                  type="DEPOSIT",
                                  amount=amount,
                                  date=today)
        db.session.add(transaction)
        user.balance += amount
        db.session.commit()
        return redirect("/user")    
    

@api.route("/user/withdraw-money", methods=["POST"])
@login_required
def user_withdraw_money():
    
    if request.method == "POST":

        # parse the amount as an integer
        amount = request.form.get("amount", type=int)
        user = User.query.filter_by(id=session["user-id"]).first()

        today = datetime.datetime.today()
        month = datetime.date(year=today.year, 
                              month=today.month,
                              day=1)
        
        # Check if amount is invalid and return an error
        if not amount or amount > user.balance:
            return render_template("user/index.html", user=user, withdraw=True)
        
        elif Transaction.query.filter(Transaction.date >= month).filter_by(user_id=user.id, type="WITHDRAW").count() >= 5:
            return redirect("/user")
        
        # if valid amount and satisfy monthly constraint deduct and render dashboard
        # and create an transaction
        user.balance -= amount

        transaction = Transaction(user_id=user.id,
                                  type="WITHDRAW",
                                  amount=amount,
                                  date=today)
        db.session.add(transaction)
        db.session.commit()

        return redirect("/user") 
    

@api.route("/user/statement", methods=["GET", "POST"])
@login_required
def user_statement():
    user = User.query.filter_by(id=session["user-id"]).first()

    # if get method retreive transaction done by the user and render it
    if request.method == "GET":
        transactions = Transaction.query.filter((Transaction.user_id==user.id) |
                                                (Transaction.receiver_id==user.id)).all()
        return render_template("user/statement.html", transactions=transactions)
    
    # if post request get the filter from form and render the transaction
    # according to the filter
    elif request.method == "POST":
        start_date = request.form.get("start-date")
        end_date = request.form.get("end-date")


        # check if date is empty if empty render error
        if not start_date or not end_date:
            transactions = Transaction.query.filter_by(user_id=user.id).all()
            return render_template("user/statement.html", 
                                   transactions=transactions,
                                   invalid_form=True)

        # try to parse the date if it's valid else render error
        try:
            start_date = datetime.datetime.strptime(start_date, "%Y-%m-%d")
            end_date = datetime.datetime.strptime(end_date, "%Y-%m-%d")
        except:
            transactions = Transaction.query.filter_by(user_id=user.id).all()
            return render_template("user/statement.html", 
                                   transactions=transactions,
                                   invalid_form=True)
        

        # Check if start date is greater than the end date if it is render error message
        # else filter the statement from the transaction table using start and end date
        # and render it
        if  start_date > end_date:
            transactions = Transaction.query.filter_by(user_id=user.id).all()
            return render_template("user/statement.html", 
                                   transactions=transactions,
                                   invalid_form=True)

        else:
            transactions = Transaction.query.filter(Transaction.date >= start_date,
                                                    Transaction.date <= end_date)\
                            .filter_by(user_id=user.id).all()
            
            return render_template("user/statement.html", 
                                    transactions=transactions)
        
@api.route("/user/transfer", methods=["POST"])
@login_required
def user_money_transfer():
    if request.method == "POST":
        
        email = request.form.get("email")
        amount = request.form.get("amount", type=int)

        user = User.query.filter_by(id=session["user-id"]).first()
        person = User.query.filter_by(email=email).first()

        # if the form is empty or user doesn't exist render error
        if not email or not person or person.id == user.id:
            return render_template("user/index.html", user=user, email_error=True)
        
        # if the amount is invalid render error
        if not amount or amount > user.balance:
            return render_template("user/index.html", user=user, transfer_amount_error=True)
        
        today = datetime.datetime.today()

        # if input is valid make the trasaction and update the database.
        transaction = Transaction(user_id=user.id,
                                  receiver_id=person.id,
                                  type="TRANSFER",
                                  amount=amount,
                                  date=today)
        db.session.add(transaction)
        user.balance -= amount
        person.balance += amount
        db.session.commit()
        return redirect("/user")
    

def admin_graph():
    transactions = db.session.query(
        func.sum(Transaction.amount),
        Transaction.date
        ).filter_by(type="DEPOSIT").group_by(Transaction.date).all()
    
    result = [["Date", "Amount"]]
    for amount, date in transactions:
        result.append([date.strftime("%Y-%m-%d"), amount])

    return result


@api.route("/admin/deposit/create", methods=["GET", "POST"])
@login_required
def admin_deposit_create():
    if request.method == "GET":
        return render_template("admin/deposit/create.html")
    
    if request.method == "POST":
        name = request.form.get("name")
        interest = request.form.get("interest", type=float)
        days = request.form.get("days", type=int)

        if not name:
            return render_template("admin/deposit/create.html", invalid_name=True)
        
        elif not interest:
            return render_template("admin/deposit/create.html", invalid_interest=True)
        
        elif days == None:
            return render_template("admin/deposit/create.html", invalid_days=True)
        
        deposit = DepositType(deposit=name,
                              interest_rate=interest,
                              days=days)
        db.session.add(deposit)
        db.session.commit()
        return redirect("/admin")


@api.route("/admin/deposit/view")
@login_required
def admin_deposit_view():
    deposits = DepositType.query.all()
    return render_template("admin/deposit/view.html", deposits=deposits)


@api.route("/admin/deposit/<int:deposit_id>/edit", methods=["GET", "POST"])
@login_required
def admin_deposit_edit(deposit_id):
    # select deposit using id
    deposit = DepositType.query.filter_by(id=deposit_id).first()

    # if deposit not exist return to view deposit page
    if not deposit:
        return redirect("/admin/deposit/view")
    
    if request.method == "GET":
        return render_template("admin/deposit/edit.html",
                            deposit=deposit)
    
    elif request.method == "POST":

        name = request.form.get("name")
        interest = request.form.get("interest", type=float)
        days = request.form.get("days", type=int)

        # check if another deposit exit but not the deposit that editing 
        # right now.
        duplicate = DepositType.query.filter_by(deposit=name).first() 
        if duplicate and deposit.id != duplicate.id:
            return render_template("admin/deposit/edit.html",
                            deposit=deposit, invalid_name=True)
        
        # if name or interest or days is invalid render error else 
        # update the deposit
        elif not name:
            return render_template("admin/deposit/edit.html",
                    deposit=deposit, invalid_name=True)
        
        elif not interest:
            return render_template("admin/deposit/edit.html",
                    deposit=deposit, invalid_interest=True)
        
        elif days == None:
            return render_template("admin/deposit/edit.html",
                    deposit=deposit, invalid_days=True)
        
        deposit.deposit = name
        deposit.interest_rate = interest
        deposit.days = days
        db.session.commit()

        return redirect("/admin/deposit/view")
    

@api.route("/admin/deposit/<int:deposit_id>", methods=["GET"])
def admin_deposit_delete(deposit_id):

    deposit = DepositType.query.filter_by(id=deposit_id).first()

    if deposit:
        db.session.delete(deposit)
        db.session.commit()

    return redirect("/admin/deposit/view")
    

@api.route("/admin/deposit/monitor")
def admin_deposit_monitor():
    deposits = DepositType.query.all()

    return render_template("admin/deposit/monitor.html", deposits=deposits)


@api.route("/user/deposit", methods=["POST"])
def user_add_deposit():
    deposit_id = request.form.get("deposit-id", type=int)
    amount = request.form.get("amount", type=int)

    user = User.query.filter_by(id=session.get("user-id")).first()
    
    deposits = DepositType.query.all()

    if deposit_id == None:
        return render_template("user/index.html", 
                               user=user,
                               deposits=deposits,
                               invalid_deposit=True)
    found = False
    for deposit in deposits:
        if deposit.id == deposit_id:
            found = True
    if not found:
        return render_template("user/index.html", 
                               user=user,
                               deposits=deposits,
                               invalid_deposit=True)
    
    elif amount == None:
        return render_template("user/index.html", 
                               user=user,
                               deposits=deposits,
                               invalid_amount=True)
    
    deposit = Deposit(user_id=user.id,
                      deposit=deposit_id,
                      amount=amount)
    db.session.add(deposit)
    db.session.commit()

    return render_template("user/index.html", 
                               user=user,
                               deposits=deposits,
                               deposit_success=True)


@api.route("/user/brochure")
@login_required
def user_download_brochure():
    return send_file("static/MAD I Bootcamp Problem Statement.pdf")