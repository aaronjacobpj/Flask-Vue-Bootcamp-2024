export const Hello = {
    template: `
        <h1>Hello, {{ name }}</h1>
        <input type="text" v-model="name">
    `,
    data(){
        return {
            name: null
        }
    }
}