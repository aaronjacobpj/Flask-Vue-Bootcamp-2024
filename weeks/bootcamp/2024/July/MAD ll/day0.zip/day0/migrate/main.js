import { Hello } from "./hello.js"

const app = Vue.createApp({
    template:`
        <h1> {{ message }} </h1>
        <Hello/>
    `,
    data(){
        return{
            message: "Home page"
        }
    }
})
app.component("Hello", Hello);
app.mount("#app")
