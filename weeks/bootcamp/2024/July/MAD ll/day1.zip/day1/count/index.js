import {store} from './store.js'

const app = Vue.createApp({
    template: `<h1>count: {{$store.state.count}} </h1>
    <button @click="$store.dispatch('increment')">Click me</button>`,
});
app.use(store);
app.mount("#app");