<script setup>
import store from "@/store"
</script>

<template>
  <h1>Count: {{store.state.count}}</h1>
  <button @click="store.commit('increment')">Click</button>
</template>

<script>
  export default{
    data(){
      return{
        count: 0
      }
    }
  }
</script>

<style scoped>
h1 {
  font-weight: 500;
  font-size: 2.6rem;
  position: relative;
  top: -10px;
}

h3 {
  font-size: 1.2rem;
}

.greetings h1,
.greetings h3 {
  text-align: center;
}

@media (min-width: 1024px) {
  .greetings h1,
  .greetings h3 {
    text-align: left;
  }
}
</style>
