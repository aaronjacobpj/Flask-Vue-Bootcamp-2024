<script setup>
    import Navbar from "@/components/Navbar.vue";
</script>

<template>
    <Navbar/>
    <div class="container-fluid">
        <div class="card" style="width: fit-content;">
            <div class="card-body">
                <h4 class="card-title" align="center">Sign in</h4>
               <form @submit.prevent="login()">
                    <div class="row">
                        <div class="col">
                        <input type="text" class="form-control" v-model="username"
                            placeholder="username" aria-label="username">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                        <input type="password" class="form-control" v-model="password"
                            placeholder="password" aria-label="password">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <input type="submit" class="btn btn-primary" 
                                style="width: 100%;" value="Sign in"/>
                        </div>
                    </div>
               </form>
            </div>
          </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                username: null,
                password: null
            }
        },
        methods:{
            validate(){
                console.log(this.username, this.password);
            },
            login(){
                this.validate();
            }
        }
    }
</script>
<style scoped>
    .container-fluid{
        width: 100%;
        height: 90vh;
        overflow: hidden;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .row{
        padding: 10px;
    }
</style>
