from flask import Blueprint, request
from flask import current_app as app
from werkzeug.security import check_password_hash
from flask_security import login_user

from .models import User

api = Blueprint("api", __name__)


@api.route("/signin", methods=["POST"])
def signin():

    username = request.json.get("username")
    password = request.json.get("password")

    if not username:
        return {"message": "Invalid username"}, 400
    
    if not password:
        return {"message": "Invalid password"}, 400
    
    user = app.security.datastore.find_user(username=username)
    
    if not user:
        return {"message": "User not Found"}, 404
    
    if not check_password_hash(user.password, password):
        return {"message": "User not Found"}, 404

    
    login_user(user)

    return {"token": user.get_auth_token(),
            "roles": user.get_roles()}


