import { createRouter, createWebHistory } from 'vue-router'
import store from "@/store";
import LoginView from '../views/LoginView.vue'
import SignupView from "@/views/SignupView.vue";
import AdminView from "@/views/admin/AdminView.vue";
import CreateTheatreView from "@/views/admin/CreateTheatreView.vue";


const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'login-view',
      component: LoginView
    },
    {
      path: "/signup",
      name: "signup-view",
      component: SignupView
    },
    {
      path: "/admin",
      name: "admin-view",
      component: AdminView,
      children: [
        {
          path: "",
          name: "admin-create-theatre",
          component: CreateTheatreView
        }
      ]
    }
  ]
})

router.beforeEach((to) =>{
  if(!store.getters.getRoles.includes("admin") && to.fullPath.startsWith("/admin")){
    router.push("/")
  }
  if(!store.getters.getToken && (to.fullPath.startsWith("/admin") || to.fullPath.startsWith("/user"))){
    router.push("/")
  }
});


export default router
