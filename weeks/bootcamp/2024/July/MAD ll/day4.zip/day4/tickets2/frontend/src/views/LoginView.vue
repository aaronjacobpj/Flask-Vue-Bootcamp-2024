<script setup>
    import Navbar from "@/components/Navbar.vue";
    import store from "@/store";
    import { RouterLink } from "vue-router";
</script>

<template>
    <Navbar/>
    <div class="container-fluid">
        <div class="card" style="width: fit-content;">
            <div class="card-body">
                <h4 class="card-title" align="center">Sign in</h4>
                <form @submit.prevent="login()">
                    <div class="row">
                        <div class="col">
                            <input type="text" class="form-control" v-model="username"
                                placeholder="username" aria-label="username">
                            <div v-bind:class="{'invalid-feedback': true, 'invalid-input': error['username'] != null}" >
                                    {{ error['username'] }}
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <input type="password" class="form-control" v-model="password"
                                placeholder="password" aria-label="password">
                            <div v-bind:class="{'invalid-feedback': true, 'invalid-input': error['password'] != null}" >
                                {{ error['password'] }}
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <input type="submit" class="btn btn-primary" 
                                style="width: 100%;" value="Sign in"/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col" style="display: flex;justify-content: center;">
                            <router-link to="/signup">Register</router-link>
                        </div>
                    </div>
               </form>
            </div>
          </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                username: null,
                password: null,
                error: {
                    username: null,
                    password: null
                }
            }
        },
        methods:{
            validate(){
                this.error = {
                    username: null,
                    password: null
                }
                let valid = true;
                if(! this.username || this.username.length < 4){
                    this.error["username"] = "Invalid username.";
                    valid = false;
                }
                if(!this.password){
                    this.error["password"] = "Invalid password.";
                    valid = false;
                }

                return valid;
            },
            login(){
                if(!this.validate())
                    return;

                fetch(import.meta.env.VITE_BASEURL+"/signin", {method: "POST",
                    headers: {"Content-Type": "application/json"},
                    body: JSON.stringify({username: this.username, password: this.password})
                }).then(resp =>{
                    return [resp.json(), resp.status]
                }).then(x =>{
                    if(x[1] == 200){
                        return x[0]
                    }
                    else if(x[1] == 404 || x == 400){
                        this.error = {
                            username: "Invalid username or password.",
                            password: "Invalid username or password."
                        }
                    }
                    return {}
                }).then(x=>{
                    store.commit("setUser", x);
                })
            }
        }
    }
</script>
<style scoped>
    .container-fluid{
        width: 100%;
        height: 90vh;
        overflow: hidden;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .row{
        padding: 10px;
    }
    .invalid-input{
        display: block;
    }
</style>
