<script setup>
    import Navbar from "@/components/Navbar.vue";
    import store from "@/store";
    import router from "@/router";
    import { RouterLink } from "vue-router";
</script>

<template>
    <Navbar/>
    <div class="container-fluid">
        <div class="card" style="width: fit-content;">
            <div class="card-body">
                <h4 class="card-title" align="center">Register</h4>
                <form @submit.prevent="login()">
                    <div class="row">
                        <div class="col">
                            <input type="text" class="form-control" placeholder="Full Name" 
                                v-model="fullname" aria-label="Full Name">
                            <div v-bind:class="{'invalid-feedback': true, 'invalid-input': error['fullname'] != null}" >
                                {{ error['fullname'] }}
                            </div>
                        </div>
                        <div class="col">
                            <input type="text" class="form-control" placeholder="Username" 
                                v-model="username" aria-label="username">
                            <div v-bind:class="{'invalid-feedback': true, 'invalid-input': error['username'] != null}" >
                                {{ error['username'] }}
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <input type="password" class="form-control" placeholder="Password" 
                                v-model="password" aria-label="confirm password">
                            <div v-bind:class="{'invalid-feedback': true, 'invalid-input': error['password'] != null}" >
                                {{ error['password'] }}
                            </div>
                        </div>
                        <div class="col">
                            <input type="password" class="form-control" placeholder="Confirm Password" 
                                v-model="checkPassword" aria-label="confirm password">
                            <div v-bind:class="{'invalid-feedback': true, 'invalid-input': error['checkPassword'] != null}" >
                                {{ error['checkPassword'] }}
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <input type="submit" class="btn btn-primary" 
                                style="width: 100%;" value="Sign in"/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col" style="display: flex;justify-content: center;">
                            <router-link to="/">Log in</router-link>
                        </div>
                    </div>
               </form>
            </div>
          </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                fullname: null,
                username: null,
                password: null,
                checkPassword: null,
                error: {
                    fullname: null,
                    username: null,
                    password: null,
                    checkPassword: null,
                }
            }
        },
        methods:{
            validate(){
                this.error = {
                    fullname: null,
                    username: null,
                    password: null,
                    checkPassword: null,
                }
                let valid = true;
                if(!this.fullname){
                    this.error["fullname"] = "Required field";
                    valid = false;
                }
                if(! this.username || this.username.length < 4){
                    this.error["username"] = "Invalid username.";
                    valid = false;
                }
                if(!this.password || this.password != this.checkPassword){
                    this.error["password"] = "Invalid password.";
                    valid = false;
                }

                return valid;
            },
            login(){
                if(!this.validate())
                    return;

                fetch(import.meta.env.VITE_BASEURL+"/signup", {method: "POST",
                    headers: {"Content-Type": "application/json"},
                    body: JSON.stringify({username: this.username, 
                                          password: this.password, 
                                          fullname: this.fullname})
                }).then(resp =>{
                    return [resp.json(), resp.status]
                }).then(x =>{
                    if(x[1] == 201){
                        return x[0]
                    }
                    else if(x[1] == 409){
                        this.error["username"] = "Username already exist";
                    }
                    return x[0]
                }).then(x =>{
                    if(x["message"].match("Invalid Name")){
                        this.error["fullname"] = "Invalid Fullname";
                    }
                    else if(x["message"].match("Invalid username")){
                        this.error["username"] = "Invalid Username";
                    }
                    else if(x["message"].match("Invalid password")){
                        this.error["password"] = "Invalid password"
                    }
                    else{
                        router.push({name: "login-view"})
                    }
                })
            }
        }
    }
</script>
<style scoped>
    .container-fluid{
        width: 100%;
        height: 90vh;
        overflow: hidden;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .row{
        padding: 10px;
    }
    .invalid-input{
        display: block;
    }
</style>
