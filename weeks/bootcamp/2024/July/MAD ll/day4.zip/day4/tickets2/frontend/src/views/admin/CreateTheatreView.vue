<template>
    <h1>Create Theatre View</h1>
</template>