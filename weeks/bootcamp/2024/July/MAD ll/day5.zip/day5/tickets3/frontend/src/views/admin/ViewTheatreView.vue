<script setup>
    import store from "@/store";
    import router from "@/router";
</script>
<template>
    <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Capacity</th>
            <!-- <th scope="col">Handle</th> -->
          </tr>
        </thead>
        <tbody>
          <tr v-for="(theatre, index) in store.getters.getTheatres">
            <th scope="row">{{index+1}}</th>
            <td>{{ theatre['name'] }}</td>
            <td>{{ theatre['capacity'] }}</td>
            <td>
                <button class="btn btn-primary" @click="redirect(index)">
                    Edit
                </button>
            </td>
          </tr>
        </tbody>
    </table>
</template>
<script>
    export default{
        created(){
            store.dispatch("getTheatres")
        },
        methods:{
            redirect(id){
                router.push(`/admin/theatre/${id}`)
            }
        }
    }
</script>
<style scoped>
</style>