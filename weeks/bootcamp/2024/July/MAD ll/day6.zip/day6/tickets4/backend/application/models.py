from flask_sqlalchemy import SQLAlchemy
from flask_security import RoleMixin, UserMixin


db = SQLAlchemy()


class User(db.Model, UserMixin):

    __tablename__ = "user"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), nullable=False)
    username = db.Column(db.String(), unique=True, nullable=False)
    password = db.Column(db.String(), nullable=False)
    fs_uniquifier = db.Column(db.String(64), unique=True, nullable=False)
    active = db.Column(db.Boolean())
    roles = db.relationship('Role', secondary='roles_users',
                         backref=db.backref('users', lazy='dynamic'))
    

    def get_roles(self):
        return [role.name for role in self.roles]


class RolesUsers(db.Model):
    __tablename__ = 'roles_users'
    id = db.Column(db.Integer(), primary_key=True)
    user_id = db.Column('user_id', db.Integer(), db.ForeignKey('user.id'))
    role_id = db.Column('role_id', db.Integer(), db.ForeignKey('role.id'))


class Role(db.Model, RoleMixin):
    __tablename__ = 'role'
    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(80), unique=True)


class Theatre(db.Model):
    __tablename__ = "theatre"


    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), nullable=False)
    capacity = db.Column(db.Integer(), nullable=False)


class Movie(db.Model):
    __tablename__ = "movie"

    id = db.Column(db.Integer(), primary_key=True)
    title = db.Column(db.String(), nullable=False)
    poster = db.Column(db.String())


class Show(db.Model):
    __tablename__ = "show"

    id = db.Column(db.Integer(), primary_key=True)
    movie_id = db.Column(db.Integer(), db.ForeignKey("movie.id"))
    theatre_id = db.Column(db.Integer(), db.ForeignKey("theatre.id"))
    time = db.Column(db.Time(), nullable=False)

class Tickets(db.Model):
    __tablename__ = "tickets"

    id = db.Column(db.Integer(), primary_key=True)
    user_id = db.Column(db.Integer(), db.ForeignKey("user.id"))
    show_id = db.Column(db.Integer(), db.ForeignKey("show.id"))