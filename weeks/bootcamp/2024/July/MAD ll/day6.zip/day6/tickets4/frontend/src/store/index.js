import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            user: {
                token: null,
                roles: []
            },
            theatres: [],
        }
    },
    mutations: {
        setUser(state, value){
            localStorage.setItem("user", JSON.stringify(value));
            state.user = value;
        },
        setTheatres(state, value){
            state.theatres = value;
        }
    },
    getters: {
        getRoles(state){
            return state.user["roles"];
        },
        getToken(state){
            return state.user["token"];
        },
        getTheatres(state){
            return state.theatres
        }
    },
    actions:{
        getTheatres({commit, state}){
            fetch(import.meta.env.VITE_BASEURL+"/theatre", {
                method: "GET",
                headers:{
                    "Authentication-Token": state.user["token"]
                }
            }).then(response => response.json()).then(x =>{
                commit("setTheatres", x);
            })
        }
    }
});