from flask import Flask
from flask_cors import CORS
from flask_security import SQLAlchemyUserDatastore, Security
from werkzeug.security import generate_password_hash


def create_app():
    from application.models import db, User, Role
    from application.routes import api

    app = Flask(__name__)

    app.config['SECRET_KEY'] = "rgiegrinreingeori"
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///project.db"

    db.init_app(app)
    CORS(app)

    datastore = SQLAlchemyUserDatastore(db, User, Role)
    app.security = Security(app, datastore)

    with app.app_context():
        db.create_all()

        if not Role.query.filter_by(name="admin").first():
            role_admin = app.security.datastore.create_role(name="admin")
            app.security.datastore.create_role(name="user")
            user = app.security.datastore.create_user(name="Alice", 
                                                       username="alice",
                                                       password=generate_password_hash("alice"))
            app.security.datastore.add_role_to_user(user, role_admin)
            db.session.commit()


    app.register_blueprint(api)


    return app

    
app = create_app()
