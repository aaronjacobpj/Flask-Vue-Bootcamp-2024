import random
import string

N = 20

def generate_filename(extension):
    result = ""
    n = len(string.ascii_letters)
    for i in range(N):
        result += string.ascii_letters[random.randint(0, n-1)]

    return result+extension