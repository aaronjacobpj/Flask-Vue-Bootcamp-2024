<script setup>
</script>

<template>
  <h1>Hello, world!</h1>
</template>

<style scoped>

</style>
