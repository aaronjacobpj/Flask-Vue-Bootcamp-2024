import { createRouter, createWebHistory } from 'vue-router'
import store from "@/store";
import LoginView from '../views/LoginView.vue'
import SignupView from "@/views/SignupView.vue";
import AdminView from "@/views/admin/AdminView.vue";
import CreateTheatreView from "@/views/admin/CreateTheatreView.vue";
import ViewTheatreView from "@/views/admin/ViewTheatreView.vue";
import CreateShowView from "@/views/admin/CreateShowView.vue"
import ViewShowView from "@/views/admin/ViewShowView.vue";
import EditMovieView from "@/views/admin/EditMovieView.vue";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'login-view',
      component: LoginView
    },
    {
      path: "/signup",
      name: "signup-view",
      component: SignupView
    },
    {
      path: "/admin",
      name: "admin-view",
      component: AdminView,
      children: [
        {
          path: "theatre/view",
          name: "admin-view-theatre",
          component: ViewTheatreView
        },
        {
          path: "theatre",
          name: "admin-create-theatre",
          component: CreateTheatreView
        },
        {
          path: "theatre/:id",
          name: "admin-edit-theatre",
          props: true,
          component: CreateTheatreView
        },
        {
          path: "show/create",
          name: "admin-create-show",
          component: CreateShowView
        },
        {
          path: "show",
          name: "admin-view-show",
          component: ViewShowView
        },
        {
          path: "show/:id",
          name: "admin-edit-show",
          component: EditMovieView,
          props: true
        },
      ]
    }
  ]
})

router.beforeEach((to) =>{
  if(!store.getters.getRoles.includes("admin") && to.fullPath.startsWith("/admin")){
    router.push("/")
  }
  if(!store.getters.getToken && (to.fullPath.startsWith("/admin") || to.fullPath.startsWith("/user"))){
    router.push("/")
  }
  if(to.fullPath.startsWith("/signout")){
    store.commit("setUser", {token: null, roles: []});
    router.push("/")
  }
});


export default router
