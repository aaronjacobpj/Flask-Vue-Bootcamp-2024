import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            user: {
                token: null,
                roles: []
            },
            theatres: [],
            movies: [],
        }
    },
    mutations: {
        setUser(state, value){
            localStorage.setItem("user", JSON.stringify(value));
            state.user = value;
        },
        setTheatres(state, value){
            state.theatres = value;
        },
        setMovies(state, value){
            state.movies = value;
        }
    },
    getters: {
        getRoles(state){
            return state.user["roles"];
        },
        getToken(state){
            return state.user["token"];
        },
        getTheatres(state){
            return state.theatres
        },
        getMovies(state){
            return state.movies;
        }
    },
    actions:{
        getTheatres({commit, state}){
            fetch(import.meta.env.VITE_BASEURL+"/theatre", {
                method: "GET",
                headers:{
                    "Authentication-Token": state.user["token"]
                }
            }).then(response => response.json()).then(x =>{
                commit("setTheatres", x);
            })
        },
        getMovies({commit, state}){
            fetch(import.meta.env.VITE_BASEURL+"/movies", {
                method: "GET",
                headers:{
                    "Authentication-Token": state.user["token"]
                }
            }).then(response => response.json()).then(x =>{
                commit("setMovies", x);
            })
        }
    }
});