<script setup>
    import store from "@/store";
    import router from "@/router";
</script>
<template>
    <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Poster</th>
            <th scope="col">Title</th>
            <th scope="col">Time</th>
            <th scope="col">Theatres</th>
          </tr>
        </thead>
        <tbody>
            <tr v-for="(movie, index) in store.getters.getMovies">
                <td scope="row">{{ index+1 }}</td>
                <td>
                    <img :src="getPosterURL(movie.poster)" class="img-fluid img-thumbnail">
                </td>
                <td>{{ movie.title }}</td>
                <td>{{ movie.time }}</td>
                <td>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item" v-for="theatre in movie.theatres">
                            {{ theatre.name }}
                        </li>
                    </ul>
                </td>
                <td>
                    <button class="btn btn-warning" @click="router.push(`/admin/show/${movie.id}`)">Edit</button>
                </td>
                <td>
                    <button class="btn btn-danger" @click="deleteMovie(movie.id)">Delete</button>
                </td>
            </tr>
        </tbody>
    </table>
</template>
<script>
    export default {
        data(){
            return {

            }
        },
        created(){
            store.dispatch("getMovies")
        },
        methods:{
            getPosterURL(poster){
                return import.meta.env.VITE_BASEURL+'/static/'+poster;
            },
            deleteMovie(id){
                fetch(import.meta.env.VITE_BASEURL+`admin/movie/${id}`, {
                    method: "DELETE"
                }).then((resp)=>{
                    store.dispatch("getTheatres");
                })
            }
        }
    }
</script>
<style scoped>
    .img-fluid{
        height: 150px;
    }
</style>