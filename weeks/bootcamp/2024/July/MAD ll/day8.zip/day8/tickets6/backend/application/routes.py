from flask import Blueprint, request
from flask import current_app as app
from sqlalchemy.sql import func
from werkzeug.security import check_password_hash, generate_password_hash
from flask_security import login_user, auth_required, roles_required, current_user
from datetime import datetime
import time
import re
import os

from .models import db, User, Theatre, Movie, Show, Tickets
from .utils import generate_filename


api = Blueprint("api", __name__)


@api.route("/signin", methods=["POST"])
def signin():

    username = request.json.get("username")
    password = request.json.get("password")

    if not username:
        return {"message": "Invalid username"}, 400
    
    if not password:
        return {"message": "Invalid password"}, 400
    
    user = app.security.datastore.find_user(username=username)
    
    if not user:
        return {"message": "User not Found"}, 404
    
    if not check_password_hash(user.password, password):
        return {"message": "User not Found"}, 404

    
    login_user(user)

    return {"token": user.get_auth_token(),
            "roles": user.get_roles()}


@api.route("/signup", methods=["POST"])
def signup():

    fullname = request.json.get("fullname")
    username = request.json.get("username")
    password = request.json.get("password")

    if not fullname:
        return {"message": "Invalid Name"}, 400
    
    if not username:
        return {"message": "Invalid username"}, 400
    
    if not password:
        return {"message": "Invalid password"}, 400
    
    if app.security.datastore.find_user(username=username):
        return {"message": "Username already exist"}, 409
    
    user = app.security.datastore.create_user(name=fullname, 
                                            username=username,
                                            password=generate_password_hash(password))
    user_role = app.security.datastore.find_role("user")
    app.security.datastore.add_role_to_user(user, user_role)
    db.session.commit()

    return {"message": "Request successful"}, 201


@api.route("/theatre/create", methods=["POST"])
@auth_required("token")
@roles_required("admin")
def create_theatre():
    name = request.json.get("name")
    capacity = request.json.get("capacity")

    if not name:
        return {"message": "Invalid name"}, 400
    elif not capacity:
        return {"message": "Invalid capacity"}, 400
    
    theatre = Theatre(name=name, capacity=capacity)
    db.session.add(theatre)
    db.session.commit()

    return {"message": "Request successfull"}, 201


@api.route("/theatre")
@auth_required("token")
def get_theatres():
    result = []
    for theatre in Theatre.query.all():
        result.append({"id": theatre.id,
                       "name": theatre.name,
                       "capacity": theatre.capacity})
        
    return result


@api.route("/theatre/<int:theatre_id>", methods=["POST"])
# @auth_required("token")
# @roles_required("admin")
def update_theatre(theatre_id):
    name = request.json.get("name")
    capacity = request.json.get("capacity")

    if not name:
        return {"message": "Invalid name"}, 400
    elif not capacity:
        return {"message": "Invalid capacity"}, 400
    
    theatre = db.session.query(Theatre).get(theatre_id)
    theatre.name=name
    theatre.capacity=capacity
    db.session.commit()

    return {"message": "Request successfull"}


@api.route("/admin/theatre/<int:theatre_id>", methods=["DELETE"])
@auth_required("token")
@roles_required("admin")
def delete_theatre(theatre_id):
    theatre = db.session.query(Theatre).get(theatre_id)

    if not theatre:
        return {"message": "Theatre not found"}, 404
    
    db.session.delete(theatre)
    db.session.commit()
    return {"message": "Request successful"}, 200


@api.route("/admin/movie", methods=["POST"])
@auth_required("token")
@roles_required("admin")
def create_movie():
    name = request.form.get("name")
    image = request.files.get("image")
    theatre_ids = request.form.getlist("theatres", type=int)
    showtime = request.form.get("time")

    if not name:
        return {"message": "Invalid name"}, 400
    
    if len(theatre_ids) == 0:
        return {"message": "Invalid theatres"}, 400
    
    theatres = Theatre.query.filter(Theatre.id.in_(theatre_ids)).all()
    if  len(theatres) != len(theatre_ids):
        return {"message": "Invalid theatres"}, 400
    
    if re.match("[0-9]{2}:[0-9]{2}", showtime):
        showtime = datetime.strptime(showtime, "%H:%M").time()
    else:
        return {"message": "Invalid showtime"}

    filename, extension = os.path.splitext(image.filename)
    filename = generate_filename(extension)
    while filename in os.listdir("static"):
        filename = generate_filename(extension)
    
    image.save(os.path.join("static", filename))

    movie = Movie(title=name, poster=filename)
    db.session.add(movie)
    db.session.flush()

    for theatre in theatres:
        show = Show(movie_id=movie.id,
                    theatre_id=theatre.id,
                    time=showtime)
        db.session.add(show)

    db.session.commit()
    return {"message": "Request successful"}, 201
        

@api.route("/movies")
def get_movies():
    movies = Movie.query.all()
    result = []
    for movie in movies:
        result.append({"id": movie.id,
                       "title": movie.title,
                       "poster": movie.poster,
                       "time": movie.shows[0].time.strftime("%H:%M") if len(movie.shows) > 0 else None,
                       "theatres": [{"id": show.theatre.id,
                                     "name": show.theatre.name} 
                                     for show in movie.shows],
                    })
    
    return result


@api.route("/admin/movie/<int:movie_id>", methods=["PUT"])
@auth_required("token")
@roles_required("admin")
def update_movie(movie_id):
    movie = db.session.query(Movie).get(movie_id)

    if not movie:
        return {"message": "Movie not found."}, 404
    
    name = request.form.get("name")
    showtime = request.form.get("time")
    theatre_ids = request.form.getlist("theatres", type=int)
    image = request.files.get("image")

    if not name:
        return {"message": "Invalid name"}, 400
    
    if len(theatre_ids) == 0:
        return {"message": "Invalid theatres"}, 400
    
    theatres = Theatre.query.filter(Theatre.id.in_(theatre_ids)).all()
    if  len(theatres) != len(theatre_ids):
        return {"message": "Invalid theatres"}, 400
    
    if re.match("[0-9]{2}:[0-9]{2}", showtime):
        showtime = datetime.strptime(showtime, "%H:%M").time()
    else:
        return {"message": "Invalid showtime"}
    
    # Check if show in the form, if not delete show
    for show in movie.shows:
        if show.id not in theatre_ids:
            db.session.delete(show)
    
    # Check if new theatre in the form if yes then add
    for theatre_id in theatre_ids:
        found = False
        for show in movie.shows:
            if show.theatre_id == theatre_id:
                found = True
        
        if not found:
            db.session.add(Show(movie_id=movie_id,
                                theatre_id=theatre_id,
                                time=showtime))
            
    movie.title = name
    for show in movie.shows:
        show.time = showtime
    if image:
        image.save(os.path.join("static", movie.poster))
    db.session.commit()
    return {"message": "Request successful"}, 200
            

@api.route("/admin/movie/<int:movie_id>", methods=["DELETE"])
@auth_required("token")
@roles_required("admin")
def delete_movie(movie_id):
    movie = db.session.query(Movie).get(movie_id)

    if not movie:
        return {"message": "Movie not found."}, 404
    
    db.session.delete(movie)
    db.session.commit()

    return {"message": "Request successful"}, 200


@api.route("/movie/<int:movie_id>/book", methods=["POST"])
def book_movie(movie_id):
    theatre = request.json.get("theatre")
    tickets = request.json.get("tickets")

    show = Show.query.filter_by(movie_id=movie_id, theatre_id=theatre).first()

    if not show:
        return {"message": "Show not found."}, 404
    
    sold = db.session.query(func.sum(Tickets.tickets)).filter_by(show_id=show.id).first()[0]
    if not sold:
        sold = 0

    if sold+tickets > show.theatre.capacity:
        return {"message": f"{show.theatre.capacity-sold} tickets available."}, 400
    
    order = Tickets(user_id=current_user.id,
                    show_id=show.id,
                    tickets=tickets)
    db.session.add(order)
    db.session.commit()
    return {"message": "Request successful"}

