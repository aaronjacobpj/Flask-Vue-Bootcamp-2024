<script setup>
    import store from "@/store";
    import router from "@/router";
</script>
<template>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Edit Show</h5>
            <form @submit.prevent="submit()">
                <div class="row">
                    <div class="col">
                        <img :src="image" v-if="image" style="max-width: 90%;"/>
                    </div>
                    <div class="col">
                        <div class="row">
                            <div class="mb-3">
                                <label for="MovieNameInput" class="form-label">Movie Name</label>
                                <input type="text" class="form-control" id="MovieNameInput" 
                                v-model="name" placeholder="Movie name">
                            </div>
                        </div>
                        <div class="row">
                            <div class="mb-3">
                                <label for="MoviePosterInput" class="form-label">Movie Poster</label>
                                <input type="file" class="form-control" id="MoviePosterInput" @change="getFile">
                            </div>
                        </div>
                        <div class="row">
                            <div class="mb-3">
                                <label for="TheatresSelect" class="form-label">Theatres</label multiple>
                                <select class="form-select" id="TheatresSelect" multiple
                                    v-model="theatres">
                                    <option selected disabled>Open this select menu</option>
                                    <option v-for="theatre in store.getters.getTheatres" 
                                        :value="theatre['id']">{{theatre['name']}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="mb-3">
                                <label for="ShowTimeInput" class="form-label">Show Time</label>
                                <input type="time" class="form-control" id="ShowTimeInput" v-model="time">
                            </div>
                        </div>
                        <div class="row">
                            <div class="mb-3">
                                <input type="submit" class="btn btn-primary" id="formSubmitButton" placeholder="Example input placeholder">
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>        
    </div>
</template>
<script>
    export default {
        props: ["id"],
        data(){
            return{
                name: null,
                theatres: [],
                time: null,
                poster: null,
                image: null,
                error:{
                    name: null,
                    theatres: [],
                    time: null,
                }
            }
        },
        watch:{
            theatre(value){
                this.editName = value["name"];
                this.editCapacity = value["capacity"];
            },
            movie(value){
                this.name = value.title;
                this.image = this.getPosterURL(value.poster)
                this.time = value.time
                this.theatres = value.theatres.map(x => x.id)
            }
        },
        created(){
            store.dispatch("getTheatres");
            store.dispatch("getMovies");
        },
        computed: {
            theatre(){
                return store.getters.getTheatres[this.id]
            },
            movie(){
                return store.getters.getMovies.filter(x => parseInt(x.id) == this.id)[0]
            },

        },
        methods:{
            validate(){
                this.error = {
                    name: null,
                    capacity: null,
                }

                let valid = true;
                if(!this.name){
                    this.error["name"] = "Invalid name";
                    valid = false;
                }
                if(!this.capacity){
                    this.error["capacity"] = "Invalid capacity";
                    valid = false;
                }
                return valid
            },
            submit(){
                // if(!this.validate())
                    // return

                let form = new FormData()
                form.append("name", this.name)
                form.append("time", this.time)
                for(let each of this.theatres)
                    form.append("theatres", each)
                form.append("image", this.poster)

                fetch(import.meta.env.VITE_BASEURL+"/admin/movie/"+this.id, {
                    method: "PUT",
                    headers: {
                        "Authentication-Token": store.getters.getToken
                    },
                    body: form
                }).then(x =>{
                    router.push("/admin/show")
                })
            },
            getFile(event){
                this.readFile(event.target.files[0])
                this.poster = event.target.files[0]
                console.log(this.poster);
            },
            readFile(file){
                const reader = new FileReader();
                reader.addEventListener('load', (event) => {
                    this.image = event.target.result;
                });
                reader.readAsDataURL(file)
            },
            getPosterURL(poster){
                return import.meta.env.VITE_BASEURL+'/static/'+poster;
            }
        }
    }
</script>
<style scoped>
    .col {
        padding: 5px;
    }
    .card{
        margin: 10px;
    }
    .error{
        display: block;
    }
    #formSubmitButton{
        width: 100%;
    }
</style>