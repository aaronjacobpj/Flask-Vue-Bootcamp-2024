<script setup>
    import store from "@/store";
    import router from "@/router";
</script>
<template>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Edit Show</h5>
            <form @submit.prevent="submit()">
                <div class="row">
                    <div class="col">
                        <img :src="image" v-if="image" style="max-width: 90%;"/>
                    </div>
                    <div class="col">
                        <div class="row">
                            <div class="mb-3">
                                <label for="MovieNameInput" class="form-label">Movie Name</label>
                                <input type="text" class="form-control" id="MovieNameInput" 
                                :value="name" disabled placeholder="Movie name">
                            </div>
                        </div>
                        <div class="row">
                            <div class="mb-3">
                                <label for="ShowTimeInput" class="form-label">Show Time</label>
                                <input type="time" class="form-control" id="ShowTimeInput"
                                    disabled :value="time">
                            </div>
                        </div>
                        <div class="row">
                            <div class="mb-3">
                                <label for="TheatresSelect" class="form-label">Theatres</label multiple>
                                <select class="form-select" id="TheatresSelect"
                                    v-model="option">
                                    <option selected disabled>Open this select menu</option>
                                    <option v-for="theatre in store.getters.getTheatres" 
                                        :value="theatre['id']">{{theatre['name']}}</option>
                                </select>
                                <div :class="{'invalid-feedback': true, 'error': error['option']}" >
                                   {{ error['option'] }}
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="mb-3">
                                <label for="TicketNumber" class="form-label">Tickets</label>
                                <input type="number" class="form-control" id="TicketNumber" 
                                    min="1" v-model="ticket">
                                <div :class="{'invalid-feedback': true, 'error': error['ticket']}" >
                                    {{ error['ticket'] }}
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="mb-3">
                                <input type="submit" class="btn btn-primary" id="formSubmitButton" placeholder="Example input placeholder">
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>        
    </div>
</template>
<script>
    export default {
        props: ["id"],
        data(){
            return{
                name: null,
                option: null,
                time: null,
                ticket: 1,
                image: null,
                error:{
                    name: null,
                    option: null,
                    time: null,
                }
            }
        },
        watch:{
            theatre(value){
                this.editName = value["name"];
                this.editCapacity = value["capacity"];
            },
            movie(value){
                this.name = value.title;
                this.image = this.getPosterURL(value.poster)
                this.time = value.time
                this.theatres = value.theatres.map(x => x.id)
            }
        },
        created(){
            store.dispatch("getTheatres");
            store.dispatch("getMovies");
        },
        computed: {
            theatre(){
                return store.getters.getTheatres[this.id]
            },
            movie(){
                return store.getters.getMovies.filter(x => parseInt(x.id) == this.id)[0]
            },

        },
        methods:{
            validate(){
                this.error = {
                    tickets: null,
                    option: null,
                }

                let valid = true;
                if(!this.option){
                    this.error["option"] = "Invalid option";
                    valid = false;
                }
                if(!this.ticket){
                    this.error["ticket"] = "Invalid number of tickets";
                    valid = false;
                }
                return valid
            },
            submit(){
                if(!this.validate())
                    return

                fetch(import.meta.env.VITE_BASEURL+`movie/${this.id}/book`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": store.getters.getToken
                    },
                    body: JSON.stringify({"tickets": this.ticket, "theatre": this.option})
                }).then(x =>{

                })
            },
            getPosterURL(poster){
                return import.meta.env.VITE_BASEURL+'/static/'+poster;
            }
        }
    }
</script>
<style scoped>
    .col {
        padding: 5px;
    }
    .card{
        margin: 10px;
    }
    .error{
        display: block;
    }
    #formSubmitButton{
        width: 100%;
    }
</style>