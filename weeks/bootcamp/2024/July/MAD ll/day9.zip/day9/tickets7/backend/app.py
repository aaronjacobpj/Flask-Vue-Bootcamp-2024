from flask import Flask
from flask_cors import CORS
from flask_security import SQLAlchemyUserDatastore, Security
from werkzeug.security import generate_password_hash

from application.utils import celery_init_app
from celery.schedules import crontab
from application.worker import daily_reminder



def create_app():
    from application.models import db, User, Role
    from application.routes import api

    app = Flask(__name__)

    app.config['SECRET_KEY'] = "rgiegrinreingeori"
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///project.db"
    app.config["CELERY"] = {"broker_url": "redis://localhost",
                            "result_backend": "redis://localhost",
                            "broker_connection_retry_on_startup": True
    }

    db.init_app(app)
    CORS(app)

    datastore = SQLAlchemyUserDatastore(db, User, Role)
    app.security = Security(app, datastore)

    with app.app_context():
        db.create_all()

        if not Role.query.filter_by(name="admin").first():
            role_admin = app.security.datastore.create_role(name="admin")
            app.security.datastore.create_role(name="user")
            user = app.security.datastore.create_user(name="Alice", 
                                                       username="alice",
                                                       password=generate_password_hash("alice"))
            app.security.datastore.add_role_to_user(user, role_admin)
            db.session.commit()


    app.register_blueprint(api)


    return app


app = create_app()

celery = celery_init_app(app)


@celery.on_after_configure.connect
def setup_periodic_tasks(sender, **kwargs):

    sender.add_periodic_task(crontab(minute="*"), daily_reminder.s(), name="say hello")