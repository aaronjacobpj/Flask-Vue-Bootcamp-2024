from celery import shared_task
import requests
import time
import os

from application.models import db, User

@shared_task
def hello():
    print("hello")
    time.sleep(10)
    print("Hi")
    return "Hello"


@shared_task
def daily_reminder():
    for user in User.query.all():
        requests.post(os.environ.get("GSPACE"), json={"text": f"Hello, {user.name}"})
