<script setup>
import { RouterLink, RouterView } from 'vue-router'
import store from "@/store";
</script>
<template>
  <RouterView />
</template>
<script>
  export default {
    created(){
      let user = localStorage.getItem("user")
      store.commit("setUser", (user) ? JSON.parse(user) : {token: null,roles: []});
    }
  }
</script>
<style scoped>
</style>
