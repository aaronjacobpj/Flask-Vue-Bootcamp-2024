<script setup>
    import store from "@/store";
    import router from "@/router";
</script>
<template>
    <div class="card">
        <div class="card-body">
          <h5 class="card-title">Card title</h5>
            <form @submit.prevent="search">
                <div class="row">
                    <div class="col">
                    <input type="text" class="form-control" placeholder="Query" aria-label="Query" 
                        v-model="query">
                    </div>
                    <div class="col">
                        <select class="form-select" v-model="option">
                            <option selected disabled>Select filter</option>
                            <option value="movie">Movie</option>
                            <option value="theatre">Theatre</option>
                        </select>
                    </div>
                    <div class="col">
                    <input  style="width: 100%;" type="submit" class="btn btn-outline-primary">
                    </div>
                </div>
            </form>
        </div>
      </div>
    <div class="container-fluid" style="padding: 0%;">
        <div class="card" v-for="movie in search">
            <div class="card-body">
              <div class="row">
                <div class="col" style="max-width: fit-content;">
                    <img :src="getPosterURL(movie.poster)" class="img-thumbnail">
                </div>
                <div class="col">
                    <h5 class="card-title">{{ movie.title }}</h5>
                    <h6 class="card-subtitle mb-2 text-body-secondary">
                        {{ movie.time }}
                    </h6>
                    <span class="badge text-bg-secondary" style="margin-left: 5px;" v-for="theatre in movie.theatres">
                        {{ theatre.name }}
                    </span>
                </div>
                <div class="col" style="display: flex; justify-content: flex-end;">
                    <button class="btn btn-primary" @click="router.push(`/user/book/${movie.id}`)">
                        Buy
                    </button>
                </div>
              </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                option: null,
                query: ""
            }
        },
        created(){
            store.dispatch("getMovies");
        },
        methods: {
            getPosterURL(poster){
                return import.meta.env.VITE_BASEURL+'/static/'+poster;
            },
        },
        computed:{
            search(){
                return store.getters.getMovies.filter(movie =>{
                    if(this.option == "theatre"){
                        return movie.theatres.some(theatre =>{
                            return theatre.name.includes(this.query)
                        })
                    }
                    else {
                        return movie.title.includes(this.query)
                    }
                })
            },
        }
    }
</script>
<style scoped>
    .card{
        margin: 10px;
    }
    .img-thumbnail{
        width: 100px; 
        height: 150px;
        margin-top: 10px;
    }
</style>