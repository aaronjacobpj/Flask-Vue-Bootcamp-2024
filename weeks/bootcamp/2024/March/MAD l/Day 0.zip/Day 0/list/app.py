from flask import Flask, render_template

app = Flask(__name__)


items = ["First item", "Second item", "Third item", "Forth item"]

@app.route("/")
def index():
    return render_template("index.html", items=items)


@app.route("/empty")
def empty():
    return render_template("index.html", items=[])


@app.route("/register/<int:age>")
def register(age):
    return render_template("result.html", age=age)