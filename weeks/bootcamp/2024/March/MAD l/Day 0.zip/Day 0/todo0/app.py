from flask import Flask, render_template, request

app = Flask(__name__)

items = []

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/show", methods=["GET", "POST"])
def show():
    global items
    if request.method == "GET":
        return render_template("show.html", items=items)

    if request.method == "POST":
        item = request.form.get("item")
        items.append(item)
        return render_template("show.html", items=items)

