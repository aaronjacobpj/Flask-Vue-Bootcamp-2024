from flask import Flask, render_template, request, session

app = Flask(__name__)
app.config["SECRET_KEY"] = "todoapp"


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/show", methods=["GET", "POST"])
def show():

    if "items" not in session:
        session["items"] = []

    if request.method == "GET":
        return render_template("show.html", items=session["items"])

    if request.method == "POST":
        item = request.form.get("item")
        session["items"] = session["items"] + [item]
        return render_template("show.html", items=session["items"])

