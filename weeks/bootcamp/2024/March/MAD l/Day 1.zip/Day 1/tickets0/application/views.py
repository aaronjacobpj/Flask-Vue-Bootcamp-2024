from flask import current_app as app
from flask import Blueprint, render_template, redirect, request, flash, session
from werkzeug.security import generate_password_hash, check_password_hash

from .models import User, Role, UserRoles, db
from .utils import login_required


views = Blueprint("views", __name__)


@views.route("/")
@login_required
def index():
    return render_template("index.html")


@views.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")
    
    username = request.form.get("username")
    password = request.form.get("password")

    user = User.query.filter_by(username=username).first()

    if not user or check_password_hash(user.password, password):
        flash("invalid username or password", "error-login")
        return redirect("/login")
    
    session["user-id"] = user.id
    return redirect("/")

    


@views.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "GET":
        return render_template("register.html")
    
    elif request.method == "POST":
        firstname = request.form.get("firstname")
        lastname = request.form.get("lastname")
        username = request.form.get("username")
        password = request.form.get("password")
        confirm_password = request.form.get("confirm")

        if not firstname:
            flash("invalid firstname", "error-firstname")
            return redirect("/register")
        
        if User.query.filter_by(username=username).first():
            flash("Username already exist!", "error-username")
            return redirect("/register")
        
        if password != confirm_password:

            flash("invalid password", "error-password")
            return redirect("/register")
        
        user = User(firstname=firstname, lastname=lastname,
                    username=username, password=generate_password_hash(password))
        db.session.add(user)
        db.session.flush()
        role = Role.query.filter_by(role="user").first()
        user_role = UserRoles(user_id=user.id, role_id=role.id)
        db.session.add(user_role)
        db.session.commit()
        flash("Created user account successfully!", "success-messages")

    return redirect("/login")
        