from app import app 
from application.models import db, Movie, Venue, Show, User
from datetime import date

with app.app_context():
    movie = Movie(name="Your name", rating=10)
    db.session.add(movie)
    venue = Venue(name="IMDB", place="New york")
    db.session.add(venue)
    db.session.flush()
    show = Show(movie_id=movie.id, venue_id=venue.id, 
                capacity=100, price=150, start=date.today(),
                end=date.today())
    db.session.add(show)
    db.session.commit()
    print(venue.movies)
    print(movie.venues)
    print(show.movie_id)
    admin = User.query.first()
    print(admin.roles)