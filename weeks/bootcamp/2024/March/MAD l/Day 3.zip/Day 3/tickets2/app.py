from flask import Flask
from werkzeug.security import generate_password_hash


def create_app():

    from application.views import views
    from application.models import db, User, UserRoles, Role, Genre

    app = Flask(__name__)
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///model.db"
    app.config["SECRET_KEY"] = "asdfghjrgijt"

    app.register_blueprint(views)
    db.init_app(app)
    with app.app_context():
        db.create_all()
        if not Role.query.all():
            role = Role(role="admin")
            db.session.add(role)
            db.session.add(Role(role="user"))
            db.session.commit()
            user = User(firstname="Grace", lastname="Turner",
                        username="grace", password=generate_password_hash("grace"))
            db.session.add(user)
            db.session.flush()
            db.session.add(UserRoles(user_id=user.id, role_id=role.id))
            genres = ['Action', 'Adventure', 'Animation', 'Biography', 
            'Comedy', 'Crime', 'Documentary', 'Drama', 'Family', 
            'Fantasy', 'Film-Noir', 'History', 'Horror', 'Music', 
            'Musical', 'Mystery', 'Romance', 'Sci-Fi', 'Short', 
            'Sport', 'Thriller', 'War', 'Western']
            for genre in genres:
                db.session.add(Genre(type=genre))
            db.session.commit()

    return app


app = create_app()
