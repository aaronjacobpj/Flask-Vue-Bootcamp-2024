from flask import current_app as app
from flask import Blueprint, render_template, redirect, request, flash, session
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from sqlalchemy import or_, and_

from .models import (User, Role, UserRoles, db, Venue, Movie, 
                     Genre, MovieGenre, Show, ShowTiming)
from .utils import login_required

import os
import re
import datetime
import time


views = Blueprint("views", __name__)


@views.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")
    
    username = request.form.get("username")
    password = request.form.get("password")

    user = User.query.filter_by(username=username).first()

    if not user or not check_password_hash(user.password, password):
        flash("invalid username or password", "error-login")
        return redirect("/login")
    
    session["user-id"] = user.id
    if user.is_("admin"):
        return redirect("/admin")
    
    return redirect("/")

@views.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "GET":
        return render_template("register.html")
    
    elif request.method == "POST":
        firstname = request.form.get("firstname")
        lastname = request.form.get("lastname")
        username = request.form.get("username")
        password = request.form.get("password")
        confirm_password = request.form.get("confirm")

        if not firstname:
            flash("invalid firstname", "error-firstname")
            return redirect("/register")
        
        if User.query.filter_by(username=username).first():
            flash("Username already exist!", "error-username")
            return redirect("/register")
        
        if password != confirm_password:

            flash("invalid password", "error-password")
            return redirect("/register")
        
        user = User(firstname=firstname, lastname=lastname,
                    username=username, password=generate_password_hash(password))
        db.session.add(user)
        db.session.flush()
        role = Role.query.filter_by(role="user").first()
        user_role = UserRoles(user_id=user.id, role_id=role.id)
        db.session.add(user_role)
        db.session.commit()
        flash("Created user account successfully!", "success-messages")

    return redirect("/login")


@views.route("/signout")
def signout():
    session.clear()
    return redirect("/login")


@views.route("/admin")
@login_required
def admin_index():
    return render_template("admin/index.html")


@views.route("/")
@login_required
def user_index():
    return render_template("user/index.html")


@views.route("/admin/venue/create", methods=["GET", "POST"])
@login_required
def create_venue():
    if request.method == "GET":
        return render_template("admin/create-venue.html")
    
    if request.method == "POST":
        name = request.form.get("name")
        place = request.form.get("place")

        if not name:
            flash("Invalid name for the venue", "error-message")
            return redirect("/admin/venue/create")
        
        if not place:
            flash("Invalid place for the venue", "error-message")
            return redirect("/admin/venue/create")
        
        venue = Venue(name=name, place=place)
        db.session.add(venue)
        db.session.commit()

        flash("Created venue successfully.", "success-message")
        return redirect("/admin/venue/create")
    

@views.route("/admin/venue")
@login_required
def admin_venue():
    search = request.args.get("name")
    option = request.args.get("filter")

    if option == "Name":
        venues = Venue.query.filter(Venue.name.like(f"%{search}%")).all()
    elif option == "Place":
        venues = Venue.query.filter(Venue.place.like(f"%{search}%")).all()
    else:
        venues = Venue.query.all()
    return render_template("admin/venues.html", venues=venues)


@views.route("/admin/venue/<int:venue_id>", methods=["GET", "POST"])
@login_required
def admin_venue_edit(venue_id):
    
    venue = db.session.query(Venue).get(venue_id)
    
    if not venue:
        flash("Invalid venue id", "error-message")
        return render_template("admin/edit-venue.html", venue_id=venue_id, venue=venue)
    
    if request.method == "GET":
        return render_template("admin/edit-venue.html", venue=venue)
    
    if request.method == "POST":
        name = request.form.get("name")
        place = request.form.get("place")

        if not name:
            flash("Invalid name for the venue", "error-message")
            return redirect(f"/admin/venue/{venue_id}")
        
        if not place:
            flash("Invalid place for the venue", "error-message")
            return redirect(f"/admin/venue/{venue_id}")
        venue.name = name
        venue.place = place
        db.session.commit()
        flash("Updated venue successfully.", "success-message")
        return redirect(f"/admin/venue/{venue_id}")
    

@views.route("/admin/venue/<int:venue_id>/delete")
@login_required
def venue_delete(venue_id):
    venue = db.session.query(Venue).get(venue_id)
    
    if not venue:
        flash("Invalid venue id", "error-message")
        return redirect("/admin/venue")
    db.session.delete(venue)
    db.session.commit()
    flash("Deleted venue successfully.", "success-message")
    return redirect("/admin/venue")


@views.route("/admin/movie/create", methods=["GET", "POST"])
@login_required
def admin_create_movie():
    if request.method == "GET":
        genres = Genre.query.all()
        return render_template("admin/create-movie.html", genres=genres)
    
    if request.method == "POST":
        title = request.form.get("name")
        rating = request.form.get("rating", type=int)
        poster = request.files.get("poster")
        movie_genres = request.form.getlist("genres", type=int)

        if not title:
            flash("Invalid name for the movie", "error-message")
            return redirect("/admin/movie/create")
        
        if not rating or not 0 <= rating <= 10:
            flash("Invalid rating for the movie", "error-message")
            return redirect("/admin/movie/create")
        
        genres = Genre.query.filter(Genre.id.in_(movie_genres)).all()
        if len(genres) != len(movie_genres):
            flash("Invalid genre selected for the movie", "error-message")
            return redirect("/admin/movie/create")


        movie = Movie(name=title, rating=rating)
        db.session.add(movie)
        db.session.flush()
        for each in genres:
            db.session.add(MovieGenre(movie_id=movie.id, genre_id=each.id))
        movie.poster = f"{movie.id}-{secure_filename(poster.filename)}"
        poster.save(os.path.join("static/uploads/", movie.poster))
        db.session.commit()

        flash("Created movie successfully.", "success-message")
        return redirect(f"/admin/movie/create")
    

@views.route("/admin/movie")
def get_movies():
    search = request.args.get("name")
    rating = request.args.get("rating", type=int)
    genre = request.args.getlist("genre")

    if search and rating:
        movies = db.session.query(Movie).filter(or_(Movie.name.like(f"%{search}%"),
                                Movie.rating >= rating,
                                and_(Movie.id==MovieGenre.movie_id,
                                MovieGenre.genre_id.in_(genre)))).all()
    elif not search and rating:
        movies = db.session.query(Movie).filter(or_(Movie.rating >= rating,
                                and_(Movie.id==MovieGenre.movie_id,
                                MovieGenre.genre_id.in_(genre)))).all()
    elif search and not rating:
        movies = db.session.query(Movie).filter(or_(Movie.name.like(f"%{search}%"),
                                        and_(Movie.id==MovieGenre.movie_id,
                                        MovieGenre.genre_id.in_(genre)))).all()
    else:
        movies = db.session.query(Movie).filter(or_(Movie.name.like(f"%_%"),
                                and_(Movie.id==MovieGenre.movie_id,
                                MovieGenre.genre_id.in_(genre)))).all()

    genres = Genre.query.all()
    return render_template("admin/movies.html", movies=movies, genres=genres)


@views.route("/admin/movie/<int:movie_id>", methods=["GET", "POST"])
@login_required
def admin_edit_movie(movie_id):

    if request.method == "GET":
        movie = db.session.query(Movie).get(movie_id)
        movie_genres = set()

        genres = Genre.query.all()
        if not movie:
            flash("Invalid Movie ID.", "error-message")
        else:
            for genre in movie.genres:
                movie_genres.add(genre.id)

        return render_template("admin/edit-movie.html", 
                               movie=movie, 
                               genres=genres,
                               movie_genres=movie_genres)
    
    if request.method == "POST":
        movie = db.session.query(Movie).get(movie_id)

        if not movie:
            flash("Invalid Movie ID.", "error-message")
            return redirect(f"/admin/movie/{movie_id}")
        
        title = request.form.get("name")
        rating = request.form.get("rating", type=int)
        poster = request.files.get("poster", None)
        option = request.form.get("option")
        movie_genres = request.form.getlist("genres", type=int)


        if not title:
            flash("Invalid name for the movie", "error-message")
            return redirect(f"/admin/movie/{movie_id}")
        
        if not rating or not 0 <= rating <= 10:
            flash("Invalid rating for the movie", "error-message")
            return redirect(f"/admin/movie/{movie_id}")
        
        genres = Genre.query.filter(Genre.id.in_(movie_genres)).all()
        if len(genres) != len(movie_genres):
            flash("Invalid genre selected for the movie", "error-message")
            return redirect(f"/admin/movie/{movie_id}")
        
        if not option:
            if poster.filename:
                movie.poster = f"{movie.id}-{secure_filename(poster.filename)}"
                poster.save(os.path.join("static/uploads/", movie.poster))
        else:
            movie.poster = None

        movie.name = title
        movie.rating = rating
        genres = MovieGenre.query.filter_by(movie_id=movie_id).all()
        for genre in genres:
            if genre.id not in movie_genres:
                db.session.delete(genre)

        for genre in set(movie_genres):
            found = False
            for each in movie.genres:
                if genre == each.id:
                    found = True
            db.session.add(MovieGenre(movie_id=movie.id, genre_id=genre))

        db.session.commit()
        flash("Updated the movie successfully.", "success-message")
        return redirect(f"/admin/movie/{movie_id}")


@views.route("/admin/movie/<int:movie_id>/delete")
def delete_movie(movie_id):
    movie = db.session.query(Movie).get(movie_id)

    if not movie:
        flash("Invalid Movie ID.", "error-message")
        return redirect("/admin/movie")
    
    genres = MovieGenre.query.filter_by(movie_id=movie_id).all()
    shows = Show.query.filter_by(movie_id=movie_id).all()
    for genre in genres:
        db.session.delete(genre)
    db.session.delete(movie)
    for show in shows:
        db.session.delete(show)
    db.session.commit()
    flash("Updated the movie successfully.", "success-message")
    return redirect("/admin/movie") 


@views.route("/admin/movie/<int:movie_id>/allocate", methods=["GET", "POST"])
def movie_allocate(movie_id):
    movie = db.session.query(Movie).get(movie_id)
    if not movie:
        flash("Invalid Movie ID.", "error-message")
        return redirect("/admin/movie")
    
    if request.method == "GET":

        venues = Venue.query.all()
        return render_template("admin/allocate-movies.html", 
                               venues=venues, 
                               movie=movie)
    
    else:
        venue = request.form.get("venue", type=int)
        startdate = request.form.get("start")
        enddate = request.form.get("end")
        showtime = request.form.get("time")
        capacity = request.form.get("capacity", type=int)
        price = request.form.get("price", type=int)

        if not db.session.query(Venue).get(venue):
            flash("Invalid Venue ID.", "error-message")
            return redirect(f"/admin/movie/{movie_id}/allocate")
        if (not re.match("[0-9]{4}-[0-9]{2}-[0-9]{2}", startdate) or 
            not re.match("[0-9]{4}-[0-9]{2}-[0-9]{2}", enddate)):
            flash("Invalid Date.", "error-message")
            return redirect(f"/admin/movie/{movie_id}/allocate")
        
        if not re.match("[0-9]{2}:[0-9]{2}", showtime):
            flash("Invalid Time.", "error-message")
            return redirect(f"/admin/movie/{movie_id}/allocate")
        
        if not capacity or capacity < 0 or capacity > 200:
            flash("Invalid Capacity.", "error-message")
            return redirect(f"/admin/movie/{movie_id}/allocate")
        
        if not price or price < 0 or price > 1000:
            flash("Invalid price.", "error-message")
            return redirect(f"/admin/movie/{movie_id}/allocate")
        
        startdate = datetime.datetime.strptime(startdate, "%Y-%m-%d")
        enddate = datetime.datetime.strptime(enddate, "%Y-%m-%d")
        showtime = datetime.datetime.strptime(showtime, "%H:%M").time()

        if Show.query.filter(and_(Show.start <= startdate,
                                  Show.end >= startdate,
                                  Show.id==ShowTiming.show_id,
                                  Show.venue_id==venue,
                                  Show.movie_id==movie_id,
                                  ShowTiming.time==showtime)).first():
            flash("Invalid Time.", "error-message")
            return redirect(f"/admin/movie/{movie_id}/allocate")
        
        show = Show.query.filter_by(venue_id=venue, movie_id=movie_id).first()
        if not show:
            show = Show(movie_id=movie_id, 
                        venue_id=venue, 
                        start=startdate,
                        end=enddate, 
                        capacity=capacity, 
                        price=price)
            db.session.add(show)
            db.session.flush()
        db.session.add(ShowTiming(show_id=show.id, time=showtime))
        db.session.commit()
        flash("Updated the movie successfully.", "success-message")
        return redirect(f"/admin/movie/{movie_id}/allocate")
        