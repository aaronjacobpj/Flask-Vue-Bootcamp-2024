from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()

class User(db.Model):
    __tablename__ = "user"

    id = db.Column(db.Integer, primary_key=True, unique=True)
    firstname = db.Column(db.String, nullable=False)
    lastname = db.Column(db.String)
    username = db.Column(db.String, unique=True, nullable=False)
    password = db.Column(db.String, nullable=False)
    roles = db.relationship("Role", secondary="user_roles", lazy=True)


    def is_(self, role):
        found = False
        for each in self.roles:
            if each.role == role:
                found = True
                break
        return found


class Role(db.Model):
    __tablename__ = "role"

    id = db.Column(db.Integer, primary_key=True, unique=True)
    role = db.Column(db.String, unique=True, nullable=False)


class UserRoles(db.Model):
    __tablename__ = "user_roles"

    id = db.Column(db.Integer, primary_key=True, unique=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    role_id = db.Column(db.Integer, db.ForeignKey("role.id"))


class Venue(db.Model):
    __tablename__ = "venue"

    id = db.Column(db.Integer, primary_key=True, unique=True)
    name = db.Column(db.String, nullable=False)
    place = db.Column(db.String, nullable=False)



class Movie(db.Model):
    __tablename__ = "movie"

    id = db.Column(db.Integer, primary_key=True, unique=True)
    name = db.Column(db.String, nullable=False)
    rating = db.Column(db.Integer, nullable=False)
    poster = db.Column(db.String())
    genres = db.relationship("Genre", secondary="movie_genre")
    shows = db.relationship("Show", backref="movie")

    def genre_in(self, genre):
        found = False
        for each in self.genres:
            if each.type == genre:
                found = True
                break
        return found



class Genre(db.Model):
    __tablename__ = "genre"

    id = db.Column(db.Integer, primary_key=True, unique=True)
    type = db.Column(db.String, unique=True, nullable=False)


class MovieGenre(db.Model):
    __tablename__ = "movie_genre"

    id = db.Column(db.Integer, primary_key=True, unique=True)
    movie_id = db.Column(db.Integer, db.ForeignKey("movie.id"))
    genre_id = db.Column(db.Integer, db.ForeignKey("genre.id"))


class Show(db.Model):
    __tablename__ = "show"

    id = db.Column(db.Integer, primary_key=True)
    movie_id = db.Column(db.Integer, db.ForeignKey("movie.id"))
    venue_id = db.Column(db.Integer, db.ForeignKey("venue.id"))
    capacity = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Integer, nullable=False)
    start = db.Column(db.Date, nullable=False)
    end = db.Column(db.Date, nullable=False)
    timing = db.relationship("ShowTiming")
    venue = db.relationship("Venue", uselist=False, backref="shows")



class ShowTiming(db.Model):
    __tablename__ = "show_timing"

    id = db.Column(db.Integer, primary_key=True, unique=True)
    show_id = db.Column(db.Integer, db.ForeignKey("show.id"))
    time = db.Column(db.Time, nullable=False)
    tickets = db.relationship("Tickets")

    def total_tickets(self):
        result = 0
        for ticket in self.tickets:
            result += ticket.tickets
        return result


class Tickets(db.Model):
    __tablename__ = "tickets"

    id = db.Column(db.Integer, primary_key=True, unique=True)
    show_time_id = db.Column(db.Integer, db.ForeignKey("show_timing.id"))
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    tickets = db.Column(db.Integer, nullable=False)

