from .conftest import app, client, admin



def test_valid_admin(app, admin):
    assert admin.username == "grace"

