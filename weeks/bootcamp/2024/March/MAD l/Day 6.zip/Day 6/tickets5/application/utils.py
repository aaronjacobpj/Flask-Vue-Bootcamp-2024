from functools import wraps
from flask import redirect, url_for, request, session
from sqlalchemy import and_, or_

from application.models import db, Movie, MovieGenre, Venue

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user-id" not in session:
            return redirect("/login")
        return f(*args, **kwargs)
    return decorated_function


def get_venues():
    search = request.args.get("name")
    option = request.args.get("filter")

    if option == "Name":
        venues = Venue.query.filter(Venue.name.like(f"%{search}%")).all()
    elif option == "Place":
        venues = Venue.query.filter(Venue.place.like(f"%{search}%")).all()
    else:
        venues = Venue.query.all()

    return venues

def search_movies():
    search = request.args.get("name")
    rating = request.args.get("rating", type=int)
    genre = request.args.getlist("genre")

    if search and rating:
        movies = db.session.query(Movie).filter(or_(Movie.name.like(f"%{search}%"),
                                Movie.rating >= rating,
                                and_(Movie.id==MovieGenre.movie_id,
                                MovieGenre.genre_id.in_(genre)))).all()
    elif not search and rating:
        movies = db.session.query(Movie).filter(or_(Movie.rating >= rating,
                                and_(Movie.id==MovieGenre.movie_id,
                                MovieGenre.genre_id.in_(genre)))).all()
    elif search and not rating:
        movies = db.session.query(Movie).filter(or_(Movie.name.like(f"%{search}%"),
                                        and_(Movie.id==MovieGenre.movie_id,
                                        MovieGenre.genre_id.in_(genre)))).all()
    else:
        movies = db.session.query(Movie).filter(or_(Movie.name.like(f"%_%"),
                                and_(Movie.id==MovieGenre.movie_id,
                                MovieGenre.genre_id.in_(genre)))).all()
        
    return movies