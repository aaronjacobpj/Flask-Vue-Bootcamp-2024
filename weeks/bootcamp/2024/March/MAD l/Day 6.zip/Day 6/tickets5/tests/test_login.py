from .conftest import app, client, db, admin


def test_login_page(app, client):
    response = client.get("/login")
    assert "Sign in" in response.text
    assert '<form action="/login" method="post">' in response.text


def test_valid_login(app, client, admin):
    response = client.post("/login", data={"username": admin.username, 
                                "password": "grace"},
                                follow_redirects=True)
    assert response.status_code == 200
    assert "Create" in response.text