import { greet } from "./Greet.js";
import { home } from "./Hello.js";
import { router } from './router.js'


const app = Vue.createApp({
    template: `
    <router-link v-bind:to="'/greet/'+this.name"> Click to Greet </router-link>
    {{ name }} 
    <input type="text" v-model="name">
    <router-view></router-view>`,
    data(){
        return {
            name: "",
        }
    }

});



app.component('greet', greet);
app.component('home', home);


app.use(router);

app.mount("#app");
