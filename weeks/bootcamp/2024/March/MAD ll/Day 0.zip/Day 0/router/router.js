import { greet } from "./Greet.js";
import { home } from "./Hello.js";

const routes = [{path:"/", name:"home", component:home},
                {path:"/greet/:user", name:"greet", component:greet}
            ]

export const router = VueRouter.createRouter({
    // 4. Provide the history implementation to use. We are using the hash history for simplicity here.
    history: VueRouter.createWebHashHistory(),
    routes, // short for `routes: routes`
    })
