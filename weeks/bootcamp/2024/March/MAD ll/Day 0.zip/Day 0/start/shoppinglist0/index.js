const List = {
  template:`
  <h3>{{ title }}</h3>
  <ul class="list-group">
    <li class="list-group-item" v-for="(item, index) in items">
      {{ index }}). {{ item }}
    </li>
  </ul>
  `,
  props: ['items', "title"]
}

const app = Vue.createApp({
  template:`
    <List v-bind:items="items" v-bind:title="'Shopping List'"/>
    <input type="text" v-model="item"/>
    <input type="button" @click="add_to_list" value="Add to list"/>
  `,
  data(){
    return {
      items: [],
      item: null
    }
  },
  created(){
    console.log(this.items);
  },
  methods:{
    add_to_list(){
      this.items.push(this.item)
      this.item = null;
    }
  }
})
app.component("List", List);
app.mount("#app");
