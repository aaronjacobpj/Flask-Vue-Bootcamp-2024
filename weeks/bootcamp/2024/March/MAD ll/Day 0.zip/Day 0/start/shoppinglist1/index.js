const List = {
  template:`
  <h3>{{ title }}</h3>
  <ul class="list-group">
    <li class="list-group-item" v-for="(item, index) in items">
      {{ index }}). {{ item }}
      <a href="#" @click="this.$emit('delete_item', index)"> delete </a>
    </li>
  </ul>
  `,
  props: ['items', "title"],
  emits: ["delete_item"],
}

const app = Vue.createApp({
  template:`
    <List v-bind:title="'Shopping List'" v-bind:items="items" @delete_item="remove_item"/>
    <input type="text" v-model="item"/>
    <input type="button" @click="add_to_list" value="Add to list"/>
  `,
  data(){
    return {
      items: [],
      item: null,
      components: []
    }
  },
  created(){

  },
  methods:{
    add_to_list(){
      this.items.push(this.item)
      this.item = null;
    },
    remove_item(i){
      this.items = this.items.filter((item, index)=> index != i)
    }
  }
})
app.component("List", List);
app.mount("#app");
