<script setup>
import CommonNavbar from "@/components/CommonNavbar.vue";
import store from "@/store";
</script>
<template>
    <CommonNavbar/>
    <div class="container-fluid section-container">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title" align="center">Sign up</h4>
                <form @submit="signup">
                    <div class="row">
                        <div class="col">
                            <input type="email" class="form-control" placeholder="Email" 
                            aria-label="Email" v-model="email">
                            <div class="invalid-feedback" 
                                :style="{display: (error['email'])? 'block': 'none'}">
                                {{ error["email" ]}}
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <input type="password" class="form-control" placeholder="Password" 
                                aria-label="Password" v-model="password">
                            <div class="invalid-feedback" 
                                :style="{display: (error['password'])? 'block': 'none'}">
                                {{ error["password" ]}}
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <input type="submit" class="btn btn-primary" 
                            aria-label="Last name" value="Sign in">
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                password: null,
                email: "",
                error: {
                    password: null,
                    email: null,
                }
            }
        },
        methods: {
            validate() {
                let error = false;
                this.error = {
                    email: null,
                    password: null,
                }
                if(!this.email.match(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/)){
                    error = true;
                    this.error["email"] = "Invalid email."
                }
                return error;
            },
            signup(event) {
                event.preventDefault();
                if(!this.validate())
                    fetch(store.getters.BASEURL+"/signin", {
                                        method: "POST",
                                        headers:{
                                            "Content-Type": "application/json"
                                        },
                                        body:JSON.stringify({
                                            email: this.email,
                                            password: this.password
                                        })
                                    }).then(response =>{ 
                                        return [response.json(), response.status];
                                    }).then(data =>{
                                        if(data[1] == 404){
                                            let error = data[0]["error"]
                                            this.error["email"] = "Invalid email or password."
                                        }
                                        else if(data[1] == 200){
                                           return data[0];

                                        }
                                    }).then(data =>{
                                        console.log(data)
                                        store.commit("setToken", data)
                                    })
            }
        }
    }
</script>
<style scoped>
    .section-container {
        height: 90vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .row {
        margin-top: 20px;
    }

    .btn {
        width: 100%;
    }
</style>