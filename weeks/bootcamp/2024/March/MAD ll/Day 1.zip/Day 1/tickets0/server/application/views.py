import re

from .models import db

from flask import Blueprint, request
from flask import current_app as app
from werkzeug.security import generate_password_hash, check_password_hash
from flask_security import login_user

view = Blueprint("view", __name__)


@view.route("/signup", methods=["POST"])
def index():
    firstname = request.json.get("firstname")
    lastname = request.json.get("lastname")
    email = request.json.get("email", "")
    password = request.json.get("password")
    confirm = request.json.get("confirm")

    if not firstname:
        return {"error": "invalid-firstname"}, 400
    if not re.match("^.+@.+.+$", email):
        return {"error": "invalid-email"}, 400
    elif app.security.datastore.find_user(email=email):
        return {"error": "duplicate email"}, 400
    if password != confirm:
        return {"error": "invalid-password"}, 400
    
    user = app.security.datastore.create_user(firstname=firstname,
                           lastname=lastname,
                           email=email,
                           password=generate_password_hash(password))
    role = app.security.datastore.find_role("user")
    app.security.datastore.add_role_to_user(user, role)
    db.session.commit()
    return {"message": "Created user successfully"}, 201


@view.route("/signin", methods=["POST"])
def signin():
    email = request.json.get("email", "")
    password = request.json.get("password")

    user = app.security.datastore.find_user(email=email)
    if not user or not check_password_hash(user.password, password):
        return {"error": "user not found."}, 404
    
    login_user(user)
    token = user.get_auth_token()
    return {"token": token}