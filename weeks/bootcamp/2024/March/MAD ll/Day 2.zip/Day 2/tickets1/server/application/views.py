import re

from .models import db, Venue

from flask import Blueprint, request
from flask import current_app as app
from werkzeug.security import generate_password_hash, check_password_hash
from flask_security import login_user, auth_required

view = Blueprint("view", __name__)


@view.route("/signup", methods=["POST"])
def index():
    firstname = request.json.get("firstname")
    lastname = request.json.get("lastname")
    email = request.json.get("email", "")
    password = request.json.get("password")
    confirm = request.json.get("confirm")

    if not firstname:
        return {"error": "invalid-firstname"}, 400
    if not re.match("^.+@.+.+$", email):
        return {"error": "invalid-email"}, 400
    elif app.security.datastore.find_user(email=email):
        return {"error": "duplicate email"}, 400
    if password != confirm:
        return {"error": "invalid-password"}, 400
    
    user = app.security.datastore.create_user(firstname=firstname,
                           lastname=lastname,
                           email=email,
                           password=generate_password_hash(password))
    role = app.security.datastore.find_role("user")
    app.security.datastore.add_role_to_user(user, role)
    db.session.commit()
    return {"message": "Created user successfully"}, 201


@view.route("/signin", methods=["POST"])
def signin():
    email = request.json.get("email", "")
    password = request.json.get("password")

    user = app.security.datastore.find_user(email=email)
    if not user or not check_password_hash(user.password, password):
        return {"error": "user not found."}, 404
    
    login_user(user)
    token = user.get_auth_token()
    roles = [role.name for role in user.roles]
    return {"token": token, "roles": roles}


@view.route("/venue/create", methods=["POST"])
@auth_required("token")
def create_venue():
    name = request.json.get("name", "")
    place = request.json.get("place")

    if not name:
        return {"error": "Invalid name"}, 400
    if not place:
        return {"error": "Invalid place"}, 400
    
    venue = Venue(name=name, place=place)
    db.session.add(venue)
    db.session.commit()
    return {"message": "Created venue successfully."}, 201


@view.route("/venue/search", methods=["POST"])
@auth_required("token")
def search_venue():
    search = request.json.get("search", "")
    option = request.json.get("option")

    if option == "Place":
        venues = Venue.query.filter(Venue.place.like(f"%{search}%")).all()
    elif option == "Name":
        venues = Venue.query.filter(Venue.name.like(f"%{search}%")).all()
    elif option not in ["Place", "Name"]:
        return {"error": "Invalid filter."}, 400
    
    return [{"id": venue.id, 
             "name": venue.name, 
             "place": venue.place} for venue in venues]


@view.route("/venue/<int:venue_id>/edit", methods=["POST"])
@auth_required("token")
def update_venue(venue_id):
    name = request.json.get("name", "")
    place = request.json.get("place")

    if not name:
        return {"error": "Invalid name"}, 400
    if not place:
        return {"error": "Invalid place"}, 400
    
    venue = db.session.query(Venue).get(venue_id)
    
    if not venue:
        return {"error": "Venue not found."}, 404
    
    venue.name = name
    venue.place = place
    db.session.commit()
    return {"message": "Updated venue successfully."}, 200