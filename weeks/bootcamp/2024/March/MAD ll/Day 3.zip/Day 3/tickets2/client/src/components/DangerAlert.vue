<template>
    <div class="alert alert-danger alert-dismissible fade show" role="alert" v-if="!dismiss && message">
        {{ message }}
        <button type="button" @click="dismiss=false"class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
</template>
<script>
    export default{
        props: ["message"],
        data(){
           return  {
                dismiss: false
            }        
        }
    }
</script>