import { createStore } from "vuex";

export default createStore({
    state(){
        return{
            BASEURL: "http://127.0.0.1:5000",
            venues: [],
            genres: [],
            user: {
                roles: [],
                token: null,
            }
        }
    },
    getters:{
        BASEURL(state){
            return state.BASEURL;
        },
        getToken(state){
            return state.user["token"];
        },
        getRoles(state){
            return state.user["roles"];
        },
        getVenues(state){
            return state.venues;
        },
        getGenres(state){
            return state.genres;
        }
    },
    mutations: {
        setToken(state, value){
            state.user = value;
            sessionStorage.setItem("user", 
                JSON.stringify(value));
        },
        setVenues(state, venues){
            state.venues = venues;
        },
        setGenres(state, value){
            state.genres = value;
        }
    },
    actions: {
        getVenues({commit, state}, {search, option}){
            fetch(state.BASEURL+"/venue/search", {
                method: "POST",
                headers:{
                    "Content-Type": "application/json",
                    "Authentication-Token": state.user["token"]
                },
                body:JSON.stringify({
                    search: search,
                    option: option
                })
            }).then(response =>{
                if(response.status == 200)
                    return response.json();
                return [];
            }).then(data =>{
                commit("setVenues", data);
            })
        },
        getGenres({commit, state}){
            fetch(state.BASEURL+"/genre", {
            }).then(response =>{
                if(response.status == 200)
                    return response.json();
                return [];
            }).then(data =>{
                commit("setGenres", data);
            })
        }
    }
});
