import re
import os

from .models import db, Venue, Genre, Movie, MovieGenre

from flask import Blueprint, request
from flask import current_app as app
from werkzeug.security import generate_password_hash, check_password_hash
from flask_security import login_user, auth_required, roles_required
from werkzeug.utils import secure_filename
from sqlalchemy import and_, or_

view = Blueprint("view", __name__)


@view.route("/signup", methods=["POST"])
def index():
    firstname = request.json.get("firstname")
    lastname = request.json.get("lastname")
    email = request.json.get("email", "")
    password = request.json.get("password")
    confirm = request.json.get("confirm")

    if not firstname:
        return {"error": "invalid-firstname"}, 400
    if not re.match("^.+@.+.+$", email):
        return {"error": "invalid-email"}, 400
    elif app.security.datastore.find_user(email=email):
        return {"error": "duplicate email"}, 400
    if password != confirm:
        return {"error": "invalid-password"}, 400
    
    user = app.security.datastore.create_user(firstname=firstname,
                           lastname=lastname,
                           email=email,
                           password=generate_password_hash(password))
    role = app.security.datastore.find_role("user")
    app.security.datastore.add_role_to_user(user, role)
    db.session.commit()
    return {"message": "Created user successfully"}, 201


@view.route("/signin", methods=["POST"])
def signin():
    email = request.json.get("email", "")
    password = request.json.get("password")

    user = app.security.datastore.find_user(email=email)
    if not user or not check_password_hash(user.password, password):
        return {"error": "user not found."}, 404
    
    login_user(user)
    token = user.get_auth_token()
    roles = [role.name for role in user.roles]
    return {"token": token, "roles": roles}


@view.route("/venue/create", methods=["POST"])
@auth_required("token")
@roles_required("admin")
def create_venue():
    name = request.json.get("name", "")
    place = request.json.get("place")

    if not name:
        return {"error": "Invalid name"}, 400
    if not place:
        return {"error": "Invalid place"}, 400
    
    venue = Venue(name=name, place=place)
    db.session.add(venue)
    db.session.commit()
    return {"message": "Created venue successfully."}, 201


@view.route("/venue/search", methods=["POST"])
@auth_required("token")
@roles_required("admin")
def search_venue():
    search = request.json.get("search", "")
    option = request.json.get("option")

    if option == "Place":
        venues = Venue.query.filter(Venue.place.like(f"%{search}%")).all()
    elif option == "Name":
        venues = Venue.query.filter(Venue.name.like(f"%{search}%")).all()
    elif option not in ["Place", "Name"]:
        return {"error": "Invalid filter."}, 400
    
    return [{"id": venue.id, 
             "name": venue.name, 
             "place": venue.place} for venue in venues]


@view.route("/venue/<int:venue_id>/edit", methods=["POST"])
@auth_required("token")
@roles_required("admin")
def update_venue(venue_id):
    name = request.json.get("name", "")
    place = request.json.get("place")

    if not name:
        return {"error": "Invalid name"}, 400
    if not place:
        return {"error": "Invalid place"}, 400
    
    venue = db.session.query(Venue).get(venue_id)
    
    if not venue:
        return {"error": "Venue not found."}, 404
    
    venue.name = name
    venue.place = place
    db.session.commit()
    return {"message": "Updated venue successfully."}, 200


@view.route("/venue/<int:venue_id>", methods=["DELETE"])
@auth_required("token")
@roles_required("admin")
def delete_venue(venue_id):
    venue = db.session.query(Venue).get(venue_id)

    if not venue:
        return {"error": "Venue not Found"}, 404
    
    db.session.delete(venue)
    db.session.commit()
    return {"message": "Deleted venue successfully."}, 200


@view.route("/genre")
def get_genres():
    genres = Genre.query.all()
    result = []
    for genre in genres:
        result.append(genre.dict())

    return result

@view.route("/movie/create", methods=["POST"])
@auth_required("token")
@roles_required("admin")
def create_movie():
    title = request.form.get("name", None)
    rating = request.form.get("rating", type=int)
    movie_genres = request.form.getlist("genre", type=int)
    poster = request.files.get("poster")
   
    if not title:
        return {"error": "Invalid title"}, 400
    elif not rating:
        return {"error": "Invalid rating"}, 400
    
    genres = Genre.query.filter(Genre.id.in_(movie_genres)).all()

    if len(movie_genres) != len(genres):
        return {"error": "Invalid genres"}, 400
    
    print(genres)
    movie = Movie(title=title, rating=rating)
    db.session.add(movie)
    db.session.flush()

    for genre in genres:
        db.session.add(MovieGenre(movie_id=movie.id, genre_id=genre.id))

    movie.poster = f"{movie.id}-{secure_filename(poster.filename)}"
    poster.save(os.path.join("static/uploads", movie.poster))

    db.session.commit()
    
    return {"message": "Created movie successfully"}, 201


@view.route("/movie")
@auth_required("token")
def get_movies():
    title = request.args.get("title", None)
    rating = request.args.get("rating", type=int)
    genre = request.args.getlist("genre", type=int)

    movies = []
    if not title and not rating and not genre:
        movies = Movie.query.all()
    elif title and not rating and not genre:
        movies = Movie.query.filter(Movie.title.like(f"%{title}%")).all()
    elif title and rating and not genre:
        movies = Movie.query.filter(and_(Movie.title.like(f"%{title}%"),
                                         Movie.rating >= rating)).all()
    elif title and not rating and genre:
        movies = Movie.query.filter(and_(Movie.title.like(f"%{title}%"),
                                    MovieGenre.movie_id==Movie.id,
                                    MovieGenre.genre_id.in_(genre))).all()
    elif not title and rating and genre:
        movies = Movie.query.filter(and_(Movie.rating >= rating,
                            MovieGenre.movie_id==Movie.id,
                            MovieGenre.genre_id.in_(genre))).all()
    elif not title and not rating and genre:
        movies = Movie.query.filter(and_(Movie.id==MovieGenre.movie_id,
                    MovieGenre.genre_id.in_(genre))).all()
    elif not title and rating and not genre:
        movies = Movie.query.filter(Movie.rating >= rating).all()
    elif title and rating and genre:
        movies = Movie.query.filter(and_(Movie.title.like(f"%{title}%"),
                            Movie.rating >= rating,
                            MovieGenre.movie_id==Movie.id,
                            MovieGenre.genre_id.in_(genre))).all()
        
    result = []
    for movie in movies:
        result.append(movie.dict())

    return result
                                    