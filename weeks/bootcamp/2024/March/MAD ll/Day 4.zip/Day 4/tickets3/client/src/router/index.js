import { createRouter, createWebHistory } from 'vue-router';
import store from '@/store';

import LoginView from '../views/LoginView.vue';
import RegisterView from "@/views/RegisterView.vue";
import LayoutView from "@/views/LayoutView.vue";
import AdminLayoutView from "@/views/admin/AdminLayoutView.vue";
import VenueCreateView from "@/views/admin/VenueCreateView.vue";
import VenueSearchView from "@/views/admin/VenueSearchView.vue";
import VenueEditView from "@/views/admin/VenueEditView.vue";
import MovieCreateView from "@/views/admin/MovieCreateView.vue";
import MovieSearchView from "@/views/admin/MovieSearchView.vue";
import MovieEditView from "@/views/admin/MovieEditView.vue";
import MovieAllocateView from "@/views/admin/MovieAllocateView.vue";


const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/login',
      name: 'login',
      component: LoginView
    }, 
    {
      path: "/signup",
      name: "signup",
      component: RegisterView
    },
    {
      path: "/",
      name: "home",
      component: LayoutView
    },
    {
      path: "/admin", 
      name: "admin-index",
      component: AdminLayoutView,
      children: [
        {
          path: "venue/create",
          name: "venue-create",
          component: VenueCreateView
        },
        {
          path: "venue/search",
          name: "venue-search",
          component: VenueSearchView
        },
        {
          path: "venue/:id/edit",
          name: "venue-edit",
          component: VenueEditView,
          props: true
        },
        {
          path: "movie/create",
          name: "movie-create",
          component: MovieCreateView
        },
        {
          path: "movie/search",
          name: "movie-search",
          component: MovieSearchView
        },
        {
          path: "movie/:id/edit",
          name: "movie-edit",
          component: MovieEditView,
          props: true
        },
        {
          path: "movie/:id/allocate",
          name: "movie-allocate",
          component: MovieAllocateView,
          props: true
        }
      ]
    }
  ]
})


router.beforeEach((to, from) =>{
  if(to.path == "/" && !store.getters.getToken){
    return {name: "login"}
  }
  if(to.path.match("/admin*") && !store.getters.getToken && !store.getters.getRoles.includes("admin")){
    return {name: "login"}
  }

})

export default router;
