<script setup>
    import InputError from "@/components/InputError.vue";
    import SuccessAlert from "@/components/SuccessAlert.vue"
    import store from "@/store";
</script>
<template>
    <SuccessAlert :message="message"/>
    <div class="row create-venue-section">
        <div class="row">
            <div class="col" style="display: flex; align-items: center;">
                <div class="card" >
                    <img :src="image" v-if="image" style="height: 90% !important;" class="card-img-top" alt="...">
                </div>
            </div>
            <div class="col" style="min-width: 75%;">
                <div class="card create-venue-section">
                    <div class="card-body">
                        <form @submit="createVenue">
                            <div class="row">
                                <div class="col">
                                    <div class="mb-3">
                                        <label for="MovieTitleInput" class="form-label">Title</label>
                                        <input type="text" class="form-control" id="MovieTitleInput" v-model="name"
                                            placeholder="Movie Title">
                                        <InputError :value="error['name']"/>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="mb-3">
                                        <label for="RatingInput" class="form-label">Rating</label>
                                        <input type="number" class="form-control" id="RatingInput" v-model="rating"
                                            placeholder="Venue Place">
                                            <InputError :value="error['rating']"/>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="display: flex; align-items: center;">
                                <div class="col">
                                    <div class="mb-3">
                                        <label for="VenueNameInput" class="form-label">Genres</label>
                                        <select class="form-select" multiple v-model="movieGenres">
                                            <option v-for="genre in genres" :value="genre.id">{{ genre["type"] }}</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="mb-3">
                                        <label for="formFile" class="form-label">Movie Poster</label>
                                        <input class="form-control" @change="getPoster" type="file" id="formFile">
                                    </div>
                                </div>
                            </div>                            
                            <div class="mb-3" style="display: flex; justify-content: center;">
                                <input type="submit" class="btn btn-primary" value="Create" style="width: 25%;">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default{
        data(){
            return {
                name: null,
                rating: null,
                poster: null,
                movieGenres: [],
                image: null,
                error: {
                    name: null,
                    rating: null,
                    genre: null,
                },
                message: null
            }
        },
        created(){
            store.dispatch("getGenres")
        },
        methods:{
            getPoster(event){
                this.poster = event.target.files[0];
                this.readImage();
            },
            readImage(){
                const reader = new FileReader();
                reader.addEventListener('load', (event) => {
                    this.image = event.target.result;
                });
                reader.readAsDataURL(this.poster);
            },
            validate(){
                let error = false;
                this.error = {
                    name: null,
                }
                if(!this.name){
                    error = true;
                    this.error["name"] = "Invalid title."
                }
                if(!this.rating){
                    error=true;
                    this.error["rating"] = "Invalid rating"
                }
                return error;
            },
            createVenue(event){
                event.preventDefault();
                if(!this.validate()){
                    let form = new FormData();
                    form.append("name", this.name);
                    form.append("rating", this.rating);
                    this.movieGenres.forEach(x=> form.append("genre", x));
                    form.append("poster", this.poster);

                    fetch(store.getters.BASEURL+"/movie/create", {
                        method: "POST",
                        headers:{
                            "Authentication-Token": store.getters.getToken
                        },
                        body:form
                    }).then(response =>{
                        return response.json()
                    }).then(data =>{
                        if(Object.keys(data).includes("error")){
                            let error = data["error"];
                            if(error == "Invalid title"){
                                this.error["name"] = "Invalid title."
                            }
                            else if(error == "Invalid rating"){
                                this.error["rating"] = "Invalid rating."
                            }
                            else if(error == "Invalid genres"){
                                this.error["genre"] = "Invalid genres."
                            }
                        }else{
                            this.message = "Created movie succesfully."
                        }
                    })
                }

            }
        },
        computed:{
            genres(){
                return store.getters.getGenres;
            }
        }
    }
</script>
<style scoped>
    .create-venue-section{
        margin: 20px;
    }
</style>
