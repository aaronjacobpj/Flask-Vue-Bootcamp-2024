<script setup>
    import { RouterLink } from "vue-router";
    import InputError from "@/components/InputError.vue";
    import SuccessAlert from "@/components/SuccessAlert.vue"
    import DangerAlert from "@/components/DangerAlert.vue";
    import store from "@/store";    
</script>
<template>
    <SuccessAlert :message="deleteSuccess"/>
    <DangerAlert :message="error['deleteFaliure']"/>
    <form @submit="searchMovies">
        <div class="row" style="margin: 20px;">
            <div class="col" style="min-width: 40%;">
                <input type="text" class="form-control" placeholder="Search" v-model="search" aria-label="Search">
                <InputError :value="error['search']"/>
            </div>
            <div class="col" style="min-width: 20%;">
                <select class="form-select" v-model="rating">
                    <option selected disabled>Rating</option>
                    <option v-for="i in 10">{{ i }}</option>
                </select>
                <InputError :value="error['search']"/>
            </div>
            <div class="col" style="min-width: 20%;">
                <select class="form-select" aria-label="Filter" v-model="genre" multiple>
                    <option selected disabled>Genres</option>
                    <option v-for="genre in genres" :value="genre.id">{{ genre["type"] }}</option>
                </select>
                </div>
            <div class="col">
                <input type="submit" style="width: 100%;" class="btn btn-success" value="Search">
            </div>
        </div>
        <div class="card" v-for="movie in movies" style="margin: 15px;">
            <div class="card-body" style="display: flex; align-items: center;">
                <div class="row" style="width: 100%; display: flex; align-items: center;">
                    <div class="col" style="max-width: max-content;">
                        <img :src="posterUrl(movie.poster)" class="img-thumbnail" 
                            style="height: 150px; width: 120px;">
                    </div>
                    <div class="col" style="min-width: 60%;">
                        <div>
                            <h5 class="card-title">{{ movie.title }}</h5>
                            <h6 class="card-subtitle mb-2 text-body-secondary">Rating: {{ movie.rating }}</h6>
                            <span class="badge text-bg-info" v-for="genre in movie.genres"
                                style="margin-right: 10px;">
                                {{ genre["type"] }}
                            </span>
                        </div>
                    </div>
                    <div class="col">
                        <router-link class="btn btn-warning" 
                            :to="{name: 'movie-edit', params: {id: movie.id}, query:{name: movie.title, 
                                genre: Object.values(movie.genres).map(x => x['id']), rating: movie.rating, poster:movie.poster}}">
                                Edit
                        </router-link>
                        <router-link class="btn btn-success" style="margin-left:15px"
                            :to="{name: 'movie-allocate', params: {id: movie.id}}">
                                Allocate
                        </router-link>
                        <input type="button" class="btn btn-danger" style="margin-left:15px"
                        @click="deleteMovie(movie.id)"
                            value="Delete">
                    </div>
                </div>
            </div>
        </div>
    </form>
</template>
<script>
    export default{
        data(){
            return{
                search: null,
                rating: "Rating",
                genre: [],
                deleteSuccess: null,
                error: {
                    search: null,
                    deleteFaliure: null,
                }
            }
        },
        created(){
            store.dispatch("getGenres")
            store.dispatch("getMovies", {search: this.search, 
                                            rating: this.rating, 
                                            genre: this.genre});
        },
        methods: {
            searchMovies(event){
                event.preventDefault();
                store.dispatch("getMovies", {search: this.search, 
                                            rating: this.rating, 
                                            genre: this.genre});
            },
            posterUrl(value){
                return `${store.getters.BASEURL}/static/uploads/${value}`
            },
            deleteMovie(movie_id){
                fetch(store.getters.BASEURL+"/admin/movie/"+movie_id, {
                    method: "DELETE",
                    headers:{
                        "Content-Type": "application/json",
                        "Authentication-Token": store.getters.getToken
                    }
                }).then(response =>{
                    if(response.status == 200){
                        this.deleteSuccess = "Deleted movie successfully"
                        store.dispatch("getMovies", {search: this.search, 
                                            rating: this.rating, 
                                            genre: this.genre});
                    }
                    else if(response.status == 404){
                        this.error["deleteFaliure"] = "Movie not found."
                    }
                })
            }
            
        },
        computed: {
            genres(){
                return store.getters.getGenres;
            },
            movies(){
                return store.getters.getMovies
            }
        }
    }
</script>