<script setup>
    import { RouterLink } from "vue-router";
    import InputError from "@/components/InputError.vue";
    import SuccessAlert from "@/components/SuccessAlert.vue"
    import DangerAlert from "@/components/DangerAlert.vue";
    import store from "@/store";    
</script>
<template>
    <SuccessAlert :message="message"/>
    <DangerAlert :message="danger"/>
    <!-- <div class="row" style="padding: 20px;">
        <div class="col">
          <input type="text"  class="form-control" :value="select['id']">
        </div>
        <div class="col">
          <input type="text" class="form-control" placeholder="Venue place" disabled>
        </div>
    </div> -->
    <form @submit="AllocateMovie">
        <div class="row" style="padding: 20px 20px 20px ;">
            <div class="col">
              <select class="form-select" v-model="option">
                <option selected value="null">Venues</option>
                <option v-for="venue in venues" :value="venue.id">{{ venue.name }}</option>
              </select>
            </div>
            <div class="col">
              <input type="time" class="form-control" v-model="time" aria-label="Time">
            </div>
        </div>
        <div class="row" style="padding: 20px 20px 20px ;">
            <div class="col">
            <input type="number" v-model="price" class="form-control" placeholder="Price" aria-label="Time">
            </div>
            <div class="col">
              <input type="number" v-model="capacity" class="form-control" placeholder="Capacity" 
                aria-label="Capacity">
            </div>
        </div>
        <div class="row" style="padding: 20px 20px 20px ;">
            <div class="col">
              <input type="submit" class="btn btn-primary"  style="width: 100%;">
            </div>
        </div>
    </form>
</template>
<script>
    export default{
        props: ["id"],
        data(){
            return {
                option: null,
                time: null,
                price: null,
                capacity: null,
                message: null,
                danger: null
            }
        },
        created(){
            store.dispatch("getVenues", {search:"_", option:"Name"});
        },
        methods:{
            AllocateMovie(event){
                event.preventDefault();
                this.danger = null;
                this.message = null;
                fetch(store.getters.BASEURL+"/movie/"+this.id+"/allocate", {
                    method: "POST",
                    headers:{
                        "Content-Type": "application/json",
                        "Authentication-Token": store.getters.getToken
                    },
                    body:JSON.stringify({
                        option: this.option,
                        time: this.time,
                        price: this.price,
                        capacity: this.capacity
                    })
                }).then(response =>{
                    if(response.status == 200){
                        this.message = "Allocated Venue Succesfully";
                    }
                    else{
                        this.danger = "Something went wrong."
                    }
                })
            }
        },
        watch:{
            option(value){
                this.select = store.getters.getVenues.filter(x => x["id"] == this.option);
            }
        },
        computed:{
            venues()
            {
                return store.getters.getVenues;
            },

        }
    }
</script>
