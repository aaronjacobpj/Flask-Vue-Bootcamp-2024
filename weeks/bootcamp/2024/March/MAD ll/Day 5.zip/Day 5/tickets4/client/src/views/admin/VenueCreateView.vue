<script setup>
    import InputError from "@/components/InputError.vue";
    import SuccessAlert from "@/components/SuccessAlert.vue"
    import store from "@/store";
</script>
<template>
    <SuccessAlert :message="message"/>
    <div class="card create-venue-section">
        <div class="card-body">
            <form @submit="createVenue">
                <div class="mb-3">
                    <label for="VenueNameInput" class="form-label">Venue Name</label>
                    <input type="text" class="form-control" id="VenueNameInput" v-model="name"
                        placeholder="Venue Name">
                    <InputError :value="error['name']"/>
                </div>
                <div class="mb-3">
                    <label for="VenuePlaceInput" class="form-label">Venue Place</label>
                    <input type="text" class="form-control" id="VenuePlaceInput" v-model="place"
                        placeholder="Venue Place">
                        <InputError :value="error['place']"/>
                </div>
                <div class="mb-3" style="display: flex; justify-content: center;">
                    <input type="submit" class="btn btn-primary" value="Create" style="width: 25%;">
                </div>
            </form>
        </div>
    </div>
</template>
<script>
    export default{
        data(){
            return {
                name: null,
                place: null,
                error: {
                    name: null,
                    place: null
                },
                message: null
            }
        },
        methods:{
            validate(){
                let error = false;
                this.error = {
                    name: null,
                    place: null
                }
                if(!this.name){
                    error = true;
                    this.error["name"] = "Invalid name."
                }
                if(!this.place){
                    error = true;
                    this.error["place"] = "Invalid place."
                }
                return error;
            },
            createVenue(event){
                event.preventDefault();
                if(!this.validate()){
                    fetch(store.getters.BASEURL+"/venue/create", {
                                        method: "POST",
                                        headers:{
                                            "Content-Type": "application/json",
                                            "Authentication-Token": store.getters.getToken
                                        },
                                        body:JSON.stringify({
                                            name: this.name,
                                            place: this.place
                                        })
                                    }).then(response =>{
                                        return response.json();
                                    }).then(response =>{
                                        if(Object.keys(response).includes("error")){
                                            let error = response["error"]
                                            if(error == "Invalid name"){
                                                this.error["name"] = "Invalid name.";
                                            }
                                            else{
                                                this.error["place"] = "Invalid place.";
                                            }
                                        }
                                        else if(Object.keys(response).includes("message")){
                                            this.message = "Created Venue succcessfully."
                                        }
                                    })
                }

            }
        }
    }
</script>
<style scoped>
    .create-venue-section{
        margin: 20px;
    }
</style>
