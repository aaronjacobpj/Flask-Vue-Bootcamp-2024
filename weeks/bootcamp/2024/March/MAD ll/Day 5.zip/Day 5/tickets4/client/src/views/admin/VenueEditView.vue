<script setup>
    import InputError from "@/components/InputError.vue";
    import SuccessAlert from "@/components/SuccessAlert.vue";
    import DangerAlert from "@/components/DangerAlert.vue"
    import store from "@/store";
    import router from "@/router";
</script>
<template>
    <SuccessAlert :message="message"/>
    <DangerAlert :message="error['invalid_id']"></DangerAlert>
    <div class="card create-venue-section">
        <div class="card-body">
            <form @submit="updateVenue">
                <div class="mb-3">
                    <label for="VenueNameInput" class="form-label">Venue Name</label>
                    <input type="text" class="form-control" id="VenueNameInput" v-model="name"
                        placeholder="Venue Name">
                    <InputError :value="error['name']"/>
                </div>
                <div class="mb-3">
                    <label for="VenuePlaceInput" class="form-label">Venue Place</label>
                    <input type="text" class="form-control" id="VenuePlaceInput" v-model="place"
                        placeholder="Venue Place">
                        <InputError :value="error['place']"/>
                </div>
                <div class="mb-3" style="display: flex; justify-content: center;">
                    <input type="submit" class="btn btn-primary" value="Update" style="width: 25%;">
                </div>
            </form>
        </div>
    </div>
</template>
<script>
    export default{
        props: ["id"],
        data(){
            return {
                name: null,
                place: null,
                error: {
                    name: null,
                    place: null,
                    invalid_id: null,
                },
                message: null
            }
        },
        created(){
            this.name = this.$route.query.name;
            this.place = this.$route.query.place;
        },
        methods:{
            validate(){
                let error = false;
                this.error = {
                    name: null,
                    place: null,
                    invalid_id: null,
                }
                if(!this.name){
                    error = true;
                    this.error["name"] = "Invalid name."
                }
                if(!this.place){
                    error = true;
                    this.error["place"] = "Invalid place."
                }
                return error;
            },
            updateVenue(event){
                event.preventDefault();
                if(!this.validate()){
                    fetch(store.getters.BASEURL+"/venue/"+this.id+"/edit", {
                                        method: "POST",
                                        headers:{
                                            "Content-Type": "application/json",
                                            "Authentication-Token": store.getters.getToken
                                        },
                                        body:JSON.stringify({
                                            name: this.name,
                                            place: this.place
                                        })
                                    }).then(response =>{
                                        return response.json();
                                    }).then(response =>{
                                        if(Object.keys(response).includes("error")){
                                            let error = response["error"]
                                            if(error == "Invalid name"){
                                                this.error["name"] = "Invalid name.";
                                            }
                                            else if(error == "Venue not found."){
                                                this.error["invalid_id"] = "Invalid Venue id."
                                            }
                                            else{
                                                this.error["place"] = "Invalid place.";
                                            }
                                        }
                                        else if(Object.keys(response).includes("message")){
                                            this.message = "Created Venue succcessfully."
                                        }
                                    })
                }

            }
        }
    }
</script>
<style scoped>
    .create-venue-section{
        margin: 20px;
    }
</style>
