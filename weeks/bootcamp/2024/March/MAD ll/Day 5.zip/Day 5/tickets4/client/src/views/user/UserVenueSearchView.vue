<script setup>
    import InputError from "@/components/InputError.vue";
    import SuccessAlert from "@/components/SuccessAlert.vue"
    import DangerAlert from "@/components/DangerAlert.vue";
    import store from "@/store";
</script>
<template>
    <SuccessAlert :message="deleteSuccess"/>
    <DangerAlert :message="error['deleteFaliure']"/>
    <form @submit="searchVenue">
        <div class="row" style="margin: 20px;">
            <div class="col" style="min-width: 60%;">
                <input type="text" class="form-control" placeholder="Search" v-model="search" aria-label="Search">
                <InputError :value="error['search']"/>
            </div>
            <div class="col" style="min-width: 20%;">
                <select class="form-select" aria-label="Filter" v-model="option">
                    <option selected>Name</option>
                    <option>Place</option>
                </select>
                </div>
            <div class="col">
                <input type="submit" style="width: 100%;" class="btn btn-success" value="Search">
            </div>
        </div>
        <div class="card" v-for="venue in venues" style="margin: 15px;">
            <div class="card-body" style="display: flex; align-items: center;">
                <div style="width: 60%;">
                    <h5 class="card-title">{{ venue.name }}</h5>
                    <h6 class="card-subtitle mb-2 text-body-secondary">{{ venue.place }}</h6>
                </div>
            </div>
            <div class="accordion" id="accordionExample" style="margin: 20px;">
                <div class="accordion-item">
                  <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" @click="getMovieShows(venue.id)"
                        data-bs-toggle="collapse" :data-bs-target="'#collapseMovie'+venue.id" 
                        aria-expanded="true" aria-controls="collapseOne">
                      Movies
                    </button>
                  </h2>
                  <div :id="'collapseMovie'+venue.id" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                    <div class="accordion-body" style="display: flex; flex-wrap: wrap; ">
                        <div class="card" style="width: 18rem; margin: 10px;" v-for="movie in movies">
                            <div class="card-body">
                                <h5 class="card-title">{{ movie["title"] }}</h5>
                                <p class="card-text">Rating: {{ movie["rating"] }}</p>
                                <router-link class="btn btn-primary" style="width: 100%;"
                                    :to="{name: 'user-book-movie', params: {movie_id: movie['movie-id'], show_id:movie['show-id'], venue_id: venue.id}}" >
                                    Book
                                </router-link>
                            </div>
                        </div>
                    </div>
                  </div>
                </div>
            </div>
        </div>
    </form>
</template>
<script>
    export default{
        data(){
            return{
                search: null,
                option: "Name",
                deleteSuccess: null,
                movies: [],
                error: {
                    search: null,
                    deleteFaliure: null,
                }
            }
        },
        methods: {
            validate(){
                this.error = {
                    search: null
                }
                if(!this.search){
                    this.error["search"] = "Invalid input."
                    return true;
                }
            },
            searchVenue(event){
                event.preventDefault()
                if(!this.validate())
                    store.dispatch("getVenues", {search: this.search, option: this.option});
            },
            getMovieShows(id){
                this.movies = [];
                fetch(store.getters.BASEURL+`/venue/${id}/movies`, {
                method: "GET",
                headers:{
                    "Authentication-Token": store.getters.getToken
                }
                }).then(response =>{
                    if(response.status == 200){
                        return response.json();
                    }
                    else{
                        if(response.status == 404)
                            this.error["notFound"] = "Movie not found."
                        return []
                    }
                }).then(data => this.movies = data)
            }
        },
        computed: {
            venues(){
                return store.getters.getVenues;
            }
        }
    }
</script>