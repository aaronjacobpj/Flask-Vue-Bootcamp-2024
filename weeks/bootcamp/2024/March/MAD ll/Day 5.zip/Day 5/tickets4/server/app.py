from flask import Flask
from flask_security import SQLAlchemyUserDatastore, Security
from flask_cors import CORS

def create_app():

    from application.views import view
    from application.models import User, Role, db
    from application import intialise 
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///./model.db'
    app.config["SECRET_KEY"] = "ufgaeihiogjarbjvjear"

    db.init_app(app)
    datastore = SQLAlchemyUserDatastore(db, User, Role)
    app.security = Security(app, datastore)

    app.register_blueprint(view)

    CORS(app)

    with app.app_context():
        db.create_all()

        intialise.main()

    return app


app = create_app()
