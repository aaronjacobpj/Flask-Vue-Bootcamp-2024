import pytest
from app import create_app
from application.models import db

@pytest.fixture()
def app():
    app = create_app()
    app.config.update({
        "TESTING": True,
        'SQLALCHEMY_DATABASE_URI':  'sqlite://'
    })

    # other setup can go here

    yield app

    # clean up / reset resources here


@pytest.fixture()
def client(app):
    return app.test_client()


@pytest.fixture()
def runner(app):
    return app.test_cli_runner()


@pytest.fixture()
def admin(app):
    with app.app_context():
        user = app.security.datastore.find_user(email="grace.turner@example.com")
    return user
