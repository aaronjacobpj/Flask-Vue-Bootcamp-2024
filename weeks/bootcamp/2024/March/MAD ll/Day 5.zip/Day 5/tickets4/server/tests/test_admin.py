from .config import *

def test_admin_email(app, admin):
    assert admin.firstname == "Grace"


def test_admin_valid_login(app, client, admin):
    response = client.post("/signin", json={"email": admin.email, 
                                 "password": "grace"})
    assert response.status_code == 200

    