
def hello():
    return "Hi"

def test_is_even():
    assert hello() == "Hi"
