import { createRouter, createWebHistory } from 'vue-router';
import store from '@/store';

import LoginView from '../views/LoginView.vue';
import RegisterView from "@/views/RegisterView.vue";
import LayoutView from "@/views/LayoutView.vue";
import AdminLayoutView from "@/views/admin/AdminLayoutView.vue";
import VenueCreateView from "@/views/admin/VenueCreateView.vue";
import VenueSearchView from "@/views/admin/VenueSearchView.vue";
import VenueEditView from "@/views/admin/VenueEditView.vue";
import MovieCreateView from "@/views/admin/MovieCreateView.vue";
import MovieSearchView from "@/views/admin/MovieSearchView.vue";
import MovieEditView from "@/views/admin/MovieEditView.vue";
import MovieAllocateView from "@/views/admin/MovieAllocateView.vue";
import AdminDashboardView from "@/views/admin/AdminDashboardView.vue";
import UserLayoutView from "@/views/user/UserLayoutView.vue";
import UserMovieSearchView from "@/views/user/UserMovieSearchView.vue";
import UserBookMovieView from "@/views/user/UserBookMovieView.vue";
import UserVenueSearchView from "@/views/user/UserVenueSearchView.vue";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/login',
      name: 'login',
      component: LoginView
    }, 
    {
      path: "/signup",
      name: "signup",
      component: RegisterView
    },
    {
      path: "/",
      name: "home",
      component: LayoutView
    },
    {
      path: "/admin", 
      name: "admin-index",
      component: AdminLayoutView,
      children: [
        {
          path: "",
          name: "admin-dashboard",
          component: AdminDashboardView
        },
        {
          path: "venue/create",
          name: "venue-create",
          component: VenueCreateView
        },
        {
          path: "venue/search",
          name: "venue-search",
          component: VenueSearchView
        },
        {
          path: "venue/:id/edit",
          name: "venue-edit",
          component: VenueEditView,
          props: true
        },
        {
          path: "movie/create",
          name: "movie-create",
          component: MovieCreateView
        },
        {
          path: "movie/search",
          name: "movie-search",
          component: MovieSearchView
        },
        {
          path: "movie/:id/edit",
          name: "movie-edit",
          component: MovieEditView,
          props: true
        },
        {
          path: "movie/:id/allocate",
          name: "movie-allocate",
          component: MovieAllocateView,
          props: true
        }
      ]
    },
    {
      path: "/user", 
      name: "user-index",
      component: UserLayoutView,
      children: [
        {
          path: "movie/",
          name: "user-movie-search",
          component: UserMovieSearchView,
          props: true
        },
        {
          path: "movie/:movie_id/venue/:venue_id/show/:show_id",
          name: "user-book-movie",
          component: UserBookMovieView,
          props: true
        },
        {
          path: "venue",
          name: "user-venue",
          component: UserVenueSearchView,
          props: true
        }
      ]
    },
  ]
})


router.beforeEach((to, from) =>{
  if((to.path == "/" || to.path.match("/admin*") || to.path.match("/user*")) && !store.getters.getToken){
    return {name: "login"}
  }
  if(to.path.match("/admin*") && store.getters.getRoles.includes("user")){
    return {name: "user-index"}
  }
  if(to.path.match("/admin*") && !store.getters.getToken && !store.getters.getRoles.includes("admin")){
    return {name: "login"}
  }

})

export default router;
