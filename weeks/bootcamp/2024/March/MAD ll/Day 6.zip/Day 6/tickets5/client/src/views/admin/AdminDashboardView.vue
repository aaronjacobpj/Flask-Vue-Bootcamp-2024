<script setup>
    import { RouterLink } from "vue-router";
    import InputError from "@/components/InputError.vue";
    import SuccessAlert from "@/components/SuccessAlert.vue"
    import DangerAlert from "@/components/DangerAlert.vue";
    import store from "@/store";    
</script>
<template>
    <div class="container-fluid">
        <div class="row" style="margin: 20px;">
            <div class="col">
                <apexchart width="500" type="bar" :options="barChartoptions" :series="barChartseries"></apexchart>
            </div>
            <div class="col">
                <apexchart width="500" type="bar" :options="lineChartoptions" :series="lineChartseries"></apexchart>
            </div>
        </div>
    </div>
</template>
<script>
    export default{
        data(){
            return {
                barChart:{
                    movies: [],
                    tickets: []
                },
                lineChart:{
                    venues: [],
                    tickets: []
                }
            }
        },
        created(){
            fetch(store.getters.BASEURL+"/admin/movie/statistics", {
                    method: "GET",
                    headers:{
                        "Authentication-Token": store.getters.getToken
                    }
            }).then(response =>{
                if (response.status == 200)
                    return response.json()
                else
                    return {
                        movies: [],
                        tickets: []
                    }
            }).then(data => this.barChart = data)
            fetch(store.getters.BASEURL+"/admin/venue/statistics", {
                    method: "GET",
                    headers:{
                        "Authentication-Token": store.getters.getToken
                    }
            }).then(response =>{
                if (response.status == 200)
                    return response.json()
                else
                    return {
                        venues: [],
                        tickets: []
                    }
            }).then(data => this.lineChart = data)
        },
        computed:{
            barChartoptions(){
                return  {
                        chart: {
                        id: 'vuechart-example'
                        },
                        xaxis: {
                        categories: this.barChart["movies"]
                        }
                    }
                
            },
            barChartseries(){
                return [{
                    name: 'series-1',
                    data: this.barChart["tickets"]
                    }]
            },
            lineChartoptions(){
                return  {
                        chart: {
                        id: 'venue-performance'
                        },
                        xaxis: {
                        categories: this.lineChart["venues"]
                        }
                    }
                
            },
            lineChartseries(){
                return [{
                    name: 'series-1',
                    data: this.lineChart["tickets"]
                    }]
            }
        }
    }
</script>