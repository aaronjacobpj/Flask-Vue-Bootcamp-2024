<script setup>
    import InputError from "@/components/InputError.vue";
    import SuccessAlert from "@/components/SuccessAlert.vue"
    import DangerAlert from "@/components/DangerAlert.vue";
    import store from "@/store";
</script>
<template>
    <SuccessAlert :message="deleteSuccess"/>
    <DangerAlert :message="error['deleteFaliure']"/>
    <form @submit="searchVenue">
        <div class="row" style="margin: 20px;">
            <div class="col" style="min-width: 60%;">
                <input type="text" class="form-control" placeholder="Search" v-model="search" aria-label="Search">
                <InputError :value="error['search']"/>
            </div>
            <div class="col" style="min-width: 20%;">
                <select class="form-select" aria-label="Filter" v-model="option">
                    <option selected>Name</option>
                    <option>Place</option>
                </select>
                </div>
            <div class="col">
                <input type="submit" style="width: 100%;" class="btn btn-success" value="Search">
            </div>
        </div>
        <div class="card" v-for="venue in venues" style="margin: 15px;">
            <div class="card-body" style="display: flex; align-items: center;">
                <div style="width: 60%;">
                    <h5 class="card-title">{{ venue.name }}</h5>
                    <h6 class="card-subtitle mb-2 text-body-secondary">{{ venue.place }}</h6>
                </div>
                <div>
                    <router-link class="btn btn-outline-warning" role="button"
                        :to="{name: 'venue-edit', params: {id: venue.id}, query: {name: venue.name, place: venue.place}}"  
                        style="margin-right: 20px;color: black;border: 2px solid var(--bs-btn-hover-bg);">
                        Edit
                    </router-link>
                    <button class="btn btn-danger" @click="deleteVenue(venue.id)">Delete</button>
                </div>
            </div>
        </div>
    </form>
</template>
<script>
    export default{
        data(){
            return{
                search: null,
                option: "Name",
                deleteSuccess: null,
                error: {
                    search: null,
                    deleteFaliure: null,
                }
            }
        },
        methods: {
            validate(){
                this.error = {
                    search: null
                }
                if(!this.search){
                    this.error["search"] = "Invalid input."
                    return true;
                }
            },
            searchVenue(event){
                event.preventDefault()
                if(!this.validate())
                    store.dispatch("getVenues", {search: this.search, option: this.option});
            },
            deleteVenue(venue_id){
                fetch(store.getters.BASEURL+"/venue/"+venue_id, {
                                        method: "DELETE",
                                        headers:{
                                            "Content-Type": "application/json",
                                            "Authentication-Token": store.getters.getToken
                                        },
                                    }).then(response =>{
                                        if(response.status == 200){
                                            this.deleteSuccess = "Deleted venue successfully.";
                                            store.dispatch("getVenues", {search: "_", option: "Name"});
                                        }
                                        else if(response.status == 404)
                                            this.error["deleteFaliure"] = "Venue not Found."
                                    })
            }
        },
        computed: {
            venues(){
                return store.getters.getVenues;
            }
        }
    }
</script>