<script setup>
    import { RouterLink } from "vue-router";
    import InputError from "@/components/InputError.vue";
    import SuccessAlert from "@/components/SuccessAlert.vue"
    import DangerAlert from "@/components/DangerAlert.vue";
    import store from "@/store";    
</script>
<template>
    <SuccessAlert :message="successMessage"/>
    <DangerAlert :message="error['notFound']"/>
    <div class="container-fluid" style="padding: 20px;">
        <form @submit="bookMovie">
            <div class="row">
                <div class="col">
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Movie Name</label>
                        <input type="text" class="form-control" id="formGroupExampleInput" 
                             :value="movie['title']" disabled>
                      </div>
                </div>
                <div class="col">
                    <div class="mb-3">
                        <label for="formGroupExampleInput2" class="form-label">Movie Rating</label>
                        <input type="text" class="form-control" id="formGroupExampleInput2"
                         :value="movie['rating']" disabled/>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Venue Name</label>
                        <input type="text" class="form-control" id="formGroupExampleInput" 
                        :value="venue['name']" disabled>
                      </div>
                </div>
                <div class="col">
                    <div class="mb-3">
                        <label for="formGroupExampleInput2" class="form-label">Venue Place</label>
                        <input type="text" class="form-control" id="formGroupExampleInput2" 
                        :value="venue['place']" disabled>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Show Time</label>
                        <select class="form-select" v-model="time">
                            <option :value="time['id']" v-for="time in venuDetails['times']">{{ time['time'] }}</option>
                        </select>
                      </div>
                </div>
                <div class="col">
                    <div class="mb-3">
                        <label for="formGroupExampleInput2" class="form-label">Tickets</label>
                        <input type="number" v-model="tickets" class="form-control" id="formGroupExampleInput2" placeholder="Another input placeholder">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="mb-3">
                        <input type="submit" style="width: 100%;" value="Book" class="btn btn-primary"/>
                      </div>
                </div>
            </div>
        </form>
    </div>
</template>
<script>
    export default{
        props: ["movie_id", "show_id", "venue_id"],
        created(){
            store.dispatch("getMovies", {search: "", 
                                            rating: "", 
                                            genre: []});
            store.dispatch("getVenues", {search: "", 
                                        option: "Name"});
            this.getMovieVenues(this.movie_id);
        },
        data(){
            return {
                successMessage: null,
                tickets: null,
                time: null,
                venuDetails: {
                    times: []
                },
                error:{
                    notFound: null
                }
            }
        },
        methods:{
            getMovieVenues(id){
                this.venues = [];
                fetch(store.getters.BASEURL+`/movie/${id}/venue`, {
                method: "GET",
                headers:{
                    "Authentication-Token": store.getters.getToken
                }
                }).then(response =>{
                    if(response.status == 200){
                        return response.json();
                    }
                    else{
                        if(response.status == 404)
                            this.error["notFound"] = "Movie not found."
                        return []
                    }
                }).then(data => {
                    let result = data.filter(x => x["show-id"] == this.show_id)[0]
                    if(result)
                        this.venuDetails = result;
                })
            },
            validate(){
                if(!this.time || !this.tickets)
                    return false;
            },
            bookMovie(event){
                event.preventDefault();
                if (!this.validate)
                    return
                fetch(store.getters.BASEURL+`/show/${this.show_id}`, {
                    method: "POST",
                    headers:{
                        "Authentication-Token": store.getters.getToken,
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        time: this.time,
                        tickets: this.tickets
                    })
                }).then(response => {
                    if(response.status == 200){
                        this.successMessage = "Booked movie successfully."
                    }
                })
            }
        },
        computed:{
            movie(){
                let result = store.getters.getMovies.filter(x => x["id"] == this.movie_id)[0]
                if (!result)
                    result = {}
                return result;
            },
            venue(){
                let result = store.getters.getVenues.filter(x => x["id"] == this.venue_id)[0];
                if (!result)
                    result = {}
                return result;
            }
        }
    }
</script>