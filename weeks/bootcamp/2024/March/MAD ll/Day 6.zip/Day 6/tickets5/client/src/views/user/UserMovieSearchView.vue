<script setup>
    import { RouterLink } from "vue-router";
    import InputError from "@/components/InputError.vue";
    import SuccessAlert from "@/components/SuccessAlert.vue"
    import DangerAlert from "@/components/DangerAlert.vue";
    import store from "@/store";    
</script>
<template>
    <DangerAlert :message="error['notFound']"/>
    <form @submit="searchMovies">
        <div class="row" style="margin: 20px;">
            <div class="col" style="min-width: 40%;">
                <input type="text" class="form-control" placeholder="Search" v-model="search" aria-label="Search">
                <InputError :value="error['search']"/>
            </div>
            <div class="col" style="min-width: 20%;">
                <select class="form-select" v-model="rating">
                    <option selected disabled>Rating</option>
                    <option v-for="i in 10">{{ i }}</option>
                </select>
                <InputError :value="error['search']"/>
            </div>
            <div class="col" style="min-width: 20%;">
                <select class="form-select" aria-label="Filter" v-model="genre" multiple>
                    <option selected disabled>Genres</option>
                    <option v-for="genre in genres" :value="genre.id">{{ genre["type"] }}</option>
                </select>
                </div>
            <div class="col">
                <input type="submit" style="width: 100%;" class="btn btn-success" value="Search">
            </div>
        </div>
        <div class="card" v-for="movie in movies" style="margin: 15px;">
            <div class="card-body" style="display: flex; align-items: center;">
                <div class="row" style="width: 100%; display: flex; align-items: center;">
                    <div class="col" style="max-width: max-content;">
                        <img :src="posterUrl(movie.poster)" class="img-thumbnail" 
                            style="height: 150px; width: 120px;">
                    </div>
                    <div class="col" style="min-width: 60%;">
                        <div>
                            <h5 class="card-title">{{ movie.title }}</h5>
                            <h6 class="card-subtitle mb-2 text-body-secondary">Rating: {{ movie.rating }}</h6>
                            <span class="badge text-bg-info" v-for="genre in movie.genres"
                                style="margin-right: 10px;">
                                {{ genre["type"] }}
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="accordion" id="accordionExample" style="margin: 20px;">
                <div class="accordion-item">
                  <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" @click="getMovieVenues(movie.id)"
                        data-bs-toggle="collapse" :data-bs-target="'#collapseMovie'+movie.id" 
                        aria-expanded="true" aria-controls="collapseOne">
                      Venues
                    </button>
                  </h2>
                  <div :id="'collapseMovie'+movie.id" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                    <div class="accordion-body" style="display: flex; flex-wrap: wrap; ">
                        <div class="card" style="width: 18rem; margin: 10px;" v-for="venue in venues">
                            <div class="card-body">
                                <h5 class="card-title">{{ venue["name"] }}</h5>
                                <p class="card-text">{{ venue["place"] }}</p>
                                <router-link class="btn btn-primary" style="width: 100%;"
                                    :to="{name: 'user-book-movie', params: {movie_id: movie.id, show_id:venue['show-id'], venue_id: venue['venue-id']}}" >
                                    Book
                                </router-link>
                            </div>
                        </div>
                    </div>
                  </div>
                </div>
            </div>
        </div>
    </form>
</template>
<script>
    export default{
        data(){
            return{
                search: null,
                rating: "Rating",
                genre: [],
                venues: [],
                deleteSuccess: null,
                error: {
                    search: null,
                    notFound: null,
                }
            }
        },
        created(){
            store.dispatch("getGenres")
            store.dispatch("getMovies", {search: this.search, 
                                            rating: this.rating, 
                                            genre: this.genre});
        },
        methods: {
            searchMovies(event){
                event.preventDefault();
                store.dispatch("getMovies", {search: this.search, 
                                            rating: this.rating, 
                                            genre: this.genre});
            },
            posterUrl(value){
                return `${store.getters.BASEURL}/static/uploads/${value}`
            },
            getMovieVenues(id){
                this.venues = [];
                fetch(store.getters.BASEURL+`/movie/${id}/venue`, {
                method: "GET",
                headers:{
                    "Authentication-Token": store.getters.getToken
                }
                }).then(response =>{
                    if(response.status == 200){
                        return response.json();
                    }
                    else{
                        if(response.status == 404)
                            this.error["notFound"] = "Movie not found."
                        return []
                    }
                }).then(data => this.venues = data)
            }
        },
        computed: {
            genres(){
                return store.getters.getGenres;
            },
            movies(){
                return store.getters.getMovies
            }
        }
    }
</script>
