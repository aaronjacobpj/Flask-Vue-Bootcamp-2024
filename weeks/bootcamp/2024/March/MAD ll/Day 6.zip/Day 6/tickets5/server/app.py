from flask import Flask
from flask_security import SQLAlchemyUserDatastore, Security
from flask_cors import CORS

from application.intialise import celery_init_app
from application.worker import daily_reminder, report
from celery.schedules import crontab

def create_app():

    from application.views import view
    from application.models import User, Role, db
    from application import intialise 
    from application.cache import cache

    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///./model.db'
    app.config["SECRET_KEY"] = "ufgaeihiogjarbjvjear"
    app.config["CELERY"] = {"broker_url": "redis://localhost:6379", 
                            "result_backend": "redis://localhost:6379"}

    db.init_app(app)
    datastore = SQLAlchemyUserDatastore(db, User, Role)
    app.security = Security(app, datastore)

    app.register_blueprint(view)

    CORS(app)
    cache.init_app(app, {"CACHE_TYPE": "RedisCache",
                         "CACHE_DEFAULT_TIMEOUT": 10,
                        #  "CACHE_REDIS_HOST": "redis://localhost/",
                        #  "CACHE_REDIS_PORT": 6379,
                        #  "CACHE_REDIS_DB": 0,
                         "CACHE_REDIS_URL": "redis://localhost:6379/0"})

    with app.app_context():
        db.create_all()

        intialise.main()

    return app


app = create_app()

celery = celery_init_app(app)


@celery.on_after_configure.connect
def setup_periodic_tasks(sender, **kwargs):
    sender.add_periodic_task(10.0, daily_reminder.s(), name='say hello every 10')
    sender.add_periodic_task(10.0, report.s(), name='say hello every 10')
    sender.add_periodic_task(crontab(day_of_month="*", 
                                     hour=7, 
                                     minute=0), 
                            report.s(), 
                            name='say hello every 10')