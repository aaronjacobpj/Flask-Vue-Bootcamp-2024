from flask import current_app as app
from werkzeug.security import generate_password_hash
from celery import Celery, Task
from flask import Flask


from .models import db, Genre


GENRES = ['Action', 'Adventure', 'Animation', 'Biography', 
            'Comedy', 'Crime', 'Documentary', 'Drama', 'Family', 
            'Fantasy', 'Film-Noir', 'History', 'Horror', 'Music', 
            'Musical', 'Mystery', 'Romance', 'Sci-Fi', 'Short', 
            'Sport', 'Thriller', 'War', 'Western']


def main():
    if not app.security.datastore.find_role("admin"):
        admin = app.security.datastore.create_role(name="admin")
        app.security.datastore.create_role(name="user")
        db.session.flush()
        user = app.security.datastore.create_user(firstname="Grace", 
                                        lastname="Turner",
                                        email="grace.turner@example.com", 
                                        password=generate_password_hash("grace"))
        app.security.datastore.add_role_to_user(user, admin)
        add_genres()
        db.session.commit()


def add_genres():

    for genre in GENRES:
        db.session.add(Genre(type=genre))


def celery_init_app(app: Flask) -> Celery:
    class FlaskTask(Task):
        def __call__(self, *args: object, **kwargs: object) -> object:
            with app.app_context():
                return self.run(*args, **kwargs)

    celery_app = Celery(app.name, task_cls=FlaskTask)
    celery_app.config_from_object(app.config["CELERY"])
    celery_app.set_default()
    app.extensions["celery"] = celery_app
    return celery_app