from celery import shared_task
from jinja2 import Template

from smtplib import SMTP
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.encoders import encode_base64

import csv
from io import StringIO


from .models import db, User, Ticket, Venue

@shared_task
def daily_reminder():
    user_ids = []
    for ticket in Ticket.query.all():
        user_ids.append(ticket.user_id)

    server = SMTP(host="0.0.0.0",
                   port=1025)

    for user in User.query.filter(User.id.not_in(user_ids)).all():
        message = MIMEMultipart()
        message["From"] = "grace.turner@example.com"
        message["To"] = user.email
        message["Subject"] = "We miss you! Vist soon, You are missing out really good movies."

        with open("static/cat.jpg", "rb") as file:
            image = MIMEBase("application", "octet-stream")
            image.set_payload(file.read())
            image.add_header("content-disposition", "attachment; filename=image.png")
            encode_base64(image) # Convert binary object base64 string


        message.attach(image)

        with open("static/image.pdf", "rb") as file:
            image = MIMEBase("application", "octet-stream")
            image.set_payload(file.read())
            image.add_header("content-disposition", "attachment; filename=image.pdf")
            encode_base64(image) # Convert binary object base64 string
        
        message.attach(image)

        server.sendmail("grace@example.com", 
                        user.email, 
                        message.as_string())
        
    return True


@shared_task
def export_csv():
    content = StringIO()
    writer = csv.writer(content)
    writer.writerow(["Venue Name", "Movie Name", "Tickets Sold"])

    for venue in Venue.query.all():
        for show in venue.shows:
            row = [venue.name, show.movie.title]
            count = 0
            for timing in show.timing:
                count += timing.ticket_count()
            row.append(count)
            writer.writerow(row)

    content.seek(0)
    return content.read()


@shared_task
def report():
    with open("templates/report.html") as file:
        template = Template(file.read())

    server = SMTP(host="0.0.0.0",
                   port=1025)

    for user in User.query.all():
        tickets = Ticket.query.filter_by(user_id=user.id)
        content = template.render(user=user, tickets=tickets)

        message = MIMEMultipart()
        message["From"] = "grace.turner@example.com"
        message["To"] = user.email
        message["Subject"] = "Monthly Report."
        html = MIMEText(content, "html")
        message.attach(html)

        server.sendmail("grace.turner@example.com",
                        user.email,
                        message.as_string())