from flask import Flask

app = Flask(__name__)

@app.route("/<string:name>")
def index(name="world!"):
    return f"Hello, {name}"

@app.route("/")
def unknown(name="world!"):
    return f"Hello, {name}"