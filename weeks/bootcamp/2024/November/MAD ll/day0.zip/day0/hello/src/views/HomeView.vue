<script setup>
</script>
<template>
  <main>
    <ul>
      <li v-for="item in items" :style="style">
        {{ item }}
      </li>
      <button @click="change" class="btn btn-primary">Switch</button>
    </ul>
  </main>
</template>
<script>
export default {
    data(){
      return {
        items: ["Foo", "Bar"],
        style: {
          color: "blue",
        }
      }
    },
    methods: {
      change(){
        if(this.style['color'] == "red"){
          this.style['color'] = "blue";
        }
        else
        this.style['color'] = "red";

      }
    }
}
</script>