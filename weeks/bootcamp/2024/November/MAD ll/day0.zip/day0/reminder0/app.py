from flask import Flask, render_template, request

app = Flask(__name__)

reminders = ["Foo", "Bar", "Baz"]


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        reminders.append(request.form.get("item"))

    return render_template("index.html", items=reminders)


@app.route("/form")
def add_reminder():
    return render_template("form.html")