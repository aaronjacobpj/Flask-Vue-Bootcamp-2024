from flask import Flask
from flask_security import SQLAlchemyUserDatastore, Security
from models import db, User, Role


app = Flask(__name__)
app.config['SECRET_KEY'] = "usebfsknerskdln"
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite://'

db.init_app(app)

datastore = SQLAlchemyUserDatastore(db, User, Role)
app.security = Security(app, datastore)

with app.app_context():
    db.create_all()

