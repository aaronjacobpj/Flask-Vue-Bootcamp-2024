<script setup>
import { RouterLink, RouterView } from 'vue-router'
import store from "@/store"
</script>

<template>
  <RouterView />
</template>
<script>
  export default{
    created(){
      store.commit("setItems", JSON.parse(localStorage.getItem("items") || JSON.stringify([])))
    }
  }
</script>