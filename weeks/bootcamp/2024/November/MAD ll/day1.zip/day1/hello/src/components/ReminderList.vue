<template>
    <li :style="{color: color}">{{ item }}</li>
</template>
<script>
    export default{
        props: ["color", "item"],
        data(){
            return {

            }
        }
    }
</script>