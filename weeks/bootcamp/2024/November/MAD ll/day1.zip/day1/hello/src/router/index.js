import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import DateView from  "@/views/DateView.vue"
import ListsView from  "@/views/ListsView.vue"
import ListsUpdatedView from  "@/views/ListsUpdatedView.vue"
import GreetView from "@/views/GreetView.vue";
 
const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView
    },
    {
      path: '/date',
      name: 'date',
      component: DateView
    },
    {
      path: '/lists',
      name: 'lists',
      component: ListsView
    },
    {
      path: '/lists-updated',
      name: 'lists-updated',
      component: ListsUpdatedView
    },
    {
      path: '/greet/:name',
      name: 'greet',
      component: GreetView,
      props: true
    },
  ]
})

export default router
