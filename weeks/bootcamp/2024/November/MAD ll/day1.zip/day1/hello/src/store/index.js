import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            message: "My List",
            items: []
        }
    },
    getters: {
        getMessage(state){
            return state.message+ "!";
        },
        getItems(state){
            return state.items
        }
    },
    mutations: {
        addItem(state, value){
            state.items.push({color: "green", message: value})
            localStorage.setItem("items", JSON.stringify(state.items))
        },
        setItems(state, value){
            state.items = value
            localStorage.setItem("items", JSON.stringify(state.items))
        }
    },
    actions:{
        addItem(context, value){
            setTimeout(()=> context.commit("addItem", value), 2000);
        }
    }
})