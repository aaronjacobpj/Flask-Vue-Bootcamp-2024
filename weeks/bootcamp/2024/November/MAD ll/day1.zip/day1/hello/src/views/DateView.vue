<script setup>
</script>
<template>
  <main>
    <h1>{{ now }}</h1>
    <h3>You have clicked {{ count }} times!</h3>
    <h3 v-show="count % 10 == 0" >It is ia multiple of ten!</h3>
    <button @click="add" class="btn btn-primary">Add</button>
  </main>
</template>
<script>
  export default {
    data(){
      return {
        count: 0,
        message: new Date()
      }
    },
    methods: {

      add(){
        this.count++;
      }
    },
    computed:{
        now(){
            return new Date();
        },
    }
  }
</script>