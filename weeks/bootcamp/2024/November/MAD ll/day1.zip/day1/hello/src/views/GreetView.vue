<script setup>
</script>
<template>
  <main>
    <h1>Hello, {{name}}</h1>
  </main>
</template>
<script>
    export default{
        props: ["name"]
    }
</script>