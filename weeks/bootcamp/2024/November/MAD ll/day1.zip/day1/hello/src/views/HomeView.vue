<script setup>
      import { RouterLink } from "vue-router";
</script>
<template>
  <main>
    <ul>
      <li v-for="item in items" :style="style">
        {{ item }}
      </li>
      <button @click="change" class="btn btn-primary">Switch</button>
      <input type="text" v-model="name">
      <RouterLink :to="{name: 'greet', params: {'name':name || 'world'}}">Greet</RouterLink>
    </ul>
  </main>
</template>
<script>
export default {
    data(){
      return {
        items: ["Foo", "Bar"],
        style: {
          color: "blue",
        },
        name: null
      }
    },
    methods: {
      change(){
        if(this.style['color'] == "red"){
          this.style['color'] = "blue";
        }
        else
        this.style['color'] = "red";

      }
    }
}
</script>