<script setup>
    import { RouterLink } from "vue-router";
    import ReminderList from "@/components/ReminderList.vue";
    import store from "@/store";
</script>
<template>
    <h1>{{ store.getters.getMessage }}</h1>
    <ul>
        <ReminderList v-for="item in store.getters.getItems" :color="item['color']" :item="item['message']"/>
    </ul>
    <input type="text" v-model="item">
    <input type="button" value="Add" @click="add" class="btn"/>
    <RouterLink to="/date">date</RouterLink>
    <RouterLink :to="{name: 'home'}">Home</RouterLink>
</template>
<script>
  export default {
    data(){
      return {
        item: null
      }
    },
    methods:{
        add(){
            store.dispatch('addItem', this.item);
        }
    }
  }
</script>