<script setup>
    import ReminderList from "@/components/ReminderList.vue";
    import store from "@/store";
</script>
<template>
    <h1>{{ store.getters.getMessage }}</h1>
    <ul>
        <ReminderList v-for="item in items" :color="item['color']" :item="item['message']"/>
    </ul>
    <input type="text" v-model="item">
    <input type="button" value="Add" @click="add" class="btn"/>
</template>
<script>
  export default {
    data(){
      return {
        items: [{color: "red", message: "Buy Groceries"}, 
            {color: "Blue", message: "Foo"},

        ],
        item: null
      }
    },
    methods:{
        add(){
            this.items.push({color: "green", message: this.item})
        }
    }
  }
</script>