from flask_caching import Cache

cache = Cache(config={"CACHE_REDIS_URL": "redis://localhost:6379/0",
              "CACHE_DEFAULT_TIMEOUT": 3000,
              "CACHE_TYPE": "RedisCache"
              })