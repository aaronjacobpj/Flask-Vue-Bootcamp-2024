<script setup>
    import { RouterView, RouterLink } from "vue-router";
    import store from "@/store";
</script>
<template>
    <div class="container-fluid">
        <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
              <a class="navbar-brand" href="#">Navbar</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                  <li class="nav-item">
                    <RouterLink class="nav-link active" aria-current="page" to="/admin/author">Authors</RouterLink>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" @click="exportCsv">Export</a>
                  </li>
                  <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      Genre
                    </a>
                    <ul class="dropdown-menu">
                      <li><RouterLink class="dropdown-item" to="/admin/genre/create">Add</RouterLink></li>
                      <li><RouterLink class="dropdown-item" to="/admin/genre/">Search</RouterLink></li>
                    </ul>
                  </li>
                  <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      Books
                    </a>
                    <ul class="dropdown-menu">
                      <li><RouterLink class="dropdown-item" to="/admin/book/create">Add</RouterLink></li>
                      <li><RouterLink class="dropdown-item" to="/admin/book/">Search</RouterLink></li>
                      <li><RouterLink class="dropdown-item" to="/admin/book/requests">Requests</RouterLink></li>
                    </ul>
                  </li>
                  <li class="nav-item">
                    <RouterLink class="nav-link active" aria-current="page" to="/logout" style="color:red">Logout</RouterLink>
                  </li>
                </ul>
              </div>
            </div>
        </nav>
        <RouterView/>
    </div>
</template>
<script>
  export default {
    data(){
      return {
        id: null
      }
    },
    methods:{
      exportCsv(){
        fetch(import.meta.env.VITE_BASEURL+"/export", {
                    headers: {
                        "Authentication-Token": store.getters.getToken,
                    },
          }).then(x =>{
            if(x.status == 200){
             this.checkExportStatus()
              return x.text()
            }
          }).then(x =>{
            console.log(x);
            
            this.id = x
          })
      },
      checkExportStatus(){
      console.log("status...");
      
      fetch(import.meta.env.VITE_BASEURL+"/export/"+this.id+"/status", {
                    headers: {
                        "Authentication-Token": store.getters.getToken,
                    },
      }).then(x =>{
        if(x.status == 200){
          return x.text()
        }
      }).then(x =>{
        console.log(x);
        
        if (x == "SUCCESS")
        {
          this.dowloadExport();
          return
        }
        setTimeout(this.checkExportStatus, 5000)
      })
    },
    dowloadExport(){
      // if client side download

      fetch(import.meta.env.VITE_BASEURL+"/export/"+this.id, {
                    headers: {
                        "Authentication-Token": store.getters.getToken,
                    },
      }).then(x =>{
        if(x.status == 200){
          return x.text()
        }
      }).then(x =>{
        function download(data){
            // Create a Blob with the CSV data and type
            const blob = new Blob([data], { type: 'text/csv' });
            
            // Create a URL for the Blob
            const url = URL.createObjectURL(blob);
            
            // Create an anchor tag for downloading
            const a = document.createElement('a');
            
            // Set the URL and download attribute of the anchor tag
            a.href = url;
            a.download = 'export.csv';
            
            // Trigger the download by clicking the anchor tag
            a.click();
        }

        download(x);
      })
      // end

      // severside download
      // open(import.meta.env.VITE_BASEURL+"/export/"+this.id)
    }
    },
    
  }
</script>