<script setup>
    import store from "@/store"
</script>
<template>
    <div class="alert alert-success" v-show="message">
        {{ message }}
    </div>
    <div class="alert alert-danger" v-show="invalid_message">
        {{ invalid_message }}
    </div>
    <div class="container-fluid">
        <table class="table">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">Genre</th>
                <th scope="col">Authors</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="book in books">
                <th scope="row">{{ book.id }}</th>
                <td>{{ book.name }}</td>
                <td>{{ book.genre["name"] }}</td>
                <td>
                    <div class="col" style="display: flex;">
                        <span class="badge text-bg-primary" style="margin-left: 5px;" v-for="author in book.authors">
                            {{ author['name'] }}
                        </span>
                    </div>
                </td>
                <td>
                    <button class="btn btn-outline-warning" @click="modifyBook(book['id'])">
                        Modify
                    </button>
                </td>
                <td>
                    <button class="btn btn-outline-danger" @click="deleteBook(book['id'])">
                        Delete
                    </button>
                </td>
              </tr>
            </tbody>
          </table>
          <div class="modal" tabindex="-1" style="display: block;" v-show="modify">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Modify Book</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" @click="modify=false"></button>
                </div>
                <form @submit.prevent="updateBook">
                    <div class="modal-body">
                        <div class="row mb-3">
                            <div class="col" style="min-width: 80%;">
                                <label for="formGroupExampleInput" class="form-label">Title</label>
                                <input type="text" class="form-control" placeholder="Genre" aria-label="Genre"
                                 v-model="form['name']">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Date Issued</label>
                            <input type="date" class="form-control" id="formGroupExampleInput2" v-model="form['date']">
                        </div>
                        <div class="row mb-3">
                            <div class="col" style="min-width: 80%;">
                                <label for="formGroupExampleInput2" class="form-label">Authors</label>
                                <select class="form-select" aria-label="Default select example" multiple v-model="form['authors']">
                                    <option :value="author" :selected="form['authors'].map(x => x['id']).includes(author.id)" 
                                        v-for="author in store.getters.getAuthors">
                                        {{ author.name }}
                                    </option>
                                </select>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col" style="min-width: 80%;">
                                <label for="formGroupExampleInput2" class="form-label">Genre</label>
                                <select class="form-select" aria-label="Default select example" multiple v-model="form['genre']">
                                    <option :value="genre" v-for="genre in store.getters.getGenres">
                                        {{ genre.name }}
                                    </option>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="formFile" class="form-label">Upload Book</label>
                            <input class="form-control" type="file" id="formFile" @change="getFile">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
              </div>
            </div>
          </div>
    </div>
</template>
<script>
    export default {
        props: ["id"],
        data(){
            return {
                name: "",
                message: null,
                invalid_message: null,
                form: {
                    name: null,
                    authors: [],
                    genre: [],
                    file: null,
                    date: null
                },
                modify: false
            }
        },
        created(){
                store.dispatch("getBooks", "");
                store.dispatch("getGenres", "");
                store.dispatch("getAuthors", "")

        },
        methods:{
            searchGenre(){
                store.dispatch("getGenres", this.name)

            },
            validate(){
                this.error = {
                    name: null, 
                }

                if(!this.name)
                {
                    this.error["name"]= true;
                    return false
                }
                return true
            },
            flterBook(id){
                var book = this.books.filter(x => x["id"] == id)[0]
                book['genre'] = [book['genre']]
                book["file"] = book["filename"]
                
                this.form = book

            },
            modifyBook(id){
                this.modify = true
                this.flterBook(id);

            },
            getFile(event){
                this.form["file"] = event.target.files[0]
                
            },
            deleteBook(id){
                fetch(import.meta.env.VITE_BASEURL+"/admin/book/"+id, {
                        method: "DELETE",
                        headers: {
                            "Authentication-Token": store.getters.getToken,
                            "Content-Type": "application/json"
                        }
                }).then(x=>{
                    if(x.status == 200){
                        this.message = "Deleted Book successfully.";
                    }
                    else{
                        this.invalid_message = "Something went wrong."
                    }
                    store.dispatch("getBooks", this.name)
                }
                )
            },
            updateBook(){
                console.log(this.form)
                var form = new FormData();
                form.append("name", this.form["name"]);
                form.append("date", this.form["date"]);
                this.form["authors"].forEach(element => {
                    form.append("authors", element["id"])
                });
                form.append("book", this.form["file"]);
                form.append("genre", this.form["genre"][0]["id"])
                fetch(import.meta.env.VITE_BASEURL+"/admin/book/"+this.form["id"],
                    {
                        method: "PUT",
                        headers: {
                            "Authentication-Token": store.getters.getToken
                        },
                        body: form
                    }
                ).then(x =>{
                    if(x.status == 200){
                        this.message = "Updated Book successfully."
                    };
                    store.dispatch("getBooks", "");
                    this.modify = false;
                })
            }
        },
        computed:{
            genres(){
                return store.state.genres;
            },
            books(){
                if (!this.id)
                    return store.getters.getBooks;

                return store.getters.getBooks.filter(book => (book["genre"]["id"] == parseInt(this.id)));
                
            }
        }
    }
</script>
<style scoped>
    .mb-3{
        margin-top: 10px;
    }
    .btn-primary{
        width: 100%;
    }
</style>