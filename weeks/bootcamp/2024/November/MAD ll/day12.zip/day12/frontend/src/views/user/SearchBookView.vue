<script setup>
    import store from "@/store"
</script>
<template>
    <div class="alert alert-success" v-show="message">
        {{ message }}
    </div>
    <div class="alert alert-danger" v-show="invalid_message">
        {{ invalid_message }}
    </div>
    <div class="container-fluid">
        <div class="card" style="margin-top: 15px;">
            <div class="card-body">
                <div class="row">
                    <div class="col" style="min-width: 60%;">
                      <input type="text" class="form-control" placeholder="Genre" aria-label="Genre" v-model="name">
                    </div>
                    <div class="col">
                        <select class="form-select" aria-label="Default select example" v-model="option">
                            <option selected default>Book</option>
                            <option>Genre</option>
                            <option>Author</option>
                        </select>
                    </div>
                    <div class="col">
                      <input type="button" class="btn btn-primary" value="Search" @click="search=true">
                    </div>
                </div>
            </div>
        </div>
        <table class="table">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">Genre</th>
                <th scope="col">Authors</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="book in searchBooks">
                <th scope="row">{{ book.id }}</th>
                <td>{{ book.name }}</td>
                <td>{{ book.genre["name"] }}</td>
                <td>
                    <div class="col" style="display: flex;">
                        <span class="badge text-bg-primary" style="margin-left: 5px;" v-for="author in book.authors">
                            {{ author['name'] }}
                        </span>
                    </div>
                </td>
                <td>
                    <div class="col" style="display: flex;">
                        <button class="btn btn-success" @click="makeRequest(book.id)">
                            Request
                        </button>
                    </div>
                </td>
              </tr>
            </tbody>
          </table>
          <h2 align="center" style="margin: 10px 0px 10px 0px;">Requested Books</h2>
        <table class="table">
            <thead>
                <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">Genre</th>
                <th scope="col">Authors</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="book in requestedBooks">
                <th scope="row">{{ book.id }}</th>
                <td>{{ book.name }}</td>
                <td>{{ book.genre["name"] }}</td>
                <td>
                    <div class="col" style="display: flex;">
                        <span class="badge text-bg-primary" style="margin-left: 5px;" v-for="author in book.authors">
                            {{ author['name'] }}
                        </span>
                    </div>
                </td>
                <td v-if="store.getters.getBookRequests.some(x => x['book-id'] == book.id && x['status'])">
                    <button class="btn btn-primary" @click="renderfile(book.id)">
                        View
                    </button>
                </td>
                </tr>
            </tbody>
        </table>
        <div class="modal" tabindex="-1" style="display: block;min-height: 90vh;" v-show="view">
            <div class="modal-dialog-lg">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Modal title</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" @click="view=false"></button>
                </div>
                <div class="modal-body">
                    <iframe :src="filename" width="100%" style="min-height: 90vh;"></iframe>
                </div>
              </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        props: ["id"],
        data(){
            return {
                view:false,
                name: null,
                message: null,
                invalid_message: null,
                option: "Book",
                search: true,
                books: [],
                filename: null
            }
        },
        created(){
                store.dispatch("getBooks", "");
                store.dispatch("getGenres", "");
                store.dispatch("getAuthors", "")
                store.dispatch("getBookRequests")

        },
        methods:{
            searchGenre(){
                store.dispatch("getGenres", this.name)

            },
            validate(){
                this.error = {
                    name: null, 
                }

                if(!this.name)
                {
                    this.error["name"]= true;
                    return false
                }
                return true
            },
            flterBook(id){
                var book = this.books.filter(x => x["id"] == id)[0]
                book['genre'] = [book['genre']]
                book["file"] = book["filename"]
                
                this.form = book

            },
            makeRequest(id){
                fetch(import.meta.env.VITE_BASEURL+"/user/book/"+id,
                    {
                        method: "GET",
                        headers: {
                            "Authentication-Token": store.getters.getToken
                        },
                    }
                ).then(x => {
                    store.dispatch("getBookRequests")
                })
            },
            renderfile(id){
                this.view = true;
                this.filename = import.meta.env.VITE_BASEURL+"/user/book/"+id+"/view?auth_token="+store.getters.getToken
            }
        },
        computed:{
            searchBooks(){
                
                if (!this.search || this.name == null)
                    return store.getters.getBooks.filter(x => !store.getters.getBookRequests.some(r => r["book-id"] == x["id"]));

                if (this.option == "Book")
                    this.books = store.getters.getBooks.filter(x => x["name"].includes(this.name));

                if (this.option == "Genre")
                    this.books = store.getters.getBooks.filter(x => x["genre"]["name"].includes(this.name));

                if (this.option == "Author")
                    this.books = store.getters.getBooks.filter(x => x["authors"].some(author => author["name"].includes(this.name || "")));
                
                this.books = this.books.filter(x => !store.getters.getBookRequests.some(r => r["id"] == x["id"]))
                return this.books
            },
            requestedBooks(){
                return store.getters.getBooks.filter(x => store.getters.getBookRequests.some(r => r["book-id"] == x["id"]))
            }
        },
    }
</script>
<style scoped>
    .mb-3{
        margin-top: 10px;
    }
    .btn-primary{
        width: 100%;
    }
    .card{
        margin: 0px 10px 0px 10px;
        margin-bottom: 10px
    }
</style>