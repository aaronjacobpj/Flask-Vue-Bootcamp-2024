<script setup>
    import store from "@/store"
</script>
<template>
  <div>
    <apexchart
      width="500"
      type="bar"
      :options="chartOptions"
      :series="series"
    ></apexchart>
  </div>
</template>
<script>
export default {
    created(){
        store.dispatch("getBookRequests");
    },
    data: function () {
        return {
            data: []
        }
    },
    computed:{
        chartOptions(){
            var freq = {}
            for (let each of store.getters.getBookRequests){
                if(freq[each['date']])
                    freq[each["date"]]++;
                else
                    freq[each["date"]] = 1;
            }
            return  {
                chart: {
                    id: "vuechart-example",
                    },
                    xaxis: {
                    categories: Object.keys(freq),
                }
            }
        },
        series(){
            var freq = {}
            for (let each of store.getters.getBookRequests){
                if(freq[each['date']])
                    freq[each["date"]]++;
                else
                    freq[each["date"]] = 1;
            }
            return [
                {
                    name: "Book requests",
                    data: Object.values(freq),
                }
            ]
        }
    }
};
</script>