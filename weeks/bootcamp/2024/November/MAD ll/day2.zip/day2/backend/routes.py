from flask import Blueprint, current_app as app, request
from flask_security import roles_required, auth_required, current_user, login_user
from models import db, Reminder

from werkzeug.security import generate_password_hash, check_password_hash



api = Blueprint("api", __name__)


@api.route("/signup", methods=["POST"])
def signup():
    username = request.json.get('username')
    password = request.json.get("password")

    role = app.security.datastore.find_role("user")
    user = app.security.datastore.create_user(username=username, password=generate_password_hash(password))
    app.security.datastore.add_role_to_user(user, role)
    db.session.commit()

    return "Created user successfully", 201


@api.route("/signin", methods=["POST"])
def signin():
    username = request.json.get('username')
    password = request.json.get("password")

    user = app.security.datastore.find_user(username=username)
    login_user(user)

    if  not check_password_hash(user.password, password):
        return {"message": "User not found"}, 404
    
    return {
        "token": user.get_auth_token()
    }


@api.route("/reminder", methods=["GET", "POST"])
# @auth_required("token")
@roles_required("user")
def reminder():
    if request.method == "GET":
        reminders = Reminder.query.filter_by(user_id=current_user.id).all()

        return [reminder.reminder for reminder in reminders]
    

    reminder = Reminder(user_id=current_user.id, 
                        reminder=request.json.get("reminder"))
    db.session.add(reminder)
    db.session.commit()

    return "Created reminder successfully."