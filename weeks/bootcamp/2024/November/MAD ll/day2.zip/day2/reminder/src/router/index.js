import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue';
import RegisterView from "@/views/RegisterView.vue";
import LoginView from "@/views/LoginView.vue";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView,
    },
    {
      path: '/signup',
      name: 'signup',
      component: RegisterView,
    },
    {
      path: '/signin',
      name: 'signin',
      component: LoginView,
    }
  ],
})

router.beforeEach((to, form) =>{
  if (!localStorage.getItem("token") && (!["signup", "signin"].includes(to.name))){
    return {name: "signin"}
  }
})

export default router
