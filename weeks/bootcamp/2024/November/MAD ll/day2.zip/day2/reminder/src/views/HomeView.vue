<script setup>
</script>

<template>
  <main>
    <ul class="list-group list-group-flush">
      <li class="list-group-item" v-for="reminder in reminders">{{ reminder}}</li>
    </ul>
    <div class="row">
      <form @submit.prevent="addReminder">
        <div class="row">
          <input type="text" v-model="reminder" placeholder="Reminder" class="form-control">
        </div>
        <div class="row">
          <input type="submit" value="Add" class="btn btn-primary">
        </div>
      </form>
    </div>
  </main>
</template>
<script>
  export default{
    data(){
      return {
        reminder: null,
        reminders: []
      }
    },
    created(){
      this.getReminder()
    },
    methods:{
      getReminder(){
        fetch(import.meta.env.VITE_BASEURL+"/reminder",{
          headers: {
            "Authentication-Token": localStorage.getItem("token")
          }
        }).then(x => x.json())
        .then(x=> this.reminders = x)
      },
      addReminder(){
        fetch(import.meta.env.VITE_BASEURL+"/reminder",{
          method: "POST",
          headers: {
            "Authentication-Token": localStorage.getItem("token"),
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            reminder: this.reminder
          })
        }).then(x =>{
          if (x.status == 200){
            this.getReminder()
          }
        })
      }
    }
  }
</script>
<style scoped>
  .row{
    margin-top: 10px;
  }
</style>