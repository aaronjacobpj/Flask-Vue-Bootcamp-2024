<script setup>
import router from "@/router"
</script>
<template>
    <div class="container-fluid" style="height: 100vh;">
        <form class="signup-form" @submit.prevent="signup">
            <div class="row">
                <input type="text" placeholder="username" class="form-control" v-model="username">
            </div>
            <div class="row">
                <input type="password" placeholder="password" class="form-control" v-model="password">
            </div>
            <div class="row">
                <input type="submit" value="Sign up" class="btn btn-primary">
            </div>
        </form>

    </div>

</template>
<script>
    export default{
        data(){
            return{
                username: null,
                password: null
            }
        },
        methods: {
            signup(){
                fetch(import.meta.env.VITE_BASEURL+"/signup", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        username: this.username,
                        password: this.password
                    })
                }).then(x => {
                    if(x.status == 201){
                        router.push({name: "signin"})
                    }
                })

            }
        }
    }
</script>
<style scoped>
    .container-fluid{
        align-items: center !important;
        display: flex !important;
        justify-content: center !important;
        height: 100vh !important;
    }
    .row{
        margin-top: 10px;
    }
</style>