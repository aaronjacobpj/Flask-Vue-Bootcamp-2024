<script setup>
    import router from "@/router"
</script>
<template>
    <div class="container-fluid">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title" align="center">Sign Up</h4>
                <form @submit.prevent="signup">
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Name</label>
                        <input type="text" class="form-control" id="formGroupExampleInput" 
                        v-model="name" placeholder="Full Name">
                        <div class="invalid-feedback" v-show="error['name']" style="display: block;">
                            Required Field
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="formGroupExampleInput2" class="form-label">Email</label>
                        <input type="text" class="form-control" id="formGroupExampleInput2" 
                        v-model="username" placeholder="abcd@example.com">
                        <div class="invalid-feedback" v-show="error['username']" style="display: block;">
                            Required Field
                        </div>                        
                        <div class="invalid-feedback" v-show="error['valid']" style="display: block;">
                           Username Taken.
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Password</label>
                        <input type="text" class="form-control" id="formGroupExampleInput" 
                        v-model="password" placeholder="password">
                        <div class="invalid-feedback" v-show="error['password']" style="display: block;">
                            Required Field
                        </div>
                    </div>
                    <div class="mb-3">
                        <input type="submit" class="btn btn-primary" value="Sign Up" style="width: 100%;">
                    </div>
                </form>
            </div>
        </div> 
    </div>
</template>
<script>
    export default {
        data(){
            return {
                username: null,
                name: null,
                password: null,
                error:{
                    username: null,
                    name: null,
                    password: null,
                    valid: null
                }
            }
        },
        methods: {
            signup(){
                if(!this.validate())
                    return false;
                fetch(import.meta.env.VITE_BASEURL+"/signup", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        name: this.name,
                        password: this.password,
                        username: this.username
                    })
                }).then(x =>{
                    if(x.status == 201){
                        router.push({name: "login"})
                    }
                    else if(x.status == 400){
                        this.validate();
                    }
                    else if (x.status == 409){
                        this.error['valid'] = true;
                    }
                })
            },
            validate(){
                this.error = {
                    username: null,
                    name: null,
                    password: null,
                    valid: null
                }

                if(!this.username){
                    this.error['username'] = true;
                    return false
                }
                if(!this.name){
                    this.error['name'] = true;
                    return false
                }
                if(!this.password){
                    this.error['password'] = true;
                    return false
                }
                else
                    return true
            }
        }
    }
</script>
<style scoped>
    .container-fluid{
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }
</style>