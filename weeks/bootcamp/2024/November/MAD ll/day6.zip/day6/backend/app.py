from flask import Flask
from flask_security import SQLAlchemyUserDatastore, Security
from models import db, User, Role
from flask_cors import CORS
from werkzeug.security import generate_password_hash

from routes import api



def create_app():

    app = Flask(__name__)
    
    CORS(app)

    app.config['SECRET_KEY'] = "usebfsknerskdln"
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///model.db'

    db.init_app(app)

    datastore = SQLAlchemyUserDatastore(db, User, Role)
    app.security = Security(app, datastore)

    with app.app_context():
        db.create_all()


        if not app.security.datastore.find_role("admin"):
            admin = app.security.datastore.create_role(name="admin")
            app.security.datastore.create_role(name="user")
            alice = app.security.datastore.create_user(name="Alice", 
                                                       username="alice", 
                                                       password=generate_password_hash("alice"))

            app.security.datastore.add_role_to_user(alice, admin)

            db.session.commit()

    app.register_blueprint(api)


    return app



app = create_app()
