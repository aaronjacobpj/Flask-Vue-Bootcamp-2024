from flask_security import RoleMixin, UserMixin
from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()


class User(db.Model, UserMixin):

    __tablename__ = "user"

    id = db.Column(db.Integer(), primary_key=True)
    username = db.Column(db.String(), unique=True)
    name = db.Column(db.String())
    password = db.Column(db.String())
    fs_uniquifier = db.Column(db.String(), unique=True)
    active = db.Column(db.Boolean())
    roles = db.relationship("Role", secondary="roles_user", backref="user")


    def get_roles(self):
        return [role.name for role in self.roles]


class RolesUser(db.Model):

    __tablename__ = "roles_user"

    id = db.Column(db.Integer(), primary_key=True)
    user_id = db.Column(db.Integer(), db.ForeignKey("user.id"))
    role_id = db.Column(db.Integer(), db.ForeignKey("role.id"))


class Role(db.Model, RoleMixin):

    __tablename__ = "role"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), unique=True)


class Book(db.Model):

    __tablename__ = "book"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String())
    filename = db.Column(db.String(), unique=True)
    genre_id = db.Column(db.Integer(),  db.ForeignKey("genre.id"), nullable=False)
    date_issued = db.Column(db.Date())
    genre = db.relationship("Genre", backref="books")
    authors = db.relationship("Author", secondary="book_author", backref="books")


    def get_author_ids(self):
        return [author.id for author in self.authors]


class Genre(db.Model):

    __tablename__ = "genre"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String())
    date = db.Column(db.Date())
    description = db.Column(db.String())


class Author(db.Model):

    __tablename__ = "author"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String())


class BookAuthor(db.Model):

    __tablename__ = "book_author"
    
    id = db.Column(db.Integer(), primary_key=True)
    book_id = db.Column(db.Integer(), db.ForeignKey("book.id"))
    author_id = db.Column(db.Integer(), db.ForeignKey("author.id"))


class BookRequest(db.Model):

    __tablename__ = "book_request"

    id = db.Column(db.Integer(), primary_key=True)
    book_id = db.Column(db.Integer(), db.ForeignKey("book.id"))
    user_id = db.Column(db.Integer(), db.ForeignKey("user.id"))
    date = db.Column(db.Date())
    access = db.Column(db.Boolean())
    rating = db.Column(db.Integer())

