import { createRouter, createWebHistory } from 'vue-router'
import store from '@/store';
import LoginView from '../views/LoginView.vue'
import RegisterView from "@/views/RegisterView.vue";
import AdminLayoutView from '@/views/admin/AdminLayoutView.vue'
import UserLayoutView from '@/views/user/UserLayoutView.vue'
import CreateGenreView from "@/views/admin/CreateGenreView.vue"
import GenreManagementView from "@/views/admin/GenreManagementView.vue"
import CreateBookView from "@/views/admin/CreateBookView.vue";
import AuthorManagementView from "@/views/admin/AuthorManagementView.vue";
import BookManagementView from "@/views/admin/BookManagementView.vue";


const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'login',
      component: LoginView,
    },
    {
      path: '/signup',
      name: 'signup',
      component: RegisterView,
    },
    {
      path: "/admin",
      name: "admin",
      component: AdminLayoutView,
      children: [
        {
          path: "",
          name: "admin-dashboard",
          component: LoginView
        },
        {
          path: "genre/create",
          name: "admin-create-genre",
          component: CreateGenreView
        },
        {
          path: "genre",
          name: "admin-manage-genre",
          component: GenreManagementView
        },
        {
          path: "book/create",
          name: "admin-create-book",
          component: CreateBookView
        },
        {
          path: "author",
          name: "admin-manage-author",
          component: AuthorManagementView
        },
        {
          path: "book",
          name: "admin-manage-book",
          component: BookManagementView
        }
      ]
    },
    {
      path: "/user",
      name: "user",
      component: UserLayoutView
    }
  ],
})

router.beforeEach((to, from)=>{
  if(to.fullPath.startsWith("/admin") && !store.getters.getRoles.includes("admin"))
    router.push({name: "login"})
  if(to.fullPath.startsWith("/user") && !store.getters.getRoles.includes("user"))
    router.push({name: "login"})
})

export default router
