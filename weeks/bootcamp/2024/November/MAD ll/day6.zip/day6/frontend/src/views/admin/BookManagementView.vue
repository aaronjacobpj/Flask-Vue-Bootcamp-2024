<script setup>
    import store from "@/store"
</script>
<template>
    <div class="alert alert-success" v-show="message">
        {{ message }}
    </div>
    <div class="alert alert-danger" v-show="invalid_message">
        {{ invalid_message }}
    </div>
    <div class="container-fluid">
        <table class="table">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">Genre</th>
                <th scope="col">Authors</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="book in books">
                <th scope="row">{{ book.id }}</th>
                <td>{{ book.name }}</td>
                <td>{{ book.genre["name"] }}</td>
                <td>
                    <div class="col" style="display: flex;">
                        <span class="badge text-bg-primary" style="margin-left: 5px;" v-for="author in book.authors">
                            {{ author['name'] }}
                        </span>
                    </div>
                </td>
                <td>
                    <button class="btn btn-outline-warning" >
                        Modify
                    </button>
                </td>
                <td>
                    <button class="btn btn-outline-danger" >
                        Delete
                    </button>
                </td>
              </tr>
            </tbody>
          </table>
          <div class="modal" tabindex="-1" style="display: block;" v-show="modify">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Modify Genre</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" @click="modify=false"></button>
                </div>
                <form @submit.prevent="updateGenre">
                    <div class="modal-body">
                        <div class="row mb-3">
                            <div class="col" style="min-width: 80%;">
                                <label for="formGroupExampleInput" class="form-label">Genre</label>
                                <input type="text" class="form-control" placeholder="Genre" aria-label="Genre"
                                 v-model="form['name']">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col" style="min-width: 80%;">
                                <label for="formGroupExampleInput" class="form-label">Description</label>
                                <input type="text" class="form-control" placeholder="Description" aria-label="Description"
                                 v-model="form['description']">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
              </div>
            </div>
          </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                name: "",
                message: null,
                invalid_message: null,
                form: {
                    name: null,
                    description: null
                },
                modify: false
            }
        },
        created(){
                store.dispatch("getBooks", "");
                store.dispatch("getGenres", "");
                store.dispatch("getAuthors", "")

        },
        methods:{
            searchGenre(){
                store.dispatch("getGenres", this.name)

            },
            validate(){
                this.error = {
                    name: null, 
                }

                if(!this.name)
                {
                    this.error["name"]= true;
                    return false
                }
                return true
            },
            flterGenre(id){
                var genre = this.genres.filter(x => x.id == id)[0];
                
                this.form = genre

            },
            modifyGenre(id){
                this.modify = true
                this.flterGenre(id);

            },
            updateGenre(){
                fetch(import.meta.env.VITE_BASEURL+"/admin/genre/"+this.form["id"], {
                        method: "PUT",
                        headers: {
                            "Authentication-Token": store.getters.getToken,
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({name: this.form["name"], 
                        description: this.form["description"]})
                    }).then(x =>{
                      if(x.status == 200){
                        this.message = "Updated Genre successfully.";
                        this.modify = false;
                      }
                      else{
                        this.invalid_message = "Something went wrong."
                      }
                      store.dispatch("getGenre", this.name)
                    })
            },
            deleteGenre(id){
                fetch(import.meta.env.VITE_BASEURL+"/admin/genre/"+id, {
                        method: "DELETE",
                        headers: {
                            "Authentication-Token": store.getters.getToken,
                            "Content-Type": "application/json"
                        }
                }).then(x=>{
                    if(x.status == 200){
                        this.message = "Deleted Genre successfully.";
                    }
                    else{
                        this.invalid_message = "Something went wrong."
                    }
                    store.dispatch("getGenres", this.name)
                }
                )
            }
        },
        computed:{
            genres(){
                return store.state.genres;
            },
            books(){
                return store.getters.getBooks;
            }
        }
    }
</script>
<style scoped>
    .mb-3{
        margin-top: 10px;
    }
    .btn-primary{
        width: 100%;
    }
</style>