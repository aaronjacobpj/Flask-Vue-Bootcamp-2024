<script setup>
    import { RouterView, RouterLink } from "vue-router";
</script>
<template>
    <div class="container-fluid">
        <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
              <a class="navbar-brand" href="#">Navbar</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                  <li class="nav-item">
                    <RouterLink class="nav-link active" aria-current="page" to="/admin/author">Authors</RouterLink>
                  </li>
                  <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      Genre
                    </a>
                    <ul class="dropdown-menu">
                      <li><RouterLink class="dropdown-item" to="/admin/genre/create">Add</RouterLink></li>
                      <li><RouterLink class="dropdown-item" to="/admin/genre/">Search</RouterLink></li>
                    </ul>
                  </li>
                  <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      Books
                    </a>
                    <ul class="dropdown-menu">
                      <li><RouterLink class="dropdown-item" to="/admin/book/create">Add</RouterLink></li>
                      <li><RouterLink class="dropdown-item" to="/admin/book/">Search</RouterLink></li>
                    </ul>
                  </li>
                  <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      Dropdown link
                    </a>
                    <ul class="dropdown-menu">
                      <li><a class="dropdown-item" href="#">Action</a></li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
        </nav>
        <RouterView/>
    </div>
</template>