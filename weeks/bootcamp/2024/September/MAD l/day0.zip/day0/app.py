from flask import Flask, render_template, request, session
from sqlalchemy.sql.expression import func

from models import db, User, Reminder


app = Flask(__name__)
app.config["SECRET_KEY"] = "sdbknkvdsn"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///project.db"

db.init_app(app)

with app.app_context():
    db.create_all()


@app.route("/", methods=["GET", "POST"])
def index():

    if "user-id" not in session:
        user = User(name="User")
        db.session.add(user)
        db.session.flush()
        session["user-id"] = user.id
        session.update()

    if request.form.get("reminder"):

        reminder = Reminder(user_id=session.get("user-id"),
                reminder=request.form.get("reminder"))
        db.session.add(reminder)
        db.session.commit()

    user = User.query.get(session.get("user-id"))
    reminders = Reminder.query.filter_by(user_id=session.get("user-id"))

    return render_template("index.html", reminders=reminders, user=user)


@app.route("/form")
def add_reminder():
    return render_template("form.html")



if __name__ == "__main__":
    app.run(debug=True)