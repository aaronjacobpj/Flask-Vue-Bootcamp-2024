from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class Reminder(db.Model):
    __tablename__ = "reminder"

    id = db.Column(db.Integer(), primary_key=True)
    user_id = db.Column(db.Integer(), foreign_key="user.id", nullable=False)
    reminder = db.Column(db.String())


class User(db.Model):
    __tablename__ = "user"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String())
