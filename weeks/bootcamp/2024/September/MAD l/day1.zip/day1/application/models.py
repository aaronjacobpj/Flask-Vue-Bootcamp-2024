from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class User(db.Model):
    __tablename__ = "user"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), nullable=False)
    username = db.Column(db.String(), unique=True, nullable=False)
    password = db.Column(db.String(), nullable=False)


class Roles(db.Model):
    __tablename__ = "role"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), nullable=False, unique=True)


class RolesUsers(db.Model):
    __tablename__ = "roles_user"

    id = db.Column(db.Integer(), primary_key=True)
    user_id = db.Column(db.Integer(), db.ForeignKey("user.id")) 
    role_id = db.Column(db.Integer(), db.ForeignKey("role.id")) 


class Venues(db.Model):
    __tablename__ = "venue"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), nullable=False)
    capacity = db.Column(db.Integer(), nullable=False)


class Show(db.Model):
    __tablename__ = "show"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), nullable=False)
    image = db.Column(db.String())
    venue_id = db.Column(db.Integer(), db.ForeignKey("venue.id"))


class Tickets(db.Model):
    __tablename__ = "tickets"

    id = db.Column(db.Integer(), primary_key=True)
    user_id = db.Column(db.Integer(), db.ForeignKey("user.id"))
    show_id = db.Column(db.Integer(), db.ForeignKey("show.id"))
    tickets = db.Column(db.Integer(), nullable=False)