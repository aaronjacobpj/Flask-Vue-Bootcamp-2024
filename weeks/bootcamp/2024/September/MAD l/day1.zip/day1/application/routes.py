from flask import Blueprint, render_template, session, request, flash, redirect
from application.models import db, User
from sqlalchemy.sql.expression import func
from werkzeug.security import check_password_hash

from application.utils import login_required


api = Blueprint("api", __name__)

@api.route("/", methods=["GET", "POST"])
def index():
    if request.method == "GET":
        return render_template("login.html")
    
    username = request.form.get("username", None)
    password = request.form.get("password", None)

    if not username or not password:
        flash("Field required.", "error")
        return render_template("login.html", 
                               username=username, 
                               password=password)
    
    user = User.query.filter_by(username=username).first()
    
    if not user or not check_password_hash(user.password, password):
        flash("Username or password doesn't match", "error")
        return render_template("login.html", 
                               username=username, 
                               password=password)
    
    session["user-id"] = user.id
    return redirect("/user")


@api.route("/user")
@login_required
def user():
    session.clear()
    return "Hello"
