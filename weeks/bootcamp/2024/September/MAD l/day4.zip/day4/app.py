from flask import Flask

from application.routes import api, db
from application.models import User, Roles, RolesUsers
from werkzeug.security import generate_password_hash


app = Flask(__name__)
app.config["SECRET_KEY"] = "sdbknkvdsn"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///project.db"

db.init_app(app)

with app.app_context():
    db.create_all()


app.register_blueprint(api)

with app.app_context():
    if not User.query.filter_by(username="alice").first():
        user = User(name="Alice", username="alice", password=generate_password_hash("alice"))
        admin = Roles(name="admin")
        user_role = Roles(name="user")
        db.session.add_all([admin, user_role, user])
        db.session.flush()
        db.session.add(RolesUsers(user_id=user.id, role_id=admin.id))
        db.session.commit()



if __name__ == "__main__":
    app.run(debug=True)