from flask import Blueprint, render_template, session, request, flash, redirect
from sqlalchemy.sql.expression import func
from werkzeug.security import check_password_hash, generate_password_hash
import os

from application.models import db, User, RolesUsers, Roles, Show, Venues, Tickets
from application.utils import login_required, get_filename


api = Blueprint("api", __name__)

@api.route("/", methods=["GET", "POST"])
def index():
    if request.method == "GET":
        return render_template("login.html")
    
    username = request.form.get("username", None)
    password = request.form.get("password", None)

    if not username or not password:
        flash("Field required.", "error")
        return render_template("login.html", 
                               username=username, 
                               password=password)
    
    user = User.query.filter_by(username=username).first()
    
    if not user or not check_password_hash(user.password, password):
        flash("Username or password doesn't match", "error")
        return render_template("login.html", 
                               username=username, 
                               password=password)
    
    session["user-id"] = user.id

    if "user" in user.get_roles():
        return redirect("/user")
    else:
        return redirect("/admin")


@api.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "GET":
        return render_template("register.html")
    
    name = request.form.get("name", None)
    username = request.form.get("username", None)
    password = request.form.get("password", None)

    if not name or not username or not password:
        flash("Field required.", "error")
        return render_template("register.html", 
                                name=name,
                                username=username, 
                                password=password)

    if User.query.filter_by(username=username).first():
        flash("username already exist.", "error-username")
        return render_template("register.html", 
                                name=name,
                                username=username, 
                                password=password)
    

    user = User(name=name,
                username=username,
                password=generate_password_hash(password))
    db.session.add(user)
    db.session.flush()
    role = Roles.query.filter_by(name="user").first()
    db.session.add(RolesUsers(user_id=user.id,
                              role_id=role.id))
    db.session.commit()

    return redirect("/")



@api.route("/admin")
@login_required
def admin():
    theatres = Venues.query.all()
    return render_template("admin/theatre.html", 
                           theatres=theatres)


@api.route("/admin/theatre", methods=["POST"])
@login_required
def create_theatre():
    name = request.form.get("name", None)
    capacity = request.form.get("capacity", None, type=int)

    if not name or not capacity or not (isinstance(capacity, int) and  0 < capacity < 500):

        flash("Invalid input.", "error")
        return render_template("admin/theatre.html", 
                               name=name,
                               capacity=capacity)
    
    db.session.add(Venues(name=name, capacity=capacity))
    db.session.commit()
    return redirect("/admin")


@api.route("/admin/theatre/<int:theatre_id>/delete")
@login_required
def delete_theatre(theatre_id):
    theatre = db.session.query(Venues).get(theatre_id)

    if not theatre:
        flash("Invalid Theatre.", "alert-danger")
        return redirect("/admin")
    
    db.session.delete(theatre)
    db.session.commit()

    flash("Deleted Theatre successfully.", "alert-success")
    return redirect("/admin")

@api.route("/admin/theatre/<int:theatre_id>", methods=["GET", "POST"])
@login_required
def update_theatre(theatre_id):

    if request.method == "GET":
        theatres = Venues.query.all()
        theatre = db.session.query(Venues).get(theatre_id)
        return render_template("/admin/theatre.html", 
                               theatres=theatres,
                               theatre=theatre)

    name = request.form.get("name", None)
    capacity = request.form.get("capacity", None, type=int)

    if not name or not capacity or not (isinstance(capacity, int) and  0 < capacity < 500):

        flash("Invalid Input.", "alert-danger")
        return redirect("/admin")


    theatre = db.session.query(Venues).get(theatre_id)

    if not theatre:
        flash("Invalid Theatre.", "alert-danger")
        return redirect("/admin")
    
    theatre.name = name
    theatre.capacity = capacity
    db.session.commit()

    flash("Updated Theatre successfully.", "alert-success")    
    return redirect("/admin")



@api.route("/admin/movie", methods=["GET", "POST"])
@login_required
def create_movies():
    if request.method == "GET":
        theatres = Venues.query.all()
        movies = Show.query.all()
        return render_template("admin/movie.html", 
                               theatres=theatres,
                               movies=movies)
    
    theatre_id = request.form.get("theatre")
    name = request.form.get("title")
    file = request.files.get("poster")

    if not theatre_id or not name:
        flash("Invalid Input.", "alert-danger")
        return redirect("/admin/movie")
    
    theatre = db.session.query(Venues).get(theatre_id)
    if not theatre:
        flash("Invalid theatre.", "alert-danger")
        return redirect("/admin")
    
    check = os.listdir("static")
    extension = os.path.splitext(file.filename)[1]
    filename = get_filename() + extension
    while filename in check:
        filename = get_filename() + extension

    movie = Show(name=name,
                 venue_id=theatre_id,
                 image=filename
                 )
    file.save(os.path.join("static", filename))
    db.session.add(movie)
    db.session.commit()

    flash("Created Movie successfully.", "alert-success")    
    return redirect("/admin/movie")


@api.route("/admin/movie/<int:movie_id>", methods=["GET", "POST"])
@login_required
def update_movies(movie_id):

    movie = db.session.query(Show).get(movie_id)

    if not movie:
        flash("Invalid movie.", "alert-danger")
        return redirect("/admin/movie")
    
    if request.method == "GET":
        
        theatres = Venues.query.all()
        movies = Show.query.all()
        return render_template("admin/movie.html", 
                                theatres=theatres,
                                movies=movies,
                                movie=movie)
    
    theatre_id = request.form.get("theatre")
    name = request.form.get("title")
    file = request.files.get("poster")
    delete = request.form.get("delete", type=bool)
    print(delete)

    if delete and movie.image:
        os.remove(os.path.join("static", movie.image))
        movie.image = None

    if file:
        check = set(os.listdir("static"))
        extension = os.path.splitext(file.filename)[1]
        filename = get_filename() + extension

        while filename in check:
            filename = get_filename() + extension

        file.save(os.path.join("static", filename))
        movie.image = filename

    if not name or not db.session.query(Venues).get(theatre_id):
        flash("Invalid Input.", "alert-danger")
        return redirect("/admin/movie")
    
    movie.venue_id = theatre_id
    movie.name = name
    db.session.commit()

    flash("Updated Movie successfully.", "alert-success")    
    return redirect("/admin/movie")
            

@api.route("/admin/movie/<int:movie_id>/delete")
@login_required
def delete_movies(movie_id):

    movie = db.session.query(Show).get(movie_id)

    if not movie:
        flash("Invalid movie.", "alert-danger")
        return redirect("/admin/movie")
    
    db.session.delete(movie)
    db.session.commit()

    flash("Deleted Movie successfully.", "alert-success")    
    return redirect("/admin/movie")


@api.route("/user")
@login_required
def user_home():

    name = request.args.get("movie", None)
    if name:
        movies = Show.query.filter(Show.name.like(f"%{name}%")).all()
    else:
        movies = Show.query.all()
    return render_template("user/search.html", movies=movies)