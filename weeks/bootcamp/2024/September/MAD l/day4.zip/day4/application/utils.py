from flask import session, redirect
from functools import wraps
import random
from string import ascii_letters


MAX_LENGTH = 10

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user-id" not in session:
            return redirect("/")
        return f(*args, **kwargs)
    return decorated_function


def get_filename():
    result = ""
    for i in range(MAX_LENGTH):
        result += random.choice(ascii_letters)

    return result