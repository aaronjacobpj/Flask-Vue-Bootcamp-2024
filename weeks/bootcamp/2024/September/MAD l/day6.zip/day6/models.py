from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()


class User(db.Model):

    __tablename__ = "user"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), nullable=False)
    username = db.Column(db.String(), nullable=False, unique=True)
    password = db.Column(db.String(), nullable=False)


class UserRole(db.Model):

    __tablename__ = "roles_users"

    id = db.Column(db.Integer(), primary_key=True)
    user_id = db.Column(db.Integer(), db.ForeignKey("user.id"))
    role_id = db.Column(db.Integer(), db.ForeignKey("role.id"))


class Role(db.Model):

    __tablename__ = "role"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), nullable=False, unique=True)


class Book(db.Model):

    __tablename__ = "book"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), nullable=False, unique=True)
    date_issued = db.Column(db.Date())
    content = db.Column(db.String())
    genres = db.relationship("Genre", secondary="genres_books", backref="books")


class BookGenre(db.Model):
       
    __tablename__ = "genres_books"

    id = db.Column(db.Integer(), primary_key=True)
    book_id = db.Column(db.Integer(), db.ForeignKey("book.id"))
    genre_id = db.Column(db.Integer(), db.ForeignKey("genre.id"))


class Genre(db.Model):

    __tablename__ = "genre"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), nullable=False, unique=True)


class Author(db.Model):

    __tablename__ = "author"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), nullable=True)


class BookAuthor(db.Model):

    __tablename__ = "book_author"

    id = db.Column(db.Integer(), primary_key=True)
    book_id = db.Column(db.Integer(), db.ForeignKey("book.id"))
    author_id = db.Column(db.Integer(), db.ForeignKey("author.id"))


class Request(db.Model):

    __tablename__ = "request"

    id = db.Column(db.Integer(), primary_key=True)
    book_id = db.Column(db.Integer(), db.ForeignKey("book.id"))
    user_id = db.Column(db.Integer(), db.ForeignKey("user.id"))
    access_date = db.Column(db.Date())
    feedback = db.Column(db.String())
    access = db.Column(db.Boolean())