from app import *
import csv
import datetime


def insert_data():
    with app.app_context():
        insert_books()
        insert_genre()
        insert_book_genre()
        insert_authors()
        insert_book_authors()

        db.session.commit()


def insert_books():
    with open("books.csv") as file:
        reader = csv.DictReader(file)

        for row in reader:
            book = Book(name=row["name"], 
                        date_issued=datetime.datetime.strptime(row["date_issued"], "%Y-%m-%d").date(), 
                        content=row["content"])
            db.session.add(book)
        
    db.session.flush()


def insert_genre():
    with open("genre.csv") as file:
        reader = csv.DictReader(file)

        for row in reader:
            genre = Genre(name=row["name"])
            db.session.add(genre)

    db.session.flush()


def insert_book_genre():
    with open("book_genre.csv") as file:
        reader = csv.DictReader(file)

        for row in reader:
            book_genre =BookGenre(book_id=row["book_id"], genre_id=row["genre_id"])
            db.session.add(book_genre)

    db.session.flush()


def insert_authors():
    with open("authors.csv") as file:
        reader = csv.DictReader(file)

        for row in reader:
            author = Author(name=row["name"])
            db.session.add(author)

    db.session.flush()


def insert_book_authors():
    with open("book_author.csv") as file:
        reader = csv.DictReader(file)

        for row in reader:
            book_author =BookAuthor(book_id=row["book_id"], author_id=row["author_id"])
            db.session.add(book_author)

    db.session.flush() 



if __name__ == "__main__":
    insert_data()
