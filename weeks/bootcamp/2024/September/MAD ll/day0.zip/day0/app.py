from flask import Flask
from application.models import db, User, Role, RolesUsers
from flask_security import Security, SQLAlchemyUserDatastore, login_user, current_user

app = Flask(__name__)
# Use an in-memory db
app.config ['SECRET_KEY'] = "rgiegrinreingeori"
app.config ["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory"

db.init_app(app)

datastore = SQLAlchemyUserDatastore(db, User, Role)

app.security = Security(app, datastore)

with app.app_context():
    db.create_all()
    app.security.datastore.create_user(name="a", username="a", password="a")
    db.session.commit()


@app.route("/")
def index():
    login_user(app.security.datastore.find_user(username="a"))
    print(current_user)
    return "Hello"


if __name__ == "__main__":
    app.run(debug=True)