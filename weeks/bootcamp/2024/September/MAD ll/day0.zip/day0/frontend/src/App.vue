<script setup>
import { RouterLink, RouterView } from 'vue-router'
import store from "@/store";
import router from "@/router";
</script>

<template>
  <router-link :to="{name: 'register', params: {name: 'Charlie'}}">register</router-link>
  <router-link to="/">Home</router-link>
  <RouterView />
</template>
<script>
  export default {
    created(){
      store.dispatch('asyncSetMessage')
    }
  }
</script>
