import { createStore } from "vuex";


export default createStore({
    state(){
        return {
            message: "Hello, World!!"
        }
    },
    mutations: {
        setMessage(state, value){
            state.message = value;
        }
    },
    actions: {
        asyncSetMessage(context){
            setTimeout(() =>{
                context.commit("setMessage", "Hello, Charlie!");
            }, 2000)
        }
    }
})