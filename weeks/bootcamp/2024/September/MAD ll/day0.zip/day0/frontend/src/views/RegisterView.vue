<template>
    <h1>Hello, {{ message }}</h1>
    {{ count }}
    <h1>{{ date }}</h1>
    <button @click="counter">Counter</button>
</template>
<script>
    export default {
        props: ["name"],
        data(){
            return {
                count: 0
            }
        },
        created(){
            this.count = parseInt(sessionStorage.getItem("count")) || 1
        },
        methods: {

            counter(){
                this.count++;
                sessionStorage.setItem("count", this.count)
            }
        },
        computed: {
            message(){
                return (this.name)? this.name : "World!";
            },
            date(){
                this.count
                return new Date();
            },
        }
    }
</script>