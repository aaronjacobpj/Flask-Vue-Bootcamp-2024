from flask import Blueprint, request
from flask import current_app as app

from flask_security import current_user, login_user, roles_required
from werkzeug.security import generate_password_hash, check_password_hash


api = Blueprint("api", __name__)


@api.route("/signin", methods=["POST"])
def hello():
    username = request.json.get("username", None)
    password = request.json.get("password", None)

    if not username or not password:
        return {"message": "Invalid request"}, 400
    
    user = app.security.datastore.find_user(username=username)
    if not user or not check_password_hash(user.password, password):
        return {"message": "User not found"}, 404
    
    login_user(user)
    return {"token": user.get_auth_token(),
            "roles": user.get_roles()}