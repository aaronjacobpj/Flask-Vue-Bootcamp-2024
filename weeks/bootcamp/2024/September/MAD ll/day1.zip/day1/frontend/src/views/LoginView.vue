<script setup>
    import store from "@/store";
    import { RouterLink } from "vue-router";
</script>
<template>
    <div class="container-fluid">
        <div class="card">
            <div class="card-body">
                <h3 align="center"> Login
                </h3>
                <form @submit.prevent="login">
                    <div class="row">
                        <div class="col">
                          <input type="text" class="form-control" placeholder="Username" v-model="username">
                          <div class="invalid-feedback" :style="{display: (error['username']) ? 'block' : 'none' }">
                            Required field.
                          </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                          <input type="password" class="form-control" placeholder="First name" v-model="password">
                          <div class="invalid-feedback" :style="{display: (error['password']) ? 'block' : 'none' }">
                           Required field.
                          </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                          <input type="submit" class="btn btn-primary" placeholder="First name" aria-label="First name">
                        </div>
                    </div>
                    <div class="row">
                        <router-link to="/register" align="center">Register</router-link>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                username: null,
                password: null,
                error: {
                    username: null,
                    password: null
                }
            }
        },
        methods: {
            validate(){
                this.error = {
                    username: null,
                    password: null
                }
                if(!this.username){
                    this.error["username"] = true
                    return false
                }
                if(!this.password){
                    this.error["password"] = true
                    return false
                }
                return true
            },
            login(){
                console.log(import.meta.env.VITE_BASEURL);
                if(!this.validate())
                    return
                fetch(import.meta.env.VITE_BASEURL+'/signin', {method: "POST",
                    headers:{"Content-Type": "application/json"},
                    body: JSON.stringify({username: this.username, password: this.password})
                }).then(x =>{
                    if(x.status == 200){
                        return x.json();
                    }
                    return {}
                }).then(x =>{
                    store.commit('setUser', x);
                })
            }
        }

    }
</script>
<style scoped>
    .container-fluid{
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
    }
    .btn-primary{
        width: 100%;
    }
    .row{
        padding: 10px 0 10px 0;
    }
</style>