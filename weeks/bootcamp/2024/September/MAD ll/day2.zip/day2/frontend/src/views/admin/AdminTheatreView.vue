<script setup>
    import store from "@/store";
</script>
<template>
    <div class="card">
        <div class="card-body">
            <form @submit.prevent="create">
                <div class="mb-3">
                    <label for="formGroupExampleInput" class="form-label">Name</label>
                    <input type="text" class="form-control" id="formGroupExampleInput"
                        v-model="name" placeholder="Theatre Name">
                    <div class="invalid-feedback" :style="{display: (invalid) ? 'block' : 'none' }">
                        Invalid name or capacity.
                    </div>
                  </div>
                <div class="mb-3">
                    <label for="formGroupExampleInput2" class="form-label">Another label</label>
                    <input type="number" class="form-control" id="formGroupExampleInput2"
                        v-model="capacity" placeholder="Capacity">
                    <div class="invalid-feedback" :style="{display: (invalid) ? 'block' : 'none' }">
                        Invalid name or capacity.
                    </div>
                </div>
                <div class="row">
                    <div class="col"></div>
                    <div class="col"></div>
                    <div class="col">
                        <input type="submit" class="btn btn-primary" value="Submit">
                    </div>
                </div>
            </form>
        </div>
    </div>
    <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Theatre</th>
            <th scope="col">Capacity</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="theatre in store.state.theatres">
            <th scope="row">{{ theatre.id }}</th>
            <td>{{ theatre.name }}</td>
            <td>{{ theatre.capacity }}</td>
          </tr>
        </tbody>
      </table>
</template>
<script>
    export default {
        data(){
            return {
                name: null,
                capacity: null,
                invalid: false
            }
        },
        created(){
            store.dispatch("getTheatres");
        },
        methods: {
            create(){
                this.invalid = false
                fetch(import.meta.env.VITE_BASEURL+"/admin/theatre", {
                    headers: {"Content-Type": "application/json"},
                    method: "POST",
                    body: JSON.stringify({name: this.name, capacity: this.capacity})
                }).then(x =>{
                    if (x.status == 400){
                        this.invalid = true
                    }
                    else if(x.status == 201){
                        store.dispatch("getTheatres");
                    }
                })
            }
        }
    }
</script>
<style>
    .card{
        margin: 15px 10px 15px 10px;
    }
    .btn{
        width: 100%;
    }
</style>