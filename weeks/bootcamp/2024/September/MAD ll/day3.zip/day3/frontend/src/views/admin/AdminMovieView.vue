<script setup>
    import store from "@/store";
</script>
<template>
    <div class="alert alert-success" role="alert" v-if="alert['success']">
        {{ alert["success"] }}
     </div>
     <div class="alert alert-danger" role="alert" v-if="alert['danger']">
        {{ alert["danger"] }}
     </div>
     <div class="card">
         <div class="card-body">
             <div class="row">
                <div class="col" style="max-width: 30% !important;">
                    <img :src="image" v-if="image"class="img-thumbnail" alt="...">
                </div>
                <div class="col">
                    <form @submit.prevent="create">
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Name</label>
                            <input type="text" class="form-control" id="formGroupExampleInput"
                                v-model="name" placeholder="Theatre Name">
                            <div class="invalid-feedback" :style="{display: (invalid) ? 'block' : 'none' }">
                                Invalid name.
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Poster</label>
                            <input type="file" class="form-control" id="formGroupExampleInput2"
                                @change="get_image" placeholder="Poster">
                        </div>
                        <div class="row">
                            <div class="col"></div>
                            <div class="col"></div>
                            <div class="col">
                                <input type="submit" class="btn btn-primary" value="Submit">
                            </div>
                        </div>
                    </form>
                </div>
             </div>
         </div>
     </div>
</template>
<script>
    export default {
        data(){
            return {
                name: null,
                image: null,
                file: null,
                invalid: false,
                alert: {
                    success: null,
                    danger: null
                },
            }
        },
        methods:{
            create(){
                var form = new FormData();
                form.append("name", this.name)
                form.append("image", this.file)
                fetch(import.meta.env.VITE_BASEURL+"/admin/movie",
                    {
                        method: "POST",
                        headers: {
                            "Authentication-Token": store.getters.getToken,
                        },
                        body: form
                    },
                    
                ).then(x =>{
                    if(x.status == 201){
                        this.alert["success"] = "Created movie successfully."
                    }
                    else{
                        this.alert["success"] = "Something went wrong."
                    }
                })

            },
            get_image(event){
                
                var input = event.target;
                var reader = new FileReader();
                reader.addEventListener('load', (event) => {
                    this.image = event.target.result;
                });
                reader.readAsDataURL(input.files[0]);
                this.file = event.target.files[0];
            }
        }
    }
</script>
