import random
import string

MAX_LENGTH = 10

def get_filename():
    return "".join(random.choices(string.ascii_letters, 
                                  k=MAX_LENGTH))