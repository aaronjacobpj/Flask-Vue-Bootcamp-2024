<script setup>
import { RouterLink, RouterView } from 'vue-router'
import store from "@/store";
import router from "@/router";
</script>

<template>
  <RouterView />
</template>
<script>
  export default {
    created(){
        store.commit('setUser', 
          JSON.parse(localStorage.getItem('user') || "{}")
        )
    }
  }
</script>
