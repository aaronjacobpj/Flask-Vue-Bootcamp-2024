import { createRouter, createWebHistory } from 'vue-router'
import store from '@/store';
import LoginView from "@/views/LoginView.vue";
import RegisterView from "@/views/RegisterView.vue";
import AdminView from "@/views/admin/AdminView.vue";
import AdminTheatreView from "@/views/admin/AdminTheatreView.vue";
import AdminMovieView from "@/views/admin/AdminMovieView.vue";


const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: LoginView
    },
    {
      path: "/register/:name",
      name: "register",
      component: RegisterView,
      props: true
    },
    {
      path: "/register",
      name: "register-world",
      component: RegisterView,
      props: true
    },
    {
      path: "/admin",
      name: "admin-home",
      component: AdminView,
      children: [
        {
          path: "",
          name: "admin-theatre",
          component: AdminTheatreView
        },
        {
          path: "movie",
          name: "admin-movie",
          component: AdminMovieView
        }
      ]
    },
    {
      path: "/user",
      name: "user-home",
      component: AdminView,
    }
  ]
})

router.beforeEach((to, from) =>{
  console.log("redirect");
  
  if(to.fullPath.match(/[/]admin*/)){
    if(store.getters.getRoles.includes("admin")){
      return true
    }
    else{
      router.push('/');
    }
  }
  else if(to.fullPath.match(/[/]user*/)){

    if(store.getters.getRoles.includes("user")){
      return true
    }
    else{
      router.push('/');
    }
  }
  
})

export default router

