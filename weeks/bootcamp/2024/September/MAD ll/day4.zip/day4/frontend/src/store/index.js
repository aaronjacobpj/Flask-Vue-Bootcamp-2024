import { createStore } from "vuex";


export default createStore({
    state(){
        return {
            user: {
                roles: [],
                token: null,
            },
            theatres: [],
            movies: []
        }
    },
    getters: {
        getRoles(state){
            return state.user["roles"]
        },
        getToken(state){
            return state.user["token"]
        },
        getTheatres(state){
            return state.theatres;
        },
        getMovies(state){
            return state.movies;
        }
    },
    mutations: {
        setUser(state, payload){
            state.user['roles'] = payload['roles'] || [];
            state.user['token'] = payload['token'];
            localStorage.setItem("user", JSON.stringify(state.user));
            
        },
        setTheatre(state, value){
            state.theatres = value
        },
        setMovie(state, value){
            state.movies = value
        }
    },
    actions:{
        getTheatres(context){
            fetch(import.meta.env.VITE_BASEURL+"/admin/theatre").then(x =>{
                return x.json()
            }).then(x =>{
                context.commit('setTheatre', x || []);
            })
        },
        getMovies({commit, state}){
            fetch(import.meta.env.VITE_BASEURL+"/movies",
                {headers: {"Authentication-Token": state.user.token}}
            ).then(x =>{
                return x.json()
            }).then(x =>{
                commit('setMovie', x || []);
            })
        }
    }
})