<script setup>
    import store from "@/store";
</script>
<template>
    <div class="alert alert-success" role="alert" v-if="alert['success']">
        {{ alert["success"] }}
     </div>
     <div class="alert alert-danger" role="alert" v-if="alert['danger']">
        {{ alert["danger"] }}
     </div>
     <div class="card">
         <div class="card-body">
             <div class="row">
                <div class="col" style="max-width: 30% !important;">
                    <img :src="image" v-if="image"class="img-thumbnail" alt="...">
                </div>
                <div class="col">
                    <form @submit.prevent="create">
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Name</label>
                            <input type="text" class="form-control" id="formGroupExampleInput"
                                v-model="name" placeholder="Theatre Name">
                            <div class="invalid-feedback" :style="{display: (invalid) ? 'block' : 'none' }">
                                Invalid name.
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col">
                                <label for="formGroupExampleInput2" class="form-label">Poster</label>
                                <input type="file" class="form-control" id="formGroupExampleInput2"
                                    @change="get_image" placeholder="Poster">
                            </div>
                            <div class="col">
                                <label for="formGroupExampleInput2" class="form-label">Theatres</label>
                                <select class="form-select" v-model="theatres" multiple>
                                    <option v-for="theatre in store.getters.getTheatres" :value="theatre['id']">
                                        {{ theatre['name'] }}
                                    </option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col"></div>
                            <div class="col"></div>
                            <div class="col">
                                <input type="submit" class="btn btn-primary" value="Submit">
                            </div>
                        </div>
                    </form>
                </div>
             </div>
         </div>
     </div>
     <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Title</th>
            <th scope="col">Theatres</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="movie in store.getters.getMovies">
            <th scope="row">{{ movie.id }}</th>
            <td>{{ movie.name}}</td>
            <td>
                <span class="badge text-bg-primary" v-for="theatre in movie['theatre']" style="margin-left: 5px;">
                    {{ theatre['name'] }}
                </span>
            </td>
            <td>
                <button class="btn btn-warning" @click="() => {show=true; edit=movie}">
                    Edit
                </button>
            </td>
            <td>
                <button class="btn btn-danger" @click="delete_movie(movie.id)">
                    Delete
                </button>
            </td>
          </tr>
        </tbody>
      </table>
        <div class="modal" tabindex="-1" :style="{display: (show)? 'block' : 'none'}">
            <div class="modal-dialog modal-lg">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Modal title</h5>
                  <button type="button" class="btn-close" @click="show=false"
                  data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col">
                        </div>
                        <div class="col">
                          <input type="text" class="form-control" placeholder="Last name" v-model="edit['name']">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                        </div>
                        <div class="col">
                            <input type="file" class="form-control" id="formGroupExampleInput2"
                            @change="get_image" placeholder="Poster">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                        </div>
                        <div class="col">
                            <select class="form-select" multiple v-model="edit['theatres']">
                                <option v-for="theatre in store.getters.getTheatres" :value="theatre['id']" 
                                    :selected="edit_theatres.includes(theatre['id'])">
                                    {{ theatre['name'] }}
                                </option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary">Save changes</button>
                </div>
              </div>
            </div>
        </div>
</template>
<script>
    export default {
        data(){
            return {
                name: "",
                image: null,
                file: null,
                invalid: false,
                theatres:  [],
                show: null,
                edit: {
                    name: "",
                    image: null,
                    file: null,
                    theatre:  [],
                },
                alert: {
                    success: null,
                    danger: null
                },
            }
        },
        created(){
            store.dispatch('getTheatres');
            store.dispatch("getMovies");
        },
        computed:{
            edit_theatres(){
                let result = this.edit['theatre'].map(x => x['id'])
                return result
                
            }
        },
        methods:{
            create(){
                var form = new FormData();
                form.append("name", this.name)
                form.append("image", this.file)

                if (this.theatres)
                    this.theatres.forEach(x=> form.append("theatres", x))

                fetch(import.meta.env.VITE_BASEURL+"/admin/movie",
                    {
                        method: "POST",
                        headers: {
                            "Authentication-Token": store.getters.getToken,
                        },
                        body: form
                    },
                    
                ).then(x =>{
                    if(x.status == 201){
                        this.alert["success"] = "Created movie successfully."
                    }
                    else{
                        this.alert["danger"] = "Something went wrong."
                    }
                    store.dispatch("getMovies");
                })

            },
            get_image(event){
                
                var input = event.target;
                var reader = new FileReader();
                reader.addEventListener('load', (event) => {
                    this.image = event.target.result;
                });
                reader.readAsDataURL(input.files[0]);
                this.file = event.target.files[0];
            },
            delete_movie(id){
                alert()
                fetch(import.meta.env.VITE_BASEURL+"/admin/movie/"+id,
                        {headers: {"Authentication-Token": store.getters.getToken}}
                ).then(x =>{
                    if(x.status == 200){
                        this.alert["success"] = "Deleted movie successfully."
                    }
                    else{
                        this.alert["danger"] = "Something went wrong."
                    }
                    store.dispatch("getMovies");
                })
            }
        }
    }
</script>
<style scoped>
    .col{
        margin: 5px;
    }
</style>