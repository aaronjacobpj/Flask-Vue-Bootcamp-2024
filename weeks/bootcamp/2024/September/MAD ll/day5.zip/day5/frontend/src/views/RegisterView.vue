<script setup>
    import router from "@/router";
</script>
<template>
    <div class="container-fluid">
        <div class="card">
            <div class="card-body">
                <h3 align="center"> 
                    Register
                </h3>
                <form @submit.prevent="signup">
                    <div class="row">
                        <div class="col">
                            <input type="text" class="form-control" placeholder="Full Name" v-model="name">
                            <div class="invalid-feedback" :style="{display: (error['name']) ? 'block' : 'none' }">
                              Required field.
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <input type="text" class="form-control" placeholder="Username" v-model="username">
                            <div class="invalid-feedback" :style="{display: (error['username']) ? 'block' : 'none' }">
                              Required field.
                            </div>
                            <div class="invalid-feedback" :style="{display: (error['invalid']) ? 'block' : 'none' }">
                                username already exist.
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <input type="password" class="form-control" placeholder="Password" v-model="password">
                            <div class="invalid-feedback" :style="{display: (error['password']) ? 'block' : 'none' }">
                              Required field.
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <input type="submit" class="btn btn-primary" value="Register">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data(){
            return{
                name: null,
                username: null,
                password: null,
                error: {
                    name: null,
                    username: null,
                    password: null,
                    invalid: null
                }
            }
        },
        methods: {
            validate(){
                this.error = {
                        name: null,
                        username: null,
                        password: null,
                        invalid: null
                }
                if(!this.name){
                    this.error['name'] = true;
                    return false
                }
                else if(!this.username){
                    this.error['username'] = true;
                    return false
                }
                else if(!this.password){
                    this.error['passwor'] = true;
                    return false
                }
                return true;
            },
            signup(){
                this.error["invalid"]  = null;
                if(!this.validate())
                    return false
                fetch(import.meta.env.VITE_BASEURL+"/signup", {
                    method: "POST",
                    headers: {"Content-Type": "application/json"},
                    body: JSON.stringify({name:this.name, username:this.username, password:this.password})
                }).then(x =>{
                    console.log(x.status);
                    
                    if (x.status == 409){
                        this.error["invalid"] = true;
                    }
                    else if (x.status == 400){
                        this.validate()
                    }
                    else{
                        router.push({name: "home"})
                    }


                })
            }
        }
       
    }
</script>
<style scoped>
    .container-fluid{
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
    }
    .btn-primary{
        width: 100%;
    }
    .row{
        padding: 10px 0 10px 0;
    }
</style>