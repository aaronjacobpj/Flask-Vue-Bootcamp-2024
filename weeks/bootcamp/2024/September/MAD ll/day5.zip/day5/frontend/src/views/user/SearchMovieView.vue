<script setup>
    import store  from "@/store"
</script>
<template>
    <div class="card">
        <div class="card-body">
            <div class="row" style="margin: 15px 10px 15px 10px;">
                <div class="row">
                    <div class="col">
                        <input type="text" class="form-control" placeholder="First name" aria-label="First name">
                    </div>
                    <div class="col">
                        <input type="text" class="form-control" placeholder="Last name" aria-label="Last name">
                    </div>
                    <div class="col">
                        <input type="button" class="btn btn-primary" placeholder="Last name" aria-label="Last name">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card" v-for="movie in movies">
        <div class="card-body">
            <div class="row">
                <div class="col">
                    <img :src="get_src(movie['poster'])" class="img-thumbnail" style="width: 150px; height: 200px;">
                </div>
                <div class="col" style="display: flex; align-items: center;">
                    <div>
                        <div class="row">
                            <h3>{{ movie.name }}</h3>
                        </div>
                        <div class="col" v-for="theatre in movie['theatre']">
                            <span class="badge text-bg-primary" v-for="theatre in movie['theatre']" style="margin-left: 5px;">
                                {{ theatre['name'] }}
                            </span>
                        </div>
                    </div>
                </div>
                <div class="col" style="display: flex; align-items: center;">
                    <button type="button" class="btn btn-primary"> Book</button>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default{
        data(){

        },
        created(){
            store.dispatch("getMovies");
        },
        computed:{
            movies(){
                return store.getters.getMovies
            }
        },
        methods: {
            get_src(filename){
                return `${import.meta.env.VITE_BASEURL}/static/${filename}`
            },
        }
    }
</script>