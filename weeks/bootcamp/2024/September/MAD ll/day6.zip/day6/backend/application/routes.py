from flask import Blueprint, request
from flask import current_app as app
from flask_security import current_user, login_user, roles_required, auth_required
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import func

from application.models import db, Theatre, Show, Tickets, Movie
from application.utils import get_filename

import os


api = Blueprint("api", __name__)


@api.route("/signin", methods=["POST"])
def signin():
    username = request.json.get("username", None)
    password = request.json.get("password", None)

    if not username or not password:
        return {"message": "Invalid request"}, 400
    
    user = app.security.datastore.find_user(username=username)
    if not user or not check_password_hash(user.password, password):
        return {"message": "User not found"}, 404
    
    login_user(user)
    return {"token": user.get_auth_token(),
            "roles": user.get_roles()}


@api.route("/signup", methods=["POST"])
def signup():
    name = request.json.get("name", None)
    username = request.json.get("username", None)
    password = request.json.get("password", None) 

    if not username or not name or not password:
        return {"message": "Invalid request"}, 400
    
    if app.security.datastore.find_user(username=username):
        return {"message": "Username exist."}, 409
    
    app.security.datastore.create_user(name=name, username=username, password=generate_password_hash(password))
    app.security.datastore.add_role_to_user(app.security.datastore.find_user(username=username),
                                            app.security.datastore.find_role("user"))
    db.session.commit()

    return {"message": "Created user successfully"}, 201


@api.route("/admin/theatre", methods=["GET"])
def theatre():
    theatres = Theatre.query.all()
    result = []
    for each in theatres:
        result.append({"id": each.id, 
                       "name": each.name, 
                       "capacity": each.capacity})
        
    return result


@api.route("/admin/theatre", methods=["POST"])
@roles_required("admin")
def create_theatre():
    name = request.json.get("name", None)
    capacity = request.json.get("capacity", None) 

    if not name or not capacity or (isinstance(capacity, int) and 0 < capacity > 500):
        return {"message": "Invalid request"}, 400
    
    theatre = Theatre(name=name, capacity=capacity)
    db.session.add(theatre)
    db.session.commit()

    return {"message": "Created theatre successfully"}, 201
    

@api.route("/admin/theatre/<int:theatre_id>", methods=["DELETE"])
@roles_required("admin")
def delete_theatre(theatre_id):
    theatre = db.session.query(Theatre).get(theatre_id)
    if not theatre:
        return {"message": "Theatre not found"}, 404
    
    db.session.delete(theatre)
    db.session.commit()

    return {"message": "Deleted theatre successfully"}, 200


@api.route("/admin/theatre/<int:theatre_id>", methods=["PUT"])
@roles_required("admin")
def update_theatre(theatre_id):
    theatre = db.session.query(Theatre).get(theatre_id)
    if not theatre:
        return {"message": "Theatre not found"}, 404
    
    name = request.json.get("name", None)
    capacity = request.json.get("capacity", None) 

    if not name or not capacity or (isinstance(capacity, int) and 0 < capacity > 500):
        return {"message": "Invalid request"}, 400
    
    theatre.name = name
    theatre.capacity = capacity
    db.session.commit()

    return {"message": "Updated theatre successfully"}, 200


@api.route("/admin/movie", methods=["POST"])
@roles_required("admin")
def create_movie():
    name = request.form.get("name", None)
    image = request.files.get("image", None)
    theatre_ids = request.form.getlist("theatres", type=int)

    theatres = db.session.query(Theatre).filter(Theatre.id.in_(theatre_ids)).count()

    if not name or theatre_ids == [] or len(theatre_ids) != theatres:
        return {"message": "Invalid request"}, 400

    movie = Movie(name=name)

    if image:
        filename = get_filename()
        check = set(os.listdir("static"))
        while filename in check:
            filename = get_filename()

        movie.poster = filename+os.path.splitext(image.filename)[1]
        image.save(os.path.join("static", movie.poster))
    
    db.session.add(movie)
    db.session.flush()
    for theatre in theatre_ids:
        db.session.add(Show(movie_id=movie.id, theatre_id=theatre))
        
    db.session.commit()

    return {"message": "Created movie successfully"}, 201


@api.route("/movies")
@auth_required("token")
def get_movies():
    result = []

    for movie in Movie.query.all():
        result.append({
            "id": movie.id,
            "name": movie.name,
            "poster" : movie.poster,
            "theatre": [{"id": show.theatre.id,
                         "name": show.theatre.name,
                         "capacity": show.theatre.capacity,
                         "sold": show.total_tickets()
                         }
                         for show in movie.shows]
        })
    return result


@api.route("/admin/movie/<int:movie_id>")
@roles_required("admin")
def delete_movie(movie_id):
    movie = db.session.query(Movie).get(movie_id)

    if not movie:
        return {"message": "Movie not found."}, 404
    
    shows = Show.query.filter_by(movie_id=movie_id).all()
    db.session.delete(movie)
    for show in shows:
        db.session.delete(show)
    db.session.commit()

    return {"message": "Deleted movie successfully"}, 200


@api.route("/admin/movie/<int:movie_id>", methods=["PUT"])
@roles_required("admin")
def update_movie(movie_id):

    name = request.form.get("name", None)
    image = request.files.get("image")
    delete = request.form.get("delete") == "true"
    theatre_ids = request.form.getlist("theatres", type=int)

    movie = db.session.query(Movie).get(movie_id)

    if not movie:
        return {"message": "Movie not found."}, 404

    theatres = db.session.query(Theatre).filter(Theatre.id.in_(theatre_ids)).count()
    if not name:
        return {"message": "Invalid request"}, 400
    
    if delete and movie.poster:
        os.remove(os.path.join("static", movie.poster))

    if image:
        filename = get_filename()
        check = set(os.listdir("static"))
        while filename in check:
            filename = get_filename()

        movie.poster = filename+os.path.splitext(image.filename)[1]
        image.save(os.path.join("static", movie.poster))

    movie.name = movie.name
    theatres = [ theatre.id 
                for theatre in db.session.query(Theatre).filter(Theatre.id==Show.theatre_id,
                                                                Show.movie_id==movie_id).all()]

    for theatre in theatres:
        if theatre not in theatre_ids:
            db.session.delete(Show.query.filter_by(movie_id=movie_id, theatre_id=theatre).first())
        
    for theatre in theatre_ids:
        if theatre not in theatres:
            db.session.add(Show(movie_id=movie_id, theatre_id=theatre))

    db.session.commit()

    return {"message": "Updated movie successfully"}, 200


@api.route("/user/movie/<int:movie_id>", methods=["POST"])
@auth_required("token")
def book_movie(movie_id):

    theatre = request.json.get("theatre")
    tickets = request.json.get("tickets")

    show = Show.query.filter_by(movie_id=movie_id, theatre_id=theatre).first()

    if  tickets > show.theatre.capacity - show.total_tickets():
        return {"message": "Invalid request"}, 400
    
    ticket = Tickets(show_id=show.id, user_id=current_user.id, tickets=tickets)
    db.session.add(ticket)
    db.session.commit()

    return {"message": "Booked movie successfully"}, 200


@api.route("/user/movie")
# @auth_required("token")
def booked_movies():
    result = []

    tickets = Tickets.query.filter_by(user_id=current_user.id).all()
    for ticket in tickets:
        result.append({
            "id": ticket.show.movie.id,
            "name": ticket.show.movie.name,
            "poster" : ticket.show.movie.poster,
            "theatre": {"id": ticket.show.theatre.id,
                         "name": ticket.show.theatre.name,
                         "tickets": ticket.tickets
                        }

        })

    return result