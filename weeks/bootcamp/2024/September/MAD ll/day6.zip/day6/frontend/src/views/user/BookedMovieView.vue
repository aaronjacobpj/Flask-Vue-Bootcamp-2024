<script setup>
    import store  from "@/store"
</script>
<template>
    <div class="alert alert-success" role="alert" v-if="alert['success']">
        {{ alert["success"] }}
    </div>
    <div class="alert alert-danger" role="alert" v-if="alert['danger']">
    {{ alert["danger"] }}
    </div>
    <div class="card" v-for="movie in movies">
        <div class="card-body">
            <div class="row">
                <div class="col">
                    <img :src="get_src(movie['poster'])" class="img-thumbnail" style="width: 150px; height: 200px;">
                </div>
                <div class="col" style="display: flex; align-items: center;">
                    <div>
                        <div class="row">
                            <h3>Movie Name: {{ movie.name }}</h3>
                        </div>
                        <div class="col">
                            <span class="badge text-bg-primary" style="margin-left: 5px;">
                                {{ movie["theatre"]['name'] }}
                            </span>
                        </div>
                        <div class="row">
                            <h3>{{ movie["theatre"]['tickets'] }}</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default{
        data(){
            return {
                movies: [],
                alert: {}
            }
        },
        created(){
            fetch(import.meta.env.VITE_BASEURL+"/user/movie",
                    {
                        headers: {
                            "Authentication-Token": store.getters.getToken,
                        }
                    },
                ).then(x=>{
                    if (x.status == 200){
                        return x.json();
                    }
                    else{
                        return []
                    }

                }).then(x=> this.movies = x);
        },
        computed:{
            
        },
        methods: {
            get_src(filename){
                return `${import.meta.env.VITE_BASEURL}/static/${filename}`
            },
            
        }
    }
</script>
<style>
    .col{
        margin: 5px;
    }
</style>