<script setup>
    import store  from "@/store"
</script>
<template>
    <div class="alert alert-success" role="alert" v-if="alert['success']">
        {{ alert["success"] }}
    </div>
    <div class="alert alert-danger" role="alert" v-if="alert['danger']">
    {{ alert["danger"] }}
    </div>
    <div class="card">
        <div class="card-body">
            <div class="row" style="margin: 15px 10px 15px 10px;">
                <div class="row">
                    <div class="col">
                        <input type="text" class="form-control" placeholder="Query" v-model="search">
                    </div>
                    <div class="col">
                        <select class="form-select" aria-label="Default select example" v-model="option">
                            <option v-for="option in options">{{ option }}</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card" v-for="movie in query">
        <div class="card-body">
            <div class="row">
                <div class="col">
                    <img :src="get_src(movie['poster'])" class="img-thumbnail" style="width: 150px; height: 200px;">
                </div>
                <div class="col" style="display: flex; align-items: center;">
                    <div>
                        <div class="row">
                            <h3>{{ movie.name }}</h3>
                        </div>
                        <div class="col">
                            <span class="badge text-bg-primary" v-for="theatre in movie['theatre']" style="margin-left: 5px;">
                                {{ theatre['name'] }}
                            </span>
                        </div>
                    </div>
                </div>
                <div class="col" style="display: flex; align-items: center;">
                    <button type="button" class="btn btn-primary" @click="() => {show=true; this.movie=movie}"> Book</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal" tabindex="-1" :style="{display: (show)? 'block' : 'none'}">
        <div class="modal-dialog modal-lg">
            <form @submit.prevent="book_tickets" method="post">
                <div class="modal-content">
                    <div class="modal-header">
                    <h5 class="modal-title">Edit Movie</h5>
                    <button type="button" class="btn-close" @click="show=false"
                    data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col">
                                <img :src="get_src(movie['poster'])" style="height: 200px; width: 150px;">
                        </div>
                        <div class="col">
                            <div class="row">
                                <div class="col">
                                <input type="text" class="form-control" placeholder="Last name" :value="movie['name']" disabled>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <input type="number" class="form-control" id="formGroupExampleInput2" :value="avilableTickets" disabled>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <input type="number" class="form-control" id="formGroupExampleInput2" v-model="form['tickets']" :max="avilableTickets">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <select class="form-select" v-model="form['theatre']">
                                        <option v-for="theatre in movie['theatre']" :value="theatre['id']">
                                            {{ theatre['name'] }}
                                        </option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</template>
<script>
    export default{
        data(){
            return {
                options: ["theatre", "movie"],
                option: "movie",
                search: "",
                show: false,
                movie: {
                    id: null,
                    name: null,
                    poster: null,
                    theatre: [
                    ]
                },
                alert: {},
                form: {
                    theatre: null,
                    tickets: null
                }
            }
        },
        created(){
            store.dispatch("getMovies");
        },
        computed:{
            movies(){
                return store.getters.getMovies
            },
            query(){
                if (this.option.match("movie")){
                    return this.movies.filter(x=> x["name"].includes(this.search))
                }
                else{
                    return this.movies.filter(x=> x["theatre"].find(x => x["name"].includes(this.search)))
                }
            },
            avilableTickets(){
                if(!this.form['theatre'])
                    return null
                let theatre = this.movie["theatre"].filter(x => x['id'] == this.form['theatre'])[0]
                return theatre["capacity"] - theatre["sold"];
            }
        },
        methods: {
            get_src(filename){
                return `${import.meta.env.VITE_BASEURL}/static/${filename}`
            },
            book_tickets(){
                fetch(import.meta.env.VITE_BASEURL+"/user/movie/"+this.movie["id"],
                    {
                        method: "POST",
                        headers: {
                            "Authentication-Token": store.getters.getToken,
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(this.form)
                    },
                ).then(x=>{
                    if (x.status == 200){
                        this.alert["success"] = "Booked tickets successfully."
                    }
                    else{
                        this.alert["danger"] = "Something went wrong."
                    }
                    this.show = false
                    this.movie = {
                        id: null,
                        name: null,
                        poster: null,
                        theatre: [
                        ]
                    }
                    this.form = {
                        theatre: null,
                        tickets: null
                    }
                    store.dispatch("getMovies");
                })
            }
            
        }
    }
</script>
<style>
    .col{
        margin: 5px;
    }
</style>