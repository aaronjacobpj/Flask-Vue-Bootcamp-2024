from celery import shared_task
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from jinja2 import Template
import time
import os
from csv import DictWriter
from io import StringIO
from sqlalchemy.sql import func

from application.models import db, User, Movie, Tickets, Show

@shared_task
def hello():
    print("hello")
    time.sleep(10)
    print("Hi")
    return "Hello"


@shared_task
def daily_reminder():
    smtpObj = smtplib.SMTP('localhost', 1025)

    with open("templates/daily-reminder.html") as file:
        content = Template(file.read())

    for user in User.query.all():
        email = MIMEMultipart()
        email["TO"] = user.username
        email["FROM"] = "admin@ticket.com"
        email["SUBJECT"] = f"Daily Reminder - {user.name}"

        html = MIMEText(content.render(user=user), "html")
        email.attach(html)
         
        smtpObj.sendmail("admin@ticket.com", user.username, email.as_string())


@shared_task
def export_csv():
    
    file = StringIO()
    writer = DictWriter(file, fieldnames=["Movie", "Tickets"])
    writer.writeheader()
    for movie in Movie.query.all():
        tickets = db.session.query(func.sum(Tickets.tickets)
                                   ).filter(Show.movie_id==movie.id
                                               ).first()[0]
        writer.writerow({"Movie": movie.title, 
                         "Tickets": tickets})
        
    file.seek(0)
    result = file.read()
    return result



@shared_task
def monthly_report():

    smtpObj = smtplib.SMTP('localhost', 1025)

    with open("templates/monthly-report.html") as file:
        content = Template(file.read())

    email = MIMEMultipart()
    email["TO"] = "admin@ticket.com"
    email["FROM"] = "admin@ticket.com"
    email["SUBJECT"] = f"Daily Reminder - Admin"

    movies = []
    for movie in Movie.query.all():
        tickets = db.session.query(func.sum(Tickets.tickets)
                                   ).filter(Show.movie_id==movie.id
                                               ).first()[0]
        movies.append({"Movie": movie.title, 
                         "Tickets": tickets})
    html = MIMEText(content.render(movies=movies), "html")
    email.attach(html)
    html = MIMEText(content.render(movies=movies), "plain")
    email.attach(html)
        
    smtpObj.sendmail("admin@ticket.com", "admin@ticket.com", email.as_string())