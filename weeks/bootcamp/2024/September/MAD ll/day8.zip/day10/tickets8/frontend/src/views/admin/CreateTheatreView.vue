<script setup>
    import store from "@/store";
    import router from "@/router";
</script>
<template>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Create Theatre</h5>
            <form @submit.prevent="submit()">
                <div class="row">
                    <div class="col">
                        <input type="text" class="form-control" v-model="name"
                            placeholder="Theatre Name" aria-label="Theatre Name">
                        <div :class="{'invalid-feedback': true, error: error['name']}">
                            Please provide a valid city.
                          </div>
                    </div>
                    <div class="col">
                        <input type="number" class="form-control" v-model="capacity"
                            placeholder="Theatre Capacity" aria-label="Theatre Capacity">
                        <div :class="{'invalid-feedback': true, error: error['capacity']}">
                            Please provide a valid city.
                            </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <input type="submit" class="btn btn-primary" value="Create"/>
                    </div>
                </div>
            </form>
        </div>        
    </div>

    <div class="card" v-if="id">
        <div class="card-body">
            <h5 class="card-title">Edit Theatre</h5>
            <form @submit.prevent="updateTheatre()">
                <div class="row">
                    <div class="col">
                        <input type="text" class="form-control" :value="id"
                            placeholder="Theatre Name" aria-label="Theatre Name" disabled>
                        <div :class="{'invalid-feedback': true, error: error['name']}">
                            Please provide a valid city.
                          </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <input type="text" class="form-control" v-model="editName"
                            placeholder="Theatre Name" aria-label="Theatre Name">
                        <div :class="{'invalid-feedback': true, error: error['name']}">
                            Please provide a valid city.
                          </div>
                    </div>
                    <div class="col">
                        <input type="number" class="form-control" v-model="editCapacity"
                            placeholder="Theatre Capacity" aria-label="Theatre Capacity">
                        <div :class="{'invalid-feedback': true, error: error['capacity']}">
                            Please provide a valid city.
                            </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <input type="submit" class="btn btn-primary" value="Update"/>
                    </div>
                </div>
            </form>
        </div>        
    </div>
</template>
<script>
    export default {
        props: ["id"],
        data(){
            return{
                name: null,
                capacity: null,
                editCapacity: null,
                editName: null,
                error:{
                    name: null,
                    capacity: null,
                }
            }
        },
        watch:{
            theatre(value){
                this.editName = value["name"];
                this.editCapacity = value["capacity"];
            }
        },
        created(){
            store.dispatch("getTheatres");
        },
        computed: {
            theatre(){
                return store.getters.getTheatres[this.id]
            }
        },
        methods:{
            validate(){
                this.error = {
                    name: null,
                    capacity: null,
                }

                let valid = true;
                if(!this.name){
                    this.error["name"] = "Invalid name";
                    valid = false;
                }
                if(!this.capacity){
                    this.error["capacity"] = "Invalid capacity";
                    valid = false;
                }
                return valid
            },
            submit(){
                if(!this.validate())
                    return

                fetch(import.meta.env.VITE_BASEURL+"/theatre/create", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": store.getters.getToken
                    },
                    body: JSON.stringify({name: this.name, capacity: this.capacity})
                })
            },
            updateTheatre(){
                fetch(import.meta.env.VITE_BASEURL+`theatre/${this.theatre["id"]}`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": store.getters.getToken
                    },
                    body: JSON.stringify({name: this.editName, capacity: this.editCapacity})
                }).then(x =>{
                    if(x.status == 200){
                        router.push("/admin/theatre/view")
                    }
                })
            }
        }
    }
</script>
<style scoped>
    .col {
        padding: 5px;
    }
    .card{
        margin: 10px;
    }
    .error{
        display: block;
    }
</style>