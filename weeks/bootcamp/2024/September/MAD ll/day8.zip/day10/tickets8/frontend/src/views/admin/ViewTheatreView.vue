<script setup>
    import store from "@/store";
    import router from "@/router";
</script>
<template>
    <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Capacity</th>
            <!-- <th scope="col">Handle</th> -->
          </tr>
        </thead>
        <tbody>
          <tr v-for="(theatre, index) in store.getters.getTheatres">
            <th scope="row">{{index+1}}</th>
            <td>{{ theatre['name'] }}</td>
            <td>{{ theatre['capacity'] }}</td>
            <td>
                <button class="btn btn-primary" @click="redirect(index)">
                    Edit
                </button>
            </td>
            <td>
                <button class="btn btn-danger" @click="deleteTheatre(theatre['id'])">
                    Delete
                </button>
            </td>
          </tr>
        </tbody>
    </table>
</template>
<script>
    export default{
        created(){
            store.dispatch("getTheatres")
        },
        methods:{
            redirect(id){
                router.push(`/admin/theatre/${id}`)
            },
            deleteTheatre(id){
                fetch(import.meta.env.VITE_BASEURL+`admin/theatre/${id}`, {
                    method: "DELETE",
                    headers: {
                        "Authentication-Token": store.getters.getToken
                    }
                }).then((resp)=>{
                    store.dispatch("getTheatres");
                })
            }
        }
    }
</script>
<style scoped>
</style>