<script setup>
    import { RouterView } from "vue-router";
    import UserNavbar from "@/components/user/Navbar.vue";
</script>
<template>
    <UserNavbar/>
    <RouterView/>
</template>