from flask import Flask, render_template
import datetime

app = Flask(__name__)


@app.route("/")
def index():
    date = datetime.date.today()
    status = date.day == 1 and date.month == 1
    return render_template("index.html", status=status)

