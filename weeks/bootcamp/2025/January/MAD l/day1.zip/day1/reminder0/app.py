from flask import Flask, render_template

app = Flask(__name__)

REMINDERS = [
    "FOO",
    "BAR",
    "BAZ",
    "Another item"
]

@app.route("/")
def index():
    return render_template("index.html", reminders=REMINDERS)

