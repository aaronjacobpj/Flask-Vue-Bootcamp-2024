from flask import Flask, render_template, redirect

app = Flask(__name__)

REMINDERS = [
]

@app.route("/")
def index():
    return render_template("index.html", reminders=REMINDERS)


@app.route("/<string:reminder>")
def add_reminder(reminder):
    REMINDERS.append(reminder)
    return redirect("/")
