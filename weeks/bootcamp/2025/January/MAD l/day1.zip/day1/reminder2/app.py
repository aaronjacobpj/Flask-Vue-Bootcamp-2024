from flask import Flask, render_template, redirect, request

app = Flask(__name__)

REMINDERS = [
]

@app.route("/")
def index():
    return render_template("index.html", reminders=REMINDERS)


@app.route("/add", methods=["GET", "POST"])
def add_reminder():
    reminder = request.form.get("reminder")

    if reminder:
        REMINDERS.append(reminder)
        return render_template("index.html", reminders=REMINDERS)

    return render_template("add_reminder.html")
