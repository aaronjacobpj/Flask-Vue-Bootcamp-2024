from flask import Flask, render_template, redirect, request, session

app = Flask(__name__)

app.config["SECRET_KEY"] = "iruhgiuengineomnom"


@app.route("/")
def index():
    reminders = session.get("reminder", [])
    print(reminders)
    return render_template("index.html", reminders=reminders)


@app.route("/add", methods=["GET", "POST"])
def add_reminder():
    reminder = request.form.get("reminder")

    if reminder:
        reminders = session.get("reminder", [])
        reminders.append(reminder)
        session["reminder"] = reminders
        return redirect("/")

    return render_template("add_reminder.html")
