from flask import Flask


app = Flask(__name__)


@app.route("/count")
def count():
    result = "<ul>"
    for i in range(100000):
        result += f"<li>{i}</li>"

    return result+"</ul>"