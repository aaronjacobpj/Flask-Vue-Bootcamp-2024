from flask import Flask

from application.models import db
from application.routes import api

def create_app():

    app = Flask(__name__)

    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///model.db"

    db.init_app(app)

    with app.app_context():
        db.create_all()

    app.register_blueprint(api)

    return app


app = create_app()

