from flask import Blueprint, current_app as app


api = Blueprint("api", __name__)


@api.route("/")
def index():
    return "Hello, world!"