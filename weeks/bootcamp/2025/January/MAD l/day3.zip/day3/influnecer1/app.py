from flask import Flask
from werkzeug.security import generate_password_hash, check_password_hash

from application.models import db, User, Role, UserRoles
from application.routes import api
from application.initialise.utils import add_categories

def create_app():

    app = Flask(__name__)

    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///model.db"
    app.config["SECRET_KEY"] = "vhjvbjknbvdkn"


    db.init_app(app)

    with app.app_context():
        db.create_all()

        if not Role.query.filter_by(name="admin").first():
            admin = Role(name="admin")
            influencer = Role(name="influencer")
            sponser = Role(name="sponser")
            db.session.add_all([admin, influencer, sponser])

            user = User(name="Alice", 
                        username="alice", 
                        password=generate_password_hash("alice")
                    )
            db.session.add(user)
            db.session.flush()

            db.session.add(
                UserRoles(user_id=user.id,
                            role_id=admin.id)
            )

            add_categories()

            db.session.commit()

    app.register_blueprint(api)

    return app


app = create_app()

