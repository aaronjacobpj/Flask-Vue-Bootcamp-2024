from flask import Blueprint, current_app as app
from flask import render_template, request, flash, redirect
from random import randrange
from werkzeug.security import generate_password_hash, check_password_hash


from application.models import Category, User, db, Influencer


api = Blueprint("api", __name__)


@api.route("/")
def index():
    return render_template("layout.html")


@api.route("/register/influencer", methods=["GET", "POST"])
def register_influencer():

    categories = Category.query.all()

    if request.method == "GET":
        return render_template("influencer/influencer-register.html", options=categories)
    
    name = request.form.get("fullname", None)
    username = request.form.get("username", None)
    password = request.form.get("password", None)
    category = request.form.get("category", None)
    reach = randrange(25, 100)

    category = Category.query.filter_by(name=category).first()
    valid = True

    if not name:
        flash("Field required!", category="invalid-fullname")
        valid=False

    elif not password:
        flash("Field required!", category="invalid-password")
        valid=False
    elif not username:
        flash("Field required!", category="invalid-username")
        valid=False
    elif User.query.filter_by(username=username).first():
        flash("Username already taken!", category="invalid-username")
        valid=False
    elif not category:
        flash("Invalid Category!", category="invalid-category")
        valid=False

    if not valid:
        return render_template("influencer/influencer-register.html",
                               options=categories,
                               password=password,
                               name=name,
                               username=username,
                               category=category), 400
    
    user = User(name=name,
                username=username,
                password=generate_password_hash(password)
                )
    db.session.add(user)
    db.session.flush()
    db.session.add(Influencer(user_id=user.id,
                              category_id=category.id,
                              reach=reach))
    db.session.commit()
    flash("Created User successfully.", category="alert-success")
    return redirect("/register/influencer")