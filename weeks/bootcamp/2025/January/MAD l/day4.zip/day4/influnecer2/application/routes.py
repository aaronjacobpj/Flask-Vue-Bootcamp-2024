from flask import Blueprint, current_app as app
from flask import render_template, request, flash, redirect, session
from random import randrange
from werkzeug.security import generate_password_hash, check_password_hash


from application.models import Category, User, db, Influencer, Sponser
from application.utils import login_required


api = Blueprint("api", __name__)


@api.route("/", methods=["GET", "POST"])
def index():
    if request.method == "GET":
        return render_template("login.html")
    
    username = request.form.get("username", None)
    password = request.form.get("password", "")

    user = User.query.filter_by(username=username).first()

    if not user or not check_password_hash(user.password, password):
        flash("Invalid username or password.", category="invalid-credentials")
        return render_template("login.html", username=username, password=password)
    
    session["user-id"] = user.id
    
    if "admin" in user.get_roles():
        return redirect("/sponser")
    elif "influencer" in user.get_roles():
        return "You are an influencer"
    else:
        return "You are a sponser"


@api.route("/signout")
@login_required
def signout():
    session.clear()
    return redirect("/")


@api.route("/register/influencer", methods=["GET", "POST"])
def register_influencer():

    categories = Category.query.all()

    if request.method == "GET":
        return render_template("influencer/register.html", options=categories)
    
    name = request.form.get("fullname", None)
    username = request.form.get("username", None)
    password = request.form.get("password", None)
    category = request.form.get("category", None)
    reach = randrange(25, 100)

    category = Category.query.filter_by(name=category).first()
    valid = True

    if not name:
        flash("Field required!", category="invalid-fullname")
        valid=False

    elif not password:
        flash("Field required!", category="invalid-password")
        valid=False
    elif not username:
        flash("Field required!", category="invalid-username")
        valid=False
    elif User.query.filter_by(username=username).first():
        flash("Username already taken!", category="invalid-username")
        valid=False
    elif not category:
        flash("Invalid Category!", category="invalid-category")
        valid=False

    if not valid:
        return render_template("influencer/register.html",
                               options=categories,
                               password=password,
                               name=name,
                               username=username,
                               category=category), 400
    
    user = User(name=name,
                username=username,
                password=generate_password_hash(password)
                )
    db.session.add(user)
    db.session.flush()
    db.session.add(Influencer(user_id=user.id,
                              category_id=category.id,
                              reach=reach))
    db.session.commit()
    flash("Created User successfully.", category="alert-success")
    return redirect("/register/influencer")


@api.route("/register/sponser", methods=["GET", "POST"])
def register_sponser():

    if request.method == "GET":
        return render_template("sponser/register.html")

    name = request.form.get("fullname", None)
    username = request.form.get("username", None)
    password = request.form.get("password", None)
    industry = request.form.get("industry", None)
    budget = request.form.get("budget", None, type=int)
    
    valid = True

    if not name:
        flash("Field required!", category="invalid-fullname")
        valid=False

    elif not password:
        flash("Field required!", category="invalid-password")
        valid=False
    elif not username:
        flash("Field required!", category="invalid-username")
        valid=False
    elif User.query.filter_by(username=username).first():
        flash("Username already taken!", category="invalid-username")
        valid=False
    elif industry is None:
        flash("Field required!", category="invalid-industry")
        valid=False
    elif budget is None or budget < 0:
        flash("Invalid Budget!", category="invalid-budget")
        valid=False

    if not valid:
        return render_template("sponser/register.html",
                                password=password,
                                name=name,
                                username=username,
                                industry=industry,
                                budget=budget), 400
    
    user = User(name=name,
                username=username,
                password=generate_password_hash(password)
                )
    db.session.add(user)
    db.session.flush()
    db.session.add(Sponser(user_id=user.id,
                           industry=industry,
                           budget=budget
    ))
    db.session.commit()
    flash("Created User successfully.", category="alert-success")
    return redirect("/register/sponser")


@api.route("/sponser")
@login_required
def sponser_dashboard():
    return render_template("sponser/layout.html")


@api.route("/sponser/campaign")
@login_required
def sponser_campaign():
    return render_template("sponser/campaign.html")