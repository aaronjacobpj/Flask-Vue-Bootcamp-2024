from application.models import db, Category

def add_categories():

    with open("application/initialise/categories.txt") as file:
        for line in file.readlines():
            db.session.add(Category(name=line.strip()))

        db.session.commit()
