from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class User(db.Model):

    __tablename__ = "user"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), nullable=False)
    username = db.Column(db.String(), nullable=False, unique=True)
    password = db.Column(db.String(), nullable=False)
    roles = db.relationship("Role", secondary="user_roles")

    def get_roles(self):
        result = set()
        for role in self.roles:
            result.add(role.name)
        return result


class Role(db.Model):

    __tablename__ = "role"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), nullable=False, unique=True)


class UserRoles(db.Model):

    __tablename__ = "user_roles"

    id = db.Column(db.Integer(), primary_key=True)
    user_id = db.Column(db.Integer(), db.ForeignKey("user.id"), nullable=False)
    role_id = db.Column(db.Integer(), db.ForeignKey("role.id"), nullable=False)


class Sponser(db.Model):

    __tablename__ = "sponser"

    id = db.Column(db.Integer(), primary_key=True)
    user_id = db.Column(db.Integer(), db.ForeignKey("user.id"), nullable=False)
    industry = db.Column(db.String(), nullable=False)
    budget = db.Column(db.Integer(), nullable=False)


class Influencer(db.Model):

    __tablename__ = "influencer"

    id = db.Column(db.Integer(), db.ForeignKey("user.id"), nullable=False, primary_key=True)
    reach = db.Column(db.Integer())
    category_id = db.Column(db.Integer(), db.ForeignKey("category.id"), nullable=False)
    user = db.relationship("User", backref="incluencer", uselist=False)


class Category(db.Model):

    __tablename__ = "category"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), nullable=False)


class AdRequest(db.Model):

    __tablename__ = "ad_request"

    id = db.Column(db.Integer(), primary_key=True)
    campaign_id = db.Column(db.Integer(), db.ForeignKey("campaign.id"), nullable=False)
    influencer_id = db.Column(db.Integer(), db.ForeignKey("influencer.id"), nullable=False)
    requirements = db.Column(db.String())
    amount = db.Column(db.Integer(), nullable=False)
    status = db.Column(db.Boolean())
    influencer = db.relationship("Influencer", backref="campaigns", uselist=False)


class Campaign(db.Model):

    __tablename__ = "campaign"

    id = db.Column(db.Integer(), primary_key=True)
    sponser_id = db.Column(db.Integer(), db.ForeignKey("sponser.id"), nullable=False)
    name = db.Column(db.String(), nullable=False)
    description = db.Column(db.String())
    start_date = db.Column(db.Date(), nullable=False)
    end_date =  db.Column(db.Date(), nullable=False)
    budget = db.Column(db.Integer(), nullable=False)
    private = db.Column(db.Boolean())
    goals = db.Column(db.String())
    category_id = db.Column(db.Integer(), db.ForeignKey("category.id"))


