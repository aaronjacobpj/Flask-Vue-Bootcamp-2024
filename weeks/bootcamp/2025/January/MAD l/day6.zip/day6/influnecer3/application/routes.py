from flask import Blueprint, current_app as app
from flask import render_template, request, flash, redirect, session, url_for
from random import randrange
from werkzeug.security import generate_password_hash, check_password_hash
import re
import datetime


from application.models import Category, User, db, Influencer, Sponser, Campaign, AdRequest
from application.utils import login_required


api = Blueprint("api", __name__)


@api.route("/", methods=["GET", "POST"])
def index():
    if request.method == "GET":
        return render_template("login.html")
    
    username = request.form.get("username", None)
    password = request.form.get("password", "")

    user = User.query.filter_by(username=username).first()

    if not user or not check_password_hash(user.password, password):
        flash("Invalid username or password.", category="invalid-credentials")
        return render_template("login.html", username=username, password=password)
    
    session["user-id"] = user.id
    
    if "admin" in user.get_roles():
        return "You are the admin"
    elif "influencer" in user.get_roles():
        return "You are an influencer"
    else:
        return redirect("/sponser")


@api.route("/signout")
@login_required
def signout():
    session.clear()
    return redirect("/")


@api.route("/register/influencer", methods=["GET", "POST"])
def register_influencer():

    categories = Category.query.all()

    if request.method == "GET":
        return render_template("influencer/register.html", options=categories)
    
    name = request.form.get("fullname", None)
    username = request.form.get("username", None)
    password = request.form.get("password", None)
    category = request.form.get("category", None)
    reach = randrange(25, 100)

    category = Category.query.filter_by(name=category).first()
    valid = True

    if not name:
        flash("Field required!", category="invalid-fullname")
        valid=False

    elif not password:
        flash("Field required!", category="invalid-password")
        valid=False
    elif not username:
        flash("Field required!", category="invalid-username")
        valid=False
    elif User.query.filter_by(username=username).first():
        flash("Username already taken!", category="invalid-username")
        valid=False
    elif not category:
        flash("Invalid Category!", category="invalid-category")
        valid=False

    if not valid:
        return render_template("influencer/register.html",
                               options=categories,
                               password=password,
                               name=name,
                               username=username,
                               category=category), 400
    
    user = User(name=name,
                username=username,
                password=generate_password_hash(password)
                )
    db.session.add(user)
    db.session.flush()
    db.session.add(Influencer(user_id=user.id,
                              category_id=category.id,
                              reach=reach))
    db.session.commit()
    flash("Created User successfully.", category="alert-success")
    return redirect("/register/influencer")


@api.route("/register/sponser", methods=["GET", "POST"])
def register_sponser():

    if request.method == "GET":
        return render_template("sponser/register.html")

    name = request.form.get("fullname", None)
    username = request.form.get("username", None)
    password = request.form.get("password", None)
    industry = request.form.get("industry", None)
    budget = request.form.get("budget", None, type=int)
    
    valid = True

    if not name:
        flash("Field required!", category="invalid-fullname")
        valid=False

    elif not password:
        flash("Field required!", category="invalid-password")
        valid=False
    elif not username:
        flash("Field required!", category="invalid-username")
        valid=False
    elif User.query.filter_by(username=username).first():
        flash("Username already taken!", category="invalid-username")
        valid=False
    elif industry is None:
        flash("Field required!", category="invalid-industry")
        valid=False
    elif budget is None or budget < 0:
        flash("Invalid Budget!", category="invalid-budget")
        valid=False

    if not valid:
        return render_template("sponser/register.html",
                                password=password,
                                name=name,
                                username=username,
                                industry=industry,
                                budget=budget), 400
    
    user = User(name=name,
                username=username,
                password=generate_password_hash(password)
                )
    db.session.add(user)
    db.session.flush()
    db.session.add(Sponser(user_id=user.id,
                           industry=industry,
                           budget=budget
    ))
    db.session.commit()
    flash("Created User successfully.", category="alert-success")
    return redirect("/register/sponser")


@api.route("/sponser")
@login_required
def sponser_dashboard():
    return render_template("sponser/layout.html")


@api.route("/sponser/campaign", methods=["GET", "POST"])
@login_required
def sponser_campaign():
    categories = Category.query.all()
    campaigns = Campaign.query.filter_by(sponser_id=session["user-id"]).all()

    if request.method == "GET":
        return render_template("sponser/campaign.html",
                            categories=categories,
                            campaigns=campaigns)
    
    title = request.form.get("title", None)    
    description = request.form.get("description", None)
    start_date = request.form.get("start-date", None)
    end_date = request.form.get("end-date", None)
    budget = request.form.get("budget", None, type=int)
    private = request.form.get("private", None) == "on"
    goals = request.form.get("goals", None)
    category = request.form.get("category", None, type=int)

    valid = True
    if not title:
        valid = False
        flash("Field required!", category="invalid-title")

    elif not start_date or not re.match("[0-9]{4}-(0[1-9]{1}|10|11|12)-([012][0-9]|30|31)", start_date):
        valid = False
        flash("Invalid start date", category="invalid-start-date")
    
    elif not end_date or not re.match("[0-9]{4}-(0[1-9]{1}|10|11|12)-([012][0-9]|30|31)", end_date):
        valid = False
        flash("Invalid end date", category="invalid-end-date")

    elif not budget or budget < 0:
        valid = False
        flash("Invalid budget!", category="invalid-budget")

    elif not category or not db.session.query(Category).get(category):
        valid = False
        flash("Invalid category.", category="invalid-category")
    

    if not valid:
        return render_template("sponser/campaign.html", 
                                title=title,
                                description=description,
                                start_date=start_date,
                                end_date=end_date,
                                budget=budget,
                                goals=goals,
                                category_id=category,
                                error=True,
                                categories=categories)


    start_date = datetime.datetime.strptime(start_date, "%Y-%m-%d")
    end_date = datetime.datetime.strptime(end_date, "%Y-%m-%d")

    if start_date > end_date:
        valid = False
        flash("Invalid end date.", category="invalid-end-date")
        flash("Invalid start date.", category="invalid-start-date")
        return render_template("sponser/campaign.html", 
                        title=title,
                        description=description,
                        start_date=start_date,
                        end_date=end_date,
                        budget=budget,
                        goals=goals,
                        category_id=category,
                        error=True,
                        categories=categories)
    
    campaign = Campaign(sponser_id=session["user-id"],
                        name=title,
                        description=description,
                        budget=budget,
                        start_date=start_date,
                        end_date=end_date,
                        goals=goals,
                        category_id=category,
                        private=private)
    db.session.add(campaign)
    db.session.commit()

    flash("Created campaign succesfully", category="alert-success")
    return redirect("/sponser/campaign")


@api.route("/sponser/campaign/<int:id_>", methods=["GET", "POST"])
def update_campaign(id_):
    campaign = db.session.query(Campaign).get(id_)
    categories = Category.query.all()
    campaigns = Campaign.query.filter_by(sponser_id=session["user-id"]).all()

    if request.method == "GET":
        if not campaign:
            flash("Campaign not found.", "alert-danger")
        return render_template("sponser/campaign.html", 
                        campaign=campaign, 
                        campaigns=campaigns, 
                        categories=categories)
    

    title = request.form.get("title", None)    
    description = request.form.get("description", None)
    start_date = request.form.get("start-date", None)
    end_date = request.form.get("end-date", None)
    budget = request.form.get("budget", None, type=int)
    private = request.form.get("private", None) == "on"
    goals = request.form.get("goals", None)
    category = request.form.get("category", None, type=int)

    valid = True
    if not title:
        valid = False
        flash("Field required!", category="invalid-title")

    elif not start_date or not re.match("[0-9]{4}-(0[1-9]{1}|10|11|12)-([012][0-9]|30|31)", start_date):
        valid = False
        flash("Invalid start date", category="invalid-start-date")
    
    elif not end_date or not re.match("[0-9]{4}-(0[1-9]{1}|10|11|12)-([012][0-9]|30|31)", end_date):
        valid = False
        flash("Invalid end date", category="invalid-end-date")

    elif not budget or budget < 0:
        valid = False
        flash("Invalid budget!", category="invalid-budget")

    elif not category or not db.session.query(Category).get(category):
        valid = False
        flash("Invalid category.", category="invalid-category")
    

    if not valid:
        return render_template("sponser/campaign.html", 
                                title=title,
                                description=description,
                                start_date=start_date,
                                end_date=end_date,
                                budget=budget,
                                goals=goals,
                                category_id=category,
                                error=True,
                                categories=categories,
                                campaign=campaign,
                                campaigns=campaigns)


    start_date = datetime.datetime.strptime(start_date, "%Y-%m-%d")
    end_date = datetime.datetime.strptime(end_date, "%Y-%m-%d")

    if start_date > end_date:
        valid = False
        flash("Invalid end date.", category="invalid-end-date")
        flash("Invalid start date.", category="invalid-start-date")
        return render_template("sponser/campaign.html", 
                        title=title,
                        description=description,
                        start_date=start_date,
                        end_date=end_date,
                        budget=budget,
                        goals=goals,
                        category_id=category,
                        error=True,
                        categories=categories,
                        campaign=campaign,
                        campaigns=campaigns)
    
    campaign.name = title
    campaign.description = description
    campaign.start_date = start_date
    campaign.end_date = end_date
    campaign.budget = budget
    campaign.goals = goals
    campaign.private = private
    campaign.category_id = category

    print(campaign.private)

    db.session.commit()
    flash("Updated campaign", category="alert-success")
    return redirect("/sponser/campaign")


@api.route("/campaign/<int:id_>", methods=["POST"])
def delete_campiagn(id_):
    campaign = db.session.query(Campaign).get(id_)

    if not campaign:
        flash("Campaign not found!", category="alert-danger")
        return redirect("/sponser")
    
    db.session.delete(campaign)
    db.session.commit()

    flash("Deleted campaign successfully.", category="alert-success")
    return redirect("/sponser/campaign")


@api.route("/campaign/<int:id_>")
def ad_management(id_):
    campaign = db.session.query(Campaign).get(id_)
    requests = AdRequest.query.filter_by(campaign_id=id_).all()
    influencers = Influencer.query.filter_by(category_id=campaign.category_id).all()

    return render_template("sponser/ad-management.html",
                           campaign_id=campaign.id,
                           requests=requests, 
                           influencers=influencers)


@api.route("/campaign/<int:id_>/add", methods=["POST"])
def create_ad_request(id_):
    campaign = db.session.query(Campaign).get(id_)

    if not campaign:
        flash("Invalid campaign", category="alert-danger")
        return redirect("/sponser/campaign")
    
    influencer = Influencer.query.filter_by(user_id=request.form.get("influencer", None, type=int)).first()
    requirements = request.form.get("requirements", None)
    amount = request.form.get("amount", -1, type=int)

    if not influencer or amount < 0:
        flash("Invalid form!", category="alert-danger")
        return redirect("/sponser/campaign")
    
    ad = AdRequest(influencer_id=influencer.user_id,
                   campaign_id=campaign.id,
                   requirements=requirements,
                   amount=amount)
    db.session.add(ad)
    db.session.commit()

    return redirect(f"/campaign/{id_}")


@api.route("/ad-request/<int:id_>", methods=["GET", "POST"])
def edit_ad_request(id_):
    ad_request = db.session.query(AdRequest).get(id_)
    campaign = db.session.query(Campaign).get(ad_request.campaign_id)
    requests = AdRequest.query.filter_by(campaign_id=id_).all()
    influencers = Influencer.query.filter_by(category_id=campaign.category_id).all()

    if request.method == "GET":
        return render_template("sponser/ad-management.html",
                            ad_request=ad_request,
                            requests=requests,
                            influencers=influencers
                            )

    influencer = Influencer.query.filter_by(user_id=request.form.get("influencer", None, type=int)).first()
    requirements = request.form.get("requirements", None)
    amount = request.form.get("amount", -1, type=int)

    print(influencer, amount)
    if not influencer or amount < 0:
        flash("Invalid form!", category="alert-danger")
        return redirect(f"/ad_request/{id_}")
    
    ad_request.influencer_id=influencer.user_id
    ad_request.requirements=requirements
    ad_request.amount=amount
    db.session.commit()

    return redirect(f"/campaign/{ad_request.campaign_id}")
