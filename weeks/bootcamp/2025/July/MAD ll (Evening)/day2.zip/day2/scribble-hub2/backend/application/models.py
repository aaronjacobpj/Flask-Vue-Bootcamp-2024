from flask_sqlalchemy import SQLAlchemy
from flask_security.models import fsqla


db = SQLAlchemy()


class User(db.Model, fsqla.FsUserMixin):
    __tablename__ = "user"

    name = db.Column(db.String(), nullable=False)
    roles = db.relationship("Role", secondary="user_roles")


class Role(db.Model, fsqla.FsRoleMixin):
    __tablename__ = "role"


class UserRole(db.Model):
    __tablename__ = "user_roles"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.ForeignKey("user.id"), nullable=False)
    role_id = db.Column(db.ForeignKey("role.id"), nullable=False)


class Post(db.Model):
    __tablename__ = "post"

    id = db.Column(db.Integer(), primary_key=True)
    content = db.Column(db.String(), nullable=False)


class Comment(db.Model):
    __tablename__ = "comment"

    id = db.Column(db.Integer(), primary_key=True)
    content = db.Column(db.String(), nullable=False)
    user_id = db.Column(db.ForeignKey("user.id"), nullable=False)
    post_id = db.Column(db.ForeignKey("post.id"), nullable=False)
