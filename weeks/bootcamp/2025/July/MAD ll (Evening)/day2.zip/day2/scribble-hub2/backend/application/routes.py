from flask import Blueprint, request
from flask import current_app as app
from werkzeug.security import generate_password_hash, check_password_hash
from flask_security import login_user

from application.models import db, User

api = Blueprint("api", __name__)


@api.route("/signup", methods=["POST"])
def signup():
    name = request.json.get("name")
    email = request.json.get("email")
    password = request.json.get("password")
    
    if not name:
        return {"message": "Invalid name"}, 400
    
    if app.security.datastore.find_user(email=email):
        return {"message": "email already taken"}, 409
    
    if not password:
        return {"message": "Invalid password"}, 400
    
    user = app.security.datastore.create_user(name=name,
                                              email=email,
                                              password=generate_password_hash(password))
    role = app.security.datastore.find_role("user")
    user.roles.append(role)
    db.session.commit()


    return {"message": "Created user succesfully"}, 201


@api.route("/signin", methods=["POST"])
def signin():
    email = request.json.get("email")
    password = request.json.get("password")

    user = app.security.datastore.find_user(email=email)

    if not user or not check_password_hash(user.password, password):
        return {"message": "Invalid email or password"}, 404
    
    login_user(user)

    return {"roles": [role.name for role in user.roles],
            "token": user.get_auth_token()
        }, 200

