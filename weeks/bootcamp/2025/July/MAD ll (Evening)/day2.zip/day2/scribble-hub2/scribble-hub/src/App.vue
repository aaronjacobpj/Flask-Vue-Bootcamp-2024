<script setup>
  import { RouterView } from "vue-router";
</script>
<template>
  <div class="alert alert-success alert-dismissible fade show m-2"
    v-for="(alert, index) in $store.getters.getSuccessAlert" role="alert">
    {{ alert }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" 
    aria-label="Close" @click="deleteSuccessAlert(index)"></button>
  </div>
  <router-view></router-view>
</template>
<script>
  export default {
    created(){
      let user = localStorage.getItem("user")
      
      this.$store.commit("setUser", JSON.parse(user) || {roles: [], token: null})
    },
    methods:{
      deleteSuccessAlert(index){
        this.$store.commit("deleteSuccessAlert", index)
      }
    }
  }
</script>