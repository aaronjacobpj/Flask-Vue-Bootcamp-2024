import { createRouter, createWebHistory } from "vue-router";
import RegisterView from "@/views/RegisterView.vue";
import SigninView from "@/views/SigninView.vue"

export default createRouter({
    history: createWebHistory(),
    routes: [
        {
            path: "/",
            name: "signin",
            component: SigninView
        },
        {
            path: "/:name",
            name: "signin1",
            component: SigninView,
            props: true
        },
        {
            path: "/signup",
            name: "signup",
            component: RegisterView
        }
    ]
})