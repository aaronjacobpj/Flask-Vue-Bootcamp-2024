import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            user: {
                roles: [],
                token: null
            },
            successAlert: []
        }
    },
    getters: {
        getSuccessAlert(state){
            return state.successAlert
        }
    },
    mutations: {
        setUser(state, value){
            state.user = value
            localStorage.setItem("user", JSON.stringify(value))
        },
        addSuccessAlert(state, value){
            state.successAlert.push(value)
        },
        deleteSuccessAlert(state, id){
            state.successAlert = state.successAlert.filter((x, i) => i != id)
        }
    }
})