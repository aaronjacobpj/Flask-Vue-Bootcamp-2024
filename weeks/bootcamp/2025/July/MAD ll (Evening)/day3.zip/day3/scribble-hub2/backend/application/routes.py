from flask import Blueprint, request
from flask import current_app as app
from werkzeug.security import generate_password_hash, check_password_hash
from flask_security import login_user, roles_required, auth_token_required
from bleach import clean

from application.models import db, User, Post, Comment

api = Blueprint("api", __name__)


@api.route("/signup", methods=["POST"])
def signup():
    name = request.json.get("name")
    email = request.json.get("email")
    password = request.json.get("password")
    
    if not name:
        return {"message": "Invalid name"}, 400
    
    if app.security.datastore.find_user(email=email):
        return {"message": "email already taken"}, 409
    
    if not password:
        return {"message": "Invalid password"}, 400
    
    user = app.security.datastore.create_user(name=name,
                                              email=email,
                                              password=generate_password_hash(password))
    role = app.security.datastore.find_role("user")
    user.roles.append(role)
    db.session.commit()


    return {"message": "Created user succesfully"}, 201


@api.route("/signin", methods=["POST"])
def signin():
    email = request.json.get("email")
    password = request.json.get("password")

    user = app.security.datastore.find_user(email=email)

    if not user or not check_password_hash(user.password, password):
        return {"message": "Invalid email or password"}, 404
    
    login_user(user)

    return {"roles": [role.name for role in user.roles],
            "token": user.get_auth_token()
        }, 200


@api.route("/admin/post", methods=["PUT"])
@roles_required("admin")
def create_post():

    content = request.json.get("content")

    if not content:
        return {"message": "Invalid request"}, 400
    
    post = Post(content=clean(content,
                              tags=["h1", "h2", "h3", "h4", "h5", "h6", "p", "b",
                                    "strong", "em"]))
    db.session.add(post)
    db.session.commit()

    return {"message": "Created post successfully."}, 201


@api.route("/post")
@auth_token_required
def get_posts():
    posts = Post.query.all()
    return [{"id": post.id,
             "content": post.content} for post in posts]


@api.route("/admin/post/<int:id>", methods=["DELETE"])
def delete_post(id):
    post = db.session.query(Post).get(id)

    if not post:
        return {"message": "Invalid request"}, 404
    
    db.session.delete(post)
    db.session.commit()

    return {"message": "Request successful."}, 200

