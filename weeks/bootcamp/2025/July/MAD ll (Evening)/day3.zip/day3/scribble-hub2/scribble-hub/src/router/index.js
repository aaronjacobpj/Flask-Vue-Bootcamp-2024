import { createRouter, createWebHistory } from "vue-router";
import store from "@/store";

import RegisterView from "@/views/RegisterView.vue";
import SigninView from "@/views/SigninView.vue";
import AdminLayoutView from "@/views/admin/AdminLayoutView.vue";
import AdminBlogManagementView from "@/views/admin/AdminBlogManagementView.vue"
import AdminBlogView from "@/views/admin/AdminBlogView.vue";

export default createRouter({
    history: createWebHistory(),
    routes: [
        {
            path: "/",
            name: "signin",
            component: SigninView
        },
        {
            path: "/:name",
            name: "signin1",
            component: SigninView,
            props: true
        },
        {
            path: "/signup",
            name: "signup",
            component: RegisterView
        },
        {
            path: "/admin",
            name: "admin",
            component: AdminLayoutView,
            beforeEnter(to, from, next){
                if (store.getters.getRoles.includes("admin"))
                    next()
                else
                    next({name: "signin"})
            },
            children: [
                {
                    path: "blog",
                    name: "admin-blog",
                    component: AdminBlogManagementView
                },
                {
                    path: "search",
                    name: "admin-blog-view",
                    component: AdminBlogView
                }
            ]
        }
    ]
})