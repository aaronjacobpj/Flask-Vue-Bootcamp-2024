import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            user: {
                roles: [],
                token: null
            },
            successAlert: [],
            dangerAlert: [],
            posts: [],
        }
    },
    getters: {
        getSuccessAlert(state){
            return state.successAlert
        },
        getRoles(state){
            return state.user["roles"]
        },
        getToken(state){
            return state.user["token"]
        },
        getDangerAlert(state){
            return state.dangerAlert
        },
        getPosts(state){
            return state.posts
        }
    },
    mutations: {
        setUser(state, value){
            state.user = value
            localStorage.setItem("user", JSON.stringify(value))
        },
        addSuccessAlert(state, value){
            state.successAlert.push(value)
        },
        deleteSuccessAlert(state, id){
            state.successAlert = state.successAlert.filter((x, i) => i != id)
        },
        addDangerAlert(state, value){
            state.dangerAlert.push(value)
        },
        deleteDangerAlert(state, id){
            state.dangerAlert = state.dangerAlert.filter((x, i) => i != id)
        },
        setPosts(state, value){
            state.posts = value
        }
    },
    actions: {
        getPosts(context){
            fetch(import.meta.env.VITE_BASEURL+"/post", {
                headers: {
                    "Authentication-Token": context.getters.getToken
                }
            }).then(x =>{
                if(x.status == 200){
                    return x.json()
                }
                return []
            }).then(x =>{
                context.commit("setPosts", x);
            })
        }
    }
})