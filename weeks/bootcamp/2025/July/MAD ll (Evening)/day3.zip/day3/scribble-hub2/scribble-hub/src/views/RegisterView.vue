<script setup>
    import { RouterLink } from "vue-router";
</script>
<template>
    <div class="container-fluid d-flex justify-content-center align-items-center" style="min-height: 90vh;">
        <div class="card" style="border: none;">
            <div class="card-body">
                <h3 class="text-center">Sign up</h3>
                <div class="mb-3">
                    <label for="form-name" class="form-label">Full name</label>
                    <input type="text" class="form-control" id="form-name" 
                    placeholder="Harry Potter" v-model="form['name']" required>
                </div>
                <div class="mb-3">
                    <label for="form-email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="form-email" 
                    placeholder="harry@example.com" v-model="form['email']" required>
                    <div class="invalid-feedback feedback-div" v-show="error['email']">
                        {{ error["email"] }}
                    </div>
                </div>
                <div class="mb-3">
                    <label for="form-password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="form-password" 
                    placeholder="password" v-model="form['password']" required minlength="4">
                </div>
                <div class="mb-3 justify-content-center d-flex">
                    <input type="submit" value="Sign up" class="btn btn-primary" @click="signup">
                </div>
                <div class="mb-3 justify-content-center d-flex">
                    <router-link to="/">Sign in</router-link>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                form: {
                    name: null,
                    email: null,
                    password: null
                },
                error: {
                    name: null,
                    email: null,
                    password: null
                }
            }
        },
        methods: {
            validate(){
                if(!this.form["name"]){
                    return false
                }
                else if(!this.form["email"]){
                    return false
                }
                else if(!this.form['password'] || this.form['password'].length < 3){
                    return false
                }
                return true
            },
            signup(){
                if(!this.validate())
                    return 

                fetch(import.meta.env.VITE_BASEURL+"/signup", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(this.form)
                }).then(response =>{
                    if(response.status == 201){
                        this.$store.commit("addSuccessAlert", 
                                            "Created account successfully.")
                        this.$router.push({name: "signin"})
                    }
                    else if (response.status == 409){
                        this.error["email"] = "Email already taken"
                    }
                })

            }
        }
    }
</script>