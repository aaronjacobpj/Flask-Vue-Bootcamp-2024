<script setup>
    import { RouterLink } from "vue-router";
</script>
<template>
    <div class="container-fluid d-flex justify-content-center align-items-center" style="min-height: 90vh;">
        <div class="card" style="border: none;">
            <div class="card-body">
                <h3 class="text-center">Sign in</h3>
                <div class="mb-3">
                    <label for="form-email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="form-email" 
                    placeholder="harry@example.com" v-model="form['email']" required>
                    <div class="invalid-feedback feedback-div" v-show="error['email']">
                        {{ error["email"] }}
                    </div>
                </div>
                <div class="mb-3">
                    <label for="form-password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="form-password" 
                    placeholder="password" v-model="form['password']" required minlength="4">
                </div>
                <div class="mb-3 justify-content-center d-flex">
                    <input type="submit" value="Sign up" class="btn btn-primary" @click="signin">
                </div>
                <div class="mb-3 justify-content-center d-flex">
                    <router-link to="/signup">Create an account.</router-link>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                form: {
                    email: null,
                    password: null
                },
                error: {
                    email: null,
                    password: null
                }
            }
        },
        methods: {
            validate(){
                this.error = {
                    email: null,
                    password: null
                }

                if(!this.form["email"]){
                    return false
                }
                else if(!this.form['password']){
                    return false
                }
                return true
            },
            signin(){
                if(!this.validate())
                    return 

                fetch(import.meta.env.VITE_BASEURL+"/signin", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(this.form)
                }).then(x=>{
                    if(x.status == 200){
                        this.$store.commit("addSuccessAlert", "signed in successfully.")
                        return x.json()
                    }
                    else if (x.status == 404){
                        this.error["email"] = "Invalid email or password"
                    }
                    return {roles: [], token: null}
                }).then(x =>{
                    this.$store.commit("setUser", x);
                    if(x["roles"].includes("admin")){
                        this.$router.push({name: "admin"})
                    }
                })
            },
            
        }
    }
</script>