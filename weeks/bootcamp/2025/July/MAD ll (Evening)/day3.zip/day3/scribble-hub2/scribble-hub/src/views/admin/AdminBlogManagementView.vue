<template>
    <div class="row m-2" v-html="form['content']">
    </div>
    <hr>
    <div class="row">
        <div class="mb-3 m-2">
            <label for="contenttext" class="form-label">Content</label>
            <textarea class="form-control" id="contenttext" v-model="form['content']"
                rows="3">
            </textarea>
        </div>
        <div class="mb-3 m-2">
            <input type="submit" value="Create" @click="save" class="btn btn-primary"/>
        </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                form: {
                    content: null
                }
            }
        },
        methods: {
            save(){
                fetch(import.meta.env.VITE_BASEURL+"/admin/post", {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify(this.form)
                }).then(x =>{
                    if(x.status == 201){
                        this.$store.commit("addSuccessAlert", 
                            "Created post successfully."
                        )
                        this.$router.push({name: "admin-blog-view"})
                    }
                    else if(x.status == 400){
                        this.$store.commit("addDangerAlert", 
                            "Invalid request."
                        )
                    }
                })
            }
        }
    }
</script>