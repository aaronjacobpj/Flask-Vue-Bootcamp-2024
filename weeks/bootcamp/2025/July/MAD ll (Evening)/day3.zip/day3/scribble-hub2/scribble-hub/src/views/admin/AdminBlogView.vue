<template>
    <div class="row m-3">
        <div class="mb-3">
            <input type="search" placeholder="Search for content" 
                class="form-control" v-model="query">
        </div>
    </div>
    <div class="row m-3" v-for="post in posts" >
        <div v-html="post['content']">
        </div>
        <div class="d-flex justify-content-end">
            <button class="btn btn-danger" @click="delete_post(post['id'])">
                Delete
            </button>
        </div>
    </div>
</template>
<script>
    export default {
        created(){
            this.$store.dispatch("getPosts")
        },
        data(){
            return {
                query: ""
            }
        },
        methods: {
            delete_post(id){
                fetch(import.meta.env.VITE_BASEURL+"/admin/post/"+id, {
                    method: "DELETE",
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(x =>{
                    if(x.status == 200){
                        this.$store.dispatch("getPosts");
                        this.$store.commit("addSuccessAlert", 
                            "Deleted Post successfully.")
                    }
                    else {
                        this.$store.commit("addDangerAlert", 
                            "Invalid request") 
                    }
                })
            }
        },
        computed:{
            posts(){
                let posts = this.$store.getters.getPosts
                posts = posts.filter(x => x["content"].toLowerCase().includes(
                    this.query.toLowerCase()))
                posts = JSON.parse(JSON.stringify(posts))
                posts.forEach(element => {
                    element["content"] = element["content"].slice(0, 200)+"..."
                });
                return posts
            }
        }
    }
</script>