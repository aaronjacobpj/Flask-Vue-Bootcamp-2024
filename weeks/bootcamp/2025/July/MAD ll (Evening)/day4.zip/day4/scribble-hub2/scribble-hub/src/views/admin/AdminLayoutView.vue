<script setup>
    import { RouterView, RouterLink } from "vue-router";
</script>
<template>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
            <router-link class="navbar-brand" to="/admin">Admin</router-link>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <router-link class="nav-link" to="/admin/blog">Create</router-link>
                </li>
                <li class="nav-item">
                    <router-link class="nav-link" to="/admin/search">Search</router-link>
                </li>
                <li class="nav-item">
                    <a class="nav-link" style="color: red;" href="#" @click="signout">Sign out</a>
                </li>
            </ul>
            </div>
        </div>
    </nav>
    <router-view></router-view>
</template>
<script>
export default {
    methods: {
        signout(){
            this.$store.commit("setUser", {roles: [], token: null});
            this.$router.push({name: "signin"})
        }
    }
}
</script>