from flask import Flask
from flask_security import Security, SQLAlchemyUserDatastore
from werkzeug.security import generate_password_hash
from flask_cors import CORS
import os
from celery import Celery
from celery.schedules import crontab


from application.models import db, User, Role
from application.routes import api
from application.celery import celery_init_app
from application.worker import daily_reminder, monthly_reminder
from application.cache import cache

def create_app():
    app = Flask(__name__)

    CORS(app)

    app.config["SECRET_KEY"] = os.environ.get("SECRET", "udfsihighireh")
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///model.db"
    app.config["CELERY"] = dict(broker_url="redis://localhost",
                                result_backend="redis://localhost"
                            )
    app.config["CACHE_TYPE"] = "RedisCache"
    app.config["CACHE_REDIS_URL"] = "redis://localhost/0"
    app.config["CACHE_DEFAULT_TIMEOUT"] = 20

    db.init_app(app)
    cache.init_app(app)

    datastore = SQLAlchemyUserDatastore(db, User, Role)
    app.security = Security(app, datastore)


    with app.app_context():
        db.create_all()

        if not app.security.datastore.find_role("admin"):
            admin = app.security.datastore.create_role(name="admin")
            app.security.datastore.create_role(name="user")

            user = app.security.datastore.create_user(name="Alice",
                                            email="alice@example.com",
                                            password=generate_password_hash("alice"))
            user.roles.append(admin)
            db.session.commit()

    app.register_blueprint(api)

    return app


app = create_app()

celery = celery_init_app(app)


@celery.on_after_configure.connect
def setup_periodic_tasks(sender: Celery, **kwargs):
    sender.add_periodic_task(crontab(minute="*"), 
                            daily_reminder.s(), 
                            name="daily reminder")

    sender.add_periodic_task(crontab(minute="*"), 
                            monthly_reminder.s(), 
                            name="monthly reminder")



if __name__ == "__main__":
    app.run(debug=True)
