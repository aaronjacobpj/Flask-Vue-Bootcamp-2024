from celery import shared_task
from celery.result import AsyncResult
import csv
from io import StringIO
from smtplib import SMTP
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import os
from flask import render_template

from application.models import Post, User

@shared_task
def export():

    file = StringIO()
    writer = csv.writer(file)

    writer.writerow(["ID", "No. comments"])
    
    for post in Post.query.all():
        writer.writerow([post.id, post.total_comments()])

    file.seek(0)
    return file.read()


@shared_task
def daily_reminder():
    smtp = SMTP("localhost",
                port=os.environ.get("port", 1025))
    
    for user in User.query.all():

        smtp.sendmail(msg="Check out new posts!", 
                          from_addr="daily@example.com",
                          to_addrs=user.email)
        

@shared_task
def monthly_reminder():
    smtp = SMTP("localhost",
                port=os.environ.get("port", 1025))
    
    posts = Post.query.all()
    
    message = MIMEMultipart()
    message["Subject"] = "Monthly Mail"
    message["From"] = "monthly@example.com"
    message["To"] = "alice@example.com"

    content = render_template("report.html", posts=posts)
    message.attach(MIMEText(content, "text/html"))

    smtp.sendmail(msg=message.as_string(),
                  from_addr="monthly@example.com",
                  to_addrs="alice@example.com")
