import { createRouter, createWebHistory } from "vue-router";
import store from "@/store";

import RegisterView from "@/views/RegisterView.vue";
import SigninView from "@/views/SigninView.vue";
import AdminLayoutView from "@/views/admin/AdminLayoutView.vue";
import AdminBlogManagementView from "@/views/admin/AdminBlogManagementView.vue";
import AdminBlogView from "@/views/admin/AdminBlogView.vue";
import AdminBlogEditView from "@/views/admin/AdminBlogEditView.vue";
import AdminDashboardView from "@/views/admin/AdminDashboardView.vue"

import UserLayoutView from "@/views/user/UserLayoutView.vue";
import UserSearchView from "@/views/user/UserSearchView.vue";
import UserBlogView from "@/views/user/UserBlogView.vue";


export default createRouter({
    history: createWebHistory(),
    routes: [
        {
            path: "/",
            name: "signin",
            component: SigninView
        },
        {
            path: "/signup",
            name: "signup",
            component: RegisterView
        },
        {
            path: "/admin",
            name: "admin",
            component: AdminLayoutView,
            beforeEnter(to, from, next){
                if (store.getters.getRoles.includes("admin"))
                    next()
                else
                    next({name: "signin"})
            },
            children: [
                {
                    path: "",
                    name: "admin-home",
                    component: AdminDashboardView
                },
                {
                    path: "blog",
                    name: "admin-blog",
                    component: AdminBlogManagementView
                },
                {
                    path: "search",
                    name: "admin-blog-view",
                    component: AdminBlogView
                },
                {
                    path: "blog/:id",
                    name: "admin-blog-edit",
                    component: AdminBlogEditView,
                    props: true
                }
            ]
        },
        {
            path: "/user",
            name: "user",
            component: UserLayoutView,
            beforeEnter(to, from, next){
                if (store.getters.getRoles.includes("user"))
                    next()
                else
                    next({name: "signin"})
            },
            children: [
                {
                    path: "",
                    name: "user-blog-search",
                    component: UserSearchView
                },
                {
                    path: "blog/:id",
                    name: "user-blog-view",
                    component: UserBlogView,
                    props: true
                }
            ]
        }
    ]
})