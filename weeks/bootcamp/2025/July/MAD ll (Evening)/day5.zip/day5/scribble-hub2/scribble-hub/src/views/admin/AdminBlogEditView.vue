<template>
    <div class="row m-2" v-html="form['content']">
    </div>
    <hr>
    <div class="row m-2">
        <div class="mb-3">
            <label for="contenttext" class="form-label">Content</label>
            <textarea class="form-control" id="contenttext" v-model="form['content']"
                rows="3">
            </textarea>
        </div>
        <div class="mb-3">
            <input type="submit" value="Update" @click="save" class="btn btn-primary"/>
        </div>
    </div>
</template>
<script>
    export default {
        props: ["id"],
        data(){
            return {
                form: {
                    content: null
                }
            }
        },
        created(){
            this.$store.dispatch("getPosts")
        },
        watch: {
            "$store.state.posts": function(value){
                let result = value.find(x => x["id"] == this.id)
                if(result)
                    this.form["content"] = result["content"]
            }
        },
        methods: {
            save(){
                fetch(import.meta.env.VITE_BASEURL+"/admin/post/"+this.id, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify(this.form)
                }).then(x =>{
                    if(x.status == 201){
                        this.$store.commit("addSuccessAlert", 
                            "Updated post successfully."
                        )
                        this.$router.push({name: "admin-blog-view"})
                    }
                    else if(x.status == 400){
                        this.$store.commit("addDangerAlert", 
                            "Invalid request."
                        )
                    }
                })
            }
        }
    }
</script>