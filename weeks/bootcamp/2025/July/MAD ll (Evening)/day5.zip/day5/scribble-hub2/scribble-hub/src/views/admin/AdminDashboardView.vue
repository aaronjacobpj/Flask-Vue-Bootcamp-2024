<template>
    <apexchart width="500" type="pie" :options="chartOptions" :series="chartSeries">
    </apexchart>
</template>
<script>
    export default {
        data(){
            return {
                stats: {
                    post: [],
                    comments: []
                },
            }
        },
        created(){
            fetch(import.meta.env.VITE_BASEURL+"/statistics",{
                headers: {
                    "Authentication-Token": this.$store.getters.getToken
                }
            }).then(x =>{
                if(x.status == 200)
                    return x.json()
                return {posts: [], comments: []}
            }).then(x =>{
                this.stats = x
            })
        },
        computed: {
            chartOptions(){
                return {
                    labels: this.stats["post"]
                }
            },
            chartSeries(){
                return this.stats["comments"]
            }
        }
    }
</script>