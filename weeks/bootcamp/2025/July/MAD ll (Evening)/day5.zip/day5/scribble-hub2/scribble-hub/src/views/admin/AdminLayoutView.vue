<script setup>
    import { RouterView, RouterLink } from "vue-router";
</script>
<template>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
            <router-link class="navbar-brand" to="/admin">Admin</router-link>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <router-link class="nav-link" to="/admin/blog">Create</router-link>
                </li>
                <li class="nav-item">
                    <router-link class="nav-link" to="/admin/search">Search</router-link>
                </li>
                <li class="nav-item">
                    <a class="nav-link" @click="export_file">Export</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" style="color: red;" href="#" @click="signout">Sign out</a>
                </li>
            </ul>
            </div>
        </div>
    </nav>
    <router-view></router-view>
</template>
<script>
export default {
    data(){
        return {
            task: null
        }
    },
    methods: {
        signout(){
            this.$store.commit("setUser", {roles: [], token: null});
            this.$router.push({name: "signin"})
        },
        export_file(){
            fetch(import.meta.env.VITE_BASEURL+"/export",{
                headers: {
                    "Authentication-Token": this.$store.getters.getToken
                }
            }).then(x => x.json()
            ).then(x => {
                this.task = x["task-id"]
                this.download()
            }) 
        },
        download(){
            fetch(import.meta.env.VITE_BASEURL+"/task/"+this.task,{
                headers: {
                    "Authentication-Token": this.$store.getters.getToken
                }
            }).then(x => x.json()
            ).then(x =>{
                if(x["status"] == "SUCCESS")
                    open(import.meta.env.VITE_BASEURL+"/task/"+this.task+"/download")
                else if(["PENDING", "STARTED"].includes(x["status"])){
                    setTimeout(this.download, 1000)
                }

            })
        }
    }
}
</script>