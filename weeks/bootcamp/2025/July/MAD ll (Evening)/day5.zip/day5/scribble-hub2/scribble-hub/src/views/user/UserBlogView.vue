<template>
    <div class="row m-2" v-html="content">
    </div>
    <hr>
    <div class="row m-2">
        <div class="mb-3">
            <label for="contenttext" class="form-label">Comment</label>
            <textarea class="form-control" id="contenttext" v-model="form['comment']"
                rows="3">
            </textarea>
        </div>
        <div class="mb-3">
            <input type="submit" value="Save" @click="save" class="btn btn-primary"/>
        </div>
    </div>
    <hr/>
    <h1>Comments</h1>
    <div class="row m-2" v-for="comment in comments">
        {{ comment['content'] }}
        <hr/>
    </div>
</template>
<script>
    export default {
        props: ["id"],
        data(){
            return {
                content: null,
                form: {
                    comment: null
                },
                comments: []
            }
        },
        created(){
            this.$store.dispatch("getPosts")
            this.getComments()
            this.userComment()
        },
        watch: {
            "$store.state.posts": function(value){
                let result = value.find(x => x["id"] == this.id)
                if(result)
                    this.content = result["content"]
            }
        },
        methods: {
            save(){
                fetch(import.meta.env.VITE_BASEURL+"/user/post/"+this.id, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify(this.form)
                }).then(x =>{
                    if(x.status == 200){
                        this.$store.commit("addSuccessAlert", 
                            "Request successful."
                        )
                        this.getComments()
                    }
                    else if(x.status == 400){
                        this.$store.commit("addDangerAlert", 
                            "Invalid request."
                        )
                    }
                })
            },
            getComments(){
                fetch(import.meta.env.VITE_BASEURL+"/user/post/"+this.id, {
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(x =>{
                    if (x.status == 200){
                        return x.json()
                    }
                    else{
                        return []
                    }
                }).then(x => this.comments = x)
            },
            userComment(){
                fetch(import.meta.env.VITE_BASEURL+"/user/post/"+this.id+"/comment", 
                {
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(x =>{
                    if (x.status == 200){
                        return x.json()
                    }
                    else{
                        return {}
                    }
                }).then(x => this.form["comment"] = x["content"])
            }
        }
    }
</script>