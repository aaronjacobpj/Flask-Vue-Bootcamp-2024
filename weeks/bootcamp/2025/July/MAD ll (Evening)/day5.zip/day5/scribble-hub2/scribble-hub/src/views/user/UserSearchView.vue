<template>
    <div class="row m-3">
        <div class="mb-3">
            <input type="search" placeholder="Search for content" 
                class="form-control" v-model="query">
        </div>
    </div>
    <div class="row m-3" v-for="post in posts" >
        <div v-html="post['content']">
        </div>
        <div class="d-flex justify-content-end mx-3">
            <button class="btn btn-primary" @click="redirect_post(post['id'])">
                Read
            </button>
        </div>
    </div>
</template>
<script>
    export default {
        created(){
            this.$store.dispatch("getPosts")
        },
        data(){
            return {
                query: ""
            }
        },
        methods: {
            redirect_post(id){
                this.$router.push({name: "user-blog-view", params: {"id": id}})
            }
        },
        computed:{
            posts(){
                let posts = this.$store.getters.getPosts
                posts = posts.filter(x => x["content"].toLowerCase().includes(
                    this.query.toLowerCase()))
                posts = JSON.parse(JSON.stringify(posts))
                posts.forEach(element => {
                    element["content"] = element["content"].slice(0, 200)+"..."
                });
                return posts
            }
        }
    }
</script>