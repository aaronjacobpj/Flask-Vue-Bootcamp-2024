from flask import Flask, render_template, redirect


app = Flask(__name__)

count = 0

@app.route("/")
def index():
    return render_template("index.html",
                           count=count)

@app.route("/click")
def click():
    global count
    count += 1
    return redirect("/")