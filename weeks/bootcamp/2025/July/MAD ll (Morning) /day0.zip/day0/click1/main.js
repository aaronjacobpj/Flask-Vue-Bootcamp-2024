counter = 0;
function count(){
  counter++;
  message = `You have clicked ${counter} times!`
  document.querySelector("h1").innerText = message;
}