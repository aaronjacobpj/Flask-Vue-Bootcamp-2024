<template>
  <ul>
    <li v-for="(item, index) in items">{{ index }}). {{ item }}</li>
  </ul>
</template>
<script>
  export default {
    data(){
      return {
        counter: 0,
        items: [
          "Item 1",
          "Item 2",
          "Item 3",
          "Item 4"
        ]
      }
    }
  }
</script>