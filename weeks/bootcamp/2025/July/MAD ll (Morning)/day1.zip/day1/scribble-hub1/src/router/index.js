import { createRouter, createWebHistory } from "vue-router";
import SigninView from "@/views/SigninView.vue"
import RegisterView from "@/views/RegisterView.vue"



export default createRouter({
    history: createWebHistory(),
    routes: [
        {
            path: "/",
            name: "signin",
            component: SigninView,
            props:true 
        },
        {
            path: "/signup",
            name: "signup",
            component: RegisterView
        }
    ]
})