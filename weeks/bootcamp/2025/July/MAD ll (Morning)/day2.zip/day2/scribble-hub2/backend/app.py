from flask import Flask
from flask_security import Security, SQLAlchemyUserDatastore
from werkzeug.security import generate_password_hash
from flask_cors import CORS
from application.models import db, User, Role
from application.routes import api
import os


def create_app():
    app = Flask(__name__)

    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///model.db"
    app.config["SECRET_KEY"] = os.environ.get("SECRET", "uefbusvnkn")

    db.init_app(app)

    datastore = SQLAlchemyUserDatastore(db, User, Role)
    app.security = Security(app, datastore)
    CORS(app)


    with app.app_context():
        db.create_all()
        if not Role.query.filter_by(name="admin").first():
            admin = app.security.datastore.create_role(name="admin")
            app.security.datastore.create_role(name="user")

            user = app.security.\
                    datastore.\
                    create_user(name="Alice",
                                email="alice@example.com",
                                password=generate_password_hash("alice"))
            user.roles.append(admin)
            db.session.commit()

    app.register_blueprint(api)

    return app


app = create_app()


if __name__ == "__main__":
    app.run(debug=True)
