import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            successAlert: [],
            user: {
                token: null,
                roles: []
            }
        }
    },
    getters: {
        getSuccessAlert(state){
            return state.successAlert;
        }
    },
    mutations: {
        deleteSuccessAlert(state, id){
            state.successAlert = state.successAlert.filter((v, i) => i != id);
        },
        addSuccessAlert(state, value){
            state.successAlert.push(value)
        },
        setUser(state, value){
            state.user = value
            localStorage.setItem("user", JSON.stringify(value))
        }
    }
})