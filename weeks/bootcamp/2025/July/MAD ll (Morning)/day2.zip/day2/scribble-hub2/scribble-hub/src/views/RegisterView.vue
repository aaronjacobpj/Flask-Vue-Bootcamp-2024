<template>
    <div class="container-fluid d-flex justify-content-center align-items-center" style="height: 90vh;">
        <div class="row">
            <form v-on:submit.prevent="signup">
                <div class="col">
                    <div class="mb-3 d-flex justify-content-center">
                        <h3>Sign up {{ $store.getters.getMessage }}</h3>
                    </div>
                    <div class="mb-3">
                        <label for="fullname-input" class="form-label">Full name</label>
                        <input type="text" class="form-control" id="fullname-input" v-model="form['name']"
                        placeholder="Harry Potter" required>
                    </div> 
                    <div class="mb-3">
                        <label for="email-input" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email-input" v-model="form['email']"
                        placeholder="harry@example.com" required>
                        <div class="invalid-feedback" v-bind:class="{'error-message': error['email']}">
                            {{ error['email'] }}
                        </div>
                    </div>         
                    <div class="mb-3">
                        <label for="password-input" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password-input"  v-model="form['password']"
                        placeholder="password" required minlength="4" maxlength="16">
                    </div>
                    <div>
                        <input type="submit" value="Sign up" class="btn btn-primary" style="width: 100%;">
                    </div> 
                    <div class="mb-3 d-flex justify-content-center py-2">
                        <router-link to="/">Sign in</router-link>
                    </div> 
                </div>
            </form>
        </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                form : {
                    name: null,
                    email: null,
                    password: null
                },
                error: {
                    email: null
                },
            }
        },
        methods: {
            validate(){
                this.error =  {
                    email: null
                }

                if(!this.form['name']){
                    return false
                }
                else if(!this.form['email']){
                    return false
                }
                else if (!this.form['password']){
                    return false
                }
                return true
            },
            signup(){
                if(!this.validate())
                    return

                fetch(import.meta.env.VITE_BASEURL+"/signup", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(this.form)
                }).then(response => {
                    if (response.status == 201){
                        this.$store.commit("addSuccessAlert", 
                                        "Created user successfully.")
                        this.$router.push({name: "signin"})
                    }
                    else if (response.status == 409){
                        this.error["email"] = "Email already taken."
                    }
                })
            },
        },
        computed: {
        }
    }
</script>