from flask import Blueprint, request
from flask import current_app as app
from werkzeug.security import generate_password_hash, check_password_hash
from flask_security import login_user, current_user, auth_token_required, roles_required
from bleach import clean
from sqlalchemy import desc


from application.models import db, Post


api = Blueprint("api", __name__)


@api.route("/signup", methods=["POST"])
def signup():
    name = request.json.get("name")
    email = request.json.get("email")
    password = request.json.get("password")

    if not name:
        return {"message": "Invalid name."}, 400
    
    if not email or app.security.datastore.find_user(email=email):
        return {"message": "Invalid email"}, 409
    
    if not password:
        return {"message": "Invalid password."}, 400
    

    user = app.security.datastore.create_user(name=name,
                                              email=email,
                                              password=generate_password_hash(password))
    role = app.security.datastore.find_role("user")
    user.roles.append(role)
    db.session.commit()

    return {"message": "Created user successfully"}, 201


@api.route("/signin", methods=["POST"])
def signin():
    email = request.json.get("email")
    password = request.json.get("password")

    user =  app.security.datastore.find_user(email=email)

    if not user or not check_password_hash(user.password, password):
        return {"message": "Invalid username or password"}, 404
    
    login_user(user)

    return {
            "token": user.get_auth_token(),
            "roles": [role.name for role in user.roles]
        }


@api.route("/admin/blog", methods=["PUT"])
@roles_required("admin")
def add_blog():
    user_id = current_user.id
    content = request.json.get("content", "")

    post = Post(user_id=user_id,
                content=clean(content, tags=["h1", "h2", "h3", "h4", "h5", "h6", "p", "b", "br"]))
    db.session.add(post)
    db.session.commit()
    return {"message": "Created blog successfully."}, 201


@api.route("/blog")
@auth_token_required
def get_blogs():
    posts = Post.query.order_by(desc(Post.id)).all()
    return [{"id": post.id,
             "content": post.content
            }
             for post in posts]


@api.route("/blog/<int:id>", methods=["DELETE"])
@roles_required("admin")
def delete_post(id):
    post = db.session.query(Post).get(id)

    if not post:
        return {"message": "Post not found."}, 404
    
    db.session.delete(post)
    db.session.commit()

    return {"message": "Deleted post successfully"}, 200


