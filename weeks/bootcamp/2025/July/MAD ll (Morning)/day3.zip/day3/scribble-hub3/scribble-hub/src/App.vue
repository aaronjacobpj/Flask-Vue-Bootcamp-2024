<script setup>
  import { RouterView } from "vue-router"
</script>
<template>
  <div class="alert alert-success alert-dismissible fade show my-1" 
    v-for="(alert, index) in $store.getters.getSuccessAlert" role="alert">
      {{ alert }}
    <button type="button" class="btn-close" @click="deleteSuccessAlert(index)"
    data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
  <div class="alert alert-danger alert-dismissible fade show my-1" 
    v-for="(alert, index) in $store.getters.getDangerAlert" role="alert">
      {{ alert }}
    <button type="button" class="btn-close" @click="deleteDangerAlert(index)"
    data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
  <router-view></router-view>
</template>
<script>
  export default {
    created(){
      let value = JSON.parse(localStorage.getItem("user")) || {token: null, roles: []}
      this.$store.commit("setUser", value)
    },
    methods: {
      deleteSuccessAlert(id){
        this.$store.commit("deleteSuccessAlert", id)
      },
      deleteDangerAlert(id){
        this.$store.commit("deleteDangerAlert", id)
      }
    }
  }
</script>