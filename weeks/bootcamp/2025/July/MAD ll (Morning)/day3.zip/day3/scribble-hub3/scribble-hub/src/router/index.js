import { createRouter, createWebHistory } from "vue-router";
import SigninView from "@/views/SigninView.vue"
import RegisterView from "@/views/RegisterView.vue"
import adminLayoutView from "@/views/admin/adminLayoutView.vue"
import adminDashboardView from "@/views/admin/adminDashboardView.vue"
import adminBlogManagementView from "@/views/admin/adminBlogManagementView.vue"
import adminBlogView from "@/views/admin/adminBlogView.vue"


import store from "@/store";

export default createRouter({
    history: createWebHistory(),
    routes: [
        {
            path: "/",
            name: "signin",
            component: SigninView,
            props:true 
        },
        {
            path: "/signup",
            name: "signup",
            component: RegisterView
        },
        {
            path: "/admin",
            name: "admin",
            component: adminLayoutView,
            beforeEnter(from, to, next){
                if(store.getters.getRoles.includes("admin")){
                    next()
                }
                else{
                    next({name: "signin"})
                }
            },
            children: [
                {
                    path: "",
                    name: "admin-home",
                    component: adminDashboardView
                },
                {
                    path: "blog",
                    name: "admin-blog",
                    component: adminBlogManagementView
                },
                {
                    path: "search",
                    name: "admin-blog-view",
                    component: adminBlogView
                }
            ]
        }
    ]
})