import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            successAlert: [],
            dangerAlert: [],
            user: {
                token: null,
                roles: []
            },
            posts: []
        }
    },
    getters: {
        getSuccessAlert(state){
            return state.successAlert;
        },
        getDangerAlert(state){
            return state.dangerAlert;
        },
        getRoles(state){
            return state.user["roles"]
        },
        getToken(state){
            return state.user["token"]
        },
        getPosts(state){
            return state.posts
        }
    },
    mutations: {
        deleteSuccessAlert(state, id){
            state.successAlert = state.successAlert.filter((v, i) => i != id);
        },
        deleteDangerAlert(state, id){
            state.dangerAlert = state.dangerAlert.filter((v, i) => i != id);
        },
        addSuccessAlert(state, value){
            state.successAlert.push(value)
        },
        addDangerAlert(state, value){
            state.dangerAlert.push(value)
        },
        setUser(state, value){
            state.user = value
            localStorage.setItem("user", JSON.stringify(value))
        },
        setPosts(state, value){
            state.posts = value
        }
    },
    actions: {
        getPosts(context){
            fetch(import.meta.env.VITE_BASEURL+"/blog",
                {
                    headers: {
                        "Authentication-Token": context.getters.getToken
                    }
                }
            ).then(x =>{
                if(x.status == 200)
                    return x.json()
                return []
            }).then(x =>{
                context.commit("setPosts", x)
            })
        }
    }
})