<script setup>
    import { RouterLink } from "vue-router"
</script>
<template>
    <div class="container-fluid d-flex justify-content-center align-items-center" style="height: 90vh;">
        <div class="row">
            <form v-on:submit.prevent="signin">
                <div class="col">
                    <div class="mb-3 d-flex justify-content-center">
                        <h3>Sign in </h3>
                    </div>
                    <div class="mb-3">
                        <label for="email-input" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email-input" v-model="form['email']"
                        placeholder="harry@example.com">
                        <div class="invalid-feedback" v-bind:class="{'error-message': error['email']}">
                            {{ error['email'] }}
                        </div>
                    </div>         
                    <div class="mb-3">
                        <label for="password-input" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password-input"  v-model="form['password']"
                        placeholder="password">
                    </div>
                    <div>
                        <input type="submit" value="Sign in" class="btn btn-primary" style="width: 100%;">
                    </div>  
                    <div class="mb-3 d-flex justify-content-center py-2">
                        <router-link v-bind:to="{name: 'signup'}">
                            Create an account.
                        </router-link>
                    </div>
                </div>
            </form>
        </div>
    </div>
</template>
<script>
    export default {
        props: ['name'],
        created(){
            
        },
        data(){
            return {
                form : {
                    email: null,
                    password: null
                },
                error: {
                    email: null
                }
            }
        },
        methods: {
            signin(){
                fetch(import.meta.env.VITE_BASEURL+"/signin", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(this.form)
                }).then(response => {
                    if (response.status == 200){
                        return response.json()
                    }
                    else if (response.status == 404){
                        this.error["email"] = "Invalid email or password."
                    }
                    return {
                            token: null,
                            roles: []
                        }
                }).then(x =>{
                    this.$store.commit("setUser", x);
                    this.$router.push({name: "admin-home"})
                })
            }
        }
    }
</script>