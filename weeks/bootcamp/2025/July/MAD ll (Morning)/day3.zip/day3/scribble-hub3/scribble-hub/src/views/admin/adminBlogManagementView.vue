<script setup>
</script>
<template>
    <div class="container-fluid">
        <div class="row" v-html="form['content']">
        </div>
        <div class="row">
            <div class="mb-3 my-3">
                <label for="content" class="form-label">Content</label>
                <textarea class="form-control" id="content" v-model="content" rows="3"></textarea>
            </div>
            <div class="mb-3">
                <input type="button" value="Save" class="btn btn-primary" @click="save">
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                form: {
                    content: null
                },
                content: null
            }
        },
        watch: {
            content(value){
                this.form['content'] = this.content.replace(/<script .*>.*<\/script.*>/, "")
            }
        },
        methods: {
            save(){
                fetch(import.meta.env.VITE_BASEURL+"/admin/blog", {
                    method: "PUT",
                    headers:{
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify(this.form)
                }).then(x =>{
                    if(x.status == 201){
                        this.$router.push({name: "admin-blog-view"})
                    }
                })
            }
        }
    }
</script>