<template>
    <div class="row m-3">
        <input type="text" class="form-control" v-model="query">
    </div>
    <div class="row m-3" v-for="post in posts">
        <div class="row" v-html="post['content']">
        </div>
        <div class="row d-flex justify-content-end">
            <button class="btn btn-danger" @click="delete_post(post['id'])"
                style="width: fit-content;">
                Delete
            </button>
        </div>
    </div>
</template>
<script>
    export default {
        created(){
            this.$store.dispatch("getPosts")
        },
        data(){
            return {
                query: ""
            }
        },
        methods: {
            delete_post(id){
                fetch(import.meta.env.VITE_BASEURL+"/blog/"+id,
                {
                    method: "DELETE",
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }
                ).then(x =>{
                    if(x.status == 200){
                        this.$store.dispatch("getPosts")
                    }
                    else if(x.status == 404)
                        this.$store.commit("addDangerAlert", 
                        "Deleted post successfully.")
                })
            }
        },
        computed: {
            posts(){
                return this.$store.getters.getPosts.filter(x =>{
                    return x["content"].toLowerCase().includes(this.query.toLowerCase())
                })
            },
        }
    }
</script>