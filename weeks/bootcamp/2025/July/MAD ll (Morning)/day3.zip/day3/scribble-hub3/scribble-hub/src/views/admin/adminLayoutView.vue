<script setup>
    import { RouterLink, RouterView } from "vue-router"
</script>
<template>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
            <router-link class="navbar-brand" :to="{name:'admin-home'}">Admin</router-link>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" 
                data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" 
                aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <router-link class="nav-link" :to="{name:'admin-blog'}">
                        Create
                    </router-link>
                    <router-link class="nav-link" :to="{name:'admin-blog-view'}">
                        Search
                    </router-link>                
                </div>
            </div>
        </div>
    </nav>
    <router-view></router-view>
</template>