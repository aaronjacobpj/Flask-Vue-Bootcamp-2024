from flask import Flask
from flask_security import Security, SQLAlchemyUserDatastore
from werkzeug.security import generate_password_hash
from flask_cors import CORS
from celery import Celery, Task
from celery.schedules import crontab
import os

from application.models import db, User, Role
from application.routes import api
from application.worker import daily_reminder, monthly_reminder



def create_app():
    app = Flask(__name__)

    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///model.db"
    app.config["SECRET_KEY"] = os.environ.get("SECRET", "uefbusvnkn")
    app.config["CELERY"] = dict(
        broker_url="redis://localhost",
        result_backend="redis://localhost"
    )

    db.init_app(app)

    datastore = SQLAlchemyUserDatastore(db, User, Role)
    app.security = Security(app, datastore)
    CORS(app)


    with app.app_context():
        db.create_all()
        if not Role.query.filter_by(name="admin").first():
            admin = app.security.datastore.create_role(name="admin")
            app.security.datastore.create_role(name="user")

            user = app.security.\
                    datastore.\
                    create_user(name="Alice",
                                email="alice@example.com",
                                password=generate_password_hash("alice"))
            user.roles.append(admin)
            db.session.commit()

    app.register_blueprint(api)

    return app


def celery_init_app(app: Flask) -> Celery:
    class FlaskTask(Task):
        def __call__(self, *args: object, **kwargs: object) -> object:
            with app.app_context():
                return self.run(*args, **kwargs)

    celery_app = Celery(app.name, task_cls=FlaskTask)
    celery_app.config_from_object(app.config["CELERY"])
    celery_app.set_default()
    app.extensions["celery"] = celery_app
    return celery_app


app = create_app()
celery = celery_init_app(app)


@celery.on_after_configure.connect
def setup_periodic_tasks(sender: Celery, **kwargs):
    # sender.add_periodic_task(10.0, monthly_reminder.s(), name="hello 10s")
    sender.add_periodic_task(crontab(minute="*"), 
                             daily_reminder.s(), 
                             name="reminder 1min")
    sender.add_periodic_task(crontab(minute="*"),
                            monthly_reminder.s(), 
                            name="monthly reminder")

    


if __name__ == "__main__":
    app.run(debug=True)
