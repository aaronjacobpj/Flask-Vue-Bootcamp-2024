from celery import shared_task
import csv
import io
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os
from flask import render_template
from sqlalchemy import func

from application.models import db, Post, User, Comment

@shared_task
def export():
    
    file = io.StringIO()
    writer = csv.writer(file)
    writer.writerow(["id", "content"])

    for post in Post.query.all():
        writer.writerow([post.id, post.content])

    file.seek(0)
    return file.read()

@shared_task
def daily_reminder():
    server = smtplib.SMTP(host="localhost",
                          port=int(os.environ.get("port", 1025)))
    
    

    for user in User.query.all():
        server.sendmail(msg="Sign in to read cool posts...",
                            from_addr="admin@example.com",
                            to_addrs=user.email)


@shared_task
def monthly_reminder():
    server = smtplib.SMTP(host="localhost",
                          port=int(os.environ.get("port", 1025)))
    
    subquery = (
        db.session.query(
            Comment.post_id,
            func.count(Comment.id).label('comment_count')
        )
        .group_by(Comment.post_id)
        .order_by(func.count(Comment.id).desc())
        .limit(1)
        .subquery()
    )

    # Join back to Post to get the full Post record
    post = db.session.query(Post).join(subquery, 
                                        Post.id == subquery.c.post_id).first()
    rows = Post.query.all()

    content = render_template("report.html", 
                              article=post,
                              posts=rows)
    
    mail = MIMEMultipart()
    mail["To"] = "alice@example.com"
    mail["From"] = "monthly@example.com"
    mail["Subject"] = "Monthly Report"

    mail.attach(MIMEText(content, "html"))
    server.sendmail(from_addr="monthly@example.com",
                    to_addrs="alice@example.com",
                    msg=mail.as_string())
    
