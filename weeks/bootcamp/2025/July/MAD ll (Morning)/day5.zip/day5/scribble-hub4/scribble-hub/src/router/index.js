import { createRouter, createWebHistory } from "vue-router";
import SigninView from "@/views/SigninView.vue"
import RegisterView from "@/views/RegisterView.vue"
import adminLayoutView from "@/views/admin/adminLayoutView.vue"
import adminDashboardView from "@/views/admin/adminDashboardView.vue"
import adminBlogManagementView from "@/views/admin/adminBlogManagementView.vue"
import adminBlogView from "@/views/admin/adminBlogView.vue"
import adminBlogUpdateView from "@/views/admin/adminBlogUpdateView.vue"

import userLayoutView from "@/views/user/userLayoutView.vue"
import UserHomeView from "@/views/user/UserHomeView.vue"
import UserBlogReviewView from "@/views/user/UserBlogReviewView.vue"


import store from "@/store";

export default createRouter({
    history: createWebHistory(),
    routes: [
        {
            path: "/",
            name: "signin",
            component: SigninView,
            props:true 
        },
        {
            path: "/signup",
            name: "signup",
            component: RegisterView
        },
        {
            path: "/signout",
            name: "signout",
            component: SigninView,
            beforeEnter(from, to, next){
                store.commit("setUser", {token: null, roles:[]})
                next({name: "signin"})
            }
        },
        {
            path: "/admin",
            name: "admin",
            component: adminLayoutView,
            beforeEnter(from, to, next){
                if(store.getters.getRoles.includes("admin")){
                    next()
                }
                else{
                    next({name: "signin"})
                }
            },
            children: [
                {
                    path: "",
                    name: "admin-home",
                    component: adminDashboardView
                },
                {
                    path: "blog",
                    name: "admin-blog",
                    component: adminBlogManagementView
                },
                {
                    path: "search",
                    name: "admin-blog-view",
                    component: adminBlogView
                },
                {
                    path: "blog/:id",
                    name: "admin-blog-edit",
                    component: adminBlogUpdateView,
                    props: true
                }
            ]
        },
        {
            path: "/user",
            name: "user",
            component: userLayoutView,
            beforeEnter(from, to, next){
                if(store.getters.getRoles.includes("user")){
                    next()
                }
                else{
                    next({name: "signin"})
                }
            },
            children: [
                {
                    path: "",
                    name: "user-home",
                    component: UserHomeView
                },
                {
                    path: "blog/:id",
                    name: "user-blog",
                    component: UserBlogReviewView,
                    props: true
                }
            ]
        }
    ]
})