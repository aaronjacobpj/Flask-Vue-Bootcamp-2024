<script setup>
</script>
<template>
    <div class="container-fluid">
        <div class="row" v-html="form['content']">
        </div>
        <div class="row">
            <div class="mb-3 my-3">
                <label for="content" class="form-label">Content</label>
                <textarea class="form-control" id="content" v-model="content" rows="3"></textarea>
            </div>
            <div class="mb-3">
                <input type="button" value="Save" class="btn btn-primary" @click="save">
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        props: ["id"],
        created(){
            this.$store.dispatch("getPosts");
        },
        data(){
            return {
                form: {
                    content: null
                },
                content: ""
            }
        },
        watch: {
            content(value){
                this.form['content'] = this.content.replace(/<script .*>.*<\/script.*>/, "")
            },
            "$store.state.posts": function(value){
                let content = value.find((v, i) => v["id"] == this.id)
                if (content){
                    this.content = content["content"];
                }
            }
        },
        methods: {
            save(){
                fetch(import.meta.env.VITE_BASEURL+"/admin/blog/"+this.id, {
                    method: "POST",
                    headers:{
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify(this.form)
                }).then(x =>{
                    if(x.status == 200){
                        this.$router.push({name: "admin-blog-view"})
                    }
                })
            }
        }
    }
</script>