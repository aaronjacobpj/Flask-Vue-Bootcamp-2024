<template>
    <div>
      <apexchart width="380" type="pie" :options="chartOptions" :series="chartSeries"></apexchart>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                options: {
                    labels: [],
                    responsive: [{
                        breakpoint: 480,
                        options: {
                            chart: {
                            width: 200
                            },
                            legend: {
                            position: 'bottom'
                            }
                        }
                    }]
                },
                series: []
            }
        },
        created(){
            fetch(import.meta.env.VITE_BASEURL+`/statistics`,
                {
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }
            ).then(x =>{
                if(x.status == 200)
                    return x.json()
                return []
            }).then(x =>{
                this.options["labels"] = x["posts"]
                this.series = x["comments"]
            })
        },
        computed: {
            chartSeries(){
                return this.series
            },
            chartOptions(){
                return this.options
            }
        }
    }
</script>