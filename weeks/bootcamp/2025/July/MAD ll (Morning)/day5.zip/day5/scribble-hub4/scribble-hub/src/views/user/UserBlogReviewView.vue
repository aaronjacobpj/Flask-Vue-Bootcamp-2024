<script setup>
</script>
<template>
    <div class="container-fluid">
        <div class="row" v-html="form['content']">
        </div>
        <div class="row">
            <div class="mb-3 my-3">
                <label for="content" class="form-label">Comment</label>
                <textarea class="form-control" id="content" v-model="comment"  rows="3"></textarea>
            </div>
            <div class="mb-3">
                <input type="button" value="Save" class="btn btn-primary" @click="save">
            </div>
        </div>
        <div class="container-fluid">
            <h3>Comments</h3>
            <div class="row" v-for="review in $store.getters.getComments">
                {{ review["content"] }}
                <hr/>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        props: ["id"],
        created(){
            this.$store.dispatch("getPosts")
            this.$store.dispatch("getComments", this.id);
            this.getUserComment()
        },
        data(){
            return {
                form: {
                    content: null
                },
                content: "",
                comment: null
            }
        },
        watch: {
            content(value){
                this.form['content'] = this.content.replace(/<script .*>.*<\/script.*>/, "")
            },
            "$store.state.posts": function(value){
                let content = value.find((v, i) => v["id"] == this.id)
                if (content){
                    this.content = content["content"];
                }
            }
        },
        methods: {
            getUserComment(){
                fetch(import.meta.env.VITE_BASEURL+"/user/blog/"+this.id, {
                    headers:{
                        "Authentication-Token": this.$store.getters.getToken
                    },
                }).then(x=>{
                    return x.json()
                }).then(x => {
                    this.comment = x["content"] || ""
                })
            },
            save(){
                fetch(import.meta.env.VITE_BASEURL+"/user/blog/"+this.id, {
                    method: "POST",
                    headers:{
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify({content: this.comment})
                }).then(x =>{
                    if(x.status == 200){
                        this.$store.dispatch("getComments", this.id);
                    }
                })
            }
        }
    }
</script>