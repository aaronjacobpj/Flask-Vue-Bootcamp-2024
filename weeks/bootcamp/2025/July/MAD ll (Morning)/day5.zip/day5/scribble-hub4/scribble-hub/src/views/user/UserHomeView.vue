<template>
    <div class="row m-3">
        <input type="text" class="form-control" v-model="query">
    </div>
    <div class="row m-3" v-for="post in posts">
        <div class="row" v-html="post['content']">
        </div>
         <div class="row d-flex justify-content-end">
            <div class="col-1">
                <button class="btn btn-primary" @click="redirect_post(post['id'])"
                    style="width: fit-content;">
                    Read
                </button>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        created(){
            this.$store.dispatch("getPosts")
        },
        data(){
            return {
                query: ""
            }
        },
        methods: {
            redirect_post(id){
                this.$router.push({name: "user-blog", params: {"id": id}})
            }
        },
        computed: {
            posts(){
                let posts = this.$store.getters.getPosts.filter(x =>{
                    return x["content"].toLowerCase().includes(this.query.toLowerCase())
                })
                console.log(posts);
                posts = JSON.parse(JSON.stringify(posts))
                    
                posts.forEach(element => {
                    element["content"] = element["content"].slice(0, 200)+"..."
                });
                return posts
            },
        }
    }
</script>