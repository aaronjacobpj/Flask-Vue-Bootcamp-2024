const Home = {
    template:`
        <div v-show="!invoked">
            <input type="text" v-model="message">
            <button @click="add_reminder"> Greet </button>
            <router-link to="/reminder">Reminders</router-link>
        </div>
    `,
    data(){
        return {
            message: null,
            invoked: false
        }
    },
    methods:{
        add_reminder(){
            this.$store.commit("addReminder", this.message)
            // this.$store.dispatch("AsyncAddReminder", this.message)
        }
    }
}
export default Home;