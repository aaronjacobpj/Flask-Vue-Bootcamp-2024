const ReminderList = {
    props: ["message"],
    template: `
        <router-link to="/">Home</router-link>
        <ol>
            <li v-for="reminder in $store.getters.getReminders"> {{ reminder }} </li>
        </ol>
    `
}

export default ReminderList;