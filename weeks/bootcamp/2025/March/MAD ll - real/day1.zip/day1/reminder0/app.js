import router from "./router.js"
import store from "./store.js"

const app = Vue.createApp({
    template: `
        <router-view></router-view>
    `
})


app.use(router);
app.use(store);
app.mount("#app")