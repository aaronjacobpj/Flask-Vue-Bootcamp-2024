import Home from "./Home.js"
import ReminderList from "./ReminderList.js"

const router = VueRouter.createRouter({
    history: VueRouter.createWebHistory(),
    routes: [
        {path: "/", name: "index", component: Home},
        {path: "/reminder", name: "reminder", component: ReminderList}
    ],
})

export default router;