const store = Vuex.createStore({
    state(){
        return {
            reminders: []
        }
    },
    getters:{
        getReminders(state){

            return state.reminders
        }
    },
    mutations:{
        addReminder(state, reminder){
            state.reminders.push(reminder)
        }
    },
    actions: {
        AsyncAddReminder(context, reminder){
            setTimeout(() => context.commit("addReminder", reminder),
            1000)
        }
    }
})

export default store;