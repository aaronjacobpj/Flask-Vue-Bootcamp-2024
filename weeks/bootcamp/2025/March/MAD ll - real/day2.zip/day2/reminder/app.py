from flask import Flask, request
from flask_security import SQLAlchemyUserDatastore, Security, login_user, auth_required, current_user, roles_required
from model import db, User, Role, Reminder
from flask_cors import CORS

app = Flask(__name__)
app.config['SECRET_KEY'] = "sihagoaehwnogjnoajmno"
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///project.db'

db.init_app(app)
datastore = SQLAlchemyUserDatastore(db, User, Role)
app.security = Security(app, datastore)

CORS(app)

with app.app_context():
    db.create_all()
    
    if not Role.query.filter_by(name="user").first():
        app.security.datastore.create_role(name="user")
        app.security.datastore.create_role(name="admin")
        db.session.commit()


@app.route("/")
def index():
    return "Hello, world!"


@app.route("/create-user/<string:name>")
def create_user(name):
    user = app.security.datastore.create_user(name=name)
    user.roles.append(Role.query.filter_by(name="user").first())
    # datastore.add_role_to_user(user, Role.query.filter_by(name="user").first())
    db.session.commit()

    return user.name

@app.route("/create-admin/<string:name>")
def create_admin(name):
    user = app.security.datastore.create_user(name=name)
    user.roles.append(Role.query.filter_by(name="admin").first())
    # datastore.add_role_to_user(user, Role.query.filter_by(name="user").first())
    db.session.commit()
    return name

@app.route("/users")
def list_users():
    return [{
             "name": user.name,
             "roles": [role.name for role in user.roles ]
             } for user in User.query.all()]


@app.route("/login/<string:name>")
def login(name):
    user = User.query.filter_by(name=name).first()
    login_user(user)
    return current_user.get_auth_token()


@app.route("/token")
def get_token():
    return current_user.get_auth_token()


@app.route("/greet")
@auth_required("token")
def greet():
    return f"Hello, {current_user.name}"


@app.route("/admin")
@roles_required("admin")
def greet_admin():
    return f"Hello, admin: {current_user.name}"


@app.route("/add-reminder", methods=["POST"])
def add_reminder():
    reminder = request.json.get("reminder")
    db.session.add(Reminder(user_id=current_user.id,
                            content=reminder))
    db.session.commit()
    return "True"


@app.route("/reminders")
@auth_required("token")
def reminders():
    return [reminder.content 
            for reminder in Reminder.query.filter_by(user_id=current_user.id).all()]