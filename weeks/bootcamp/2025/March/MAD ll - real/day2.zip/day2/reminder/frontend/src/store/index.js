import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            reminders: [], 
            token: null
        }
    },
    mutations: {
        addReminder(state, value){
            state.reminders.push(value)
        },
        setReminder(state, value){
            state.reminders = value
        },
        setToken(state, value){
            state.token = value
        }
    },
    actions: {
        addReminder(context, value){
           fetch("http://localhost:5000/add-reminder", {
            method: "POST",
            headers: {
                "Content-type": "application/json", 
                "Authentication-Token": context.state.token
            },
            body: JSON.stringify({reminder: value})
           }).then(x =>{ context.dispatch("getReminders")})
        },
        signinUser(context, value){
            fetch("http://localhost:5000/login/"+value).then(x => {
                if (x.status == 200){
                    return x.text()
                }
                return null
            }).then(token => {
                context.commit("setToken", token); 
                context.dispatch("getReminders")
            })
        },
        getReminders(context){
            if (context.state.token == null)
                return

            fetch("http://localhost:5000/reminders", {
                headers: {
                    "Authentication-Token": context.state.token
                }
            }).then(x => {
                return x.json()
            }).then(reminders =>{

                context.commit("setReminder", reminders)
            })
        }
    }
})