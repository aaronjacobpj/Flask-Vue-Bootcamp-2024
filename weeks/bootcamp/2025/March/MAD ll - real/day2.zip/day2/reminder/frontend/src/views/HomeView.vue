<script setup>

</script>

<template>
  <main class="container-fluid p-5">
    <div class="row p-2">
      <div class="col">
        <input type="text" class="form-control" placeholder="Charlie" v-model="name">
      </div>
      <div class="col">
        <button @click="signin" class="btn btn-primary">Sign in</button>
      </div>
    </div>
    <div class="row p-2">
      <div class="col">
        <input type="email" class="form-control" placeholder="Add a new reminder..." v-model="reminder">
      </div>
      <div class="col">
        <button @click="add_reminder" class="btn btn-primary">Add</button>
      </div>
    </div>
  </main>
  <ol>
    <li v-for="item in $store.state.reminders">{{ item }}</li>
  </ol>
</template>
<script>
export default {
  data(){
    return {
      name: null,
      reminder: null
    }
  },
  methods:{
    add_reminder(){
      this.$store.dispatch("addReminder", this.reminder)
    },
    signin(){
      this.$store.dispatch("signinUser", this.name)
    }
  }
}
</script>
