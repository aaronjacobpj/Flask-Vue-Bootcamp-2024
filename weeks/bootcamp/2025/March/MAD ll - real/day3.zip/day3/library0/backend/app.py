from flask import Flask
from flask_security import SQLAlchemyUserDatastore, Security
from application.model import db, User, Role
from flask_cors import CORS
from werkzeug.security import generate_password_hash

from application.routes.authentication import api as authentication


def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = "sihagoaehwnogjnoajmno"
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///project.db'

    db.init_app(app)
    datastore = SQLAlchemyUserDatastore(db, User, Role)
    app.security = Security(app, datastore)

    CORS(app)

    with app.app_context():
        db.create_all()
        
        if not Role.query.filter_by(name="user").first():
            app.security.datastore.create_role(name="user")
            admin = app.security.datastore.create_role(name="admin")
            librarian = app.security.datastore.create_user(email="alice@gmail.com", 
                                                           password=generate_password_hash("alice"),
                                                           name="Alice")
            librarian.roles.append(admin)
            db.session.commit()

    app.register_blueprint(authentication)

    return app
    


app = create_app()





