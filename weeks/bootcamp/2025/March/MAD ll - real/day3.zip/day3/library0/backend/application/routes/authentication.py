from flask import Blueprint, request
from werkzeug.security import check_password_hash
from flask_security import login_user, current_user

from application.model import User


api = Blueprint("authentication", __name__)


@api.route("/signin", methods=["POST"])
def index():
    email = request.json.get("email", None)
    password = request.json.get("password", "")

    if not email:
        return {"message": "Invalid email or password."}, 404
    
    user = User.query.filter_by(email=email).first()
    if not user or not check_password_hash(user.password, password):
        return {"message": "Invalid email or password."}, 404
    
    login_user(user)
    return {"token": user.get_auth_token(), 
            "roles": user.get_roles()
            }
    
