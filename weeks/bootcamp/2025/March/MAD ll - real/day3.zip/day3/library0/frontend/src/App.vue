<script setup>
</script>

<template>
  <RouterView />
</template>
<script>
  export default {
    created(){
      let user = JSON.parse(localStorage.getItem("user") || '{"token":null,"roles":[]}')
      this.$store.commit("setUser", user)
    }
  }
</script>