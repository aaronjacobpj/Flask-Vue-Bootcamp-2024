import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            message: "Hello, World!",
            user: {
                token: null,
                roles: []
            }
        }
    },
    getters:{
        url(){
            return import.meta.env.VITE_BASEURL
        }
    },
    mutations: {
        setUser(state, value){
            state.user = value;
            localStorage.setItem("user", JSON.stringify(value));
        }
    }
})