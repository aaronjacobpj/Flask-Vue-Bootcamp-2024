from flask import Blueprint, request
from application.model import db, Section
from flask_security import current_user, roles_required

import datetime


api = Blueprint("section", __name__)

@api.route("/admin/section", methods=["POST"])
@roles_required("admin")
def create_section():
    name = request.json.get("name")
    description = request.json.get("description")

    if not name or Section.query.filter_by(name=name).first():
        return {"message": "Invalid name."}, 400
    
    section = Section(name=name,
                      description=description,
                      date=datetime.datetime.now(datetime.UTC).date())
    db.session.add(section)
    db.session.commit()

    return {"message": "Created section successfully"}, 201
