import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            alerts: [],
            user: {
                token: null,
                roles: [],
            }
        }
    },
    getters:{
        url(){
            return import.meta.env.VITE_BASEURL
        },
        getRoles(state){
            return state.user["roles"]
        },
        getToken(state){
            return state.user["token"]
        }
    },
    mutations: {
        setUser(state, value){
            state.user = value;
            localStorage.setItem("user", JSON.stringify(value));
        },
        removeAlert(state, index){
            state.alerts = state.alerts.filter((v, i) => i != index)
        },
        addAlert(state, value){
            state.alerts.push(value);
        }
    }
})