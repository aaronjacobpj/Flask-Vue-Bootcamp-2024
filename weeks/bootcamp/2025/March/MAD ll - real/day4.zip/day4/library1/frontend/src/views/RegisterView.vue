<script setup>
    import { RouterLink } from "vue-router"
</script>
<template>
    <main>
        <div class="container-fluid d-flex">
            <div class="card col-3" style="height: fit-content;">
                <div class="card-body">
                    <h3 class="card-title text-center">Sign Up</h3>
                    <div>
                        <form :action="$store.getters.url+'signin'" method="post" @submit.prevent="signup">
                            <div class="form-floating mb-3">
                                <input type="text" :class="{'form-control': true, 'is-invalid': error['email']}"
                                 id="name-input" v-model="name" placeholder="Charlie">
                                <label for="email-input">Full Name</label>
                                <div class="invalid-feedback" v-show="error['email']">
                                    {{error['email']}}
                                </div>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="email" :class="{'form-control': true, 'is-invalid': error['email']}"
                                 id="email-input" v-model="email"
                                placeholder="name@example.com">
                                <label for="email-input">Email address</label>
                                <div class="invalid-feedback" v-show="error['email']">
                                    {{error['email']}}
                                </div>
                            </div>
                            <div class="form-floating">
                                <input type="password" :class="{'form-control': true, 'is-invalid': error['password']}"
                                 id="input-password" v-model="password"
                                placeholder="Password">
                                <label for="input-password">Password</label>
                                <div class="invalid-feedback" v-show="error['password']">
                                    {{error['password']}}
                                </div>
                            </div>
                            <div class="row py-3">
                                <div class="col">
                                    <input type="submit" class="btn btn-primary" value="Sign Up"/>
                                </div>
                            </div>
                            <div class="row py-3 text-center">
                                <div class="col">
                                    <RouterLink to="/">Sign In</RouterLink>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>
</template>
<script>
    export default {
        data(){
            return {
                name: null,
                email: null,
                password: null,
                error: {
                    email: null,
                    password: null,
                    name: null,
                }
            }
        },
        methods:{
            validate(){
                this.error =  {
                    email: null,
                    password: null,
                    name: null,
                }
                let valid = true
                if(!this.email || !this.email.includes("@")){
                    valid = false
                    this.error["email"] = "Invalid Email."
                }

                if (!this.password || !this.password.length > 2){
                    valid = false
                    this.error["password"] = "Invalid Password."
                }
                if (!this.name || !this.name.length > 2){
                    valid = false
                    this.error["name"] = "Required field."
                }

                return valid
            },
            signup(){
                if(!this.validate())
                    return

                fetch(this.$store.getters.url+"signup", {
                    method: "post",
                    headers: {
                        "Content-type": "application/json"
                    },
                    body: JSON.stringify({name: this.name, 
                            email: this.email, 
                            password: this.password
                        })
                }).then(x => {
                    if (x.status == 201){
                        this.$store.commit("addAlert", "Created user successfully")
                        this.$router.push("/")
                        return {}
                    }
                    else if (x.status == 409){
                        this.error["email"] = "Email already taken."
                        return {}
                    }
                    else
                        return x.json()
                }).then(x =>{
                    if(x["message"] == "Invalid password."){
                        this.error["password"] = "Invalid password."
                    }
                    else if (x["message"] == "Full name required."){
                        this.error["name"] == "Full name required."
                    }
                    else if(x["message"] == "Invalid email."){
                        this.error["email"] = "Invalid email."
                    }
                })
            }
        }
        
    }
</script>
<style scoped>
    .container-fluid{
        height: 90vh;
        justify-content: center;
        align-items: center;
    }
    .btn{
        width: 100%;
    }
</style>