<script setup>
</script>
<template>
  <div class="container-fluid">
    <div class="row my-3">
        <div class="col">
            <button class="btn btn-primary" @click="sectionAddModel=true">
                Add Section
            </button>
        </div>
        <div class="modal" v-show="sectionAddModel" style="display: block;" tabindex="-1">
            <div class="modal-dialog">
                <form @submit.prevent="addSection">
                    <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Modal title</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" 
                          @click="sectionAddModel=false" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="formGroupExampleInput" class="form-label">Name</label>
                                <input type="text" class="form-control" id="formGroupExampleInput" 
                                v-model="name" placeholder="History">
                            </div>
                            <div class="mb-3">
                                <label for="exampleFormControlTextarea1" class="form-label">Description</label>
                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" v-model="description"></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <input type="submit" class="btn btn-primary" value="Add"/>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
  </div>
</template>
<script>
    export default{
        data(){
            return {
                sectionAddModel: false,
                name: null,
                description: null,
                error: {
                    name: null
                }
            }
        },
        methods:{
            validate(){
                this.error = {
                    name: null
                }
                if(!this.name){
                    this.error["name"] = "Invalid name."
                    return false
                }
                return true
            },
            addSection(){
                alert()
                if(!this.validate())
                    return

                fetch(this.$store.getters.url+"admin/section", {
                    method: "post",
                    headers: {
                        "Content-type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify({name: this.name, 
                            description:this.description
                        })
                }).then(x =>{
                    if(x.status == 201){
                        this.$store.commit("addAlert", "Created section successfully")
                    }
                    else if(x.status == 400){
                        this.error["name"] = "Invalid name."
                    }
                })
            }
        }
    }
</script>
