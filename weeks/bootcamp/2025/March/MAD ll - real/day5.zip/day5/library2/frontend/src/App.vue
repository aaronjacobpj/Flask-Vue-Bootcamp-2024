<script setup>
</script>

<template>
  <div class="alert alert-success alert-dismissible fade show m-1" role="alert" v-for="(alert, i) in $store.state.alerts">
    {{ alert }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close" 
    @click="$store.commit('removeAlert', i)">
    </button>
  </div>
  <RouterView />
</template>
<script>
  export default {
    created(){
      let user = JSON.parse(localStorage.getItem("user") || '{"token":null,"roles":[]}')
      this.$store.commit("setUser", user)
    }
  }
</script>