import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            alerts: [],
            user: {
                token: null,
                roles: [],
            },
            sections: []
        }
    },
    getters:{
        url(){
            return import.meta.env.VITE_BASEURL
        },
        getRoles(state){
            return state.user["roles"]
        },
        getToken(state){
            return state.user["token"]
        },
        getSections(state){
            return state.sections
        }
    },
    mutations: {
        setUser(state, value){
            state.user = value;
            localStorage.setItem("user", JSON.stringify(value));
        },
        removeAlert(state, index){
            state.alerts = state.alerts.filter((v, i) => i != index)
        },
        addAlert(state, value){
            state.alerts.push(value);
        },
        setSection(state, value){
            state.sections = value
        }
    },
    actions: {
        getSections(context){
            fetch(import.meta.env.VITE_BASEURL+"sections", {
                headers: {
                    "Authentication-Token": context.getters.getToken
                }
            }).then(x =>{
                if(x.status == 200)
                    return x.json()
                else
                    return []
            }).then(x =>{
                context.commit("setSection", x);
            })
        }
    }
})