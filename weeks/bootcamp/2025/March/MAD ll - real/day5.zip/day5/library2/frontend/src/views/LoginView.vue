<template>
    <main>
        <div class="container-fluid d-flex">
            <div class="card col-3" style="height: fit-content;">
                <div class="card-body">
                    <h3 class="card-title text-center">Login</h3>
                    <div>
                        <form :action="$store.getters.url+'signin'" method="post" @submit.prevent="signin">
                            <div class="form-floating mb-3">
                                <input type="email" :class="{'form-control': true, 'is-invalid': error['email']}"
                                 id="email-input" v-model="email"
                                placeholder="name@example.com">
                                <label for="email-input">Email address</label>
                                <div class="invalid-feedback" v-show="error['email']">
                                    {{error['email']}}
                                </div>
                            </div>
                            <div class="form-floating">
                                <input type="password" :class="{'form-control': true, 'is-invalid': error['password']}"
                                 id="input-password" v-model="password"
                                placeholder="Password">
                                <label for="input-password">Password</label>
                                <div class="invalid-feedback" v-show="error['password']">
                                    {{error['password']}}
                                </div>
                            </div>
                            <div class="row py-3">
                                <div class="col">
                                    <input type="submit" class="btn btn-primary" value="Sign in"/>
                                </div>
                            </div>
                            <div class="row py-3 text-center">
                                <div class="col">
                                    <RouterLink to="/signup">Sign Up</RouterLink>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>
</template>
<script>
    export default {
        data(){
            return {
                email: null,
                password: null,
                error: {
                    email: null,
                    password: null,
                }
            }
        },
        methods:{
            validate(){
                this.error =  {
                    email: null,
                    password: null,
                }
                let valid = true
                if(!this.email || !this.email.includes("@")){
                    valid = false
                    this.error["email"] = "Invalid Email."
                }

                if (!this.password || !this.password.length > 2){
                    valid = false
                    this.error["password"] = "Invalid Password."
                }

                return valid
            },
            signin(){
                if(!this.validate())
                    return

                fetch(this.$store.getters.url+"signin", {
                    method: "post",
                    headers: {
                        "Content-type": "application/json"
                    },
                    body: JSON.stringify({email: this.email, password: this.password})
                }).then(x => {
                    if (x.status == 200){
                        return x.json()
                    }
                    else{
                        this.error = {
                            email: "Invalid email or password.",
                            password: "Invalid email or password.",
                        }
                        return {token: null, roles: []}
                    }
                }).then(x =>{
                    this.$store.commit("setUser", x);
                    if (x["roles"].includes("admin")){
                        setTimeout(() =>{
                            this.$router.push("/admin")
                        }, 200)
                    }
                    else if (x["roles"].includes("user")){
                        setTimeout(() =>{
                            this.$router.push("/user")
                        }, 200)
                    }
                })
            }
        }
        
    }
</script>
<style scoped>
    .container-fluid{
        height: 90vh;
        justify-content: center;
        align-items: center;
    }
    .btn{
        width: 100%;
    }
</style>