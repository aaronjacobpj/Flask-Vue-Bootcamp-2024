<script setup>
    import { RouterLink } from "vue-router"
</script>
<template>
  <div class="container-fluid">
    <div class="row my-3">
        <div class="col">
            <button class="btn btn-primary" @click="sectionAddModel=true">
                Add Section
            </button>
        </div>
        <div class="modal" v-show="sectionAddModel" style="display: block;" tabindex="-1">
            <div class="modal-dialog">
                <form @submit.prevent="addSection">
                    <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Modal title</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" 
                          @click="sectionAddModel=false" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="formGroupExampleInput" class="form-label">Name</label>
                                <input type="text" class="form-control" id="formGroupExampleInput" 
                                v-model="name" placeholder="History">
                                <div class="invalid-feedback" v-show="error['name']" style="display: block;">
                                    {{error['name']}}
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="exampleFormControlTextarea1" class="form-label">Description</label>
                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" v-model="description"></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <input type="submit" class="btn btn-primary" value="Add"/>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="row d-flex flex-wrap">
        <div class="card col-3 m-1" v-for="section, index in $store.getters.getSections">
            <div class="card-body">
                <div class="row">
                    <h5 class="card-title">{{ section.name }}</h5>
                </div>
                <div class="row">
                    <p class="card-text">{{ section.description }}</p>
                </div>
                <div class="row">
                    <div class="col align-self-baseline">
                        <router-link class="btn btn-primary m-1" :to="{name: 'book-management', params: {id: section.id}}">
                            Add Books
                        </router-link>
                        <button class="btn btn-warning m-1" @click=update(index)>Update</button>
                        <button class="btn btn-danger m-1" @click="deleteSection(section['id'])">Delete</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal" v-show="updateSectionModel" style="display: block;" tabindex="-1">
            <div class="modal-dialog">
                <form @submit.prevent="updateSection">
                    <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Modal title</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" 
                          @click="updateSectionModel=false" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="formGroupExampleInput" class="form-label">Name</label>
                                <input type="text" class="form-control" id="formGroupExampleInput" 
                                v-model="section['name']" placeholder="History">
                                <div class="invalid-feedback" v-show="error['name']" style="display: block;">
                                    {{error['name']}}
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="exampleFormControlTextarea1" class="form-label">Description</label>
                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" 
                                v-model="section['description']"></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <input type="submit" class="btn btn-primary" value="Add"/>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
  </div>
</template>
<script>
    export default{
        data(){
            return {
                sectionAddModel: false,
                updateSectionModel: false,
                name: null,
                description: null,
                section: {
                    name: null,
                    description: null,
                },
                error: {
                    name: null
                }
            }
        },
        created(){
            this.$store.dispatch("getSections");
        },
        methods:{
            validate(){
                this.error = {
                    name: null
                }
                if(!this.name){
                    this.error["name"] = "Invalid name."
                    return false
                }
                return true
            },
            addSection(){
                if(!this.validate())
                    return

                fetch(this.$store.getters.url+"admin/section", {
                    method: "post",
                    headers: {
                        "Content-type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify({name: this.name, 
                            description:this.description
                        })
                }).then(x =>{
                    if(x.status == 201){
                        this.$store.dispatch("getSections");
                        this.$store.commit("addAlert", "Created section successfully")
                    }
                    else if(x.status == 400){
                        this.error["name"] = "Invalid name."
                    }
                    this.sectionAddModel = false
                })
            },
            update(id){
                this.updateSectionModel = true;
                this.section = Object.assign({}, this.$store.getters.getSections.filter((v, i) => i == id)[0])
            },
            updateSection(){
                fetch(this.$store.getters.url+"admin/section/"+this.section['id'], {
                    method: "post",
                    headers: {
                        "Content-type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify({name: this.section['name'], 
                            description:this.section['description']
                        })
                }).then(x =>{
                    if(x.status == 200)
                        this.$store.dispatch("getSections");
                })
                this.updateSectionModel = false;
            },
            deleteSection(id_){
                fetch(this.$store.getters.url+"admin/section/"+id_, {
                    method: "delete",
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(x =>{
                    if(x.status == 200)
                        this.$store.dispatch("getSections");
                })
            }
        }
    }
</script>
