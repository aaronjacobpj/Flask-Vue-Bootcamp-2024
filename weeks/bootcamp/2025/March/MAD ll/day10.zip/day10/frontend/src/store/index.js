import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            user: {
                token: "null",
                roles: []
            },
            genres: [],
            authors: [],
            books: [],
            bookRequests: []
        }
    },
    getters:{
        getRoles(state){
            return state.user["roles"];
        },
        getToken(state){
            return state.user["token"];
        },
        getGenres(state){
            return state.genres;
        },
        getAuthors(state){
            return state.authors;
        },
        getBooks(state){
            var books = state.books;
            
            return books.map(x =>{
                var authors = state.authors.filter(author => x["authors"].includes(author["id"]))
               return {
                    name: x["name"],
                    id: x["id"],
                    filename: x["filename"],
                    date: x["date"],
                    genre: state.genres.filter(genre => genre.id == x["genre"])[0],
                    authors:authors
                }
            });

        },
        getBookRequests(state){
            return state.bookRequests
        }
    },
    mutations: {
        setUser(state, value){
            state.user = value;
            localStorage.setItem("user", JSON.stringify(value));
        },
        setGenres(state, value){
            state.genres = value;
        },
        setAuthors(state, value){
            state.authors = value;
        },
        setBooks(state, value){
            state.books = value; 
        },
        setBookRequests(state, value){
            state.bookRequests=value;
        }
    },
    actions: {
        getGenres(context, value){
            fetch(import.meta.env.VITE_BASEURL+"/admin/genre?search="+value, {
                method: "GET",
                headers: {
                    "Authentication-Token": context.getters.getToken,
                    "Content-Type": "application/json"
                }
            }).then(x =>{
                return x.json();
            }).then(x => context.commit("setGenres", x))
        },
        getAuthors(context, value){
            fetch(import.meta.env.VITE_BASEURL+"/admin/authors?search="+value, {
                method: "GET",
                headers: {
                    "Authentication-Token": context.getters.getToken,
                    "Content-Type": "application/json"
                }
            }).then(x =>{
                return x.json();
            }).then(x => context.commit("setAuthors", x))
        },
        getBooks(context, value){
            fetch(import.meta.env.VITE_BASEURL+"/admin/book?search="+value, {
                method: "GET",
                headers: {
                    "Authentication-Token": context.getters.getToken,
                }
            }).then(x =>{
                return x.json();
            }).then(x => context.commit("setBooks", x))
        },
        getBookRequests(context){
            fetch(import.meta.env.VITE_BASEURL+"/user/book", {
                method: "GET",
                headers: {
                    "Authentication-Token": context.getters.getToken,
                }
            }).then(x =>{
                return x.json();
            }).then(x => context.commit("setBookRequests", x))
        }
    }
})