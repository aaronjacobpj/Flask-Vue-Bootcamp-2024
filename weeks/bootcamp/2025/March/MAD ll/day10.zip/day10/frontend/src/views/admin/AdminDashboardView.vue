<script setup>
    import store from "@/store"
</script>
<template>
  <div>
    <apexchart
      width="500"
      type="bar"
      :options="chartOptions"
      :series="series"
    ></apexchart>
  </div>
</template>
<script>
export default {
    created(){
        fetch(import.meta.env.VITE_BASEURL+"/admin/book/requests",
                    {
                        method: "GET",
                        headers: {
                            "Authentication-Token": store.getters.getToken
                        },
                    }
                ).then(x => {
                    if(x.status == 200)
                        return x.json();
                    return []
                }).then(x => this.requests = x)
    },
    data: function () {
        return {
            requests: []
        }
    },
    computed:{
        chartOptions(){
            var freq = {}
            for (let each of this.requests){
                if(freq[each['book']])
                    freq[each["book"]]++;
                else
                    freq[each["book"]] = 1;
            }
            return  {
                chart: {
                    id: "vuechart-example",
                    },
                    xaxis: {
                    categories: Object.keys(freq),
                }
            }
        },
        series(){
            var freq = {}
            for (let each of this.requests){
                if(freq[each['book']])
                    freq[each["book"]]++;
                else
                    freq[each["book"]] = 1;
            }
            return [
                {
                    name: "Book requests",
                    data: Object.values(freq),
                }
            ]
        }
    }
};
</script>