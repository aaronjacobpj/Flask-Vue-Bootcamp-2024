from celery import shared_task
from models import db, BookRequest, Book
import datetime
from smtplib import SMTP
import os
from jinja2 import Template
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from io import StringIO
import csv


@shared_task
def daily_reminder():
    today = datetime.datetime.now(datetime.timezone.utc).date()
    server = SMTP(host="localhost", port=os.environ.get("SMTP", 1025))

    for request in db.session.query(BookRequest).filter(BookRequest.date >= (today - datetime.timedelta(days=2))).all():
        server.sendmail("admin@example.com", request.user.username, f"Return date of {request.book.name} is comming up!")
        


@shared_task
def monthly_report():
    today = datetime.datetime.now(datetime.timezone.utc).date()
    day = datetime.date(year=today.year, month=today.month, day=1)
    requests = db.session.query(BookRequest).filter(BookRequest.date > day).all()
    with open("templates/monthly-report.html") as file:
        template = Template(file.read())

    server = SMTP(host="localhost", port=os.environ.get("SMTP", 1025))
    mail = MIMEMultipart()
    mail["FROM"]="admin@example.com"
    mail["To"] = "admin@example.com"
    mail["SUBJECT"] = "Monthly Report"
    # with open("static/4.pdf", "rb") as file:
    #     pdf = MIMEApplication(file.read(), subtype="pdf")

    # pdf.add_header('Content-Disposition','attachment',filename="wireframe.pdf")
    # mail.attach(pdf)
    html = MIMEText(template.render(requests=requests), "html")
    mail.attach(html)
    server.sendmail("admin@example.com", "admin@example.com", mail.as_string())

    

@shared_task
def export_csv():
    books = Book.query.all()

    buffer = StringIO()
    writer = csv.DictWriter(buffer, fieldnames=["Id", "Title", "Genre", "Authors", "No.Requests"])
    writer.writeheader()

    for book in books:
        writer.writerow({"Id": book.id, 
                         "Title": book.name,
                         "Genre": book.genre.name,
                         "Authors": ",".join([author.name for author in book.authors]),
                         "No.Requests": len(book.requests)})
        
    buffer.seek(0)
    return buffer.read()

        