<script setup>
  import router from "@/router"
  import store from "@/store";
  import { RouterLink } from "vue-router";
</script>
<template>
  <div class="container-fluid">
      <div class="card">
          <div class="card-body">
              <h4 class="card-title" align="center">Sign In</h4>
              <form @submit.prevent="signin">
                  <div class="mb-3">
                      <label for="formGroupExampleInput2" class="form-label">Email</label>
                      <input type="text" class="form-control" id="formGroupExampleInput2" 
                      v-model="username" placeholder="abcd@example.com">
                      <div class="invalid-feedback" v-show="error['username']" style="display: block;">
                          Required Field
                      </div>                        
                      <div class="invalid-feedback" v-show="error['valid']" style="display: block;">
                         Invalid username or password.
                      </div>
                  </div>
                  <div class="mb-3">
                      <label for="formGroupExampleInput" class="form-label">Password</label>
                      <input type="text" class="form-control" id="formGroupExampleInput" 
                      v-model="password" placeholder="password">
                      <div class="invalid-feedback" v-show="error['password']" style="display: block;">
                          Required Field
                      </div>
                      <div class="invalid-feedback" v-show="error['valid']" style="display: block;">
                        Invalid username or password.
                     </div>
                  </div>
                  <div class="mb-3">
                      <input type="submit" class="btn btn-primary" value="Sign In" style="width: 100%;">
                  </div>
                  <div class="mb-3" style="display:flex; justify-content:center">
                    <RouterLink to="/signup" style="text-decoration: none;">Sign up</RouterLink>
                </div>
              </form>
          </div>
      </div> 
  </div>
</template>
<script>
  export default {
      data(){
          return {
              username: null,
              password: null,
              error:{
                  username: null,
                  password: null,
                  valid: null
              }
          }
      },
      methods: {
          signin(){
              if(!this.validate())
                  return false;
              fetch(import.meta.env.VITE_BASEURL+"/signin", {
                  method: "POST",
                  headers: {
                      "Content-Type": "application/json"
                  },
                  body: JSON.stringify({
                      password: this.password,
                      username: this.username
                  })
              }).then(x =>{
                  if(x.status == 200){
                      return x.json()
                  }
                  else if(x.status == 404){
                      this.error["valid"] = true;
                  }
                  return {
                      token: null,
                      roles: []
                    }
              }).then(x =>{
                store.commit("setUser", x);
                if (x['roles'].includes('admin'))
                  router.push({name: "admin"})
                else if (x["roles"].includes("user"))
                  router.push({name: "user"})
              })
          },
          validate(){
              this.error = {
                  username: null,
                  password: null,
                  valid: null
              }

              if(!this.username){
                  this.error['username'] = true;
                  return false
              }
              if(!this.password){
                  this.error['password'] = true;
                  return false
              }
              else
                  return true
          }
      }
  }
</script>
<style scoped>
  .container-fluid{
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
  }
</style>