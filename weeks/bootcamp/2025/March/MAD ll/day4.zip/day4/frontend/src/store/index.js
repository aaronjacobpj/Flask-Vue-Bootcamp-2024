import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            user: {
                token: "null",
                roles: []
            }
        }
    },
    getters:{
        getRoles(state){
            return state.user["roles"];
        },
        getToken(state){
            return state.user["token"];
        }
    },
    mutations: {
        setUser(state, value){
            state.user = value;
            localStorage.setItem("user", JSON.stringify(value));
        }
    }
})