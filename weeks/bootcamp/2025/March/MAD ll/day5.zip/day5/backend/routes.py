from flask import Blueprint, current_app as app, request
from flask_security import roles_required, auth_required, current_user, login_user
from models import db, User, Genre, Author

import datetime

from werkzeug.security import generate_password_hash, check_password_hash



api = Blueprint("api", __name__)



@api.route("/signup", methods=["POST"])
def signup():
    username = request.json.get("username")
    name = request.json.get("name")
    password = request.json.get("password")

    if app.security.datastore.find_user(username=username):
        return {"message": "username already exist"}, 409
    
    if not username or not name or not password:
        return {"message": "Invalid request"}, 400
    
    user = app.security.datastore.create_user(username=username, 
                                            name=name,
                                            password=generate_password_hash(password))
    app.security.datastore.add_role_to_user(user, 
                                            app.security.datastore.find_role("user"))
    db.session.commit()

    return {"message": "Created user successfuly"}, 201


@api.route("/signin", methods=["POST"])
def signin():

    username = request.json.get("username")
    password = request.json.get("password")

    user = app.security.datastore.find_user(username=username)

    if not user or not check_password_hash(user.password, password):
        return {"message": "Invalid username or password"}, 404
    
    login_user(user)
    return {
        "token": user.get_auth_token(),
        "roles": user.get_roles()
    }


@api.route("/admin/genre", methods=["POST"])
@roles_required("admin")
def create_genre():


    name = request.json.get("name")
    description = request.json.get("description")

    if not name:
        return {"message": "Invalid request"}, 400
    

    db.session.add(Genre(name=name,
                         description=description,
                         date=datetime.datetime.now(datetime.timezone.utc).date()))
    db.session.commit()
    return {"message": "Created genre successfuly"}, 201    


@api.route("/admin/genre")
def search_genre():
    name = request.args.get("search")
    return [{"id": genre.id, 
             "name": genre.name, 
             "description": genre.description}
            for genre in Genre.query.filter(Genre.name.like(f"%{name}%")).all()]


@api.route("/admin/genre/<int:genre_id>", methods=["PUT"])
def modify_genre(genre_id):
    genre = db.session.query(Genre).get(genre_id)


    if not genre:
        return {"message": "Genre not found."}, 404
    
    name = request.json.get("name")
    description = request.json.get("description")

    if not name:
        return {"message": "Invalid request"}, 400
    
    genre.name = name
    genre.description = description
    db.session.commit()

    return {"message": "Request succesfull"}, 200


@api.route("/admin/genre/<int:genre_id>", methods=["DELETE"])
def delete_genre(genre_id):
    genre = db.session.query(Genre).get(genre_id)


    if not genre:
        return {"message": "Genre not found."}, 404
    
    db.session.delete(genre)
    db.session.commit()

    return {"message": "Request succesfull"}, 200


@api.route("/admin/author", methods=["POST"])
def add_author():
    name = request.json.get("name")

    if not name:
        return {"message": "Invalid request"}, 400
    
    db.session.add(Author(name=name))
    db.session.commit()

    return {"message": "Request succesfull"}, 201


@api.route("/admin/authors")
def get_authors():
    name = request.args.get("search")
    return [{"id": author.id, 
            "name": author.name
            }
        for author in Author.query.filter(Author.name.like(f"%{name}%")).all()]


@api.route("/admin/author/<int:author_id>", methods=["PUT"])
def update_author(author_id):

    author = db.session.query(Author).get(author_id)

    if not author:
        return {"message": "Author not found."}, 404
    
    name = request.json.get("name")

    if not name:
        return {"message": "Invalid request"}, 400
    
    author.name = name
    db.session.commit()

    return {"message": "Request succesfull"}, 200


@api.route("/admin/author/<int:author_id>", methods=["DELETE"])
def delete_author(author_id):

    author = db.session.query(Author).get(author_id)

    if not author:
        return {"message": "Author not found."}, 404
    
    db.session.delete(author)
    db.session.commit()

    return {"message": "Request succesfull"}, 200