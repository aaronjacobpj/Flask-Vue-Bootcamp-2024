<script setup>
    import store from "@/store"
</script>
<template>
    <div class="alert alert-success" v-show="message">
        {{ message }}
    </div>
    <div class="container-fluid">
        <div class="card">
            <div class="card-body">
                <h2>Add New Book</h2>
                <form @submit.prevent="createGenre">
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Genre</label>
                        <input type="text" class="form-control" id="formGroupExampleInput" v-model="name" placeholder="Genre">
                        <p class="invalid-feedback" style="display: block;" v-show="error['name']">Required Field</p>
                    </div>
                    <div class="mb-3">
                        <label for="formGroupExampleInput2" class="form-label">Description</label>
                        <input type="text" class="form-control" id="formGroupExampleInput2" v-model="description" placeholder="Description">
                    </div>
                    <div class="mb-3">
                        <input type="submit" class="btn btn-primary" id="formGroupExampleInput2" placeholder="Description">
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                name: null,
                description: null,
                message: null,
                error:{
                    name: null,
                }
            }
        },
        methods:{
            createGenre(){
                if(!this.validate())
                    return false
                fetch(import.meta.env.VITE_BASEURL+"/admin/genre", {
                    method: "POST",
                    headers: {
                        "Authentication-Token": store.getters.getToken,
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({name: this.name, description: this.description})
                }).then(x =>{
                    if (x.status == 400){
                        this.validate()
                    }
                    else if(x.status == 201){
                        this.message = "Created Genre Successfully."
                    }
                })
            },
            validate(){
                this.error = {
                    name: null, 
                }

                if(!this.name)
                {
                    this.error["name"]= true;
                    return false
                }
                return true
            }
        }
    }
</script>
<style scoped>
    .container-fluid{
        justify-content: center; 
        display: flex; 
        align-items: center;
        height: 90vh;
    }
    .mb-3{
        margin-top: 10px;
    }
    .btn-primary{
        width: 100%;
    }
</style>