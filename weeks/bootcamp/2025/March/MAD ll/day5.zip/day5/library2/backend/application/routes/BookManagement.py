from flask import Blueprint, request
from application.model import db, Book
from flask_security import current_user, roles_required

import datetime
import os


api = Blueprint("book", __name__)

@api.route("/admin/book", methods=["POST"])
@roles_required("admin")
def add_book():
    title = request.form.get("name")
    author = request.form.get("author")
    content = request.files.get("file")

    if not title or not author or not content:
        return {"message": "Inavlid form."}, 400
    
    book = Book(name=title,
                author=author,
                date=datetime.datetime.now(datetime.UTC).date(),
                content="")
    db.session.add(book)
    db.session.flush()
    content.save(os.path.join("static", str(book.id)+content.filename))
    book.content = str(book.id)+content.filename
    db.session.commit()

    return {"message": "Added book successfully"}, 201

