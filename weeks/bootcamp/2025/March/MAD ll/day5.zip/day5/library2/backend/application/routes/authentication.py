from flask import Blueprint, request
from werkzeug.security import check_password_hash, generate_password_hash
from flask_security import login_user, current_user
from flask import current_app as app

from application.model import Role, User, db


api = Blueprint("authentication", __name__)


@api.route("/signin", methods=["POST"])
def signin():
    email = request.json.get("email", None)
    password = request.json.get("password", "")

    if not email:
        return {"message": "Invalid email or password."}, 404
    
    user = User.query.filter_by(email=email).first()
    if not user or not check_password_hash(user.password, password):
        return {"message": "Invalid email or password."}, 404
    
    login_user(user)
    return {"token": user.get_auth_token(), 
            "roles": user.get_roles()
            }
    

@api.route("/signup", methods=["POST"])
def signup():
    name = request.json.get("name")
    email = request.json.get("email", None)
    password = request.json.get("password", "")

    if not email:
        return {"message": "Invalid email."}, 400
    
    user = User.query.filter_by(email=email).first()
    if user:
        return {"message": "Email already taken."}, 409
    
    if not password:
        return {"message": "Invalid password."}, 400
    
    if not name:
        return {"message": "Full name required."}, 400
    
    user = app.security.datastore.create_user(name=name, 
                                              email=email, 
                                              password=generate_password_hash(password))
    user.roles.append(Role.query.filter_by(name="user").first())
    db.session.commit()

    return {"message": "Created user successfully"}, 201