from flask import Blueprint, request
from application.model import db, Section
from flask_security import current_user, roles_required

import datetime


api = Blueprint("section", __name__)

@api.route("/admin/section", methods=["POST"])
@roles_required("admin")
def create_section():
    name = request.json.get("name")
    description = request.json.get("description")

    if not name or Section.query.filter_by(name=name).first():
        return {"message": "Invalid name."}, 400
    
    section = Section(name=name,
                      description=description,
                      date=datetime.datetime.now(datetime.UTC).date())
    db.session.add(section)
    db.session.commit()

    return {"message": "Created section successfully"}, 201


@api.route("/sections")
def get_sections():
    return [{"id": section.id,
             "name": section.name,
             "description": section.description} for section in Section.query.all()]



@api.route("/admin/section/<int:id_>", methods=["POST"])
@roles_required("admin")
def update_section(id_):
    name = request.json.get("name")
    description = request.json.get("description")

    if not name:
        return {"message": "Invalid name."}, 400
    
    section = db.session.query(Section).get(id_)

    if not section:
        return {"message": "Section not found"}, 404
    
    section.name = name
    section.description = description
    db.session.commit()

    return {"message": "Updated section successfully"}, 200


@api.route("/admin/section/<int:id_>", methods=["DELETE"])
@roles_required("admin")
def delete_section(id_):
    section = db.session.query(Section).get(id_)

    if not section:
        return {"message": "Section not found"}, 404
    
    db.session.delete(section)
    db.session.commit()
    
    return {"message": "Deleted section successfully"}, 200