from flask import Blueprint, request
from application.model import db, Book, Section
from flask_security import current_user, roles_required, auth_required

import datetime
import os


api = Blueprint("book", __name__)

@api.route("/admin/book", methods=["POST"])
@roles_required("admin")
def add_book():
    title = request.form.get("name")
    author = request.form.get("author")
    content = request.files.get("file")
    section_id = request.form.get("section", -1)

    section = db.session.query(Section).get(section_id)

    if not title or not author or not content or not section:
        return {"message": "Inavlid form."}, 400
    
    book = Book(name=title,
                author=author,
                date=datetime.datetime.now(datetime.UTC).date(),
                content="",
                section_id=section_id)
    db.session.add(book)
    db.session.flush()
    content.save(os.path.join("static", str(book.id)+content.filename))
    book.content = str(book.id)+content.filename
    db.session.commit()

    return {"message": "Added book successfully"}, 201


@api.route("/section/<int:id_>/books")
@auth_required("token")
def section_books(id_):
    books = Book.query.filter_by(section_id=id_).all()
    return [{"id": book.id,
             "author": book.author,
             "name": book.name} for book in books]


@api.route("/admin/book/<int:id_>", methods=["POST"])
def update_book(id_):
    book = db.session.query(Book).get(id_)
    
    if not book:
        return {"message": "Book not found."}, 404
    
    title = request.form.get("name")
    author = request.form.get("author")
    content = request.files.get("file")

    if not title or not author:
        return {"message": "Inavlid form."}, 400
    
    book.name = title
    book.author = author

    if content:
        content.save(os.path.join("static", book.content))
    
    db.session.commit()

    return {"message": "Updated book successfully."}


@api.route("/admin/book/<int:id_>", methods=["DELETE"])
def delete_book(id_):
    book = db.session.query(Book).get(id_)
    
    if not book:
        return {"message": "Book not found."}, 404
    
    db.session.delete(book)
    db.session.commit()

    return {"message": "Deleted book successfully."}