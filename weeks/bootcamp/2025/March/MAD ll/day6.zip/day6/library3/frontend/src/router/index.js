import { createRouter, createWebHistory } from 'vue-router'
import store from '@/store'

import HomeView from '../views/HomeView.vue'
import LoginView from "@/views/LoginView.vue"
import RegisterView from "@/views/RegisterView.vue"
import AdminLayoutView from "@/views/admin/AdminLayoutView.vue"
import SectionManagementView from "@/views/admin/SectionManagementView.vue"
import BookManagementView from "@/views/admin/BookManagementView.vue";


const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'login',
      component: LoginView,
    },
    {
      path: '/signup',
      name: 'signup',
      component: RegisterView,
    },
    {
      path: "/admin",
      name: "admin-home",
      component: AdminLayoutView,
      children: [
        {
          path: "",
          name: "section-management",
          component: SectionManagementView
        },
        {
          path: "section/:id",
          name: "book-management",
          component: BookManagementView,
          props: true
        }
      ],
      beforeEnter(to, from, next){
        if (store.getters.getRoles.includes("admin")){
         next()
        }
        else if(store.getters.getRoles.includes("user")){
          next({path: "/user"})
        }
        else {
          next({path: "/"})
        }
      }
    }
  ],
})

export default router
