<script setup>
</script>
<template>
  <div class="container-fluid">
    <div class="row my-3">
        <div class="col">
            <button class="btn btn-primary" @click="bookAddModel=true">
                Add Book
            </button>
        </div>
        <div class="modal" v-show="bookAddModel" style="display: block;" tabindex="-1">
            <div class="modal-dialog">
                <form @submit.prevent="addBook">
                    <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Add Book</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" 
                          @click="bookAddModel=false" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="formGroupExampleInput" class="form-label">Title</label>
                                <input type="text" class="form-control" id="formGroupExampleInput" 
                                v-model="name" placeholder="History">
                                <div class="invalid-feedback" v-show="error['name']" style="display: block;">
                                    {{error['name']}}
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="formGroupExampleInput1" class="form-label">Author</label>
                                <input type="text" class="form-control" id="formGroupExampleInput1" 
                                v-model="author" placeholder="Author name">
                                <div class="invalid-feedback" v-show="error['author']" style="display: block;">
                                    {{error['author']}}
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="inputGroupFile01" class="form-label">File</label>
                                <input type="file" class="form-control" @change="addFile"
                                id="inputGroupFile01">
                                <div class="invalid-feedback" v-show="error['file']" style="display: block;">
                                    {{error['file']}}
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <input type="submit" class="btn btn-primary" value="Add"/>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="row d-flex flex-wrap">
        <div class="card col-3 m-1" v-for="book, index in books">
            <div class="card-body">
                <div class="row">
                    <h5 class="card-title">{{ book.name }}</h5>
                </div>
                <div class="row">
                    <p class="card-text">{{ book.author }}</p>
                </div>
                <div class="row">
                    <div class="col align-self-baseline">
                        <button class="btn btn-warning m-1" @click=update(index)>Update</button>
                        <button class="btn btn-danger m-1" @click="deleteBook(book['id'])">Delete</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal" v-show="updateBookModel" style="display: block;" tabindex="-1">
            <div class="modal-dialog">
                <form @submit.prevent="updateBook">
                    <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Modify Book</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" 
                          @click="updateBookModel=false" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="formGroupExampleInput" class="form-label">Title</label>
                                <input type="text" class="form-control" id="formGroupExampleInput" 
                                v-model="editbook['name']" placeholder="History">
                                <div class="invalid-feedback" v-show="editbookerror['name']" style="display: block;">
                                    {{editbookerror['name']}}
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="formGroupExampleInput1" class="form-label">Author</label>
                                <input type="text" class="form-control" id="formGroupExampleInput1" 
                                v-model="editbook['author']" placeholder="Author name">
                                <div class="invalid-feedback" v-show="editbookerror['author']" style="display: block;">
                                    {{editbookerror['author']}}
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="inputGroupFile01" class="form-label">File</label>
                                <input type="file" class="form-control" @change="updateFile"
                                id="inputGroupFile01">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <input type="submit" class="btn btn-primary" value="Update"/>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
  </div>
</template>
<script>
    export default{
        props: ["id"],
        data(){
            return {
                bookAddModel: false,
                updateBookModel: false,
                name: null,
                author: null,
                file: null,
                editbook: {
                    name: null,
                    author:null,
                    file:null
                },
                editbookerror: {
                    name: null,
                    author: null,
                },
                error: {
                    name: null,
                    author: null,
                    file: null
                },
                books: []
            }
        },
        created(){
            this.getBooks()
        },
        methods: {
            addBook(){
                console.log(this.name, this.author, this.file)
            },
            addFile(event){
                this.file = event.target.files[0]
            },
            validate(){
                let valid = true
                this.error = {
                    name: null,
                    author: null,
                    file: null
                }

                if(!this.name){
                    this.error["name"] = "Field required."
                    valid = false
                }
                if(!this.author){
                    this.error["author"] = "Field required."
                    valid = false
                }
                if(!this.file){
                    this.error["file"] = "Field required."
                    valid = false
                }
                return valid

            },
            addBook(){
                if(!this.validate())
                    return 

                let form = new FormData()
                form.append("name", this.name)
                form.append("author", this.author)
                form.append("file", this.file)
                form.append("section", this.id)

                fetch(import.meta.env.VITE_BASEURL+"admin/book", {
                    method: "POST",
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: form
                }).then(x =>{
                    if (x.status == 201){
                        this.$store.commit("addAlert", "Added book successfully")
                        this.bookAddModel = false
                    }
                    else
                        this.validate()
                })

            },
            getBooks(){
                fetch(import.meta.env.VITE_BASEURL+`section/${this.id}/books`, {
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(x =>{
                    if(x.status == 200)
                        return x.json()
                    else
                        return []
                }).then(x =>{
                   this.books = x;
                })
            },
            update(index){
                this.updateBookModel = true
                this.editbook = Object.assign({}, this.books.filter((v, i) => i == index)[0])
            },
            updateFile(event){
                this.editbook["file"] = event.target.files[0]
            },
            validateUpdateBookForm(){
                let valid = true
                this.editbookerror = {
                    name: null,
                    author: null,
                }  
                if(!this.editbook["name"]){
                    valid = false
                    this.editbookerror["name"] = "Required Field."
                }
                if(!this.editbook["author"]){
                    valid = false
                    this.editbookerror["author"] = "Required Field."
                }
                return valid
            },
            updateBook(){
                if (!this.validateUpdateBookForm())
                    return false

                let form = new FormData()
                form.append("name", this.editbook["name"])
                form.append("author", this.editbook["author"])
                form.append("file", this.editbook["file"])

                fetch(import.meta.env.VITE_BASEURL+"admin/book/"+this.editbook["id"], {
                    method: "POST",
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: form
                }).then(x =>{
                    if (x.status == 200){
                        this.$store.commit("addAlert", "Updated book successfully")
                        this.updateBookModel = false
                        this.getBooks()
                    }
                    else
                        this.validate()
                })
            },
            deleteBook(id){
                fetch(this.$store.getters.url+"admin/book/"+id, {
                    method: "delete",
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(x =>{
                    if(x.status == 200)
                        this.getBooks()
                })
            }
        },
        
        
    }
</script>
