from flask import Blueprint, current_app as app, request, send_file
from flask_security import roles_required, auth_required, current_user, login_user
from models import db, User, Genre, Author, Book, BookAuthor, BookRequest

import datetime
import os
import base64

from werkzeug.security import generate_password_hash, check_password_hash



api = Blueprint("api", __name__)



@api.route("/signup", methods=["POST"])
def signup():
    username = request.json.get("username")
    name = request.json.get("name")
    password = request.json.get("password")

    if app.security.datastore.find_user(username=username):
        return {"message": "username already exist"}, 409
    
    if not username or not name or not password:
        return {"message": "Invalid request"}, 400
    
    user = app.security.datastore.create_user(username=username, 
                                            name=name,
                                            password=generate_password_hash(password))
    app.security.datastore.add_role_to_user(user, 
                                            app.security.datastore.find_role("user"))
    db.session.commit()

    return {"message": "Created user successfuly"}, 201


@api.route("/signin", methods=["POST"])
def signin():

    username = request.json.get("username")
    password = request.json.get("password")

    user = app.security.datastore.find_user(username=username)

    if not user or not check_password_hash(user.password, password):
        return {"message": "Invalid username or password"}, 404
    
    login_user(user)
    return {
        "token": user.get_auth_token(),
        "roles": user.get_roles()
    }


@api.route("/admin/genre", methods=["POST"])
@roles_required("admin")
def create_genre():


    name = request.json.get("name")
    description = request.json.get("description")

    if not name:
        return {"message": "Invalid request"}, 400
    

    db.session.add(Genre(name=name,
                         description=description,
                         date=datetime.datetime.now(datetime.timezone.utc).date()))
    db.session.commit()
    return {"message": "Created genre successfuly"}, 201    


@api.route("/admin/genre")
def search_genre():
    name = request.args.get("search")
    return [{"id": genre.id, 
             "name": genre.name, 
             "description": genre.description}
            for genre in Genre.query.filter(Genre.name.like(f"%{name}%")).all()]


@api.route("/admin/genre/<int:genre_id>", methods=["PUT"])
@roles_required("admin")
def modify_genre(genre_id):
    genre = db.session.query(Genre).get(genre_id)


    if not genre:
        return {"message": "Genre not found."}, 404
    
    name = request.json.get("name")
    description = request.json.get("description")

    if not name:
        return {"message": "Invalid request"}, 400
    
    genre.name = name
    genre.description = description
    db.session.commit()

    return {"message": "Request succesfull"}, 200


@api.route("/admin/genre/<int:genre_id>", methods=["DELETE"])
@roles_required("admin")
def delete_genre(genre_id):
    genre = db.session.query(Genre).get(genre_id)


    if not genre:
        return {"message": "Genre not found."}, 404
    
    db.session.delete(genre)
    db.session.commit()

    return {"message": "Request succesfull"}, 200


@api.route("/admin/author", methods=["POST"])
@roles_required("admin")
def add_author():
    name = request.json.get("name")

    if not name:
        return {"message": "Invalid request"}, 400
    
    db.session.add(Author(name=name))
    db.session.commit()

    return {"message": "Request succesfull"}, 201


@api.route("/admin/authors")
def get_authors():
    name = request.args.get("search")
    return [{"id": author.id, 
            "name": author.name
            }
        for author in Author.query.filter(Author.name.like(f"%{name}%")).all()]


@api.route("/admin/author/<int:author_id>", methods=["PUT"])
@roles_required("admin")
def update_author(author_id):

    author = db.session.query(Author).get(author_id)

    if not author:
        return {"message": "Author not found."}, 404
    
    name = request.json.get("name")

    if not name:
        return {"message": "Invalid request"}, 400
    
    author.name = name
    db.session.commit()

    return {"message": "Request succesfull"}, 200


@api.route("/admin/author/<int:author_id>", methods=["DELETE"])
@roles_required("admin")
def delete_author(author_id):

    author = db.session.query(Author).get(author_id)

    if not author:
        return {"message": "Author not found."}, 404
    
    db.session.delete(author)
    db.session.commit()

    return {"message": "Request succesfull"}, 200


@api.route("/admin/book", methods=["POST"])
@roles_required("admin")
def create_book():
    name = request.form.get("name")
    date = request.form.get("date")
    genre_id = request.form.get("genre", type=int)
    author_ids = request.form.getlist("authors", type=int)
    file = request.files.get("book")
    
    count = db.session.query(Author).filter(Author.id.in_(author_ids)).count()
    genre = db.session.query(Genre).get(genre_id)

    if not name or not date or not file and len(author_ids) != count or not genre:
        return {"message": "Invalid request"}, 400
    
    book = Book(name=name, 
                date_issued=datetime.datetime.strptime(date, "%Y-%M-%d").date(),
                genre_id=genre_id)
    db.session.add(book)
    db.session.flush()

    book.filename = str(book.id) + os.path.splitext(file.filename)[1]
    file.save(os.path.join("static", book.filename))

    for author in author_ids:
        db.session.add(BookAuthor(book_id=book.id,
                                  author_id=author))
        
    db.session.commit()

    return {"message": "Request succesfull"}, 201


@api.route("/admin/book")
def get_books():
    name = request.args.get("search", "")

    books = Book.query.filter(Book.name.like(f"%{name}%")).all()
    return [{"id": book.id,
             "name": book.name,
             "filename": book.filename,
             "genre": book.genre.id,
             "authors": book.get_author_ids(),
             "date": datetime.datetime.strftime(book.date_issued, "%Y-%M-%d"),
             } for book in books]


@api.route("/admin/book/<int:book_id>", methods=["PUT"])
@roles_required("admin")
def update_book(book_id):
    book = db.session.query(Book).get(book_id)
    
    name = request.form.get("name")
    date = request.form.get("date")
    genre_id = request.form.get("genre", type=int)
    author_ids = request.form.getlist("authors", type=int)
    file = request.files.get("book")

    if not book or not name or not date or not genre_id or not author_ids:
        return {"message": "Invalid request"}, 400
    
    book.name = name
    book.date_issued=datetime.datetime.strptime(date, "%Y-%M-%d").date()
    book.genre_id = genre_id

    check = set()
    for author in BookAuthor.query.filter(BookAuthor.book_id==book_id).all():
        if author.id not in author_ids:
            db.session.delete(author)

    for author in author_ids:
        if author not in check:
            db.session.add(BookAuthor(book_id=book_id,
                                      author_id=author))
            
    if file:
        file.save(os.path.join("static", book.filename))
            
    db.session.commit()
    return {"message": "Request succesfull"}, 200


@api.route("/admin/book/<int:book_id>", methods=["DELETE"])
@roles_required("admin")
def delete_book(book_id):
    book = db.session.query(Book).get(book_id)

    if not book:
        return {"message": "Book not found"}, 404
    
    db.session.delete(book)
    db.session.commit()

    return {"message": "Request succesfull"}, 200



@api.route("/user/book/<int:book_id>",)
@auth_required("token")
def request_book(book_id):

    book = db.session.query(Book).get(book_id)

    if not book:
        return {"message": "Book not found"}, 404
    
    db.session.add(BookRequest(book_id=book_id,
                               user_id=current_user.id))
    db.session.commit()
    return {"message": "Request succesfull"}, 200


@api.route("/user/book",)
@auth_required("token")
def user_books():
    return [{"status": request.access,
             "id": request.id,
             "book-id": request.book.id,
             "date":  datetime.datetime.strftime(request.date if request.date else datetime.date.today(), "%Y-%M-%d") 
            } for request in BookRequest.query.filter_by(user_id=current_user.id).all()]



@api.route("/admin/book/requests",)
@roles_required("admin")
def requested_books():
    return [{"status": request.access,
             "id": request.id,
             "username": request.user.username,
             "book": request.book.name,
             "date": request.date
            } for request in BookRequest.query.all()]


@api.route("/admin/book/requests/<int:request_id>",)
@roles_required("admin")
def update_book_access(request_id):
    book = db.session.query(BookRequest).get(request_id)

    if not request:
        return {"message": "Book not found"}, 404
    
    book.access = request.args.get("option") == "grant"
    book.date = datetime.datetime.now(datetime.timezone.utc).today()
    db.session.commit()

    return {"message": "Request succesfull"}, 200



@api.route("/user/book/<int:book_id>/view",)
@auth_required("token")
def view_book(book_id):
    request = BookRequest.query.filter_by(book_id=book_id, 
                                       user_id=current_user.id,
                                       access=True).first()
    
    if not request or (datetime.datetime.now(datetime.timezone.utc).date() - request.date).days > 5:
        return {"message": "Invalid request"}, 400
    
    return send_file(os.path.join("static", request.book.filename), )

    
