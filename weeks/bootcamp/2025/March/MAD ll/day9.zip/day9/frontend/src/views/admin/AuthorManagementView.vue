<script setup>
    import store from "@/store"
</script>
<template>
    <div class="alert alert-success" v-show="message">
        {{ message }}
    </div>
    <div class="alert alert-danger" v-show="invalid_message">
        {{ invalid_message }}
    </div>
    <div class="container-fluid">
        <div class="card" style="margin: 15px 0 15px 0;">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                      <input type="button" class="btn btn-primary" value="Add Author" @click="modal=true">
                    </div>
                </div>
            </div>
        </div>
        <table class="table">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
              </tr>
            </thead>
            <tbody> 
                <tr v-for="author in authors">
                    <th scope="row">{{ author.id }}</th>
                    <td>{{ author.name }}</td>
                    <td>{{ author.description }}</td>
                    <td>
                        <button class="btn btn-outline-warning" @click="modifyAuthor(author.id)">
                            Modify
                        </button>
                    </td>
                    <td>
                        <button class="btn btn-outline-danger" @click="deleteAuthor(author.id)">
                            Delete
                        </button>
                    </td>
                </tr>
            </tbody>
          </table>
          <div class="modal" tabindex="-1" style="display: block;" v-show="modify">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Modify Author</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" @click="modify=false"></button>
                </div>
                <form @submit.prevent="updateAuthor">
                    <div class="modal-body">
                        <div class="row mb-3">
                            <div class="col" style="min-width: 80%;">
                                <label for="formGroupExampleInput" class="form-label">Name</label>
                                <input type="text" class="form-control" placeholder="Name" aria-label="Genre"
                                 v-model="form['name']">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
              </div>
            </div>
          </div>
          <div class="modal" tabindex="-1" style="display: block;" v-show="modal">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Add Author</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" @click="modal=false"></button>
                </div>
                <form @submit.prevent="addAuthor">
                    <div class="modal-body">
                        <div class="row mb-3">
                            <div class="col" style="min-width: 80%;">
                                <label for="formGroupExampleInput" class="form-label">Author</label>
                                <input type="text" class="form-control" placeholder="Author" aria-label="Author"
                                 v-model="name">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Add Author</button>
                    </div>
                </form>
              </div>
            </div>
          </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                name: "",
                message: null,
                invalid_message: null,
                form: {
                    name: null,
                },
                modify: false,
                modal: false
            }
        },
        created(){
            store.dispatch("getAuthors", "")
        },
        methods:{
            searchGenre(){
                store.dispatch("getGenres", this.name)

            },
            validate(){
                this.error = {
                    name: null, 
                }

                if(!this.name)
                {
                    this.error["name"]= true;
                    return false
                }
                return true
            },
            addAuthor(){
                fetch(import.meta.env.VITE_BASEURL+"/admin/author", {
                    method: "POST",
                    headers: {
                        "Authentication-Token": store.getters.getToken,
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({name: this.name})
                }).then(x =>{

                    if(x.status == 201){
                        this.message = "Added Author Successfully."
                    }
                    this.modal = false
                    store.dispatch("getAuthors", "")
                })
            },
            flterGenre(id){
                var author = this.authors.filter(x => x.id == id)[0];
                
                this.form = author

            },
            modifyAuthor(id){
                this.modify = true
                this.flterGenre(id);

            },
            updateAuthor(){
                fetch(import.meta.env.VITE_BASEURL+"/admin/author/"+this.form["id"], {
                        method: "PUT",
                        headers: {
                            "Authentication-Token": store.getters.getToken,
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({name: this.form["name"]})
                    }).then(x =>{
                      if(x.status == 200){
                        this.message = "Updated Author successfully.";
                        this.modify = false;
                      }
                      else{
                        this.invalid_message = "Something went wrong."
                      }
                      store.dispatch("getAuthors", this.name)
                    })
            },
            deleteAuthor(id){
                fetch(import.meta.env.VITE_BASEURL+"/admin/author/"+id, {
                        method: "DELETE",
                        headers: {
                            "Authentication-Token": store.getters.getToken,
                            "Content-Type": "application/json"
                        }
                }).then(x=>{
                    if(x.status == 200){
                        this.message = "Deleted Author successfully.";
                    }
                    else{
                        this.invalid_message = "Something went wrong."
                    }
                    store.dispatch("getAuthors", "");
                }
                )
            }
        },
        computed:{
            authors(){
                return store.getters.getAuthors;
            }
        }
    }
</script>
<style scoped>
    .mb-3{
        margin-top: 10px;
    }
    .btn-primary{
        width: 100%;
    }
</style>