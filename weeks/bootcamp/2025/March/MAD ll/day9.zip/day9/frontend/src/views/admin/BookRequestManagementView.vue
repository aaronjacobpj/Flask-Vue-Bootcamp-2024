<script setup>
    import store from "@/store"
</script>
<template>
    <div class="alert alert-success" v-show="message">
        {{ message }}
    </div>
    <div class="alert alert-danger" v-show="invalid_message">
        {{ invalid_message }}
    </div>
    <div class="container-fluid">
        <table class="table">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">User</th>
                <th scope="col">Authors</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="request in requests">
                <th scope="row">{{ request.id }}</th>
                <td>{{ request.book }}</td>
                <td>{{ request.username }}</td>
                <td>
                    <div class="col" style="display: flex;">
                        <button class="btn btn-success" @click="enableAccess(request.id)" :disabled="request.status == true">
                            Request
                        </button>
                    </div>
                </td>
                <td>
                    <div class="col" style="display: flex;">
                        <button class="btn btn-danger" @click="revokeAccess(request.id)" :disabled="request.status == false">
                            Reject
                        </button>
                    </div>
                </td>
              </tr>
            </tbody>
          </table>
    </div>
</template>
<script>
    export default {
        props: ["id"],
        data(){
            return {
                message: null,
                invalid_message: null,
                requests: []
            }
        },
        created(){
                store.dispatch("getBooks", "");
                store.dispatch("getGenres", "");
                store.dispatch("getAuthors", "")
                this.bookRequests()
        },
        methods:{
            bookRequests(){
                fetch(import.meta.env.VITE_BASEURL+"/admin/book/requests",
                    {
                        method: "GET",
                        headers: {
                            "Authentication-Token": store.getters.getToken
                        },
                    }
                ).then(x => {
                    if(x.status == 200)
                        return x.json();
                    return []
                }).then(x => this.requests = x)
            },
            enableAccess(id){
                fetch(import.meta.env.VITE_BASEURL+"/admin/book/requests/"+id+"?option=grant",
                    {
                        method: "GET",
                        headers: {
                            "Authentication-Token": store.getters.getToken
                        },
                    }
                ).then(x => {
                    if(x.status == 200)
                        this.requests.find(x => x["id"]["status"] == true)
                        this.bookRequests()
                })
            },
            revokeAccess(id){
                fetch(import.meta.env.VITE_BASEURL+"/admin/book/requests/"+id+"?option=revoke",
                    {
                        method: "GET",
                        headers: {
                            "Authentication-Token": store.getters.getToken
                        },
                    }
                ).then(x => {
                    if(x.status == 200)
                        this.requests.find(x => x["id"]["status"] == false)
                        this.bookRequests()


                })
            }
        },
        computed:{
            
        },
    }
</script>
<style scoped>
    .mb-3{
        margin-top: 10px;
    }
    .btn-primary{
        width: 100%;
    }
    .card{
        margin: 0px 10px 0px 10px;
        margin-bottom: 10px
    }
</style>