<script setup>
    import store from "@/store"
</script>
<template>
    <div class="alert alert-success" v-show="message">
        {{ message }}
    </div>
    <div class="container-fluid">
        <div class="card">
            <div class="card-body">
                <h2>Add New Book</h2>
                <form @submit.prevent="createBook">
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Book</label>
                        <input type="text" class="form-control" id="formGroupExampleInput" v-model="name" placeholder="Book">
                        <p class="invalid-feedback" style="display: block;" v-show="error['name']">Required Field</p>
                    </div>
                    <div class="mb-3">
                        <label for="formGroupExampleInput2" class="form-label">Date Issued</label>
                        <input type="date" class="form-control" id="formGroupExampleInput2" v-model="date" >
                    </div>
                    <div class="mb-3">
                        <label for="formGroupExampleInput2" class="form-label">Genre</label>
                        <select class="form-select" aria-label="Default select example" v-model="genre">
                            <option selected disabled value="null">Select Genre</option>
                            <option :value="genre.id" v-for="genre in store.getters.getGenres">
                                {{ genre.name }}
                            </option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="formGroupExampleInput2" class="form-label">Authors</label>
                        <select class="form-select" aria-label="Default select example" multiple v-model="authors">
                            <option selected disabled value="null">Select Authors</option>
                            <option :value="author.id" v-for="author in store.getters.getAuthors">
                                {{ author.name }}
                            </option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="formFile" class="form-label">Upload Book</label>
                        <input class="form-control" type="file" id="formFile" @change="getFile">
                    </div>
                    <div class="mb-3">
                        <input type="submit" class="btn btn-primary" id="formGroupExampleInput2" placeholder="Description">
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                genre: null,
                authors: [null],
                name: null,
                date: null,
                message: null,
                file: null,
                error:{
                    name: null,
                }
            }
        },
        created(){
            store.dispatch("getAuthors", "");
            store.dispatch("getGenres", "");
            
        },
        methods:{
            validate(){
                this.error = {
                    name: null, 
                }

                if(!this.name)
                {
                    this.error["name"]= true;
                    return false
                }
                return true
            },
            getFile(event){
                this.file = event.target.files[0]
                
            },
            createBook(){
                var form = new FormData();
                form.append("name", this.name);
                form.append("date", this.date);
                this.authors.forEach(element => {
                    form.append("authors", element)
                });
                form.append("book", this.file);
                form.append("genre", this.genre)
                fetch(import.meta.env.VITE_BASEURL+"/admin/book",
                    {
                        method: "POST",
                        headers: {
                            "Authentication-Token": store.getters.getToken
                        },
                        body: form
                    }
                ).then(x =>{
                    if(x.status == 201){
                        this.message = "Added Book successfully."
                    }
                })
            }
        }
    }
</script>
<style scoped>
    .container-fluid{
        justify-content: center; 
        display: flex; 
        align-items: center;
        height: 90vh;
    }
    .mb-3{
        margin-top: 10px;
    }
    .btn-primary{
        width: 100%;
    }
</style>