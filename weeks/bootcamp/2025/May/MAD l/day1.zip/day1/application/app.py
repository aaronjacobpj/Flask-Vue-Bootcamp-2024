from flask import Flask, render_template
from datetime import datetime

app = Flask(__name__)


@app.route("/")
def greet():
    today = datetime.now()
    return render_template("index.html", 
                           open=not ((today.day <= 16 and today.month == 5) or (today.month < 5)))
