import BLOCK from "./block.js";

const app = Vue.createApp({
    template: `
        <block v-bind:heading="message"></block>
        <block heading="This is the second block!"></block>
    `,
    data(){
        return {
            message: "Hello, world!"
        }
    },
    methods: {
        echo(e){
            alert(e)
        }
    }
})
app.component("block", BLOCK);
app.mount("#app")