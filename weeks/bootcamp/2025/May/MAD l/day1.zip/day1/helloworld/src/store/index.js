import { createStore } from "vuex"

const store = createStore({
    state(){
        return {
            message: "Hello, world!"
        }
    },
    mutations:{
        setMessage(state, value){
            state.message = value
        }
    },
    actions: {
        updateMessage(context, value){
            setTimeout(()=> context.commit("setMessage", value),  1000)
        }
    }
});

export default store;