from flask import Flask, render_template

app = Flask(__name__)

tasks = ["Wash dishes", "Buy cookies", "Do homework"]

@app.route("/")
def greet():
    return render_template("index.html", tasks=tasks)
