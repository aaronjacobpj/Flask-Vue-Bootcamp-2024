const Home = {
    template: `<h1>Hello, world!</h1>`
}

export default Home;