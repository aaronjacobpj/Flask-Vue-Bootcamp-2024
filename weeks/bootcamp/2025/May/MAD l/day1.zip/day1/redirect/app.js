import router from "./router.js"
import Home from "./Home.js";

const app = Vue.createApp({
            template: `
                <router-view></router-view>
                <router-link to="/">Home</router-link>
                <router-link to="/greet">Greet</router-link>
            `,
            data(){
                return {
                }
            },
            methods: {
                
            }
})

app.component("home", Home);

app.use(router);

app.mount("#app");