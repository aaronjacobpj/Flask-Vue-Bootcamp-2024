import Home from "./Home.js";
import Greet from "./Greet.js";

const routes = [
    {path: "", component: Home},
    {path: "/greet", component: Greet}
]


const router = VueRouter.createRouter({
    history: VueRouter.createMemoryHistory(),
    routes,
})

export default router;