from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

TASKS = []

@app.route("/")
def index():
    return render_template("index.html", tasks=TASKS)


@app.route("/add", methods=["POST"])
def add():
    global TASKS
    TASKS.append(request.form.get("task"))
    return redirect(url_for("index"))
        