from flask import Flask, render_template, request, redirect, url_for, session
import os

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("secret", "uegiftnqiwonioefwmnaiobbisudefkrbneioaswmnm")


@app.route("/")
def index():
    if "tasks" not in session:
        session["tasks"] = []
    return render_template("index.html", tasks=session["tasks"])


@app.route("/add", methods=["POST"])
def add():
    session["tasks"].append(request.form.get("task"))
    session.update()
    return redirect(url_for("index"))
        