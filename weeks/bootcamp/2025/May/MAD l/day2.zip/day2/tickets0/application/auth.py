from flask import Blueprint, request, render_template, flash
from werkzeug.security import check_password_hash

from application.models import User

api = Blueprint("auth", __name__)


@api.route("/", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")
    
    username = request.form.get("username")    
    password = request.form.get("password")

    user = User.query.filter_by(username=username).first()

    if not user or not check_password_hash(user.password, password):
        flash("Invalid username or password", category="invalid-user")
        return render_template("login.html")