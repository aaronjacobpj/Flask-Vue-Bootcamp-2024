from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()


class User(db.Model):
    __tablename__ = "user"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), nullable=False)
    username = db.Column(db.String(), unique=True, nullable=False)
    password = db.Column(db.String(), nullable=False)
    role = db.Column(db.String(), nullable=False)


class Theatre(db.Model):
    __tablename__ = "theatre"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), nullable=False)    
    place = db.Column(db.String(), nullable=False)
    capacity = db.Column(db.Integer(), nullable=False)


class Show(db.Model):
    __tablename__ = "show"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), nullable=False)    
    price = db.Column(db.Integer(), nullable=False)
    start = db.Column(db.Date(), nullable=False)
    end = db.Column(db.Date(), nullable=False)
    theatre_id = db.Column(db.Integer(), db.ForeignKey("theatre.id"))


class Ticket(db.Model):
    __tablename__ = "ticket"

    id = db.Column(db.Integer(), primary_key=True)
    tickets = db.Column(db.Integer(), nullable=False)
    show_id = db.Column(db.Integer(), db.ForeignKey("show.id"))
    user_id = db.Column(db.Integer(), db.ForeignKey("user.id"))