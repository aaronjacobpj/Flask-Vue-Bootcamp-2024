from flask import Flask
from werkzeug.security import generate_password_hash

from application.models import db, User
from application.auth import api as auth_api
from application.admin_api import api as admin_api
from application.theatre_api import api as theatre_api

def create_app():

    app = Flask(__name__)

    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///model.db"
    app.config["SECRET_KEY"] = "bseaugbuijbnaknk"

    db.init_app(app)

    with app.app_context():
        db.create_all()
        if not User.query.filter_by(username="alice").first():
            admin = User(name="Alice", 
                        username="alice", 
                        password=generate_password_hash("alice"),
                        role="admin")
            db.session.add(admin)
            db.session.commit()
    
    app.register_blueprint(auth_api)
    app.register_blueprint(admin_api)
    app.register_blueprint(theatre_api)

    return app



app = create_app()