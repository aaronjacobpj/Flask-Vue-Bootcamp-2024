from flask import (Blueprint, request, render_template, 
                   flash, session, redirect, url_for)
from application.models import db, User


api = Blueprint("admin_api", __name__)


@api.route("/admin")
def admin_dashboard():
    return render_template("admin/layout.html")