from flask import (Blueprint, request, render_template, 
                   flash, session, redirect, url_for)
from werkzeug.security import check_password_hash, generate_password_hash
from application.models import db, User

api = Blueprint("auth", __name__)


@api.route("/", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")
    
    username = request.form.get("username")    
    password = request.form.get("password")

    user = User.query.filter_by(username=username).first()

    if not user or not check_password_hash(user.password, password):
        flash("Invalid username or password", category="invalid-user")
        return render_template("login.html")
    
    session["user-id"] = user.id
    if user.role == "user":
        return "You are a user."
    
    return redirect(url_for("admin_api.admin_dashboard"))


@api.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "GET":
        return render_template("signup.html")
    
    name = request.form.get("name")
    username = request.form.get("username")
    password = request.form.get("password")

    if User.query.filter_by(username=username).first():
        flash("Username already taken.", category="invalid-user")
        return render_template("signup.html", name=name, username=username)
    
    if not name:
        flash("Field required.", category="invalid-name")
        return render_template("signup.html")
    user = User(name=name,
                password=generate_password_hash(password),
                username=username,
                role="user")
    db.session.add(user)
    db.session.commit()

    return redirect(url_for("auth.login"))
