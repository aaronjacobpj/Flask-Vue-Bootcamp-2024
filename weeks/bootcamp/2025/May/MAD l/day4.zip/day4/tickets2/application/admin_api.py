from flask import (Blueprint, request, render_template, 
                   flash, session, redirect, url_for)
from application.utils import login_required
from application.models import db, User


api = Blueprint("admin_api", __name__)


@api.route("/admin")
@login_required
def admin_dashboard():
    return render_template("admin/layout.html")