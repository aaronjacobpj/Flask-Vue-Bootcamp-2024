import functools
from flask import session, redirect, url_for

def login_required(route):
    @functools.wraps(route)
    def route_wrapper(*args, **kwargs):
        if session.get("user-id") is None:
            return redirect(url_for("auth.login"))

        return route(*args, **kwargs)

    return route_wrapper