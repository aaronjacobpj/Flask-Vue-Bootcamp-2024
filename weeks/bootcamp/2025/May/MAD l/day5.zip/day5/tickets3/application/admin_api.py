from flask import (Blueprint, request, render_template, 
                   flash, session, redirect, url_for)
from application.utils import login_required
from application.models import db, Show, Theatre


api = Blueprint("admin_api", __name__)


@api.route("/admin")
@login_required
def admin_dashboard():
    data = []
    for show in Show.query.all():
        data.append([show.name, show.tickets_sold()])

    return render_template("admin/dashboard.html", data=data)


@api.route("/admin/statistics")
@login_required
def statistics():

    result = []
    for theatre in Theatre.query.all():
        result.append([theatre.name, len(theatre.shows)])

    return result