from flask import (Blueprint, request, render_template, 
                   flash, session, redirect, url_for)
from application.models import db, User, Theatre, Show
from application.utils import login_required
import datetime


api = Blueprint("show_api", __name__)


@api.route("/show/create", methods=["GET", "POST"])
@login_required
def create_show():
    theatres = Theatre.query.all()
    if request.method == "GET":
        return render_template("admin/create_show.html", theatres=theatres)
    
    name = request.form.get("name")
    price = request.form.get("price", type=int)
    start = request.form.get("start")
    end = request.form.get("end")
    theatre_id = request.form.get("theatre")
    check = True

    if not name:
        flash("Invalid name.", category="invalid-name")
        check = False
    if not price:
        flash("Invalid field.", category="invalid-price")
        check=False

    try:
        start_date = datetime.datetime.strptime(start, "%Y-%m-%d")
        end_date = datetime.datetime.strptime(end, "%Y-%m-%d")
    except:
        flash("Invalid date.", category="invalid-date")
        check = False

    if not db.session.query(Theatre).get(theatre_id):
        flash("Invalid Theatre.", category="invalid-theatre")
        check = False

    if start_date > end_date:
        flash("Invalid date.", category="invalid-date")
        check = False

    if not check:
        return render_template("admin/create_show.html",
                               name=name,
                               price=price,
                               start=start,
                               end=end,
                               theatre_id=theatre_id,
                               theatres=theatres)
    

    show = Show(name=name,
                price=price,
                start=start_date,
                end=end_date,
                theatre_id=theatre_id)
    db.session.add(show)
    db.session.commit()

    flash("Created Show successfully.", category="alert-success")
    return redirect(url_for("show_api.create_show"))


@api.route("/show")
@login_required
def view_shows():
    shows = Show.query.all()
    return render_template("admin/show.html", shows=shows)


@api.route("/show/<int:id>/delete")
@login_required
def delete_show(id):
    show = db.session.query(Show).get(id)

    if not show:
        flash("Invalid Show.", category="alert-danger")
        return redirect(url_for("show_api.view_shows"))
    
    db.session.delete(show)
    db.session.commit()

    flash("Deleted Theatre Successfully.", category="alert-success")
    return redirect(url_for("show_api.view_shows"))


@api.route("/show/<int:id>", methods=["GET", "POST"])
@login_required
def update_show(id):
    show = db.session.query(Show).get(id)

    if not show:
        flash("Invalid Show.", category="alert-danger")
        return redirect(url_for("show_api.view_shows"))
    
    if request.method == "GET":
        theatres = Theatre.query.all()
        return render_template("admin/update_show.html",
                               show=show,
                               name=show.name,
                               price=show.price,
                               start=show.start,
                               end=show.end,
                               theatres=theatres,
                               theatre_id=show.theatre_id)

    name = request.form.get("name")
    price = request.form.get("price", type=int)
    start = request.form.get("start")
    end = request.form.get("end")
    theatre_id = request.form.get("theatre")
    check = True

    if not name:
        flash("Invalid name.", category="invalid-name")
        check = False
    if not price:
        flash("Invalid field.", category="invalid-price")
        check=False

    try:
        start_date = datetime.datetime.strptime(start, "%Y-%m-%d")
        end_date = datetime.datetime.strptime(end, "%Y-%m-%d")
    except:
        flash("Invalid date.", category="invalid-date")
        check = False

    if not db.session.query(Theatre).get(theatre_id):
        flash("Invalid Theatre.", category="invalid-theatre")
        check = False

    if start_date > end_date:
        flash("Invalid date.", category="invalid-date")
        check = False

    if not check:
        theatres = Theatre.query.all()
        return render_template("admin/create_show.html",
                               show=show,
                               name=name,
                               price=price,
                               start=start,
                               end=end,
                               theatre_id=theatre_id,
                               theatres=theatres)
    
    show.name = name
    show.price = price
    show.start = start_date
    show.end = end_date
    show.theatre_id = theatre_id
    db.session.commit()

    flash("Updated show successfully.", category="alert-success")
    return redirect(url_for("show_api.view_shows"))

