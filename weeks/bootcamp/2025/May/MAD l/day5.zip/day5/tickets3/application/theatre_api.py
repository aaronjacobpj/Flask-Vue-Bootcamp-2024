from flask import (Blueprint, request, render_template, 
                   flash, session, redirect, url_for)
from werkzeug.security import check_password_hash, generate_password_hash
from application.models import db, User, Theatre
from application.utils import login_required


api = Blueprint("theatre_api", __name__)


@api.route("/admin/theatre/create", methods=["GET", "POST"])
@login_required
def create_theatre():
    if request.method == "GET":
        return render_template("admin/create_theatre.html")
    
    name = request.form.get("name", "")
    place = request.form.get("place", "")
    capacity = request.form.get("capacity", type=int)

    if not name:
        flash("Field required.", category="invalid-name")
        return render_template("admin/create_theatre.html", 
                               name=name,
                               place=place,
                               capacity=capacity)
    elif not place:
        flash("Field required.", category="invalid-place")
        return render_template("admin/create_theatre.html", 
                               name=name,
                               place=place,
                               capacity=capacity)
    elif not capacity or capacity < 10:
        flash("Invalid Field.", category="invalid-capacity")
        return render_template("admin/create_theatre.html", 
                               name=name,
                               place=place,
                               capacity=capacity)
    
    theatre = Theatre(name=name,
                      place=place,
                      capacity=capacity)
    db.session.add(theatre)
    db.session.commit()

    flash("Created Theatre successfully.", category="alert-success")
    return redirect(url_for("theatre_api.create_theatre"))


@api.route("/admin/theatre")
def theatre():
    theatres = Theatre.query.all()

    return render_template("admin/theatre.html", theatres=theatres)


@api.route("/admin/theatre/<int:theatre_id>/delete")
def delete_theatre(theatre_id):
    theatre = db.session.query(Theatre).get(theatre_id)

    if theatre:
        db.session.delete(theatre)
        db.session.commit()

    flash("Deleted theatre successfully.", category="alert-success")
    return redirect(url_for("theatre_api.theatre"))


@api.route("/admin/theatre/<int:theatre_id>", methods=["GET", "POST"])
def update_theatre(theatre_id):

    theatre = db.session.query(Theatre).get(theatre_id)

    if not theatre:
        return redirect(url_for("theatre_api.theatre"))
    
    if request.method == "GET":
        return render_template("admin/update_theatre.html",
                               theatre_id=theatre_id,
                               name=theatre.name,
                               place=theatre.place,
                               capacity=theatre.capacity)
    
    name = request.form.get("name", "")
    place = request.form.get("place", "")
    capacity = request.form.get("capacity", type=int)

    if not name:
        flash("Field required.", category="invalid-name")
        return render_template("admin/create_theatre.html", 
                               name=name,
                               place=place,
                               capacity=capacity)
    elif not place:
        flash("Field required.", category="invalid-place")
        return render_template("admin/create_theatre.html", 
                               name=name,
                               place=place,
                               capacity=capacity)
    elif not capacity or capacity < 10:
        flash("Invalid Field.", category="invalid-capacity")
        return render_template("admin/create_theatre.html", 
                               name=name,
                               place=place,
                               capacity=capacity)
    
    theatre.name=name
    theatre.place=place
    theatre.capacity=capacity
    db.session.commit()
    flash("Updated Theatre successfully.", category="alert-success")
    return redirect(url_for("theatre_api.theatre"))