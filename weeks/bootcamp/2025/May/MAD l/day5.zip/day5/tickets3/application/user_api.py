from flask import (Blueprint, request, render_template, 
                   flash, session, redirect, url_for)
from application.models import db, User, Theatre, Show, Ticket
from application.utils import login_required


api = Blueprint("user_api", __name__)


@api.route("/user")
@login_required
def user_dashboard():
    return render_template("user/layout.html")


@api.route("/user/search")
@login_required
def search():
    name = request.args.get("search", "")
    shows=Show.query.filter(Show.name.like(f"%{name}%")).all()
    return render_template("user/search.html",
                           shows=shows)


@api.route("/show/<int:id>/book", methods=["GET", "POST"])
def book_show(id):
    show = db.session.query(Show).get(id)

    if not show:
        flash("Show not found.", category="alert-danger")
        return redirect(url_for("user_api.search"))
    
    if request.method == "GET":
        return render_template("user/book.html", show=show)
    
    tickets = request.form.get("tickets", type=int)

    if tickets > show.tickets_available():
        flash(f"Number of tickets can't be more than {show.tickets_available()}", 
              category="invalid-tickets")
        return redirect(url_for("user_api.book_show", id=show.id))
    
    ticket = Ticket(show_id=show.id,
                    user_id=session["user-id"],
                    tickets=tickets)
    db.session.add(ticket)
    db.session.commit()

    flash("Booked tickets successfully.", category="alert-success")
    return redirect(url_for("user_api.search"))

