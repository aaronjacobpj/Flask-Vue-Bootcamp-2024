from flask import Flask, render_template

app = Flask(__name__)

COUNTER = 0

@app.route("/")
def index():
    global COUNTER

    COUNTER += 1
    return render_template("index.html", count=COUNTER)
