const BLOCK = {
    props:["heading"],
    template: `
        <h1>{{ heading }}</h1>
    `
}

export default BLOCK;