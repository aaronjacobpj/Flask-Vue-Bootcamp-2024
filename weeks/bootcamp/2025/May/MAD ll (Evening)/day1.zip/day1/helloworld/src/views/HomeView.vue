<script setup>
</script>

<template>
  <main>
    <h1>{{ $store.state.message }}</h1>
    <button @click="$store.commit('setMessage', 'Bye!')" 
      class="btn btn-primary mx-1">
      Click me!
    </button>
    <button @click="$store.dispatch('updateMessage', 'Bye!')" 
      class="btn btn-primary mx-1">
      Delay!
    </button>
  </main>
</template>
