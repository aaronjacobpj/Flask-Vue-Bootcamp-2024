const Greet = {
    template: "<h1>Bye!</h1>"
}

export default Greet;