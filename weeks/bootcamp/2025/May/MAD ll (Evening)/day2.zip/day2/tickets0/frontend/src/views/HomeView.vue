<script setup>
  import { RouterView } from "vue-router"
</script>

<template>
  <div class="container-fluid d-flex align-items-center justify-content-center">
    <div class="card">
      <div class="card-body">
        <router-view></router-view>
      </div>
    </div>
  </div>
</template>
<style scoped>
  .container-fluid{
    height: 99vh !important;
  }
</style>