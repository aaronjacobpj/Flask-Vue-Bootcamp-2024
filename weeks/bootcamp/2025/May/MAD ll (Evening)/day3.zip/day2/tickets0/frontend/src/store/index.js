import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            user: {
                token: null,
                roles: []
            },
            alerts: {
                success: [],
                danger: [],
            }
        }
    },
    getters:{
        getSuccessAlert(state){
            return state.alerts["success"]
        },
        getDangerAlert(state){
            return state.alerts["danger"]
        }
    },
    mutations: {
        addSuccessAlert(state, value){
            state.alerts["success"].push(value)
        },
        deleteSuccessAlert(state, index){
            state.alerts["success"] = state.alerts["success"].filter((v, i) => index!=i)
        },
        setUser(state, value){
            state.user = value
        }
    }
})