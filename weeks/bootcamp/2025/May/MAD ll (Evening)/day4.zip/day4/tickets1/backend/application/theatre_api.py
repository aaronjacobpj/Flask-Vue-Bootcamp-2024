from flask import Blueprint, request
from flask_security import roles_required

from application.models import db, Theatre

api = Blueprint("theatre", __name__)


@api.route("/admin/theatre", methods=["PUT"])
@roles_required("admin")
def create_theatre():
    name = request.json.get("name")
    place = request.json.get("place")
    capacity = request.json.get("capacity")

    if not name:
        return {"message": "Theatre name is required.",
                "code": "ERROR003"}, 400
    elif not place:
        return {"message": "Theatre place is required.",
                "code": "ERROR004"}, 400
    elif not capacity or not isinstance(capacity, int) or capacity < 10:
        return {"message": "Invalid capacity",
                "code": "ERROR005"}, 400
    
    theatre = Theatre(name=name, place=place, capacity=capacity)
    db.session.add(theatre)
    db.session.commit()

    return {"message": "Created Theatre Successfully."}, 201