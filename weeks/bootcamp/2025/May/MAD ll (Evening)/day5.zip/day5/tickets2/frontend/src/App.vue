<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <div class="alert alert-success alert-dismissible fade show my-1" 
    v-for="(alert, index) in $store.getters.getSuccessAlert" role="alert">
    {{ alert }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" @click="deleteSuccessAlert(index)"
     aria-label="Close"></button>
  </div>
  <div class="alert alert-danger alert-dismissible fade show my-1" 
    v-for="alert in $store.getters.getDangerAlert" role="alert">
    {{ alert }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
  <RouterView/>
</template>
<script>
  export default{
    methods: {
      deleteSuccessAlert(i){
        this.$store.commit("deleteSuccessAlert", i)
      }
    },
    created(){
      let data = localStorage.getItem("user")

      if(data){
        this.$store.commit("setUser", JSON.parse(data))
      }

    }
  }
</script>