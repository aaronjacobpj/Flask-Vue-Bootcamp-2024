<script setup>
  import { RouterLink } from "vue-router"
</script>
<template>
    <h2 class="card-title text-center">Login</h2>
    <form @submit.prevent="signin">
        <div class="mb-3">
            <label for="emailInput" class="form-label">Email</label>
            <input type="email" class="form-control" id="emailInput" v-model="email"
             placeholder="abcd@example.com" required>
            <div class="invalid-feedback" v-show="error['email']">
                {{ error["email"] }}
            </div>
        </div>
        <div class="mb-3">
            <label for="passwordInput" class="form-label">Password</label>
            <input type="password" class="form-control" id="passwordInput" v-model="password"
                placeholder="Your password" required>
        </div>
        <div class="mb-3 justify-content-center d-flex">
            <input type="submit" class="btn btn-primary" value="Login">
        </div>
        <div class="mb-3 justify-content-center d-flex">
            <router-link to="/signup">Create an account</router-link>
        </div>
    </form>
</template>
<script>
    export default {
        data(){
            return {
                email: null,
                password: null,
                error: {
                    email: null
                }
            }
        },
        methods: {
            signin(){
                this.error["email"] = null
                fetch(import.meta.env.VITE_BASEURL+"signin", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({email: this.email, password:this.password})
                }).then(x=>{
                    if(x.status == 200){
                        return x.json()
                    }
                    else if(x.status == 404){
                        this.error["email"] = "Invalid email or password"
                    }
                    return {token: null, roles:[]}
                }).then(x =>{
                    this.$store.commit("setUser", x)
                    if(x["roles"].includes("admin"))
                        setTimeout(()=> this.$router.push({name: "admin-home"}), 1000)
                    else if(x["role"].includes("user"))
                        setTimeout(()=> this.$router.push({name: "user-home"}), 1000)
                })
            }
        }
    }
</script>
<style>
    .invalid-feedback{
        display: block
    }
</style>