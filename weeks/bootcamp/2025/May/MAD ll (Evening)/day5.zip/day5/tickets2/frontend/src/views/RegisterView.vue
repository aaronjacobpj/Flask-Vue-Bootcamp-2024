<template>
    <h2 class="card-title text-center">Register</h2>
    <form @submit.prevent="signup">
        <div class="mb-3">
            <label for="nameInput" class="form-label">Name</label>
            <input type="text" class="form-control" v-model="name"
                id="nameInput" placeholder="Full Name" required>
        </div>
        <div class="mb-3">
            <label for="emailInput" class="form-label">Email</label>
            <input type="email" class="form-control" v-model="email"
                id="emailInput" placeholder="abcd@example.com" required>
            <div class="invalid-feedback" v-show="error['email']">
                {{ error["email"] }}
            </div>
        </div>
        <div class="mb-3">
            <label for="passwordInput" class="form-label">Password</label>
            <input type="password" class="form-control" v-model="password"
                id="passwordInput" placeholder="Your password" required>
            <div class="invalid-feedback" v-show="error['password']">
                {{ error["password"] }}
            </div>
        </div>
        <div class="mb-3 justify-content-center d-flex">
            <input type="submit" class="btn btn-primary" value="Sign Up">
        </div>
        <div class="mb-3 justify-content-center d-flex">
            <router-link to="/">Login</router-link>
        </div>
    </form>
</template>
<script>
    export default {
        data(){
            return {
                name: null,
                email: null,
                password: null,
                error: {
                    email: null,
                    password: null
                } 
            }  
        },
        methods:{
            validate(){
                if(this.password.length < 3){
                    this.error["password"] = "Password must have length atleast 3."
                    return false
                }
                return true
            },
            signup(){
                if (!this.validate())
                    return
                fetch(import.meta.env.VITE_BASEURL+"signup",
                    {
                        method:"POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body:JSON.stringify({name:this.name, password:this.password, email:this.email})
                    }
                ).then(x =>{
                    if (x.status == 201){
                        this.$store.commit("addSuccessAlert", "Created user Successfully.")
                        this.$router.push({name: "login"})
                    }
                        return x.json()
                }).then(x =>{
                    if (x["code"].match("ERROR001"))
                        this.error["email"] = x["message"];
                })
            }
        }
    }
</script>
<style scoped>
    .invalid-feedback{
        display: block !important;
    }
</style>