<template>
    <div class="d-flex flex-wrap m-2">
        <div class="card m-2 col-3" v-for="show in $store.getters.getShows">
            <div class="card-body">
                <h2>{{ show.name }}</h2>
                <p>Price: {{ show.price }}</p>
                <p>Time frame: {{ show.start }} - {{ show.end }}</p>
                <div class="row">
                    <div class="col">
                        <button class="btn btn-warning" 
                            @click="this.$router.push({name: 'update-show', params: {id: show.id}})">
                            Update
                        </button>
                    </div>
                    <div class="col">
                        <button class="btn btn-danger" @click="deleteShow(show.id)">Delete</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
 export default {
    data(){
        return {

        }
    },
    created(){
        this.$store.dispatch("getShows")
    },
    methods: {
        deleteShow(showID){
            fetch(import.meta.env.VITE_BASEURL+"show/"+showID, {
                method: "DELETE",
                headers: {
                    "Authentication-Token": this.$store.getters.getToken
                }
            }).then(x =>{
                if(x.status == 200){
                    this.$store.dispatch("getShows", x)
                    this.$store.commit("addSuccessAlert", "Deleted Show Successfully.")
                }
            })
        }
    }
 }
</script>