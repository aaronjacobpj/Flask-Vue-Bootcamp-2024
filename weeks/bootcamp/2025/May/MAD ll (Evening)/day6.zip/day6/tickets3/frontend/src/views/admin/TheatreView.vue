<template>
    <div class="d-flex flex-wrap m-2">
        <div class="card m-2 col-3" v-for="theatre in $store.getters.getTheatres">
            <div class="card-body">
                <h2>{{ theatre.name }}</h2>
                <p>Place: {{ theatre.place }}</p>
                <p>Capacity: {{ theatre.capacity }}</p>
                <div class="row">
                    <div class="col">
                        <button class="btn btn-warning" 
                            @click="this.$router.push({name: 'update-theatre', params: {id: theatre.id}})">
                            Update
                        </button>
                    </div>
                    <div class="col">
                        <button class="btn btn-danger" @click="deleteTheatre(theatre.id)">Delete</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
 export default {
    data(){
        return {

        }
    },
    created(){
        this.$store.dispatch("getTheatres")
    },
    methods: {
        deleteTheatre(theatreID){
            fetch(import.meta.env.VITE_BASEURL+"theatre/"+theatreID, {
                method: "DELETE",
                headers: {
                    "Authentication-Token": this.$store.getters.getToken
                }
            }).then(x =>{
                if(x.status == 200){
                    this.$store.dispatch("getTheatres", x)
                    this.$store.commit("addSuccessAlert", "Deleted Theatre Successfully.")
                }
            })
        }
    }
 }
</script>