<template>
    <div class="container-fluid d-flex justify-content-center align-items-center" style="height: 90vh;">
        <div class="card">
            <form @submit.prevent="update">
                <div class="card-body">
                    <h2 class="text-center">Create Theatre</h2>
                    <div class="row my-3">
                        <div class="col-4">
                            <label for="formGroupExampleInput" class="form-label">Name</label>
                        </div>
                        <div class="col">
                            <input type="text" class="form-control" v-model="form['name']"
                            id="formGroupExampleInput" placeholder="Candyland" required>
                            <div class="invalid-feedback" v-show="error['name']">
                                {{ error['name'] }}
                            </div>
                        </div>
                    </div>
                    <div class="row my-3">
                        <div class="col-4">
                            <label for="formGroupExampleInput" class="form-label">Place</label>
                        </div>
                        <div class="col">
                            <input type="text" class="form-control" v-model="form['place']"
                            id="formGroupExampleInput" placeholder="Chennai" required>
                            <div class="invalid-feedback" v-show="error['place']">
                                {{ error['place'] }}
                            </div>
                        </div>
                    </div>
                    <div class="row my-3">
                        <div class="col-4">
                            <label for="formGroupExampleInput" class="form-label">Capacity</label>
                        </div>
                        <div class="col">
                            <input type="number" class="form-control" v-model="form['capacity']"
                            id="formGroupExampleInput" placeholder="200" required>
                            <div class="invalid-feedback" v-show="error['capacity']">
                                {{ error['capacity'] }}
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col d-flex justify-content-center">
                            <input type="submit" class="btn btn-primary" value="Update">
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</template>
<script>
    export default {
        props: ["id"],
        data(){
            return {
                form: {
                    id: null,
                    name: null,
                    place: null,
                    capacity: null
                },
                error: {
                    name: null,
                    place: null,
                    capacity: null
                }
            }
        },
        created(){
            this.$store.dispatch("getTheatres")
            let theatre = this.$store.getters.getTheatres.filter(x => x.id == this.id)
            if (theatre)
                this.form = Object.assign({}, theatre[0])
        },
        watch:{
            "$store.state.theatres": function (value){
                let theatre = value.filter(x => x.id == this.id)
                if (theatre)
                    this.form = Object.assign({}, theatre[0]) 
            } 
        },
        methods:{
            update(){
                // Assume checked everything is valid on the client side
                this.error = {
                    name: null,
                    place: null,
                    capacity: null
                }

                fetch(import.meta.env.VITE_BASEURL+"admin/theatre/"+this.form["id"], {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify(this.form)
                }).then(x =>{
                    if (x.status == 200){
                        this.$store.commit("addSuccessAlert", "Updated Theatre Successfully.")
                    }
                    else if(x.status == 400){
                        return x.json()
                    }
                    return {"code": ""}
                }).then(x =>{
                    if (x["code"].match("ERROR003"))
                        this.error["name"] = x["message"]
                    else if (x["code"].match("ERROR004"))
                        this.error["place"] = x["message"]
                    else if (x["code"].match("ERROR005"))
                        this.error["capacity"] = x["message"]
                })
            }
        }
    }
</script>
<style>
    .invalid-feedback{
        display: block !important;
    }
</style>