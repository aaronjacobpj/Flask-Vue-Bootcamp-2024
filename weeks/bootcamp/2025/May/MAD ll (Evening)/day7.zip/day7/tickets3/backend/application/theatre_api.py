from flask import Blueprint, request
from flask_security import roles_required, auth_token_required

from application.models import db, Theatre

api = Blueprint("theatre", __name__)


@api.route("/admin/theatre", methods=["PUT"])
@roles_required("admin")
def create_theatre():
    name = request.json.get("name")
    place = request.json.get("place")
    capacity = request.json.get("capacity")

    if not name:
        return {"message": "Theatre name is required.",
                "code": "ERROR003"}, 400
    elif not place:
        return {"message": "Theatre place is required.",
                "code": "ERROR004"}, 400
    elif not capacity or not isinstance(capacity, int) or capacity < 10:
        return {"message": "Invalid capacity",
                "code": "ERROR005"}, 400
    
    theatre = Theatre(name=name, place=place, capacity=capacity)
    db.session.add(theatre)
    db.session.commit()

    return {"message": "Created Theatre Successfully."}, 201


@api.route("/theatre")
@auth_token_required
def get_theaters():
    theatres = Theatre.query.all()
    return [{
        "id": theatre.id,
        "name": theatre.name,
        "place": theatre.place,
        "capacity": theatre.capacity
        
    } for theatre in theatres]


@api.route("/theatre/<int:theatre_id>", methods=["DELETE"])
@roles_required("admin")
def delete_theatre(theatre_id):
    theatre = db.session.query(Theatre).get(theatre_id)

    if not theatre:
        return {"message": "Theatre not found.",
                "code": "ERROR006"}, 404
    
    db.session.delete(theatre)
    db.session.commit()

    return {"message": "Deleted Theatre Successfully."}, 200


@api.route("/admin/theatre/<int:theatre_id>", methods=["POST"])
@roles_required("admin")
def update_theatre(theatre_id):
    name = request.json.get("name")
    place = request.json.get("place")
    capacity = request.json.get("capacity")

    if not name:
        return {"message": "Theatre name is required.",
                "code": "ERROR003"}, 400
    elif not place:
        return {"message": "Theatre place is required.",
                "code": "ERROR004"}, 400
    elif not capacity or not isinstance(capacity, int) or capacity < 10:
        return {"message": "Invalid capacity",
                "code": "ERROR005"}, 400
    
    theatre = db.session.query(Theatre).get(theatre_id)

    if not theatre:
        return {"message": "Theatre not found.",
                "code": "ERROR006"}, 404
    
    theatre.name = name
    theatre.place = place
    theatre.capacity = capacity

    db.session.commit()

    return {"message": "Updated Theatre Successfully."}, 200