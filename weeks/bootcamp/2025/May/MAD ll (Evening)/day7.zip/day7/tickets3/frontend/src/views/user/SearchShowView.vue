<template>
    <div class="row my-2">
        <div class="col">
            <input type="text" class="form-control" placeholder="Search Show" v-model="query">
        </div>
    </div>
    <div class="container-fluid d-flex flex-wrap" style="min-height: 85vh;">
        <div class="card m-2" style="height: fit-content;" v-for="show in filtered">
            <div class="card-body">
                <h3>{{ show.name }}</h3>
                <span class="badge text-bg-primary mx-1">{{ show.price }}</span>
                <span class="badge text-bg-success mx-1">{{ show.start }}</span>
                <span class="badge text-bg-warning mx-1">{{ show.end }}</span>
                <button class="btn btn-success my-2" style="width: 100%;" @click="picked=show.id;render=true">Buy</button>
            </div>
        </div>
    </div>
    <div class="modal" tabindex="-1" style="display: block;" v-show="render">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Buy Tickets</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                    @click="render=null" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Title</label>
                            <input type="text" class="form-control" :value="show['name']"
                                id="formGroupExampleInput" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Place</label>
                            <input type="text" class="form-control" :value="show['theatre-info']['name']"
                                id="formGroupExampleInput2" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Tickets</label>
                            <input type="number" class="form-control" id="formGroupExampleInput2" placeholder="200">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                query: "",
                form:{
                    tickets: null,
                    show: null,
                },
                render:null,
                picked: null
            }
        },
        created(){
            this.$store.dispatch("getShows")
            this.$store.dispatch("getTheatres")
        },
        computed:{
            filtered(){
                return this.$store.getters.getShows.filter(x => x.name.toLowerCase().includes(this.query.toLowerCase()))
            },
            show(){
                let show = this.$store.getters.getShows.filter((v, i)=> v.id==this.picked)
                if(!show)
                    return {}

                show = Object.assign({}, show[0])
                show["theatre-info"] = {"name": null}
                let theatre = this.$store.getters.getTheatres.filter(x => x.id == show.theatre)
                if(theatre[0])
                    show["theatre-info"] = theatre[0]
                return show
            },
            buy(){
                
            }
        }
    }
</script>