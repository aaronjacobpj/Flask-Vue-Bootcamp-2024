from flask import Blueprint, request
from flask_security import roles_required, auth_token_required, current_user
import datetime

from application.models import db, Theatre, Show, Tickets

api = Blueprint("show", __name__)


@api.route("/admin/show", methods=["PUT"])
@roles_required("admin")
def create_show():

    name = request.json.get("name")
    price = request.json.get("price")
    theatre = request.json.get("theatre")
    start = request.json.get("start")
    end = request.json.get("end")

    if not name:
        return {"message": "name is required.",
                "code": "ERROR007"}, 400
    
    if not price or not isinstance(price, int):
        return {"message": "Invalid price",
                "code": "ERROR008"}, 400
    
    theatre = Theatre.query.filter_by(id=theatre).first()

    if not theatre:
        return {"message": "Invalid Theatre", 
                "code": "Error009"}, 400
    
    try:
        start = datetime.datetime.strptime(start, "%Y-%m-%d")
        end = datetime.datetime.strptime(end, "%Y-%m-%d")
    except Exception  as e:
        print(e)
        return {"message": "Invalid date.",
                "code": "ERROR010"}, 400
    
    show = Show(name=name,
                price=price,
                theatre_id=theatre.id,
                start=start,
                end=end)
    db.session.add(show)
    db.session.commit()

    return {"message": "Created show successfully."}, 201


@api.route("/show")
@auth_token_required
def get_show():
    return [{
        "id": show.id,
        "name": show.name,
        "price": show.price,
        "theatre": show.theatre_id,
        "start": show.start.strftime("%Y-%m-%d"),
        "end": show.end.strftime("%Y-%m-%d")
    } for show in Show.query.all()]


@api.route("/show/<int:show_id>", methods=["DELETE"])
def delete_show(show_id):
    show = db.session.query(Show).get(show_id)

    if not show:
        return {"message": "Invalid show",
                "code": "ERROR011"}, 404
    
    db.session.delete(show)
    db.session.commit()

    return {"message": "Deleted Show Successfully."}, 200


@api.route("/admin/show/<int:show_id>", methods=["POST"])
def update_show(show_id):

    name = request.json.get("name")
    price = request.json.get("price")
    theatre = request.json.get("theatre")
    start = request.json.get("start")
    end = request.json.get("end")

    if not name:
        return {"message": "name is required.",
                "code": "ERROR007"}, 400
    
    if not price or not isinstance(price, int):
        return {"message": "Invalid price",
                "code": "ERROR008"}, 400
    
    theatre = Theatre.query.filter_by(id=theatre).first()

    if not theatre:
        return {"message": "Invalid Theatre", 
                "code": "Error009"}, 400
    
    try:
        start = datetime.datetime.strptime(start, "%Y-%m-%d")
        end = datetime.datetime.strptime(end, "%Y-%m-%d")
    except Exception  as e:
        print(e)
        return {"message": "Invalid date.",
                "code": "ERROR010"}, 400

    show = db.session.query(Show).get(show_id)

    if not show:
        return {"message": "Invalid show",
                "code": "ERROR011"}, 404
    
    show.name = name
    show.price = price
    show.start = start
    show.end = end
    show.theatre_id=theatre.id

    db.session.commit()

    return {"message": "Updated Show Successfully."}, 200


@api.route("/book", methods=["POST"])
@auth_token_required
def book_show():
    tickets = request.json.get("tickets")
    show = request.json.get("show")

    show = db.session.query(Show).get(show)

    if not show:
        return {"message": "Invalid show.",
                "code": "ERROR012"}, 404
    
    if show.is_housefull():
        return {"message": "House full.",
                "code": "ERROR013"}, 406
    
    ticket = Tickets(user_id=current_user.id,
                     show_id=show.id,
                     tickets=tickets)
    db.session.add(ticket)
    db.session.commit()

    return {"message": "Request successfull"}, 200

    