import { createRouter, createWebHistory } from 'vue-router'
import store from "@/store"
import HomeView from '../views/HomeView.vue'
import LoginView from "@/views/LoginView.vue"
import RegisterView from "@/views/RegisterView.vue"
import AdminLayoutView from "@/views/admin/AdminLayoutView.vue"
import TheatreManagementView from "@/views/admin/TheatreManagementView.vue"
import TheatreView from "@/views/admin/TheatreView.vue"
import UpdateTheatreView from "@/views/admin/UpdateTheatreView.vue"
import ShowManagementView from "@/views/admin/ShowManagementView.vue"
import ShowView from "@/views/admin/ShowView.vue"
import AdminHomeView from "@/views/admin/AdminHomeView.vue"
import UpdateShowView from "@/views/admin/UpdateShowView.vue"
import UserLayoutView from "@/views/user/UserLayoutView.vue"
import SearchShowView from "@/views/user/SearchShowView.vue"

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView,
      children: [
        {
          path: "",
          name: "login",
          component: LoginView
        },
        {
          path: "signup",
          name: "signup",
          component: RegisterView
        }
      ]
    },
    {
      path: "/admin",
      name: "admin-home",
      component: AdminLayoutView,
      beforeEnter:(to, from, next)=>{
        if(store.getters.getRoles.includes("admin")){
          next()
        }
        else{
          next({name: "login"})
        }
      },
      children: [
        {
          path:"",
          name: "admin-dashboard",
          component: AdminHomeView
        },
        {
          path: "theatre/create",
          name: "create-theatre",
          component: TheatreManagementView
        },
        {
          path: "theatre",
          name: "theatre",
          component: TheatreView
        },
        {
          path: "theatre/:id",
          name: "update-theatre",
          props: true,
          component: UpdateTheatreView
        },
        {
          path: "show/create",
          name: "create-show",
          component: ShowManagementView
        },
        {
          path: "show",
          name: "show",
          component: ShowView
        },
        {
          path: "show/:id",
          name: "update-show",
          props: true,
          component: UpdateShowView
        }
      ]
    },
    {
      path: "/user",
      name: "user-home",
      component: UserLayoutView,
      beforeEnter:(to, from, next)=>{
        if(store.getters.getRoles.includes("user")){
          next()
        }
        else{
          next({name: "login"})
        }
      },
      children: [
        {
          path: "",
          name: "user-search",
          component: SearchShowView
        }
      ]
    }
  ],
})

export default router
