<script setup>
    import Navbar from "@/components/user/Navbar.vue"
    import { RouterView } from "vue-router"
</script>
<template>
    <div class="container-fluid">
        <Navbar/>
        <router-view></router-view>
    </div>
</template>