from flask import Flask
from flask_security import Security, SQLAlchemyUserDatastore
from werkzeug.security import generate_password_hash
from flask_cors import CORS


from application.models import db, User, Role
from application.auth import api as auth_api


def create_app():
    app = Flask(__name__)
    CORS(app)

    app.config['SECRET_KEY'] = "skjnvdkesnak"
    app.config['SECURITY_PASSWORD_SALT'] = "88974881683601"


    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///model.db'
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    db.init_app(app)
    datastore = SQLAlchemyUserDatastore(db, User, Role)
    app.security = Security(app, datastore)

    with app.app_context():
        db.create_all()

        if not app.security.datastore.find_role("admin"):
            role = app.security.datastore.create_role(name="admin")
            app.security.datastore.create_role(name="user")
            user = app.security.datastore.create_user(name="Alice",
                                                      email="alice@example.com",
                                                      password=generate_password_hash("alice"))
            user.roles.append(role)

        db.session.commit()

    app.register_blueprint(auth_api)

    return app



app = create_app()
