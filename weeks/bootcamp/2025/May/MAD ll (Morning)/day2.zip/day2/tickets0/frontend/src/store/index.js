import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            successAlerts: [],
            user: {
                token: null,
                roles: []
            }
        }
    },
    mutations:{
        addSuccessAlert(state, value){
            state.successAlerts.push(value)
        },
        removeSuccessAlert(state, index){
            state.successAlerts = state.successAlerts.filter((v, i) => i != index)
        },
        setUser(state, value){
            localStorage.setItem("user", JSON.stringify(value))
            state.user = value
        }
    },
    getters:{
        getSuccessAlert(state){
            return state.successAlerts;
        }
    }
});