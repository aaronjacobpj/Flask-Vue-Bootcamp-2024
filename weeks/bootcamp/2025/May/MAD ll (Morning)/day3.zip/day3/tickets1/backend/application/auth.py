from flask import Blueprint, request
from flask import current_app as app
from flask_security import login_user
from werkzeug.security import check_password_hash, generate_password_hash

from application.models import db


api = Blueprint("auth", __name__)


@api.route("/signin", methods=["POST"])
def signin():
    email = request.json.get("email")
    password = request.json.get("password")

    user = app.security.datastore.find_user(email=email)

    if not user or not check_password_hash(user.password, password):
        return {"message": "Invalid email or password",
                "code": "ERROR001"}, 404
    
    login_user(user)
    return {"token": user.get_auth_token(),
            "roles": [role.name for role in user.roles]
            }


@api.route("/signup", methods=["PUT"])
def signup():

    name = request.json.get("name")    
    email = request.json.get("email")
    password = request.json.get("password")

    user = app.security.datastore.find_user(email=email)

    if user:
        return {"message": "Username already exist.",
                "code": "ERROR002"}, 409
    
    # other kinds of checking

    # Create the user
    user = app.security.datastore.create_user(name=name,
                                              email=email,
                                              password=generate_password_hash(password))
    db.session.commit()

    return {"message": "Created user successfully."}, 201
