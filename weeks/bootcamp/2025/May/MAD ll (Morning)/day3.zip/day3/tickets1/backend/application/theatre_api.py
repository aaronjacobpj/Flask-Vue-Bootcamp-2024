from flask import Blueprint, request
from flask_security import auth_token_required, roles_required

from application.models import db, Theatre


api = Blueprint("theatre_api", __name__)


@api.route("/theatre", methods=["PUT"])
@roles_required("admin")
def create_theatre():
    name = request.json.get("name")
    place = request.json.get("place")
    capacity = request.json.get("capacity")
    
    # form validation
    if not name:
        return {"message": "name is required.",
                "code": "ERROR003"}, 400
    
    # create theatre

    theatre = Theatre(name=name,
                      place=place,
                      capacity=capacity)
    db.session.add(theatre)
    db.session.commit()

    return {"message": "created theatre succesfully."}, 201


@api.route("/theatre")
@auth_token_required
def get_theatres():
    return [{
        "id": theatre.id,
        "name": theatre.name,
        "place": theatre.place,
        "capacity": theatre.capacity
    } for theatre in Theatre.query.all()]


@api.route("/theatre/<int:id>")
def delete_theatre(id):
    theatre = db.session.query(Theatre).get(id)

    if not theatre:
        return {"message": "Theatre not found.",
                "code": "ERROR004"}, 404
    
    db.session.delete(theatre)
    db.session.commit()
    return {"message": "request successfull."}, 200


@api.route("/theatre/<int:id>", methods=["POST"])
@roles_required("admin")
def update_theatre(id):
    name = request.json.get("name")
    place = request.json.get("place")
    capacity = request.json.get("capacity")
    
    # form validation
    if not name:
        return {"message": "name is required.",
                "code": "ERROR003"}, 400
    
    theatre = db.session.query(Theatre).get(id)

    if not theatre:
        return {"message": "Theatre not found.",
                "code": "ERROR004"}, 404
    
    # create theatre

    theatre.name = name
    theatre.place = place
    theatre.capacity = capacity

    db.session.commit()

    return {"message": "updated theatre succesfully."}, 200