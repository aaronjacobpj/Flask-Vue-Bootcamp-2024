import { createRouter, createWebHistory } from 'vue-router'
import store from '@/store'
import HomeLayoutView from '../views/HomeLayoutView.vue'
import LoginView from "@/views/LoginView.vue"
import RegisterView from "@/views/RegisterView.vue"
import AdminLayoutView from "@/views/admin/AdminLayoutView.vue"
import TheatreManagementView from "@/views/admin/TheatreManagementView.vue"
import TheatreView from "@/views/admin/TheatreView.vue"
import UpdateTheatreView from "@/views/admin/UpdateTheatreView.vue"

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeLayoutView,
      children: [
        {
          path:"",
          name:"login",
          component: LoginView
        },
        {
          path: "/signup",
          name: "signup",
          component: RegisterView
        }
      ]
    },
    {
      path: "/admin",
      name: "admin",
      component: AdminLayoutView,
      beforeEnter(to, from, next){
        if(store.getters.getRoles.includes("admin")){
          next()
        }
        else {
          next({name: "login"})
        }
      },
      children: [
        {
          path:"theatre/create",
          name: "create-theatre",
          component: TheatreManagementView
        },
        {
          path: "theatre",
          name: "theatre",
          component: TheatreView
        },
        {
          path: "theatre/:id",
          name: "update-theatre",
          props: true,
          component: UpdateTheatreView
        }
      ]
    }
  ],
})

export default router
