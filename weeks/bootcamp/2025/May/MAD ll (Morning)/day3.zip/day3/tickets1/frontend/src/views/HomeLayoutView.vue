<script setup>
  import { RouterView } from "vue-router"
</script>

<template>
  <main>
    <div class="container-fluid d-flex justify-content-center align-items-center" style="height: 90vh;">
      <div class="card" style="height: fit-content;">
        <div class="card-body">
          <router-view></router-view>
        </div>
    </div>
    </div>
  </main>
</template>
