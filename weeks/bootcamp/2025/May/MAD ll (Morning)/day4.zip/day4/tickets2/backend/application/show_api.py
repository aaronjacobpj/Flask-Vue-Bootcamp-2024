from flask import Blueprint, request
from flask_security import auth_token_required, roles_required
import datetime

from application.models import db, Theatre, Show


api = Blueprint("show_api", __name__)


@api.route("/show", methods=["PUT"])
@roles_required("admin")
def create_show():
    name = request.json.get("name")
    price = request.json.get("price")    
    start = request.json.get("start")
    end = request.json.get("end")
    id = request.json.get("theatre")


    if not name:
        return {"message": "name is required.",
                "code": "ERROR003"}, 400
    
    if not price or not isinstance(price, int):
        return {"message": "price is required.",
                "code": "ERROR005"}
    
    try:
        start_date = datetime.datetime.strptime(start, "%Y-%m-%d")
        end_date = datetime.datetime.strptime(end, "%Y-%m-%d")

        if start_date > end_date:
            raise Exception("Invalid Date")
        
    except:
        return {"message": "Invalid date.",
                "code": "ERROR006"}, 406
    
    if not db.session.query(Theatre).get(id):
        return {"message": "Theatre not found.",
                "code": "ERROR004"}, 404
    

    show = Show(name=name,
                price=price,
                start=start_date,
                end=end_date,
                theatre_id=id)
    db.session.add(show)
    db.session.commit()

    return {"message": "Created show successfully"}, 201


@api.route("/show")
@auth_token_required
def get_shows():
    return [{"id": show.id,
             "name": show.name,
             "price": show.price,
             "start": show.start,
             "end": show.end,
             "theatre-id": show.theatre_id
            }
            for show in Show.query.all()]


@api.route("/show/<int:id>")
def delete_show(id):
    show = db.session.query(Show).get(id)

    if not show:
        return {"message": "Show doesn't exist",
                "code": "ERROR005"}, 404
    
    db.session.delete(show)
    db.session.commit()

    return {"message": "Deleted Show successfully."}, 200


@api.route("/show/<int:id>", methods=["POST"])
def update_show(id):
    show = db.session.query(Show).get(id)

    if not show:
        return {"message": "Show doesn't exist",
                "code": "ERROR005"}, 404
    
    name = request.json.get("name")
    price = request.json.get("price")    
    start = request.json.get("start")
    end = request.json.get("end")
    theatre_id = request.json.get("theatre")


    if not name:
        return {"message": "name is required.",
                "code": "ERROR003"}, 400
    
    if not price or not isinstance(price, int):
        return {"message": "price is required.",
                "code": "ERROR005"}
    
    try:
        start_date = datetime.datetime.strptime(start, "%Y-%m-%d")
        end_date = datetime.datetime.strptime(end, "%Y-%m-%d")

        if start_date > end_date:
            raise Exception("Invalid Date")
        
    except:
        return {"message": "Invalid date.",
                "code": "ERROR006"}, 406
    
    if not db.session.query(Theatre).get(id):
        return {"message": "Theatre not found.",
                "code": "ERROR004"}, 404
    
    show.name = name
    show.price = price
    show.start = start_date
    show.end = end_date
    show.theatre_id = theatre_id
    db.session.commit()

    return {"message": "Updated show successfully."}, 200

