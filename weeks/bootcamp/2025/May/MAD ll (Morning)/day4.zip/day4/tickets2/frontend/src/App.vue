<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <div class="alert alert-success alert-dismissible fade show" role="alert" 
    v-for="alert, i in $store.getters.getSuccessAlert">
    {{ alert }}
    <button type="button" class="btn-close" @click="$store.commit('removeSuccessAlert', i)"
    data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
  <RouterView />
</template>
<script>
  export default {
    created(){
      let user = localStorage.getItem("user")
      if (user)
        this.$store.commit("setUser", JSON.parse(user))
    }
  }
</script>