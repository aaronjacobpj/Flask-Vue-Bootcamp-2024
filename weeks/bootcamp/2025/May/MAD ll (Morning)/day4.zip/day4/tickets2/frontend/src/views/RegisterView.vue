<script setup>
import { RouterLink } from "vue-router"
</script>
<template>
    <h1 class="text-center">Sign up</h1>
    <form @submit.prevent="signup">
        <div class="mb-3">
            <label for="formGroupExampleInput0" class="form-label">Full name</label>
            <input type="text" class="form-control" id="formGroupExampleInput0" 
            placeholder="Charlie" v-model="form['name']" required>
            <div class="invalid-feedback" v-show="error['name']">
                {{ error['name'] }}
            </div>
        </div>
        <div class="mb-3">
            <label for="formGroupExampleInput" class="form-label">email</label>
            <input type="email" class="form-control" id="formGroupExampleInput" 
            placeholder="abcd@example.com" v-model="form['email']" required>
            <div class="invalid-feedback" v-show="error['email']">
                {{ error['email'] }}
            </div>
        </div>
        <div class="mb-3">
            <label for="formGroupExampleInput2" class="form-label">Password</label>
            <input type="password" class="form-control" id="formGroupExampleInput2" 
            placeholder="password" v-model="form['password']" required>
            <div class="invalid-feedback" v-show="error['password']">
                {{ error['password'] }}
            </div>
        </div>
        <div class="mb-3 d-flex justify-content-center">
            <input type="submit" class="btn  btn-primary">
        </div>        
        <div class="mb-3 d-flex justify-content-center">
            <router-link :to="{name:'login'}" style="text-decoration: none;">
                Login
            </router-link>
        </div>
    </form>
</template>
<script>
    export default {
        data(){
            return {
                form: {
                    name: null,
                    email: null,
                    password: null
                },
                error: {
                    name: null,
                    email: null,
                    password: null
                }
            }
        },
        methods:{
            clear(){
                this.error = {
                    name: null,
                    email: null,
                    password: null
                }
            },
            validate(){
                this.clear()

                if(this.form['password'].length < 2){
                    this.error["password"] = "Minimum length of 2 expected."
                    return false
                }
                return true
            },
            signup(){
                if(!this.validate())
                    return

                fetch(import.meta.env.VITE_BASEURL+"signup",
                    {
                        method: "PUT",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(this.form)
                    }
                ).then(x =>{
                    if(x.status == 201){
                        this.$store.commit("addSuccessAlert", "Created user in successfully.")
                    }
                    return x.json()
                }).then(x =>{
                    if(Object.keys(x).includes("code")){
                        if (x["code"].match("ERROR002")){
                            this.error["email"] = x["message"]
                        }
                    }
                })
            }
        }
    }
</script>
<style scoped>
    .invalid-feedback{
        display: block !important;
    }
</style>