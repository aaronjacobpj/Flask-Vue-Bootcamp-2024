<template>
    <div class="container-fluid d-flex justify-content-center align-items-center" style="height: 87vh">
        <form @submit.prevent="create">
            <div class="mb-3">
                <label for="formGroupExampleInput" class="form-label">Name</label>
                <input type="text" class="form-control" id="formGroupExampleInput"
                v-model="form['name']" placeholder="Candy Land">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">Place</label>
                <input type="text" class="form-control" id="formGroupExampleInput2" 
                v-model="form['place']" placeholder="Chennai">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">Capacity</label>
                <input type="text" class="form-control" id="formGroupExampleInput2"
                v-model="form['capacity']" placeholder="200">
            </div>
            <div class="mb-3 d-flex justify-content-center">
                <input type="submit" class="btn btn-primary" value="Create">
            </div>
        </form>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                form: {
                    name: null,
                    place: null,
                    capacity: null
                },
                error:{
                    name: null,
                    place: null,
                    capacity: null
                }
            }
        },
        methods: {
            validate(){return true},
            clear(){
                this.error = {
                    name: null,
                    place: null,
                    capacity: null
                }
            },
            create(){
                this.clear()
                if(!this.validate())
                    return

                fetch(import.meta.env.VITE_BASEURL+"theatre", {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify(this.form)
                }).then(x =>{
                    if(x.status == 201)
                        this.$store.commit('addSuccessAlert', "Created theatre successfully.")
                })

            }
        }
    }
</script>