from flask_security.models import fsqla
from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()

fsqla.FsModels.set_db_info(db, role_table_name="role")


class User(db.Model, fsqla.FsUserMixin):
    __tablename__ = "user"

    name = db.Column(db.String(), nullable=False)
    roles = db.relationship("Role", secondary="user_roles")


class Role(db.Model, fsqla.FsRoleMixin):
    __tablename__ = "role"


class UserRoles(db.Model):
    __tablename__ = "user_roles"

    id = db.Column(db.Integer(), primary_key=True)
    user_id = db.Column(db.ForeignKey("user.id"))    
    role_id = db.Column(db.ForeignKey("role.id"))


class Theatre(db.Model):
    __tablename__ = "theatre"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), nullable=False)
    place = db.Column(db.String(), nullable=False)
    capacity = db.Column(db.Integer(), nullable=False)


class Show(db.Model):
    __tablename__ = "show"

    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), nullable=False)
    price = db.Column(db.Integer(), nullable=False)
    start = db.Column(db.Date(), nullable=False)
    end = db.Column(db.Date(), nullable=False)
    theatre_id = db.Column(db.ForeignKey("theatre.id"), nullable=False)
    theatre = db.relationship("Theatre", backref="shows")
    tickets = db.relationship("Tickets", backref="show")


    def tickets_sold(self):
        count = 0
        for ticket in self.tickets:
            count += ticket.tickets

        return count
    
    def tickets_available(self):
        return self.theatre.capacity - self.tickets_sold()


class Tickets(db.Model):
    __tablename__ = "tickets"

    id = db.Column(db.Integer(), primary_key=True)
    user_id = db.Column(db.ForeignKey("user.id"), nullable=False)
    show_id = db.Column(db.ForeignKey("show.id"), nullable=False)    
    tickets = db.Column(db.Integer(), nullable=False)

