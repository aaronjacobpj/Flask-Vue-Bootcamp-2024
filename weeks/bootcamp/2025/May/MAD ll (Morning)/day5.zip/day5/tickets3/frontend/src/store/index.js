import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            successAlerts: [],
            user: {
                token: null,
                roles: []
            },
            theatres: [],
            shows: []
        }
    },
    mutations:{
        addSuccessAlert(state, value){
            state.successAlerts.push(value)
        },
        removeSuccessAlert(state, index){
            state.successAlerts = state.successAlerts.filter((v, i) => i != index)
        },
        setUser(state, value){
            localStorage.setItem("user", JSON.stringify(value))
            state.user = value
        },
        setTheatres(state, value){
            state.theatres = value
        },
        setShows(state, value){
            state.shows = value
        }
    },
    getters:{
        getSuccessAlert(state){
            return state.successAlerts;
        },
        getRoles(state){
            return state.user["roles"]
        },
        getToken(state){
            return state.user["token"]
        },
        getTheatres(state){
            return state.theatres;
        },
        getShows(state){
            return state.shows;
        }
    },
    actions: {
        getTheatres(context){
            fetch(import.meta.env.VITE_BASEURL+"theatre", {
                    headers: {
                        "Authentication-Token": context.getters.getToken
                    }
                }).then(x => x.json()).then(x => context.commit("setTheatres", x))
        },
        getShows(context){
            fetch(import.meta.env.VITE_BASEURL+"show", {
                    headers: {
                        "Authentication-Token": context.getters.getToken
                    }
                }).then(x => x.json()).then(x => context.commit("setShows", x))
        }
    }
});