<template>
    <div class="container-fluid d-flex flex-wrap">
        <div class="col-6">
            <apexchart type="pie" width="380" :options="pieOption" :series="pieSeries"></apexchart>
        </div>
        <div class="col-6">
            <apexchart type="bar" height="350" :options="barOption" :series="barSeries"></apexchart>
        </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                shows: {
                    show: [], 
                    tickets: []
                },
                theatres: {
                    theatres: [],
                    shows: []
                }
            }
        },
        created(){
            fetch(import.meta.env.VITE_BASEURL+"/show/statistics", {
                headers: {
                    "Authentication-Token": this.$store.getters.getToken
                }
            }).then(x => x.json()).then(x => this.shows = x)
            fetch(import.meta.env.VITE_BASEURL+"/theatre/statistics", {
                headers: {
                    "Authentication-Token": this.$store.getters.getToken
                }
            }).then(x => x.json()).then(x => this.theatres = x)
        },
        computed:{
            pieOption(){
                return {
                    chart: {
                        width: 380,
                        type: 'pie',
                    },
                    labels: this.shows["show"],
                    responsive: [{
                        breakpoint: 480,
                        options: {
                            chart: {
                            width: 200
                            },
                            legend: {
                            position: 'bottom'
                            }
                        }
                    }]
                }
            },
            pieSeries(){
                return this.shows["tickets"]
            },
            barOption(){
                return {
                    chart: {
                    type: 'bar',
                    height: 350
                    },
                    plotOptions: {
                    bar: {
                        borderRadius: 4,
                        borderRadiusApplication: 'end',
                        horizontal: true,
                    }
                    },
                    dataLabels: {
                    enabled: false
                    },
                    xaxis: {
                    categories: this.theatres["theatres"],
                    }
                }
            },
            barSeries(){
                return [{data: this.theatres["shows"]}]
            }
        }
    }
</script>