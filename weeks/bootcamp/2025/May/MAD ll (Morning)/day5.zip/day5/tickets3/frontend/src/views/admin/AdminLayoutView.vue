<script setup>
    import { RouterView } from "vue-router"
    import Navbar from "@/components/admin/Navbar.vue";
</script>
<template>
    <Navbar/>
    <router-view></router-view>
</template>