<template>
    <div class="container-fluid" style="height: 87vh">
        <table class="table">
            <thead>
                <tr>
                    <th></th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Theatre</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="show in $store.getters.getShows">
                    <th>{{ show.id }}</th>
                    <td>{{ show.name }}</td>
                    <td>{{ show.price }}</td>
                    <td>{{ show.start }}</td>
                    <td>{{ show.end }}</td>
                    <td>{{ getTheatre(show["theatre-id"])["name"] }}</td>
                    <td>
                        <button class="btn btn-warning" 
                        @click="this.$router.push({name: 'update-show', params: {id: show.id}})">
                        Update
                        </button>
                    </td>
                    <td>
                        <button class="btn btn-danger" @click="remove(show.id)">Delete</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</template>
<script>
    export default{
        created(){
            this.$store.dispatch("getTheatres")
            this.$store.dispatch("getShows")
        },
        methods:{
            remove(id){
                fetch(import.meta.env.VITE_BASEURL+"show/"+id, {
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(x =>{ 
                    if(x.status == 200) 
                    {
                        this.$store.commit("addSuccessAlert", "Deleted Show successfully")
                        this.$store.dispatch("getShows")
                    }
                })
            },
            getTheatre(id){
                
                let theatre = this.$store.getters.getTheatres.find(x => x.id == id)
                if(!theatre)
                    return {}
                return theatre
            }
        }
    }
</script>