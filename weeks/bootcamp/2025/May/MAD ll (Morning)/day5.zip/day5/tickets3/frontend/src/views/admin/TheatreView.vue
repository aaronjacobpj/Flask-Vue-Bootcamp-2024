<template>
    <div class="container-fluid" style="height: 87vh">
        <table class="table">
            <thead>
                <tr>
                    <th></th>
                    <th>Name</th>
                    <th>Place</th>
                    <th>Capacity</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="theatre in $store.getters.getTheatres">
                    <th>{{ theatre.id }}</th>
                    <td>{{ theatre.name }}</td>
                    <td>{{ theatre.place }}</td>
                    <td>{{ theatre.capacity }}</td>
                    <td>
                        <button class="btn btn-warning" 
                        @click="this.$router.push({name: 'update-theatre', params: {id: theatre.id}})">
                        Update
                        </button>
                    </td>
                    <td>
                        <button class="btn btn-danger" @click="remove(theatre.id)">Delete</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</template>
<script>
    export default{
        created(){
            this.$store.dispatch("getTheatres")
        },
        methods:{
            remove(id){
                fetch(import.meta.env.VITE_BASEURL+"theatre/"+id, {
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(x =>{ 
                    if(x.status == 200) 
                    {
                        this.$store.commit("addSuccessAlert", "Deleted Theatre successfully")
                        this.$store.dispatch("getTheatres")
                    }
                })
            }
        }
    }
</script>