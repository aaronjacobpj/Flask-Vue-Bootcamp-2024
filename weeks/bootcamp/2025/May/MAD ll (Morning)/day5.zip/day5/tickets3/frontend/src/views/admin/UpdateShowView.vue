<template>
    <div class="container-fluid d-flex justify-content-center align-items-center" style="height: 87vh">
        <form @submit.prevent="update">
            <div class="mb-3">
                <label for="formGroupExampleInput" class="form-label">Name</label>
                <input type="text" class="form-control" id="formGroupExampleInput"
                v-model="form['name']" placeholder="Titanic">
                <div class="invalid-feedback" style="display: block;" v-show="error['name']">
                    {{ error['name'] }}
                </div>
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">Price</label>
                <input type="number" class="form-control" id="formGroupExampleInput2" 
                v-model="form['price']" placeholder="200">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">Start Date</label>
                <input type="date" class="form-control" id="formGroupExampleInput2"
                v-model="form['start']">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">End Date</label>
                <input type="date" class="form-control" id="formGroupExampleInput2"
                v-model="form['end']">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">Theatre</label>
                <select class="form-select" v-model="form['theatre']">
                    <option value="null" disabled selected> Select a Theatre</option>
                    <option :value="theatre.id" v-for="theatre in $store.getters.getTheatres">
                        {{ theatre.name }}
                    </option>
                </select>
            </div>
            <div class="mb-3 d-flex justify-content-center">
                <input type="submit" class="btn btn-primary" value="Create">
            </div>
        </form>
    </div>
</template>
<script>
    export default {
        props: ["id"],
        data(){
            return {
                form: {
                    id: null,
                    name: null,
                    price: null,
                    start: null,
                    end: null,
                    theatre: null,
                },
                error:{
                    name: null,
                    price: null,
                    start: null,
                    end: null,
                    theatre: null,
                }
            }
        },
        watch:{

            "$store.state.shows": function(values){
                let show = values.find(x => x.id == this.id)
                this.form["id"] = show["id"]
                this.form["name"] = show["name"]
                this.form["price"] = show["price"]
                this.form["theatre"] = show["theatre-id"]
                this.form["start"] = this.datetoString(show["start"])
                this.form["end"] = this.datetoString(show["end"])

            }
        },
        created(){
            this.$store.dispatch("getTheatres")
            this.$store.dispatch("getShows")
        },
        methods: {
            validate(){
                if(!this.form['name']){
                    this.error["name"] = "Required field."
                    return false
                }
                return true
            },
            clear(){
                this.error = {
                    name: null,
                    price: null,
                    start: null,
                    end: null,
                    theatre: null,
                }
            },
            datetoString(string){
                let date = new Date(string)
                let month = date.getMonth()+1
                let day = date.getDate()
                return `${date.getFullYear()}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`
            },
            update(){
                this.clear()
                if(!this.validate())
                    return

                fetch(import.meta.env.VITE_BASEURL+"show/"+this.id, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify(this.form)
                }).then(x =>{
                    if(x.status == 200)
                        this.$store.commit('addSuccessAlert', "Updated show successfully.")
                })

            }
        }
    }
</script>