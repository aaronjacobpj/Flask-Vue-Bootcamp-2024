<template>
    <div class="container-fluid d-flex justify-content-center align-items-center" style="height: 87vh">
        <form @submit.prevent="update">
            <div class="mb-3">
                <label for="formGroupExampleInput" class="form-label">Name</label>
                <input type="text" class="form-control" id="formGroupExampleInput"
                v-model="form['name']" placeholder="Candy Land">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">Place</label>
                <input type="text" class="form-control" id="formGroupExampleInput2" 
                v-model="form['place']" placeholder="Chennai">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">Capacity</label>
                <input type="text" class="form-control" id="formGroupExampleInput2"
                v-model="form['capacity']" placeholder="200">
            </div>
            <div class="mb-3 d-flex justify-content-center">
                <input type="submit" class="btn btn-primary" value="Update">
            </div>
        </form>
    </div>
</template>
<script>
    export default {
        props: ["id"],
        data(){
            return {
                form: {
                    id: null,
                    name: null,
                    place: null,
                    capacity: null
                },
                error:{
                    name: null,
                    place: null,
                    capacity: null
                }
            }
        },
        created(){
            this.$store.dispatch("getTheatres")
        },
        watch:{
            "$store.state.theatres": function (value){
                let theatre = value.filter(x => x.id == this.id)
                if(theatre)
                    this.form = theatre[0]
            }
        },
        methods: {
            validate(){return true},
            clear(){
                this.error = {
                    name: null,
                    place: null,
                    capacity: null
                }
            },
            update(){
                this.clear()
                if(!this.validate())
                    return

                fetch(import.meta.env.VITE_BASEURL+"theatre/"+this.id, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify(this.form)
                }).then(x =>{
                    if(x.status == 200)
                        this.$store.commit('addSuccessAlert', "Updated theatre successfully.")
                })

            }
        }
    }
</script>