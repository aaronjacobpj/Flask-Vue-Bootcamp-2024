<template>
    <div class="container-fluid d-flex justify-content-center align-items-center" style="height: 87vh;">
       <div class="card" style="border: 0px solid;">
            <div class="card-body">
                <h3 align="center" >Book Show</h3>
                 <form @submit.prevent="buy">
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Movie Name</label>
                        <input type="text" class="form-control" id="formGroupExampleInput"
                         :value="show['name']" disabled readonly>
                    </div>
                    <div class="mb-3">
                        <label for="formGroupExampleInput2" class="form-label">Ticket Price</label>
                        <input type="number" class="form-control" 
                        :value="show['price']" disabled readonly>
                    </div>
                    <div class="mb-3">
                        <label for="formGroupExampleInput2" class="form-label">Theatre</label>
                        <input type="text" class="form-control" 
                        :value="getTheatre(show['theatre-id'])['name']" disabled readonly>
                    </div>
                    <div class="mb-3">
                        <label for="formGroupExampleInput2" class="form-label">Tickets</label>
                        <input type="number" class="form-control" placeholder="4"
                        v-model="tickets" required>
                        <div class="invalid-feedback" v-show="error['tickets']" style="display: block;">
                            {{error['tickets']}}
                        </div>
                    </div>
                    <div class="mb-3">
                        <input type="submit" class="btn btn-primary" style="width: 100%;" value="Buy">
                    </div>
                </form>
            </div>
       </div>
    </div>
</template>
<script>
    export default {
        props: ["id"],
        data(){
            return {
                tickets: null,
                error: {
                    tickets: null
                }
            }
        },
        created(){
            this.$store.dispatch("getShows")
            this.$store.dispatch("getTheatres")
        },
        methods: {
            getTheatre(id){
                
                let theatre = this.$store.getters.getTheatres.find(x => x.id == id)
                if(!theatre)
                    return {}
                return Object.assign({}, theatre)
            },
            buy(){
                fetch(import.meta.env.VITE_BASEURL+"user/show/"+this.id,{
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify({tickets: this.tickets})
                }).then(x =>{
                    if (x.status == 200){
                        this.$store.commit("addSuccessAlert", "Request successfull")
                    }
                    else if(x.status == 406){
                        this.error["tickets"] = "Invalid number of tickets."
                    }
                })
            }
        },
        computed: {
            show(){
                let result = this.$store.getters.getShows.find(x => x.id == this.id)
                return (!result) ? {} : Object.assign({}, result)
            }
        }
    }
</script>