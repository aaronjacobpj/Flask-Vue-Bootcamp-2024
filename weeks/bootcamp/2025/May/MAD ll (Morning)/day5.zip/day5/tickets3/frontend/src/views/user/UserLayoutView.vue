<script setup>
    import { RouterView } from "vue-router"
    import Navbar from "@/components/user/Navbar.vue";
</script>
<template>
    <Navbar/>
    <router-view></router-view>
</template>