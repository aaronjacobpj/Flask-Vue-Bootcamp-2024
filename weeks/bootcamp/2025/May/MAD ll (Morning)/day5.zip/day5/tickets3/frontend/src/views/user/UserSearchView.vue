<script setup>
    import { RouterLink } from  "vue-router"
</script>
<template> 
    <div class="row m-2">
        <div class="col-8">
            <input type="search" class="form-control" placeholder="Search a movie." v-model="search">
        </div>
        <div class="col-4">
            <input type="submit" value="Search" class="btn btn-primary" style="width: 100%;" @click="filter"/>
        </div>
    </div>
    <div class="container-fluid d-flex flex-wrap">
        <div class="card m-2" v-for="show in shows">
            <div class="card-body">
                <h3>{{ show.name }}</h3>
                <div class="text-start m-2">
                    <strong>Price</strong>: {{ show.price }}
                </div>
                <div class="text-start m-2">
                    <strong>Start Date</strong>: {{ show.start }}
                </div>
                <div class="text-start m-2">
                    <strong>Start Date</strong>: {{ show.end }}
                </div>
                <div class="row">
                    <router-link class="btn btn-success" :to="{name: 'book-show', params: {id: show.id}}">
                        Buy
                    </router-link>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                query: "",
                search: "",
            }
        },
        created(){
            this.$store.dispatch("getShows")
        },
        methods:{
            filter(){
                this.query = this.search
            }
        },
        computed:{
            shows(){
                let query = this.query.toLowerCase()
                return this.$store.getters.getShows.filter(x => x["name"].toLowerCase().includes(query))
            }
        }
    }
</script>