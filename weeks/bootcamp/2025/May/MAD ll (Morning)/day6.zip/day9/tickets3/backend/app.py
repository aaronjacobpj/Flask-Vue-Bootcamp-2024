from flask import Flask
from flask_security import Security, SQLAlchemyUserDatastore
from werkzeug.security import generate_password_hash
from flask_cors import CORS
from celery import Celery, Task
from celery.schedules import crontab
import os



from application.models import db, User, Role
from application.auth import api as auth_api
from application.theatre_api import api as theatre_api
from application.show_api import api as show_api
from application.worker import daily_reminder, monthly_report
from application.cache import cache


def celery_init_app(app: Flask) -> Celery:
    class FlaskTask(Task):
        def __call__(self, *args: object, **kwargs: object) -> object:
            with app.app_context():
                return self.run(*args, **kwargs)

    celery_app = Celery(app.name, task_cls=FlaskTask)
    celery_app.config_from_object(app.config["CELERY"])
    celery_app.set_default()
    app.extensions["celery"] = celery_app
    return celery_app


def create_app():

    app = Flask(__name__)

    CORS(app)

    app.config['SECRET_KEY'] = "skjnvdkesnak"
    app.config['SECURITY_PASSWORD_SALT'] = "88974881683601"

    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///model.db'
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    app.config["CELERY"] = dict(
            broker_url="redis://localhost:6379",
            result_backend="redis://localhost:6379",
        )
    app.config["CACHE_TYPE"] = "RedisCache"
    app.config["CACHE_REDIS_URL"] = "redis://localhost:6379/1"

     
    db.init_app(app)
    cache.init_app(app)
    datastore = SQLAlchemyUserDatastore(db, User, Role)
    app.security = Security(app, datastore)

    with app.app_context():
        db.create_all()
        if Role.query.count() < 1:
            admin = app.security.datastore.create_role(name="admin")
            role = app.security.datastore.create_role(name="user")
            db.session.flush()
            user = app.security.datastore.create_user(name="Alice",
                                                      email="alice@example.com",
                                                      password=generate_password_hash("alice"))
            user.roles.append(admin)
            db.session.commit()
    

    app.register_blueprint(auth_api)
    app.register_blueprint(theatre_api)
    app.register_blueprint(show_api)

    celery = celery_init_app(app)

    return app, celery



app, celery = create_app()


@celery.on_after_configure.connect
def setup_periodic_tasks(sender: Celery, **kwargs):

    sender.add_periodic_task(crontab(minute="*"), daily_reminder.s())
    sender.add_periodic_task(crontab(minute="*"), monthly_report.s())