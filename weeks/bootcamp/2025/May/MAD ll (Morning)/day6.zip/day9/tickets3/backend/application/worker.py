from celery import shared_task
from io import StringIO
import csv
from smtplib import SMTP
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from jinja2 import Template


from application.models import db, Show, User, Tickets


@shared_task
def export_task():
    
    io = StringIO()

    writer = csv.writer(io)
    writer.writerow(["Show", "Theatre", "No. Tickets Sold"])
    for show in Show.query.all():
        writer.writerow([show.name, show.theatre.name, show.tickets_sold()])

    io.seek(0)
    return io.read()


@shared_task
def daily_reminder():
    server = SMTP(host="localhost", port=1025)


    for user in User.query.all():
        if len(user.tickets) > 0:
            continue

        content = MIMEMultipart()
        content["FROM"] = "admin@exmaple.com"
        content["TO"] = user.email
        content["Subject"] = "You are missing out!"
        content.attach(MIMEText("You haven't booked anything for a while."))

        server.sendmail("admin@example.com",
                        user.email,
                        content.as_string())


@shared_task
def monthly_report():
    server = SMTP(host="localhost", port=1025)

    content = MIMEMultipart()
    content["FROM"] = "admin@exmaple.com"
    content["TO"] = "alice@exmaple.com"
    content["Subject"] = "Monthly Report"

    shows = Show.query.all()
    with open("templates/report.html") as file:
        html = Template(file.read())
    

    attachment = MIMEText(html.render(shows=shows), "html")
    content.attach(attachment)
    server.sendmail("admin@example.com",
                "alice@example.com",
                content.as_string())