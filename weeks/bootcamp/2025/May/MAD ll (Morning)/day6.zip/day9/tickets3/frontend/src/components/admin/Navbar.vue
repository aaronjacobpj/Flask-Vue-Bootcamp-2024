<script setup>
    import { RouterLink} from "vue-router"
</script>
<template>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Navbar</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#">Home</a>
                </li>
                <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Theatre
                </a>
                <ul class="dropdown-menu">
                    <li><router-link class="dropdown-item" :to="{name: 'create-theatre'}">Create</router-link></li>
                    <li><router-link class="dropdown-item" :to="{name: 'theatre'}">View</router-link></li>
                </ul>
                </li>
                <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Show
                </a>
                <ul class="dropdown-menu">
                    <li><router-link class="dropdown-item" :to="{name: 'create-show'}">Create</router-link></li>
                    <li><router-link class="dropdown-item" :to="{name: 'show'}">View</router-link></li>
                </ul>
                </li>
                <li class="nav-item">
                    <button class="nav-link" aria-current="page" @click="export_csv">Export</button>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" style="color: red;" aria-current="page" @click="signout">Sign out</a>
                </li>
            </ul>
            </div>
        </div>
    </nav>
</template>
<script>
    export default{
        data(){
            return {
                task_id: null,
                download: false
            }
        },
        watch:{
            task_id: function(value){
                if(value){
                    this.download_csv()
                }
            }
        },
        methods:{
            signout(){
                localStorage.removeItem("user")
                this.$store.commit("setUser", {token: null, roles:[]})
                this.$router.push({name: "login"})
            },
            export_csv(){
                this.download = false
                fetch(import.meta.env.VITE_BASEURL+"export", {
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(x =>{
                    if(x.status == 200){
                        return x.json()
                    }
                    return {"id": null}
                }).then(x =>{
                    this.task_id = x["id"]
                })
            },
            download_csv(){
                if(this.download)
                    return

                fetch(import.meta.env.VITE_BASEURL+"export/"+this.task_id+"/status", {
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(x =>{
                    if(x.status == 200){
                        return x.json()
                    }
                    return {"status": "FAILED"}
                }).then(x => {
                    if(x["status"] == "SUCCESS"){
                        fetch(import.meta.env.VITE_BASEURL+"export/"+this.task_id, {
                            headers: {
                                "Authentication-Token": this.$store.getters.getToken
                            }
                        }).then(x =>{
                            if(x.status == 200){
                                return x.text()
                            }
                            return ""
                        }).then(x =>{
                            this.downloader(x, "csv", "export.csv");
                            this.download = true
                        })
                    }
                    else if(x["status"] = "PENDING"){
                        setTimeout(this.download_csv, 1000)
                    }
                })
            },
            downloader(data, type, name) {
                function downloadURI(uri, name) {
                    let link = document.createElement("a");
                    link.download = name;
                    link.href = uri;
                    link.click();
                }

                let blob = new Blob([data], {type});
                let url = window.URL.createObjectURL(blob);
                downloadURI(url, name);
                window.URL.revokeObjectURL(url);
            }
        }
    }
</script>