<script setup>
    import { RouterLink} from "vue-router"
</script>
<template>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Navbar</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <router-link class="nav-link active" aria-current="page" to="/user">Home</router-link>
                </li>
                 <li class="nav-item">
                    <a class="nav-link active" style="color: red;" aria-current="page" @click="signout">Sign out</a>
                </li>
            </ul>
            </div>
        </div>
    </nav>
</template>
<script>
    export default{
        methods:{
            signout(){
                localStorage.removeItem("user")
                this.$store.commit("setUser", {token: null, roles:[]})
                this.$router.push({name: "login"})
            }
        }
    }
</script>