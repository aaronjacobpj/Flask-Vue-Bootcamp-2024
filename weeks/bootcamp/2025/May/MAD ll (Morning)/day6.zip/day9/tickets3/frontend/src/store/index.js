import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            user: {
                token: null,
                roles: []
            },
            alerts: {
                success: [],
                danger: [],
            },
            theatres: [],
            shows: []
        }
    },
    getters:{
        getSuccessAlert(state){
            return state.alerts["success"]
        },
        getDangerAlert(state){
            return state.alerts["danger"]
        },
        getRoles(state){
            return state.user["roles"]
        },
        getToken(state){
            return state.user["token"]
        },
        getTheatres(state){
            return state.theatres;
        },
        getShows(state){
            return state.shows;
        },
    },
    mutations: {
        addSuccessAlert(state, value){
            state.alerts["success"].push(value)
        },
        deleteSuccessAlert(state, index){
            state.alerts["success"] = state.alerts["success"].filter((v, i) => index!=i)
        },
        setUser(state, value){
            state.user = value
            localStorage.setItem("user", JSON.stringify(value))
        },
        setTheatres(state, value){
            state.theatres = value;
        },
        setShows(state, value){
            state.shows = value;
        },
    },
    actions:{
        getTheatres(context){
            fetch(import.meta.env.VITE_BASEURL+"theatre", {
                headers: {
                    "Authentication-Token": context.getters.getToken
                }
            }).then(x =>{
                if(x.status == 200)
                    return x.json()
                return []
            }).then(x =>{
                context.commit("setTheatres", x)
            })
        },
        getShows(context){
            fetch(import.meta.env.VITE_BASEURL+"show", {
                headers: {
                    "Authentication-Token": context.getters.getToken
                }
            }).then(x =>{
                if(x.status == 200)
                    return x.json()
                return []
            }).then(x =>{
                context.commit("setShows", x)
            })
        }
    }
})