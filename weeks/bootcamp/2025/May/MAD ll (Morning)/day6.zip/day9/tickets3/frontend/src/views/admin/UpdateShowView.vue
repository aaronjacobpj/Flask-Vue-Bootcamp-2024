<template>
    <div class="container-fluid d-flex justify-content-center align-items-center" style="height: 90vh;">
        <div class="card">
            <form @submit.prevent="update">
                <div class="card-body">
                    <h2 class="text-center">Add Show</h2>
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Title</label>
                        <input type="text" class="form-control" v-model="form['name']"
                            id="formGroupExampleInput" placeholder="Titanic" required>
                        <div class="invalid-feedback" v-show="error['name']">
                            {{ error["name"] }}
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="formGroupExampleInput2" class="form-label">Price</label>
                        <input type="number" class="form-control" v-model="form['price']"
                            id="formGroupExampleInput2" placeholder="200" required>
                        <div class="invalid-feedback" v-show="error['price']">
                            {{ error["price"] }}
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Start Date</label>
                        <input type="date" class="form-control" v-model="form['start']"
                            id="formGroupExampleInput" required>
                        <div class="invalid-feedback" v-show="error['start']">
                            {{ error["start"] }}
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="formGroupExampleInput2" class="form-label">End Date</label>
                        <input type="date" class="form-control" v-model="form['end']"
                            id="formGroupExampleInput2" required>
                        <div class="invalid-feedback" v-show="error['end']">
                            {{ error["end"] }}
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="formGroupExampleInput2" class="form-label">Theatre</label>
                        <select class="form-select" v-model="form['theatre']" required>
                            <option value="null" disabled selected>Select Theatre</option>
                            <option v-for="theatre in $store.getters.getTheatres" 
                                :value="theatre.id">
                                {{ theatre.name }}
                            </option>
                        </select>
                        <div class="invalid-feedback" v-show="error['theatre']">
                            {{ error["theatre"] }}
                        </div>
                    </div>
                    <div class="mb-3 d-flex justify-content-center">
                        <input type="submit" class="btn btn-primary" value="Add">
                    </div>
                </div>
            </form>
        </div>
    </div>
</template>
<script>
    export default {
        props: ["id"],
        data(){
            return {
                form: {
                    name: null,
                    price: null,
                    theatre: null,
                    start: null,
                    end: null
                },
                error: {
                    name: null,
                    price: null,
                    theatre: null,
                    start: null,
                    end: null
                }
            }
        },
        created(){
            this.$store.dispatch("getShows")
            this.$store.dispatch("getTheatres")
            let show = this.$store.getters.getShows.filter(x => x.id == this.id)
            if (show)
                this.form = Object.assign({}, show[0])
        },
        watch:{
            "$store.state.shows": function (value){
                let show = value.filter(x => x.id == this.id)
                if (show)
                    this.form = Object.assign({}, show[0]) 
            } 
        },
        methods:{
            update(){
                // Assume checked everything is valid on the client side
                this.error = {
                    name: null,
                    place: null,
                    capacity: null
                }

                fetch(import.meta.env.VITE_BASEURL+"admin/show/"+this.form["id"], {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify(this.form)
                }).then(x =>{
                    if (x.status == 200){
                        this.$store.commit("addSuccessAlert", "Updated Show Successfully.")
                    }
                    else if(x.status == 400){
                        return x.json()
                    }
                    return {"code": ""}
                }).then(x =>{
                    if(Object.keys(x).includes("code")){

                        if(x["code"].match("ERRO007"))
                            this.error["name"] = x["message"]
                        if(x["code"].match("ERRO008"))
                            this.error["price"] = x["message"]
                        if(x["code"].match("ERRO009"))
                            this.error["theatre"] = x["message"]
                        if(x["code"].match("ERRO010")){
                            this.error["start"] = x["message"]
                            this.error["end"] = x["message"]
                        }

                    }
                })
            }
        }
    }
</script>
<style>
    .invalid-feedback{
        display: block !important;
    }
</style>