<template>
    <div class="container-fluid d-flex justify-content-center align-items-center" style="height: 85vh;">
        <apexchart width="500" type="bar" :options="chartOption" :series="series"></apexchart>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                theatres: [],
                series: [{
                    name: 'series-1',
                    data: []
                }]
            }
        },
        created(){
            fetch(import.meta.env.VITE_BASEURL+"theatre/statistics",{
                headers: {
                    "Authentication-Token": this.$store.getters.getToken
                }
            }).then(x => x.json()).then(x=>{
                this.theatres = x["theatres"]
                this.series = [{name: 'series-1', data: x["tickets"]}]
            })
        },
        computed:{
            chartOption(){
                return {
                    chart: {
                    id: 'vuechart-example',
                    },
                    xaxis: {
                    categories: this.theatres
                    }
                }
            }
        }
    }
</script>