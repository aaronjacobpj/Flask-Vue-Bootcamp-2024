<script setup>
</script>

<template>
  <main>
    <h1 v-bind:style="{color: color}">This is a heading!</h1>
    <button @click="color='red'">Red</button>
    <button @click="color='green'">Green</button>
    <button @click="color='blue'">Blue</button>
  </main>
</template>
<script>
export default {
  data(){
    return {
     color:"black"
    }
  }
}
</script>