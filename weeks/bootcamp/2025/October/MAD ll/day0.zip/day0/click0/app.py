from flask import Flask, render_template, redirect

app = Flask(__name__)


COUNT = 0

@app.route("/")
def index():
    return render_template("index.html", count=COUNT)


@app.route("/click")
def click():
    global COUNT
    
    COUNT += 1
    return redirect("/")