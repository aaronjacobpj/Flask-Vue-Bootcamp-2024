<script setup>
</script>

<template>
  <main>
    <h1>{{ date }}</h1>
    {{ count }}
    <button v-on:click="change">Click me!</button>
  </main>
</template>
<script>
export default {
  data(){
    return {
      count: 0
    }
  },
  methods: {
    change(){
      this.count++;
    },
    date(){
      this.count
      console.log("Calling...")
      return new Date()
    }
  },
  computed: {
    date(){
      this.count
      console.log("Calling...")
      return new Date()
    }
  }
}
</script>