<script setup>
</script>

<template>
  <main>
    <h1 v-show="show" >Hello, World!</h1>
    <h1 v-show="!show">Bye!</h1>
    <button v-on:click="show=!show">Toggle!</button>
  </main>
</template>
<script>
export default {
  data(){
    return {
     show: true
    }
  }
}
</script>