<script setup>
</script>

<template>
  <main>
    <h1 v-show="!name">Hello, World!</h1>
    <h1 v-show="name">Hello, {{ name }}!</h1>
    <input type="text" v-model="name">
  </main>
</template>
<script>
export default {
  data(){
    return {
     name: null
    }
  }
}
</script>