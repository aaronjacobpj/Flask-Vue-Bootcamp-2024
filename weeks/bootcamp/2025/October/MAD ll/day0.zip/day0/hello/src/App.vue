<script setup>
</script>

<template>
  <main>
    <h1>You have clicked {{ count }} times!</h1>
    <button v-on:click="counter">Click me!</button>
  </main>
</template>
<script>
export default {
  data(){
    return {
      count: 0
    }
  },
  methods: {
    counter(){
      this.count++;
    }
  }
}
</script>