<script setup>
</script>

<template>
  <main>
    <ul>
      <li v-for="(task, index) in tasks">
        {{ index }}). {{ task }}
      </li>
    </ul>
  </main>
</template>
<script>
export default {
  data(){
    return {
     tasks: ["Buy cookies", "Do dishes", "Study"]
    }
  }
}
</script>