<script setup>
</script>

<template>
  <main>
    <ul>
      <li v-for="word in queried">{{ word }}</li>
    </ul>
    <input v-model="search">
  </main>
</template>
<script>
export default {
  data(){
    return {
      words: ["apple", "banana", "cherry", "dog", "elephant",
       "flower", "grape", "house", "island", "jungle"],
      queried: ["apple", "banana", "cherry", "dog", "elephant",
       "flower", "grape", "house", "island", "jungle"],
      search: ""
    }
  },
  watch: {
    search(value){
      console.log(value);
      this.queried = this.words.filter(x => x.includes(value))
    }
  }
}
</script>