<script setup>
  import Hello from "@/components/Hello.vue";
</script>

<template>

  <div style="width: 100%; display: flex; ">
    <Hello v-for="item in messages" v-bind:message="item['message']" 
    v-bind:color="item['color']"/>
    <h1>hello</h1>
  </div>
</template>

<script>
  export default {
    data(){
      return {
        messages: [
          {
            "message": "Item 1",
            "color": "red"
          },
          {
            "message": "Item 2",
            "color": "blue"
          },
        ]
      }
    }
  }
</script>