<template>
    <h1 v-bind:style="{color: color}">{{ message.toUpperCase() }}</h1>
</template>
<script>
    export default {
        props: ["message", "color"]
    }
</script>
<style scoped>
    @import "@/assets/style.css";
    h1{
        font-size: 45px;
    }
</style>