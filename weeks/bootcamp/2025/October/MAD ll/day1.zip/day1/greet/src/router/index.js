import { createRouter, createWebHistory } from 'vue-router'
import HomeView from "@/views/HomeView.vue"
import GreetView from "@/views/GreetView.vue"

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      name: "home",
      component: HomeView
    },
    {
      path: "/greet/:name",
      props: true,
      name: "greet",
      component: GreetView
    }
  ],
})

export default router
