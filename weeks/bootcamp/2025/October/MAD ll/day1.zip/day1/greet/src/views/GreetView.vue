<template>
    <h1 v-if="name.match('none')">Hello, World!</h1>
    <h1 v-else-if="name">Hello, {{ name }}!</h1>
</template>
<script>
  export default {
    props: ["name"]
  }
</script>