<script setup>
  import { RouterLink } from "vue-router";
</script>
<template>
    <input v-model="name">
    <RouterLink :to="{name:'greet', params:{name: name? name: 'none'}}">Greet</RouterLink>
</template>
<script>
    export default {
        data(){
            return {
                name: ""
            }
        }
    }
</script>