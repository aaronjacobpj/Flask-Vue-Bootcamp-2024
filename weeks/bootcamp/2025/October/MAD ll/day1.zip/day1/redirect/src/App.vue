<script setup>
  import { RouterView, RouterLink } from "vue-router";
</script>

<template>
  <RouterView></RouterView>
  <RouterLink to="/">Home</RouterLink>
  <RouterLink :to="{name: 'home1'}">Second Page</RouterLink>
</template>

<style scoped></style>
