from flask_security.models import fsqla
from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()

fsqla.FsModels.set_db_info(db, role_table_name="role")


class User(db.Model, fsqla.FsUserMixin):
    __tablename__ = "user"
    name = db.Column(db.String(), nullable=False)
    roles = db.relationship("Role", secondary="user_roles")


class Role(db.Model, fsqla.FsRoleMixin):
    __tablename__ = "role"


class UserRoles(db.Model):
    __tablename__ = "user_roles"
    id = db.Column(db.Integer(), primary_key=True)
    user_id = db.Column(db.ForeignKey("user.id"))    
    role_id = db.Column(db.ForeignKey("role.id"))


