from flask import current_app as app
from flask import Blueprint, request
from werkzeug.security import generate_password_hash


from application.models import db


api = Blueprint("api", __name__)


@api.route("/signup", methods=["POST"])
def signup():
    name = request.json.get("name")
    email = request.json.get("email")
    password = request.json.get("password")

    if not name:
        return {"message": "Name required.", "code": "ERROR001"}, 400
    
    if not email:
        return {"message": "Email required.", "code": "ERROR002"}, 400
    
    if app.security.datastore.find_user(email=email):
        return {"message": "User exist.", "code": "ERROR003"}, 409
    
    if not password:
        return {"message": "Password required.", "code": "ERROR004"}, 400
    
    user = app.security.datastore.create_user(name=name, 
                                       email=email, 
                                       password=generate_password_hash(password))
    role = app.security.datastore.find_role("user")
    user.roles.append(role)
    db.session.commit()

    return {"message": "Created user successfully."}, 201
