<template>
    <div class="conatiner-fluid d-flex justify-content-center align-items-center" style="height: 95vh;">
        <div class="card p-2">
            <h1 align="center">Sign up</h1>
            <form @submit.prevent="signup">
                <div class="row">
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="exampleFormControlInput1"
                        v-model="form['name']" placeholder="Harry Potter">
                        <div class="invalid-feedback" style="display: block;" v-show="error['name']">
                            {{ error['name'] }}
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="mb-3">
                        <label for="exampleFormControlInput2" class="form-label">Email address</label>
                        <input type="email" class="form-control" id="exampleFormControlInput2"
                        v-model="form['email']" placeholder="name@example.com">
                        <div class="invalid-feedback" style="display: block;" v-show="error['email']">
                            {{ error['email'] }}
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="mb-3">
                        <label for="exampleFormControlInput3" class="form-label">Password</label>
                        <input type="password" class="form-control" id="exampleFormControlInput3"
                        v-model="form['password']" placeholder="Password">
                        <div class="invalid-feedback" style="display: block;" v-show="error['password']">
                            {{ error['password'] }}
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="mb-3">
                        <input type="submit" class="btn btn-primary" style="width: 100%;" value="Sign Up"/>
                    </div>
                </div>
            </form>
        </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                form: {
                    name: null,
                    email: null,
                    password: null
                },
                error: {
                    name: null,
                    email: null,
                    password: null
                }
            }
        },
        methods: {
            validate(){
                this.error = {
                    name: null,
                    email: null,
                    password: null
                }
                let result = true
                if(!this.form['name']){
                    result = false;
                    this.error["name"] = "Required field."
                }
                if(!this.form['email']){
                    result = false;
                    this.error["email"] = "Required field."
                }
                if(!this.form['password'] || this.form['password'].length < 2){
                    result = false
                    this.error["password"] = "Type a strong password."
                }
                return result
            },
            signup(){
                if(!this.validate())
                    return false

                fetch("http://localhost:5000/signup", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(this.form)
                }).then(x =>{
                    if(x.status == 201){
                        alert("Created User successfully.")
                        return {}
                    }
                    else if(x.status == 400){
                        return x.json()
                    }
                    else if (x.status == 409){
                        this.error["email"] = "Email already exist."
                        return {}
                    }
                }).then(x =>{
                    if(x["code"].match("ERROR001"))
                        this.error["name"] = "Required Field."
                    if(x["code"].match("ERROR002"))
                        this.error["email"] = "Required Field."
                    if(x["code"].match("ERROR004"))
                        this.error["password"] = "Required Field."
                })
            }
        }
    }
</script>