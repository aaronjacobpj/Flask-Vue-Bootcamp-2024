<script setup></script>

<template>
  <h1>{{ $store.state.message }}</h1>
  <button v-on:click="$store.dispatch('updateMessage', 'Bye!')">Click me!</button>
</template>

