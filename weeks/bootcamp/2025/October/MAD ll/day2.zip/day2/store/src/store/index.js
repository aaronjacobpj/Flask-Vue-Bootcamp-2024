import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            message: "Hello, world!",
        }
    },
    mutations: {
        setMessage(state, value){
            state.message = value
        }
    },
    actions: {
        updateMessage(context, value){
            setTimeout(()=>context.commit("setMessage", value), 2000)
        }
    }
})