from flask import Flask
from flask_security import Security, SQLAlchemyUserDatastore
from application.models import db, User, Role
from flask_cors import CORS


def create_app():

    from application.routes import api
    from werkzeug.security import generate_password_hash

    app = Flask(__name__)
    CORS(app)

    app.config['SECRET_KEY'] = "skjnvdkesnak"
    app.config['SECURITY_PASSWORD_SALT'] = "88974881683601"


    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///model.db'
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    db.init_app(app)
    datastore = SQLAlchemyUserDatastore(db, User, Role)
    app.security = Security(app, datastore)

    with app.app_context():
        db.create_all()
        if not app.security.datastore.find_role("admin"):
            role = app.security.datastore.create_role(name="admin")
            user = app.security.datastore.create_role(name="user")
            admin = app.security.datastore.create_user(name="Alice",
                                                       email="alice@example.com",
                                                       password=generate_password_hash("alice"))
            admin.roles.append(role)
            db.session.commit()


    app.register_blueprint(api)

    return app



app = create_app()
