import { createRouter, createWebHistory } from 'vue-router'
import store from '@/store'
import RegisterView from "@/views/RegisterView.vue"
import SigninView from "@/views/SigninView.vue"
import adminLayoutView from "@/views/admin/adminLayoutView.vue"
import adminDashboardView from "@/views/admin/adminDashboardView.vue"
import adminPostView from "@/views/admin/adminPostView.vue"

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/signup",
      name: "signup",
      component: RegisterView
    },
    {
      path: "/",
      name: "signin",
      component: SigninView
    },
    {
      path: "/admin",
      name: "admin-layout",
      component: adminLayoutView,
      beforeEnter(from, to, next){
        if (store.state.user["roles"].includes("admin"))
          next()
        else
          next({name: "signin"})
      },
      children: [
        {
          path: "",
          name: "admin-home",
          component: adminDashboardView
        },
        {
          path: "post/create",
          name: "admin-post-create",
          component: adminPostView
        }
      ]
    }
  ],
})

export default router
