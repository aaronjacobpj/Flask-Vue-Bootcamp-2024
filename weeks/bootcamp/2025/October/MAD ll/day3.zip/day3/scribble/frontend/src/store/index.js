import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            user: {
                token: null,
                roles: []
            },
            successAlerts: [],
            dangerAlerts: [],
        }
    },
    mutations: {
        addSuccessAlert(state, value){
            state.successAlerts.push(value)
        },
        deleteSuccessAlert(state, index){
            state.successAlerts = state.successAlerts.filter((v, i) => i != index)
        },
        setUser(state, value){
            state.user = value;
            localStorage.setItem("user", JSON.stringify(value))
        }
    }
})