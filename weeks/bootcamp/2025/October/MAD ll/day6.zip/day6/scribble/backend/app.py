from flask import Flask
from flask_security import Security, SQLAlchemyUserDatastore
from application.models import db, User, Role
from flask_cors import CORS
from celery import Celery, Task
from celery.schedules import crontab

from application.cache import cache
from application.worker import daily_reminder, monthly_reminder

def celery_init_app(app: Flask) -> Celery:
    class FlaskTask(Task):
        def __call__(self, *args: object, **kwargs: object) -> object:
            with app.app_context():
                return self.run(*args, **kwargs)

    celery_app = Celery(app.name, task_cls=FlaskTask)
    celery_app.config_from_object(app.config["CELERY"])
    celery_app.set_default()
    app.extensions["celery"] = celery_app
    return celery_app

def create_app():

    from application.routes import api
    from werkzeug.security import generate_password_hash

    app = Flask(__name__)
    CORS(app)

    app.config['SECRET_KEY'] = "skjnvdkesnak"
    app.config['SECURITY_PASSWORD_SALT'] = "88974881683601"
    app.config["CELERY"] = {
        "broker_url": "redis://localhost",
        "result_backend": "redis://localhost",
    }
    app.config["CACHE_TYPE"] = "RedisCache"  # Flask-Caching related configs
    app.config["CACHE_DEFAULT_TIMEOUT"] = 30
    app.config["CACHE_REDIS_URL"] = "redis://localhost:6379/0"

    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///model.db'
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    db.init_app(app)
    cache.init_app(app)

    datastore = SQLAlchemyUserDatastore(db, User, Role)
    app.security = Security(app, datastore)

    with app.app_context():
        db.create_all()
        if not app.security.datastore.find_role("admin"):
            role = app.security.datastore.create_role(name="admin")
            user = app.security.datastore.create_role(name="user")
            admin = app.security.datastore.create_user(name="Alice",
                                                       email="alice@example.com",
                                                       password=generate_password_hash("alice"))
            admin.roles.append(role)
            db.session.commit()


    app.register_blueprint(api)

    return app



app = create_app()
celery = celery_init_app(app)

@celery.on_after_configure.connect
def setup_periodic_tasks(sender: Celery, **kwargs):
    sender.add_periodic_task(crontab(minute="*"), daily_reminder.s())
    sender.add_periodic_task(crontab(minute="*"), monthly_reminder.s())