from flask import current_app as app
from flask import Blueprint, request, send_file
from werkzeug.security import generate_password_hash, check_password_hash
from flask_security import login_user, auth_required, roles_required, current_user
from celery.result import AsyncResult
from io import BytesIO

from application.cache import cache
from application.models import db, Post, Review
from application.worker import export

api = Blueprint("api", __name__)


@api.route("/signup", methods=["POST"])
def signup():
    name = request.json.get("name")
    email = request.json.get("email")
    password = request.json.get("password")

    if not name:
        return {"message": "Name required.", "code": "ERROR001"}, 400
    
    if not email:
        return {"message": "Email required.", "code": "ERROR002"}, 400
    
    if app.security.datastore.find_user(email=email):
        return {"message": "User exist.", "code": "ERROR003"}, 409
    
    if not password:
        return {"message": "Password required.", "code": "ERROR004"}, 400
    
    user = app.security.datastore.create_user(name=name, 
                                       email=email, 
                                       password=generate_password_hash(password))
    role = app.security.datastore.find_role("user")
    user.roles.append(role)
    db.session.commit()

    return {"message": "Created user successfully."}, 201


@api.route("/signin", methods=["POST"])
def signin():
    email = request.json.get("email")
    password = request.json.get("password")

    user =  app.security.datastore.find_user(email=email)

    if not user or not check_password_hash(user.password, password):
        return {"message": "User not found.", "code": "ERROR005"}, 404
    
    login_user(user)
    return {
        "token": user.get_auth_token(),
        "roles": [role.name for role in user.roles]
    }


@api.route("/post", methods=["POST"])
@roles_required("admin")
def create_post():
    content = request.json.get("content")

    if not content:
        return {"message": "Required Field.", "code": "ERROR006"}, 400
    
    post = Post(content=content)
    db.session.add(post)
    db.session.commit()

    return {"message": "Created post successfully."}, 201


@api.route("/posts")
@auth_required("token")
@cache.cached(10)
def get_posts():
    posts = Post.query.all()

    return [
        {
            "id": post.id,
            "content": post.content
        } for post in posts
    ]


@api.route("/post/<int:id>", methods=["DELETE"])
@roles_required("admin")
def delete_post(id):
    post = db.session.query(Post).get(id)
    
    if not post:
        return {"message": "Post not found.", "code": "ERROR007"}, 404
    
    db.session.delete(post)
    db.session.commit()

    return {"message": "Deleted post successfully."}, 200


@api.route("/post/<int:id>", methods=["PUT"])
@roles_required("admin")
def update_post(id):
    content = request.json.get("content")

    if not content:
        return {"message": "Required Field.", "code": "ERROR006"}, 400
    
    post = db.session.query(Post).get(id)
    
    if not post:
        return {"message": "Post not found.", "code": "ERROR007"}, 404
    
    post.content = content
    db.session.commit()

    return {"message": "Updated post successfully."}, 200


@api.route("/post/<int:id>/review")
@auth_required("token")
@cache.cached(10)
def get_review(id):
    review = Review.query.filter_by(post_id=id,
                                    user_id=current_user.id).first()
    
    if not review:
        review = Review(post_id=id,
                        user_id=current_user.id,
                        comment="")
        db.session.add(review)
        db.session.commit()

    return {"id": review.id,
            "comment": review.comment
            }


@api.route("/post/<int:id>/review", methods=["PUT"])
@auth_required("token")
def update_review(id):
    review = Review.query.filter_by(post_id=id,
                                user_id=current_user.id).first()
    
    if not review:
        return {"message": "Review not found."}, 404
    
    comment = request.json.get("comment")

    if not comment:
        return {"message": "Required field.", "error": "ERROR008"}, 400
    
    review.comment = comment
    db.session.commit()

    return {"message": "Request successful."}, 200


@api.route("/post/<int:id>/reviews")
@auth_required("token")
def get_reviews(id):
    reviews = Review.query.filter_by(post_id=id).all()

    return [{"comment": review.comment}
            for review in reviews]


@api.route("/statistics")
@roles_required("admin")
def statistics():
    posts = Post.query.all()
    ids = []
    reviews = []
    for post in posts:
        ids.append(post.id)
        reviews.append(sum([1 for review in post.reviews if review.comment]))

    return {
            "ids": ids,
            "reviews": reviews
        }


@api.route("/export")
@roles_required("admin")
def export_file():
    result = export.delay()
    return {"id": result.id}


@api.route("/export/<string:id>")
@roles_required("admin")
def export_status(id):
    result = AsyncResult(id)
    return {"status": result.status}


@api.route("/download/<string:id>")
def download(id):
    result = AsyncResult(id)
    file = BytesIO(bytes(result.result, "utf-8"))
    file.seek(0)
    return send_file(file, download_name="export.csv")