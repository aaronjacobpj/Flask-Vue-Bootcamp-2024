from celery import shared_task
import csv
from io import StringIO
from smtplib import SMTP
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from sqlalchemy.sql import func
from flask import render_template

from application.models import db, Post, Review, User

@shared_task
def export():

    posts = Post.query.all()
    file = StringIO()
    writer = csv.writer(file)
    writer.writerow(["id", "content", "No. reviews"])
    for post in posts:
        writer.writerow([post.id,
                         post.content,
                         sum([1 for review in post.reviews if review.comment])
                         ])
    
    file.seek(0)
    return file.read()


@shared_task
def daily_reminder():
    posts = db.session.query(Post).all()
    selected = None
    for post in posts:
        if not selected:
            selected = post

        if (len([1 for review in selected.reviews if review.comment]) 
            < sum([1 for review in post.reviews if review.comment])):
            selected = post
    
    server = SMTP("localhost", "1025")
    for user in User.query.all():
        if user.has_role("user"):
            mail = MIMEMultipart()

            mail["Subject"] = "Daily Reminder"
            mail["To"] = user.email
            mail["From"] = "admin@example.com"

            html = MIMEText(selected.content, "text/html")
            mail.attach(html)

            server.sendmail(msg=mail.as_string(), 
                                from_addr="admin@example.com",
                                to_addrs=user.email)



@shared_task
def monthly_reminder():
    posts = db.session.query(Post).all()
    selected = None
    for post in posts:
        if not selected:
            selected = post

        if (len([1 for review in selected.reviews if review.comment]) 
            < sum([1 for review in post.reviews if review.comment])):
            selected = post

    row = db.session.query(func.max(Post.id)).first()
    recent = db.session.query(Post).filter(Post.id==row[0]).first()
    
    server = SMTP("localhost", "1025")
    for user in User.query.all():
        if user.has_role("user"):
            mail = MIMEMultipart()

            mail["Subject"] = "Monthly Reminder"
            mail["To"] = user.email
            mail["From"] = "admin@example.com"

            html = MIMEText(render_template("monthly-report.html",
                                            user=user,
                                            post=selected,
                                            recent=recent), "text/html")
            mail.attach(html)

            server.sendmail(msg=mail.as_string(), 
                                from_addr="admin@example.com",
                                to_addrs=user.email)