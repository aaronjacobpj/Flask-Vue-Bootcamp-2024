<script setup>
  import { RouterView } from "vue-router"
</script>

<template>
  <div class="alert alert-success alert-dismissible fade show m-1" 
    role="alert" v-for="(alert, i) in $store.state.successAlerts">
    {{ alert }}
    <button type="button" class="btn-close" data-bs-dismiss="alert"
    v-on:click="$store.commit('deleteSuccessAlert', i)" aria-label="Close"></button>
  </div>
  <RouterView/>
</template>
<script>
  export default {
    created(){
      let x = localStorage.getItem("user")
      x = JSON.parse(x || '{"token": null, "roles": []}')
      this.$store.commit('setUser', x)
    }
  }
</script>
