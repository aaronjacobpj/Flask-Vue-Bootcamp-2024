import { createRouter, createWebHistory } from 'vue-router'
import store from '@/store'
import RegisterView from "@/views/RegisterView.vue"
import SigninView from "@/views/SigninView.vue"
import adminLayoutView from "@/views/admin/adminLayoutView.vue"
import adminDashboardView from "@/views/admin/adminDashboardView.vue"
import adminPostView from "@/views/admin/adminPostView.vue"
import adminPostSearchView from "@/views/admin/adminPostSearchView.vue"
import adminPostUpdateView from "@/views/admin/adminPostUpdateView.vue"
import userLayoutView from "@/views/user/userLayoutView.vue"
import userDashboardView from "@/views/user/userDashboardView.vue"
import userReviewView from "@/views/user/userReviewView.vue"


const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/signup",
      name: "signup",
      component: RegisterView
    },
    {
      path: "/",
      name: "signin",
      component: SigninView
    },
    {
      path: "/admin",
      name: "admin-layout",
      component: adminLayoutView,
      beforeEnter(from, to, next){
        if (store.state.user["roles"].includes("admin"))
          next()
        else
          next({name: "signin"})
      },
      children: [
        {
          path: "",
          name: "admin-home",
          component: adminDashboardView
        },
        {
          path: "post/create",
          name: "admin-post-create",
          component: adminPostView
        },
        {
          path: "post",
          name: "admin-post-view",
          component: adminPostSearchView
        },
        {
          path: "post/:id",
          name: "admin-post-edit",
          component: adminPostUpdateView,
          props: true
        }
      ]
    },
    {
      path: "/user",
      name: "user-layout",
      component: userLayoutView,
      children: [
        {
          path: "",
          name: "user-home",
          component: userDashboardView
        },
        {
          path: "post/:id",
          name: "user-post",
          component: userReviewView,
          props: true
        }
      ]
    }
  ],
})

export default router
