import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            user: {
                token: null,
                roles: []
            },
            successAlerts: [],
            dangerAlerts: [],
            posts: []
        }
    },
    getters:{
        getToken(state){
            return state.user["token"]
        },
        getPosts(state){
            return state.posts
        }
    },
    mutations: {
        addSuccessAlert(state, value){
            state.successAlerts.push(value)
        },
        deleteSuccessAlert(state, index){
            state.successAlerts = state.successAlerts.filter((v, i) => i != index)
        },
        setUser(state, value){
            state.user = value;
            localStorage.setItem("user", JSON.stringify(value))
        },
        setPosts(state, value){
            state.posts = value
        }
    },
    actions: {
        getPosts(context){
            fetch(import.meta.env.VITE_BASEURL+"posts",{
                headers: {
                    "Authentication-Token": context.getters.getToken
                }
            }).then(x =>{
                if(x.status == 200)
                    return x.json()
                return []
            }).then(x => context.commit("setPosts", x))
        }
    }
})