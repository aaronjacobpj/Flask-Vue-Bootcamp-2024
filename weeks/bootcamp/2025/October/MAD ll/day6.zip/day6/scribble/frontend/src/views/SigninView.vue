<script setup>
    import { RouterLink } from "vue-router"
</script>
<template>
    <div class="conatiner-fluid d-flex justify-content-center align-items-center" style="height: 95vh;">
        <div class="card p-2">
            <h1 align="center">Sign In</h1>
            <form @submit.prevent="signup">
                <div class="row">
                    <div class="mb-3">
                        <label for="exampleFormControlInput2" class="form-label">Email address</label>
                        <input type="email" class="form-control" id="exampleFormControlInput2"
                        v-model="form['email']" placeholder="name@example.com">
                        <div class="invalid-feedback" style="display: block;" v-show="error['email']">
                            {{ error['email'] }}
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="mb-3">
                        <label for="exampleFormControlInput3" class="form-label">Password</label>
                        <input type="password" class="form-control" id="exampleFormControlInput3"
                        v-model="form['password']" placeholder="Password">
                        <div class="invalid-feedback" style="display: block;" v-show="error['password']">
                            {{ error['password'] }}
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="mb-3">
                        <input type="submit" class="btn btn-primary" style="width: 100%;" value="Sign In"/>
                    </div>
                </div>
                <div class="row">
                    <div class="mb-3 text-center">
                        <RouterLink :to="{name:'signup'}" 
                            style="text-decoration: none;">
                            Create an account.
                        </RouterLink>
                    </div>
                </div>
            </form>
        </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                form: {
                    email: null,
                    password: null
                },
                error: {
                    email: null,
                    password: null
                }
            }
        },
        methods: {
            validate(){
                this.error = {
                    email: null,
                    password: null
                }
                let result = true
                if(!this.form['email']){
                    result = false;
                    this.error["email"] = "Required field."
                }
                if(!this.form['password'] || this.form['password'].length < 2){
                    result = false
                    this.error["password"] = "Required field."
                }
                return result
            },
            signup(){
                if(!this.validate())
                    return false

                fetch(import.meta.env.VITE_BASEURL+"signin", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(this.form)
                }).then(x =>{
                    if(x.status == 200){
                        this.$store.commit('addSuccessAlert', "Signed in user successfully.");
                        this.$router.push({name: "signin"})
                        return x.json()
                    }
                    else if(x.status == 404){
                        return {token: null, roles: []}
                    }
                }).then(x =>{
                    this.$store.commit("setUser", x)
                    if(x["roles"].includes("admin"))
                        this.$router.push({name: "admin-home"})
                    else if(x["roles"].includes("user"))
                        this.$router.push({name: "user-home"})
                })
            }
        }
    }
</script>