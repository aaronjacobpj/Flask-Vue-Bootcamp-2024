<template>
    <div class="container-fluid d-flex justify-content-center align-items-center" style="height: 95vh;">
        <div class="card col-6" style="border: 0px;">
            <div class="card col-12 my-3" style="border: 0px;" v-html="content">
            </div>
            <form @submit.prevent="create">
                <div class="card col-12" style="min-height: 200px;border: 0px;">
                    <div class="form-floating">
                        <textarea class="form-control" placeholder="Write content here."
                        id="floatingTextarea" style="min-height: 200px;" v-model="content">
                        </textarea>
                        <label for="floatingTextarea">Comments</label>
                    </div>
                    <div class="invalid-feedback" style="display: block;" v-show="feedback">
                        {{ feedback }}
                    </div>
                </div>
                <div class="card col-12 my-3">
                    <input type="submit" class="btn btn-primary" value="Submit">
                </div>
            </form>
        </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                content: "",
                feedback: null
            }
        },
        methods: {
            validate(){
                this.feedback = null
                if (!this.content){
                    this.feedback = "Required field."
                    return false
                }
                return true
            },
            create(){
                if(!this.validate())
                    return

                fetch(import.meta.env.VITE_BASEURL+"post", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify({content: this.content})
                }).then(x =>{
                    if (x.status == 201){
                        this.$store.commit('addSuccessAlert', "Created post succesfully.")
                        this.$router.push({name: "admin-post-view"})
                    }
                    else if (x.status == 400)
                        this.validate()
                })
            }
        }
    }
</script>