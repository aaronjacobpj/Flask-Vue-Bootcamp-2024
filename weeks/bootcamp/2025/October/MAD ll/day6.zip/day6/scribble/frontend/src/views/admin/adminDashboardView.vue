<template>
    <apexchart type="bar" height="350" :options="options" :series="series"></apexchart>
</template>
<script>
    export default {
        data(){
            return {
                stats: {
                    ids: [],
                    reviews: []
                }
            }
        },
        created(){
            fetch(import.meta.env.VITE_BASEURL+"/statistics", {
                headers: {
                    "Authentication-Token": this.$store.getters.getToken
                }
            }).then(x => {
                if (x.status == 200)
                    return x.json()
                return {
                    ids: [],
                    reviews: []
                }
            }).then(x =>{
                this.stats = x
            })
        },
        computed: {
            series(){
                return [{
                    data: this.stats["reviews"]
                }]
            },
            options(){
                return {
                    chart: {
                        type: 'bar'
                    },
                    plotOptions: {
                        bar: {
                        horizontal: true
                        }
                    },
                    xaxis: {
                        categories: this.stats["ids"].map(x => x.toString())
                    }
                }
            }
        }
    }
</script>