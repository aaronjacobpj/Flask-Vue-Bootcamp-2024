<script setup>
    import { RouterView, RouterLink } from "vue-router"
</script>
<template>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Admin</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <router-link class="nav-link" :to="{name: 'admin-post-create'}">Create</router-link>
                </li>
                <li class="nav-item">
                    <router-link class="nav-link" :to="{name: 'admin-post-view'}">Search</router-link>
                </li>
                <a @click="export_file">Export</a>
            </ul>
            </div>
        </div>
    </nav>
    <RouterView/>
</template>
<script>
    export default {
        data(){
            return {
                id: null
            }
        },
        methods: {
            export_file(){
                fetch(import.meta.env.VITE_BASEURL+"/export", {
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(x =>{
                    if(x.status == 200)
                        return x.json()
                    return {}
                }).then(x =>{
                    this.id = x["id"]
                    if(this.id)
                        this.download()
                })
            },
            download(){
                fetch(import.meta.env.VITE_BASEURL+"/export/"+this.id, {
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(x =>{
                    if(x.status == 200)
                        return x.json()
                    return {status: ""}
                }).then(x =>{
                    if(x["status"].match("SUCCESS")){
                        open(import.meta.env.VITE_BASEURL+"download/"+this.id)
                    }
                    else
                        setTimeout(this.download, 2000)
                })
            }
        }
    }
</script>