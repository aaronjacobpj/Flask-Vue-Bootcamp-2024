<template>
    <div class="row m-3">
        <div class="col-8">
            <input class="form-control" type="search" v-model="search">
        </div>
        <div class="col-4">
            <input type="button" @click="query" class="btn btn-primary" 
                value="Search" style="width: 100%;">
        </div>
    </div>
    <div class="row col-12 d-flex justify-content-center" v-for="post in posts">
        <div class="row col-11 m-3">
            <div class="col-10" v-html="post['content']">
            </div>
            <div class="col-2 d-flex align-items-bottom">
                <div class="row">
                    <div class="row p-1">
                        <button class="btn btn-warning" 
                        @click="$router.push({name: 'admin-post-edit', params: {id: post['id']}})">
                        Edit
                    </button>
                    </div>
                    <div class="row p-1">
                        <button class="btn btn-danger" @click="deletePost(post['id'])">Delete</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                search: "",
                posts: []
            }
        },
        created(){
            this.$store.dispatch("getPosts")
        },
        watch:{
            "$store.state.posts": function(value){
                this.posts = value
                this.query()
            }
        },
        methods: {
            query(){
                this.posts = this.$store.getters.getPosts.filter(x => x['content'].includes(this.search))
            },
            deletePost(id){
                fetch(import.meta.env.VITE_BASEURL+"post/"+id, {
                    method: "DELETE",
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(x =>{
                    if (x.status == 200){
                        this.$store.commit("addSuccessAlert", "Deleted post successfully.")
                        this.$store.dispatch("getPosts")
                    }
                })
            }
        }
    }
</script>