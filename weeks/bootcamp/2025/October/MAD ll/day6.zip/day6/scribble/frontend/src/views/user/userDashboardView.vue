<template>
    <div class="row m-3">
        <div class="col-8">
            <input class="form-control" type="search" v-model="search">
        </div>
        <div class="col-4">
            <input type="button" @click="query" class="btn btn-primary" 
                value="Search" style="width: 100%;">
        </div>
    </div>
    <div class="row col-12 d-flex justify-content-center" v-for="post in posts">
        <div class="row col-11 m-3">
            <div class="col-10" v-html="post['content'].slice(0, 150)+'...'">
            </div>
            <div class="row">
                <a style="color: #0d6efd;" 
                    @click="$router.push({name: 'user-post', params: {id: post['id']}})">
                    Read more.
                </a>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                search: "",
                posts: []
            }
        },
        created(){
            this.$store.dispatch("getPosts")
        },
        watch:{
            "$store.state.posts": function(value){
                this.posts = value
                this.query()
            }
        },
        methods: {
            query(){
                this.posts = this.$store.getters.getPosts.filter(x => x['content'].includes(this.search))
            }
        }
    }
</script>
<style scoped>
    a:hover{
        cursor:grab ;
    }
</style>