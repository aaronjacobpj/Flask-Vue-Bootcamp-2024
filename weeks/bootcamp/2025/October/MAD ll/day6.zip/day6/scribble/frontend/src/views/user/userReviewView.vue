<template>
    <div class="row">
        <div class="col-12 py-3 px-5" v-html="post">
        </div>
        <div class="row">
            <div class="col-12 p-4">
                <form @submit.prevent="saveReview">
                    <div class="row">
                        <div class="form-floating">
                            <textarea class="form-control" placeholder="Write content here."
                            id="floatingTextarea" style="min-height: 200px;" v-model="review['comment']">
                            </textarea>
                            <label for="floatingTextarea">Comments</label>
                        </div>
                    </div>
                    <div class="row p-2">
                        <input type="submit" value="Save" class="btn btn-primary"/>
                    </div>
                </form>
            </div>
        </div>
        <div class="row">
            <div class="col-12 p-4" v-for="review in reviews">
                {{ review['comment'] }}
                <hr/>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        props: ['id'],
        data(){
            return {
                post: null,
                review: {},
                reviews: []
            }
        },
        created(){
            this.$store.dispatch("getPosts")
            this.getReview();
            this.getReviews()
        },
        watch:{
            "$store.state.posts": function(value){
                this.post = value.find(x => x['id'] == this.id)["content"]
            }
        },
        methods: {
            getReview(){
                fetch(import.meta.env.VITE_BASEURL+`/post/${this.id}/review`,
                    {
                        method: "GET",
                        headers: {
                            "Authentication-Token": this.$store.getters.getToken,
                        }
                    }
                ).then(x =>{
                    if(x.status == 200){
                        return x.json()
                    }
                }).then(x =>{
                    this.review = x;
                })
            },
            saveReview(){
                fetch(import.meta.env.VITE_BASEURL+`/post/${this.id}/review`,
                    {
                        method: "PUT",
                        headers: {
                            "Authentication-Token": this.$store.getters.getToken,
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(this.review)
                    }
                )
            },
             getReviews(){
                fetch(import.meta.env.VITE_BASEURL+`/post/${this.id}/reviews`,
                    {
                        method: "GET",
                        headers: {
                            "Authentication-Token": this.$store.getters.getToken,
                        }
                    }
                ).then(x =>{
                    if(x.status == 200){
                        return x.json()
                    }
                }).then(x =>{
                    this.reviews = x;
                })
            }
        }
    }
</script>