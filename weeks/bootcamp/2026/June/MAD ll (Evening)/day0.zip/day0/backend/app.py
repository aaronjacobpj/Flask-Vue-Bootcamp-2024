from flask import Flask
import os
from flask_security import Security, SQLAlchemyUserDatastore
from werkzeug.security import generate_password_hash, check_password_hash

from dep.models import db, User, Role
from config import Config


def create_app():
    # Create app
    app = Flask(__name__)

    app.config.from_object(Config)

    db.init_app(app)

    datastore = SQLAlchemyUserDatastore(db, User, Role)
    app.security = Security(app, datastore)


    with app.app_context():
        db.create_all()
        if not app.security.datastore.find_role("admin"):
            admin = app.security.datastore.create_role(name="admin")
            manager = app.security.datastore.create_role(name="manager")
            user = app.security.datastore.create_role(name="user")
            db.session.flush()

            charlie = app.security.datastore.create_user(name="Charlie",
                                                         email="charlie@example.com",
                                                         password=generate_password_hash("charlie"))
            alice = app.security.datastore.create_user(name="Alice",
                                                       email="alice@example.com",
                                                       password=generate_password_hash("alice"))
            charlie.roles.append(admin)
            alice.roles.append(manager)
            db.session.commit()

    return app


if __name__ == "__main__":
    app = create_app()
    app.run()