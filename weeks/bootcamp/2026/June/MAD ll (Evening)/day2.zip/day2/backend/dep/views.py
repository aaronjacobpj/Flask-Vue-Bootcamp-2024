from flask import current_app as app
from flask import Blueprint, request
from werkzeug.security import check_password_hash, generate_password_hash
from flask_security import login_user, current_user, roles_required, roles_accepted
import re

from dep.models import db

api = Blueprint("api", __name__)


@api.route("/signin", methods=["POST"])
def user_login():
    email = request.json.get("email", "")
    password = request.json.get("password", "")

    admin = app.security.datastore.find_user(email=email)

    if (admin is None or
        not check_password_hash(admin.password, password)):
        return {"message": "Invalid email or password", "code": "ERROR0001"}, 404
    
    login_user(admin)

    return {"token": admin.get_auth_token(), "roles": admin.get_roles()}


@api.route("/user/signup", methods=["POST"])
def user_signup():
    name = request.json.get("name", "")
    email = request.json.get("email", "")
    password = request.json.get("password", "")

    if not email or not re.match("\w+@\w+[.][a-z]+", email):
        return {"message": "Invalid email", "code": "ERROR0005"}, 400

    user = app.security.datastore.find_user(email=email)

    if user:
        return {"message": "email already exist", "code": "ERROR0002"}, 409
    
    if not name:
        return {"message": "name is required", "code": "ERROR0003"}, 400
    
    if not password:
        return {"message": "password can't be empty", "code": "ERROR0006"}, 400
    
    if len(password) < 3:
        return {"message": "password length should be atleast 3.", "code": "ERROR0004"}, 400
    
    user = app.security.datastore.create_user(name=name,
                                              email=email,
                                              password=generate_password_hash(password))
    role = app.security.datastore.find_role("user")
    user.roles.append(role)
    db.session.commit()

    return {"message": "created user successfully."}, 201


@api.route("/manager/signup", methods=["POST"])
@roles_required("admin")
def manager_signup():
    name = request.json.get("name", "")
    email = request.json.get("email", "")
    password = request.json.get("password", "")

    if not email or not re.match("\w+@\w+[.][a-z]+", email):
        return {"message": "Invalid email", "code": "ERROR0005"}, 400

    user = app.security.datastore.find_user(email=email)

    if user:
        return {"message": "email already exist", "code": "ERROR0002"}, 409
    
    if not name:
        return {"message": "name is required", "code": "ERROR0003"}, 400
    
    if not password:
        return {"message": "password can't be empty", "code": "ERROR0006"}, 400
    
    if len(password) < 3:
        return {"message": "password length should be atleast 3.", "code": "ERROR0004"}, 400
    
    user = app.security.datastore.create_user(name=name,
                                              email=email,
                                              password=generate_password_hash(password))
    role = app.security.datastore.find_role("manager")
    user.roles.append(role)
    db.session.commit()

    return {"message": "created user successfully."}, 201

