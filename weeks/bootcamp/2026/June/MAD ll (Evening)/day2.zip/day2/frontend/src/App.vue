<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <div class="conainer-fluid">
      <div class="alert alert-success alert-dismissible fade show " role="alert" 
        v-for="(alert, idx) in $store.getters.getAlerts" style="margin: 1px;">
        {{ alert }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close" @click="deleteAlert(idx)"></button>
      </div>
  </div>
  <RouterView />
</template>
<script>
  export default {
    created(){
      const empty = this.$store.getters.getUser;
      let item = localStorage.getItem("user");
      item = (item)? item : JSON.stringify(empty);
      this.$store.commit("setUser", JSON.parse(item))
    },
    methods:{
      deleteAlert(id){
        this.$store.commit("removeAlert", id)
      }
    }
  }
</script>