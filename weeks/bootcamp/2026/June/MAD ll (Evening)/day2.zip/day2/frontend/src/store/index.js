import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            user: {
                token: null,
                roles: []
            },
            alerts: []
        }
    },
    mutations: {
        setUser(state, value){
            localStorage.setItem("user", JSON.stringify(value))
            state.user = value;   
        },
        addAlert(state, value){
            state.alerts.push(value)
        },
        removeAlert(state, idx){
            state.alerts = state.alerts.filter((v, i) => i != idx)
        }
    },
    getters: {
        getUser(state){
            return state.user
        },
        getRoles(state){
            return state.user["roles"]
        },
        getToken(state){
            return state.user["token"]
        },
        getAlerts(state){
            return state.alerts
        }
    }
})