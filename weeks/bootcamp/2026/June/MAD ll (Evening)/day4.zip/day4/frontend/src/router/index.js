import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import AdminLayoutView from "@/views/admin/AdminLayoutView.vue"
import AdminLoginView from "@/views/admin/AdminLoginView.vue"
import AdminDashboardView from "@/views/admin/AdminDashboardView.vue"
import AdminCreateManagerView from "@/views/admin/AdminCreateManagerView.vue"
import AdminCategoryView from "@/views/admin/AdminCategoryView.vue"
import UserLayoutView from "@/views/user/UserLayoutView.vue"
import UserLoginView from "@/views/user/UserLoginView.vue"
import UserSignupView from "@/views/user/UserSignupView.vue"
import ManagerLayoutView from "@/views/manager/ManagerLayoutView.vue"
import ManagerLoginView from "@/views/manager/ManagerLoginView.vue"
import ManagerDashboardView from "@/views/manager/ManagerDashboardView.vue"
import ManagerCategoryView from "@/views/manager/ManagerCategoryView.vue"

import store from '@/store'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView,
    },
    {
      path: "/admin",
      name: "admin",
      component: AdminLayoutView,
      beforeEnter(to, from){
        if(!to.name.match("admin-login") && !store.getters.getRoles.includes("admin")){
          return {name: "admin-login"}
        }
      },
      children: [
        {
          path: "",
          name: "admin-login",
          component: AdminLoginView,
        },
        {
          path: "home",
          name: "admin-home",
          component: AdminDashboardView
        },
        {
          path: "create/manager",
          name: "admin-create-manager",
          component: AdminCreateManagerView
        },
        {
          path: "category",
          name: "admin-category",
          component: AdminCategoryView
        }
      ]
    },
    {
      path: "/user",
      name: "user",
      component: UserLayoutView,
      beforeEnter(to, from){
        if(!to.name.match("user-login") 
          && !to.name.match("user-signup") 
          && !store.getters.getRoles.includes("user")){
          return {name: "user-login"}
        }
      },
      children: [
        {
          path: "",
          name: "user-login",
          component: UserLoginView
        },
        {
          path: "signup",
          name: "user-signup",
          component: UserSignupView
        },
      ]
    },
    {
      path: "/manager",
      name: "manager",
      component: ManagerLayoutView,
      beforeEnter(to, from){
        if(!to.name.match("manager-signin") && !store.getters.getRoles.includes("manager")){
          return {name: "manager-signin"}
        }
      },
      children: [
        {
          path: "",
          name: "manager-signin",
          component: ManagerLoginView
        },
        {
          path: "home",
          name: "manager-home",
          component: ManagerDashboardView
        },
        {
          path: "category",
          name: "manager-category",
          component: ManagerCategoryView
        }
      ]
    }
    
  ],
})

export default router
