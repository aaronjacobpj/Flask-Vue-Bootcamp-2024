<template>
    <form @submit.prevent="addCategories">
        <table class="table table-striped">
            <tbody>
                <tr>
                    <td>
                        <div class="mb-3">
                            <label for="email-input" class="form-label">Category</label>
                            <input type="text" class="form-control" id="email-input" v-model="form.name"
                                placeholder="Cosmetics">
                            <div class="invalid-feedback" style="display: block;">{{ error["name"] }}</div>
                        </div>
                    </td>
                    <td>
                        <div class="mb-3">
                            <label for="password-input" class="form-label" style="visibility: hidden;">Submit</label>
                            <input type="submit" class="form-control btn btn-primary" value="Create Category">
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </form>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Approval</th>
            </tr>
        </thead>
        <tbody>
            <tr v-for="category in $store.getters.getAllCategories.filter(x => !(x['category_id'] && x['id']))">
                <th scope="row">{{ category["id"] }}</th>
                <td :class="{'category-delete': category['delete']}">
                    <span :class="{'category-delete': isCategoryUpdated(category['category_id'])}">
                        {{ category["name"] }}
                    </span>
                    <span>
                        {{ (isCategoryUpdated(category['category_id']))? categories[category["category_id"]]["name"] : ""}}
                    </span>
                </td>
                <td>{{ (!category["temp"])? "" : "Waiting" }}</td>
                <td>
                    <button class="btn btn-warning" @click="editForm=category"
                     data-bs-toggle="modal" data-bs-target="#exampleModal" 
                     :disabled="category['delete']">edit</button>
                </td>
                <td>
                    <button class="btn btn-danger" @click="chooseDeleteOption(category)" 
                    :disabled="category['delete']">Delete</button>
                </td>
            </tr>
        </tbody>
    </table>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="email-input" class="form-label">Category</label>
                        <input type="text" class="form-control" id="email-input" v-model="editForm.name"
                            placeholder="Cosmetics">
                        <div class="invalid-feedback" style="display: block;">{{ editFormError["name"] }}</div>
                        <div class="valid-feedback" style="display: block;">{{ editFormError["success"] }}</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" @click="updateCategory">Save changes</button>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                form: {
                    name: ""
                },
                error: {
                    name: ""
                },
                editForm:{
                    id: null,
                    name: ""
                },
                editFormError:{
                    name: "",
                    success: "" 
                },
            }
        },
        created() {
            this.$store.dispatch("getAllCategories")
        },
        methods: {
            addCategories() {
                if (!this.validate())
                    return

                fetch(import.meta.env.VITE_SERVER + "/manager/category", {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify(this.form)
                }).then(r => {
                    if (r.status == 409) {
                        r.json().then(x => this.error["name"] = x.message)
                    }
                    if (r.status == 400) {
                        r.json().then(x => {
                            this.error["name"] = x.message
                        })
                    }
                    if (r.status == 201) {
                        this.$store.commit("addAlert", "Created category Successfully.")
                        this.$store.dispatch("getManagerCategories")
                    }
                })
            },
            validate() {
                this.error = {
                    name: "",
                    success: ""
                }
                let form = this.form
                if (!form["name"]) {
                    this.error["name"] = "name is required."
                    return false
                }

                return true
            },
            chooseDeleteOption(category) {
                if(category["temp"]){
                    this.deleteManagerCategory(category["id"])
                }
                else if(!category["temp"] ){
                    this.deleteCategory(category["id"])
                }
            },
            deleteManagerCategory(id){
                fetch(import.meta.env.VITE_SERVER + "manager/category", {
                    method: "DELETE",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify({ id })
                }).then(r => {
                    if (r.status == 200) {
                        this.$store.commit("addAlert", "Deleted category Successfully.")
                        this.$store.dispatch("getManagerCategories")
                    }
                })
            },
            deleteCategory(id){
                fetch(import.meta.env.VITE_SERVER + "manager/category/final", {
                    method: "DELETE",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify({ id })
                }).then(r => {
                    if (r.status == 200) {
                        this.$store.commit("addAlert", "Deleted category Successfully.")
                        this.$store.dispatch("getCategories")
                    }
                })
            },
            validateEditForm() {
                this.editFormError = {
                    name: ""
                }
                let form = this.editForm
                if (!form["name"]) {
                    this.editFormError["name"] = "name is required."
                    return false
                }

                return true
            },
            updateCategory(){
                if(!this.validateEditForm())
                    return

                fetch(import.meta.env.VITE_SERVER + "/manager/category", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify(this.editForm)
                }).then(r => {
                    if ([400, 404, 409].includes(r.status)) {
                        r.json().then(x => this.editFormError["name"] = x.message)
                    }
                    if (r.status == 200) {
                        this.$store.commit("addAlert", "Updated category Successfully.")
                        this.$store.dispatch("getCategories")
                        r.json().then(x => this.editFormError["success"] = x.message)
                    }
                })
            },
            isCategoryUpdated(id){
                return id in this.categories
            }
        },
        computed:{
            categories(){
                let result = {}
                this.$store.getters.getManagerCategories.forEach(x =>{
                    if(x["category_id"])
                        result[x["category_id"]] = x
                })
                return result
            }  
        }
    }
</script>
<style scoped>
    .category-delete{
        text-decoration: line-through;
    }
</style>