<template>
    <table class="table">
        <tbody>
            <tr>
                <td>
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Name</label>
                        <input type="text" class="form-control" id="formGroupExampleInput" v-model="form.name"
                            placeholder="Dettol">
                    </div>
                </td>
                <td>
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Metric</label>
                        <select name="metric_unit" id="metric_unit" class="form-select" v-model="form.metric">
                            <option value="null">Select a unit</option>
                            <option value="1">kg</option>
                            <option value="2">g</option>
                            <option value="3">mg</option>
                            <option value="4">km</option>
                            <option value="5">m</option>
                            <option value="6">cm</option>
                            <option value="7">mm</option>
                            <option value="8">L</option>
                            <option value="9">mL</option>
                        </select>
                    </div>
                </td>
                <td>
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Stock</label>
                        <input type="number" class="form-control" id="formGroupExampleInput"
                            placeholder="Example input placeholder" v-model="form.stock">
                    </div>
                </td>
                <td>
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Rate</label>
                        <input type="number" class="form-control" id="formGroupExampleInput"
                            placeholder="Example input placeholder" v-model="form.rate">
                    </div>
                </td>
                <td>
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Submit</label>
                        <input type="button" class="form-control btn btn-primary" value="Submit" @click="addProduct">
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>
                    #
                </th>
                <th>
                    Name
                </th>
                <th>
                    Metric
                </th>
                <th>
                    Stock
                </th>
                <th>
                    Rate
                </th>
            </tr>
        </thead>
    </table>
</template>
<script>
    export default {
        props: ["id"],
        data() {
            return {
                form: {
                    name: null,
                    metric: null,
                    stock: null,
                    rate: null
                },
                error: {
                    name: null,
                    metric: null,
                    stock: null,
                    rate: null
                }
            }
        },
        methods: {
            addProduct() {
                this.error = {
                    name: null,
                    metric: null,
                    stock: null,
                    rate: null
                }
                fetch(import.meta.env.VITE_SERVER + `category/${this.id}/product`, {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify(this.form)
                }).then(r => {
                    if (r.status == 409) {
                        r.json().then(x => this.error["name"] = x.message)
                    }
                    else if (r.status == 400) {
                        r.json(x => {
                            if (x.code == "ERROR0003") {
                                this.error["name"] = x.message
                            }
                            else if (x.code == "ERROR0009") {
                                this.error["metric"] = x.message
                            }
                            else if (x.code == "ERROR0010") {
                                this.error["stock"] = x.message
                            }
                            else if (x.code == "ERROR0011") {
                                this.error["rate"] = x.message
                            }
                        })
                    }
                    else if (r.status == 201) {
                        this.$store.commit("addAlert", "Created product successfully")
                    }
                })
            }
        }
    }
</script>