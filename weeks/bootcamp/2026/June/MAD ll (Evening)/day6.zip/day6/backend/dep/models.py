from flask_sqlalchemy import SQLAlchemy
from flask_security.models import fsqla_v3 as fsqla


# Create database connection object
db = SQLAlchemy()

fsqla.FsModels.set_db_info(db)

class Role(db.Model, fsqla.FsRoleMixin):
    pass


class User(db.Model, fsqla.FsUserMixin):
    name = db.Column(db.String(), nullable=False)

    def get_roles(self):
        return [role.name for role in self.roles]


class Category(db.Model):
    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), unique=True, nullable=False)
    delete = db.Column(db.Boolean())


class ManagerCategory(db.Model):
    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), unique=True, nullable=False)
    category_id = db.Column(db.Integer(), db.ForeignKey("category.id"))


class Product(db.Model):
    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(), unique=True, nullable=False)
    metric = db.Column(db.Integer(), nullable=False)
    stock = db.Column(db.Integer(), nullable=False)
    rate = db.Column(db.Float(), nullable=False)
    category_id = db.Column(db.Integer(), db.ForeignKey("category.id"), nullable=False)


class Cart(db.Model):
    id = db.Column(db.Integer(), primary_key=True)
    product_id = db.Column(db.Integer(), db.ForeignKey("product.id"), nullable=False)
    user_id = db.Column(db.Integer(), db.ForeignKey("user.id"), nullable=False)
    units = db.Column(db.Integer(), nullable=False)

