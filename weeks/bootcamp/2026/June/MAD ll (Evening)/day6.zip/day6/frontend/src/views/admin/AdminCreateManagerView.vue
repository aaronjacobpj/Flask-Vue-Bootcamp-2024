<template>
    <form @submit.prevent="login">
        <table class="table table-striped">
            <tbody>
                <tr>
                    <td>
                        <div class="mb-3">
                            <label for="email-input" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="email-input" 
                                v-model="form.name" placeholder="Harry Potter">
                            <div class="invalid-feedback" style="display: block;">{{ error["name"] }}</div>
                        </div>
                    </td>
                    <td>
                        <div class="mb-3">
                            <label for="email-input" class="form-label">Email</label>
                            <input type="text" class="form-control" id="email-input" 
                                v-model="form.email" placeholder="abc@example.com">
                            <div class="invalid-feedback" style="display: block;">{{ error["email"] }}</div>
                        </div>
                    </td>
                    <td>
                        <div class="mb-3">
                            <label for="password-input" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password-input" 
                                v-model="form.password" placeholder="password">
                            <div class="invalid-feedback" style="display: block;">{{ error["password"] }}</div>
                        </div>
                    </td>
                    <td>
                        <div class="mb-3">
                            <label for="password-input" class="form-label" style="visibility: hidden;">Submit</label>
                            <input type="submit" class="form-control btn btn-primary" value="Create Manager">
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </form>
</template>
<script>
    export default {
        data(){
            return {
                form: {
                    email: "",
                    password: "",
                    name: ""
                },
                error: {
                    email: "",
                    password: "",
                    name: ""
                }
            }
        },
        methods: {
            login(){
                if(!this.validate())
                    return

                fetch(import.meta.env.VITE_SERVER+"manager/signup", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify(this.form)
                }).then(r =>{
                    if(r.status == 409){
                        r.json().then(x => this.error["email"] = x.message)
                    }
                    if(r.status == 400){
                        r.json().then(x =>{
                            let code = x["code"]
                            if(code == "ERROR0002"){
                                this.error["email"] = x.message
                            }
                            else if(code == "ERROR0003"){
                                this.error["name"] = x.message
                            }
                            else if(code == "ERROR0004"){
                                this.error["password"] = x.message
                            }
                            else if(code == "ERROR0005"){
                                this.error["email"] = x.message
                            }
                            else if(code == "ERROR0006"){
                                this.error["password"] = x.message
                            }
                        })
                    }
                    if(r.status == 201){
                        this.$store.commit("addAlert", "Created manager Successfully.")
                    }
                })
            },
            validate(){
                this.error = {
                    email: "",
                    password: "",
                    name: ""
                }
                let form = this.form
                if (!form["name"]) {
                    this.error["name"] = "name is required."
                    return false
                }
                else if (!form["email"]) {
                    this.error["email"] = "email is required."
                    return false
                }
                else if (!form["password"]) {
                    this.error["password"] = "password is required."
                    return false
                }
                else if (form["password"].length < 3) {
                    this.error["password"] = "password length should be atleast 3."
                    return false
                }
                return true
            }
        }
    }
</script>