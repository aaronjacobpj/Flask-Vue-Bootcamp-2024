<script setup>
</script>
<template>
    <div class="container-fluid d-flex justify-content-center align-items-center" style="height: 100vh;">
        <div class="card">
            <div class="card-body">
                <h3 class="card-title" align="center">Manager Login</h3>
                <form @submit.prevent="login">
                    <div class="mb-3">
                        <label for="email-input" class="form-label">Email</label>
                        <input type="text" class="form-control" id="email-input" 
                            v-model="email" placeholder="abc@example.com">
                        <div class="invalid-feedback" style="display: block;">{{ message }}</div>
                    </div>
                    <div class="mb-3">
                        <label for="password-input" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password-input" 
                            v-model="password" placeholder="password">
                    </div>
                    <div class="mb-3 d-flex justify-content-center">
                        <input type="submit" class="btn btn-primary" value="Login">
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data(){
            return {
                email: "",
                password: "",
                message: ""
            }
        },
        methods: {
            login(){
                fetch(import.meta.env.VITE_SERVER+"signin", {
                    method: "POST",
                    headers: {"Content-Type": "application/json"},
                    body: JSON.stringify({email: this.email, password:this.password})
                }).then(r =>{
                    if(r.status == 404){
                        r.json().then(x => this.message = x.message)
                    }
                    if(r.status == 200){
                        r.json().then(x => this.$store.commit("setUser", x))
                        this.$router.push("/manager/home")
                    }
                })
            }
        }
    }
</script>