<template>
    <table class="table">
        <tbody>
            <tr>
                <td>
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Name</label>
                        <input type="text" class="form-control" id="formGroupExampleInput" v-model="form.name"
                            placeholder="Dettol">
                        <div class="invalid-feedback" style="display: block;">
                            {{ error["name"] }}
                        </div>
                    </div>
                </td>
                <td>
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Metric</label>
                        <select name="metric_unit" id="metric_unit" class="form-select" v-model="form.metric">
                            <option value="null">Select a unit</option>
                            <option :value="i+1" v-for="(unit, i) in $store.getters.getUnits">{{ unit }}</option>
                        </select>
                        <div class="invalid-feedback" style="display: block;">
                            {{ error["metric"] }}
                        </div>
                    </div>
                </td>
                <td>
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Stock</label>
                        <input type="number" class="form-control" id="formGroupExampleInput"
                            placeholder="Example input placeholder" v-model="form.stock">
                    </div>
                    <div class="invalid-feedback" style="display: block;">
                        {{ error["stock"] }}
                    </div>
                </td>
                <td>
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Rate</label>
                        <input type="number" class="form-control" id="formGroupExampleInput"
                            placeholder="Example input placeholder" v-model="form.rate">
                    </div>
                    <div class="invalid-feedback" style="display: block;">
                        {{ error["rate"] }}
                    </div>
                </td>
                <td>
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Submit</label>
                        <input type="button" class="form-control btn btn-primary" value="Submit" @click="addProduct">
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>
                    #
                </th>
                <th>
                    Name
                </th>
                <th>
                    Metric
                </th>
                <th>
                    Stock
                </th>
                <th>
                    Rate
                </th>
            </tr>
        </thead>
        <tbody>
            <tr v-for="product in $store.getters.getCategoryProduct">
                <td>
                    {{ product["id"] }}
                </td>
                <td>
                    {{ product["name"] }}
                </td>
                <td>
                    {{ $store.getters.getUnits[product["metric"]-1] }}
                </td>
                <td>
                    {{ product["stock"] }}
                </td>
                <td>
                    {{ product["rate"] }}
                </td>
                <td>
                    <button class="btn btn-warning" @click="editForm=product" data-bs-toggle="modal"
                        data-bs-target="#exampleModal">
                        Edit
                    </button>
                </td>
                <td>
                    <button class="btn btn-danger" @click=deleteProduct(product.id)>
                        Delete
                    </button>
                </td>
            </tr>
        </tbody>
    </table>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Update Product</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Name</label>
                        <input type="text" class="form-control" id="formGroupExampleInput" v-model="editForm.name"
                            placeholder="Dettol">
                        <div class="invalid-feedback" style="display: block;">
                            {{ editFormError["name"] }}
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Category</label>
                        <select name="metric_unit" id="metric_unit" class="form-select" v-model="editForm.category_id">
                            <option value="null">Select a unit</option>
                            <option :value="category.id" v-for="category in $store.getters.getCategories">
                                {{ category['name'] }}
                            </option>
                        </select>
                        <div class="invalid-feedback" style="display: block;">
                            {{ editFormError["category_id"] }}
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">metric</label>
                        <select name="metric_unit" id="metric_unit" class="form-select" v-model="editForm.metric">
                            <option value="null">Select a unit</option>
                            <option :value="i+1" v-for="(unit, i) in $store.getters.getUnits">{{ unit }}</option>
                        </select>
                        <div class="invalid-feedback" style="display: block;">
                            {{ editFormError["metric"] }}
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Stock</label>
                        <input type="text" class="form-control" id="formGroupExampleInput" v-model="editForm.stock"
                            placeholder="Dettol">
                        <div class="invalid-feedback" style="display: block;">
                            {{ editFormError["stock"] }}
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Rate</label>
                        <input type="text" class="form-control" id="formGroupExampleInput" v-model="editForm.rate"
                            placeholder="Dettol">
                        <div class="invalid-feedback" style="display: block;">
                            {{ editFormError["rate"] }}
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" @click="updateProduct()">Save changes</button>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        props: ["id"],
        created() {
            this.$store.dispatch("getCategoryProducts", this.id)
            this.$store.dispatch("getCategories")
        },
        data() {
            return {
                form: {
                    name: null,
                    metric: null,
                    stock: null,
                    rate: null
                },
                error: {
                    name: null,
                    metric: null,
                    stock: null,
                    rate: null
                },
                editForm: {
                    id: null,
                    name: null,
                    metric: null,
                    stock: null,
                    rate: null,
                    category_id: null
                },
                editFormError: {
                    name: null,
                    metric: null,
                    stock: null,
                    rate: null,
                    category_id: null
                },
            }
        },
        methods: {
            addProduct() {
                this.error = {
                    name: null,
                    metric: null,
                    stock: null,
                    rate: null
                }
                fetch(import.meta.env.VITE_SERVER + `category/${this.id}/product`, {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify(this.form)
                }).then(r => {
                    if (r.status == 409) {
                        r.json().then(x => this.error["name"] = x.message)
                    }
                    else if (r.status == 400) {
                        r.json(x => {
                            if (x.code == "ERROR0003") {
                                this.error["name"] = x.message
                            }
                            else if (x.code == "ERROR0009") {
                                this.error["metric"] = x.message
                            }
                            else if (x.code == "ERROR0010") {
                                this.error["stock"] = x.message
                            }
                            else if (x.code == "ERROR0011") {
                                this.error["rate"] = x.message
                            }
                        })
                    }
                    else if (r.status == 201) {
                        this.$store.commit("addAlert", "Created product successfully")
                        this.$store.dispatch("getCategoryProducts", this.id)
                    }
                })
            },
            deleteProduct(id) {
                fetch(import.meta.env.VITE_SERVER + `product/${id}`, {
                    method: "DELETE",
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    },
                }).then(r => {
                    if (r.status == 200) {
                        this.$store.commit("addAlert", "Deleted product successfully")
                        this.$store.dispatch("getCategoryProducts", this.id)
                    }
                })
            },
            updateProduct() {
                this.editFormError = {
                    category_id: null,
                    name: null,
                    metric: null,
                    stock: null,
                    rate: null
                }
                fetch(import.meta.env.VITE_SERVER + `category/${this.editForm["category_id"]}/product`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify(this.editForm)
                }).then(r => {
                    if (r.status == 409) {
                        r.json().then(x => this.error["name"] = x.message)
                    }
                    else if (r.status == 400) {
                        r.json(x => {
                            if (x.code == "ERROR0003") {
                                this.error["name"] = x.message
                            }
                            else if (x.code == "ERROR0009") {
                                this.error["metric"] = x.message
                            }
                            else if (x.code == "ERROR0010") {
                                this.error["stock"] = x.message
                            }
                            else if (x.code == "ERROR0011") {
                                this.error["rate"] = x.message
                            }
                            else if (x.code == "ERROR0008") {
                                this.error["category_id"] = x.message
                            }
                        })
                    }
                    else if (r.status == 201) {
                        this.$store.commit("addAlert", "Updated product successfully")
                        this.$store.dispatch("getCategoryProducts", this.id)
                    }
                })
            },
        }
    }
</script>