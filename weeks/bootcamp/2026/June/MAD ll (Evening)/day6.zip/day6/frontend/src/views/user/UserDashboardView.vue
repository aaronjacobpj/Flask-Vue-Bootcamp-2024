<template>
    <div class="row d-flex">
        <div class="col-6">
            <div class="mb-3 mx-2">
                <label for="formGroupExampleInput" class="form-label">Search</label>
                <select class="form-select" v-model="form.q" v-if="form.type.match('category')">
                    <option value="">Select a Category</option>
                    <option :value="category.id" v-for="category in $store.getters.getCategories">{{ category["name"] }}</option>
                </select>
                <input v-else :type="types[form.type]" class="form-control" id="formGroupExampleInput" placeholder="Query" v-model="form.q">
            </div>
        </div>
        <div class="col-3">
            <div class="mb-3">
                <label for="formGroupExampleInput" class="form-label">Search</label>
                <select class="form-select" v-model="form.type">
                    <option value="product">Product</option>
                    <option value="category">Category</option>
                    <option value="ratelq">Rate less than</option>
                    <option value="rategq">Rate greater than</option>
                </select>
            </div>
        </div>
        <div class="col-3">
            <div class="mb-3 mx-2">
                <label for="formGroupExampleInput" class="form-label" style="visibility: hidden;">Submit</label>
                <button class="form-control btn btn-primary" @click="getProducts">Search</button>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        created(){
            this.$store.dispatch("getCategories")
        },
        data() {
            return {
                form: {
                    q: "",
                    type: "product",
                },
                types: {
                    product: "text",
                    category: "text",
                    ratelq: "number",
                    rategq: "number"
                }
            }
        },
        methods: {
            getProducts() {
                let search = new URLSearchParams();
                
                for (let type in this.types)
                    if (type.match(this.form.type))
                        search.append(type, this.form.q)
            
                let url = new URL(import.meta.env.VITE_SERVER+"search?"+search.toString())
                
                    fetch(url, {
                        method: "GET",
                        headers: {
                            "Authentication-Token": this.$store.getters.getToken
                        },
                    }).then(r => {
                        if (r.status == 200) {
                            r.json().then(x => context.commit("setManagerCategories", x))
                        }
                    })
            }
        }
    }
</script>