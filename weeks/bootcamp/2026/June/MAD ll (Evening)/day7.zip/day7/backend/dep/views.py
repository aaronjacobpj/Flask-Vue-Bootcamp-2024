from flask import current_app as app
from flask import Blueprint, request
from werkzeug.security import check_password_hash, generate_password_hash
from flask_security import login_user, current_user, roles_required, roles_accepted, auth_required
from sqlalchemy import and_
import re

from dep.models import db, Category, ManagerCategory, Cart, Product

api = Blueprint("api", __name__)


@api.route("/signin", methods=["POST"])
def user_login():
    email = request.json.get("email", "")
    password = request.json.get("password", "")

    admin = app.security.datastore.find_user(email=email)

    if (admin is None or
        not check_password_hash(admin.password, password)):
        return {"message": "Invalid email or password", "code": "ERROR0001"}, 404
    
    login_user(admin)

    return {"token": admin.get_auth_token(), "roles": admin.get_roles()}


@api.route("/user/signup", methods=["POST"])
def user_signup():
    name = request.json.get("name", "")
    email = request.json.get("email", "")
    password = request.json.get("password", "")

    if not email or not re.match("\w+@\w+[.][a-z]+", email):
        return {"message": "Invalid email", "code": "ERROR0005"}, 400

    user = app.security.datastore.find_user(email=email)

    if user:
        return {"message": "email already exist", "code": "ERROR0002"}, 409
    
    if not name:
        return {"message": "name is required", "code": "ERROR0003"}, 400
    
    if not password:
        return {"message": "password can't be empty", "code": "ERROR0006"}, 400
    
    if len(password) < 3:
        return {"message": "password length should be atleast 3.", "code": "ERROR0004"}, 400
    
    user = app.security.datastore.create_user(name=name,
                                              email=email,
                                              password=generate_password_hash(password))
    role = app.security.datastore.find_role("user")
    user.roles.append(role)
    db.session.commit()

    return {"message": "created user successfully."}, 201


@api.route("/manager/signup", methods=["POST"])
@roles_required("admin")
def manager_signup():
    name = request.json.get("name", "")
    email = request.json.get("email", "")
    password = request.json.get("password", "")

    if not email or not re.match("\w+@\w+[.][a-z]+", email):
        return {"message": "Invalid email", "code": "ERROR0005"}, 400

    user = app.security.datastore.find_user(email=email)

    if user:
        return {"message": "email already exist", "code": "ERROR0002"}, 409
    
    if not name:
        return {"message": "name is required", "code": "ERROR0003"}, 400
    
    if not password:
        return {"message": "password can't be empty", "code": "ERROR0006"}, 400
    
    if len(password) < 3:
        return {"message": "password length should be atleast 3.", "code": "ERROR0004"}, 400
    
    user = app.security.datastore.create_user(name=name,
                                              email=email,
                                              password=generate_password_hash(password))
    role = app.security.datastore.find_role("manager")
    user.roles.append(role)
    db.session.commit()

    return {"message": "created user successfully."}, 201


@api.route("/category", methods=["PUT"])
@roles_accepted("admin")
def add_category():
    name = request.json.get("name", "")

    if not name:
        return {"message": "name is required", "code": "ERROR0003"}, 400
    
    category = Category.query.filter_by(name=name).first()

    if category:
        return {"message": "name already exist.", "code":"ERROR0007"}, 409
    
    category = Category(name=name)
    db.session.add(category)
    db.session.commit()

    return {"message": "created category successfully."}, 201


@api.route("/category")
@auth_required("token")
def get_categories():
    return [{"id": category.id,
             "name": category.name,
             "delete": category.delete
            } for category in Category.query.all()]


@api.route("/category", methods=["DELETE"])
@roles_accepted("admin")
def delete_category():
    id = request.json.get("id")

    category = db.session.get(Category, id)

    if not category:
        return {"message": "category not found.", "code": "ERROR0008"}, 404
    
    db.session.delete(category)
    db.session.commit()

    return {"message": "deleted category successfully"}, 200


@api.route("/category", methods=["POST"])
@roles_accepted("admin")
def update_category():
    id = request.json.get("id")
    name = request.json.get("name", "")

    if not name:
        return {"message": "name is required", "code": "ERROR0003"}, 400
    
    category = Category.query.filter_by(name=name).first()

    if category:
        return {"message": "name already exist.", "code":"ERROR0007"}, 409
    
    category = db.session.get(Category, id)

    if not category:
        return {"message": "category not found.", "code": "ERROR0008"}, 404
    
    category.name = name
    db.session.commit()

    return {"message": "update category successfully"}, 200


@api.route("/manager/category", methods=["PUT"])
@roles_accepted("manager")
def add_manager_category():
    name = request.json.get("name", "")

    if not name:
        return {"message": "name is required", "code": "ERROR0003"}, 400
    
    category = ManagerCategory.query.filter_by(name=name).first()

    if category or Category.query.filter_by(name=name).first():
        return {"message": "name already exist.", "code":"ERROR0007"}, 409
    
    category = ManagerCategory(name=name)
    db.session.add(category)
    db.session.commit()

    return {"message": "created category successfully."}, 201


@api.route("/manager/category")
@roles_accepted("admin", "manager")
def get_manager_categories():
    return [{"id": category.id,
             "name": category.name,
             "category_id": category.category_id
            } for category in ManagerCategory.query.all()]


@api.route("/manager/category", methods=["DELETE"])
@roles_accepted("manager")
def delete_manager_category():
    id = request.json.get("id")

    category = db.session.get(ManagerCategory, id)

    if not category:
        return {"message": "category not found.", "code": "ERROR0008"}, 404
    
    db.session.delete(category)
    db.session.commit()

    return {"message": "deleted category successfully"}, 200


@api.route("/manager/category/final", methods=["DELETE"])
@roles_accepted("manager")
def delete_final_category():
    id = request.json.get("id")

    temp = ManagerCategory.query.filter_by(category_id=id).first()
    
    if temp:
        db.session.delete(temp)

    category = db.session.get(Category, id)
    if not category:
        return {"message": "category not found.", "code": "ERROR0008"}, 404
    
    category.delete = True
    print(category.name, category.delete)
    db.session.commit()

    return {"message": "deleted category successfully"}, 200


@api.route("/manager/category", methods=["POST"])
@roles_accepted("manager")
def manager_update_categories():
    form = request.json
    id = form["id"]
    category_id = form["category_id"]
    name = form["name"]

    category = db.session.get(ManagerCategory, id)

    if (ManagerCategory.query.filter_by(name=name).first() or 
        Category.query.filter_by(name=name).first()):
        return {"message": "name already exist.", "code":"ERROR0007"}, 409

    if category:
        category.name = name

    else:
        category = ManagerCategory(name=name)
        category.category_id = category_id
        db.session.add(category)

    db.session.commit()
    return {"message": "updated category successfully"}, 200


@api.route("/admin/category/approve", methods=["POST"])
@roles_accepted("admin")
def approve_category():
    id = request.json.get("id", None)
    category_id = request.json.get("category_id", None)

    if id and not category_id:
        category = db.session.get(ManagerCategory, id)
        if category:
            entry = Category(name=category.name)
            db.session.add(entry)
            db.session.delete(category)
        else:
            return {"message": "category not found.", "code": "ERROR0008"}, 404
    
    elif not id and category_id:
        category = db.session.get(Category, category_id)
        if category and category.delete:
            db.session.delete(category)
        else:
            entry = ManagerCategory.query.filter_by(category_id=category_id).first()
            if not category or not entry:
                return {"message": "category not found.", "code": "ERROR0008"}, 404
            else:
                category.name = entry.name
                db.session.delete(entry)

    elif not id and not category_id:
        return {"message": "category not found.", "code": "ERROR0008"}, 404
    
    db.session.commit()

    return {"message": "updated category successfully."}, 200


@api.route("/admin/category/reject", methods=["POST"])
def reject_category():
    id = request.json.get("id", None)
    category_id = request.json.get("category_id", None)

    if id and not category_id:
        category = db.session.get(ManagerCategory, id)
        db.session.delete(category)

    if not id and category_id:
        category = db.session.get(Category, category_id)
        if category and category.delete:
            category.delete = False
        else:
            category = ManagerCategory.query.filter_by(category_id=category_id).first()
            if category:
                db.session.delete(category)
            else:
                return {"message": "category not found.", "code": "ERROR0008"}, 404
    
    db.session.commit()
    return {"message": "updated category successfully."}, 200


@api.route("/category/<int:category_id>/product", methods=["PUT"])
def add_product(category_id):
    if not db.session.get(Category, category_id):
        return {"message": "category not found.", "code": "ERROR0008"}, 404
    
    form = request.json
    
    name = form.get("name", None)
    metric = form.get("metric", None)
    stock = form.get("stock", None)
    rate = form.get("rate")

    if not name:
        return {"message": "name is required", "code": "ERROR0003"}, 400
    
    if Product.query.filter_by(name=name).first():
        return {"message": "name already exist.", "code":"ERROR0007"}, 409
    
    if isinstance(metric, int) and metric <= 0:
        return {"message": "Invalid metric.", "code": "ERROR0009"}, 400
    
    if isinstance(stock, int) and stock < 0:
        return {"message": "Invalid stock.", "code": "ERROR0010"}, 400
    
    if isinstance(rate, (int, float)) and rate < 0:
        return {"message": "Invalid rate.", "code": "ERROR0011"}, 400
    
    product = Product(name=name,
                      metric=metric,
                      stock=stock,
                      rate=rate,
                      category_id=category_id
                      )
    db.session.add(product)
    db.session.commit()

    return {"message": "Created product successfully."}, 201


@api.route("/category/<int:category_id>/product")
@auth_required("token")
def get_products(category_id):
    products = Product.query.filter_by(category_id=category_id).all()
    return [{"id": product.id,
             "name": product.name,
             "metric": product.metric,
             "stock": product.stock,
             "rate": product.rate,
             "category_id": category_id} for product in products]


@api.route("/product/<int:id>", methods=["DELETE"])
@roles_accepted("manager")
def delete_product(id):
    product = db.session.get(Product, id)

    if not product:
        return {"message": "product not found", "code": "ERROR0012"}, 404
    
    db.session.delete(product)
    db.session.commit()
    return {"message": "deleted product successfully."}, 200


@api.route("/category/<int:category_id>/product", methods=["POST"])
def update_product(category_id):
    if not db.session.get(Category, category_id):
        return {"message": "category not found.", "code": "ERROR0008"}, 404
    
    form = request.json
    
    id = form.get("id", None)
    name = form.get("name", None)
    metric = form.get("metric", None)
    stock = form.get("stock", None)
    rate = form.get("rate")

    product = db.session.get(Product, form.get("id", None))
    if not product:
        return {"message": "product not found", "code": "ERROR0012"}, 404
    
    if not name:
        return {"message": "name is required", "code": "ERROR0003"}, 400
    
    if Product.query.filter(Product.name==name, Product.id!=id).first():
        return {"message": "name already exist.", "code":"ERROR0007"}, 409
    
    if isinstance(metric, int) and metric <= 0:
        return {"message": "Invalid metric.", "code": "ERROR0009"}, 400
    
    if isinstance(stock, int) and stock < 0:
        return {"message": "Invalid stock.", "code": "ERROR0010"}, 400
    
    if isinstance(rate, (int, float)) and rate < 0:
        return {"message": "Invalid rate.", "code": "ERROR0011"}, 400
    
    
    product.name = name
    product.category_id = category_id
    product.metric = metric
    product.stock = stock
    product.rate = rate

    db.session.commit()

    return {"message": "Created product successfully."}, 201


@api.route("/search")
@auth_required("token")
def search():
    product = request.args.get("product", "")
    ratelq = request.args.get("ratelq", float("inf"), type=float)
    rategq = request.args.get("rategq", 0, type=float)
    category = request.args.get("category", "", type=int)

    if not category:
        products = Product.query.filter(and_(Product.name.like(f"%{product}%"),
                                        Product.rate <= ratelq,
                                        Product.rate >= rategq))
    else:
        products = Product.query.filter_by(category_id=category).all()
    
    return [{"id": product.id,
             "name": product.name,
             "metric": product.metric,
             "stock": product.stock,
             "rate": product.rate,
             "category_id": product.category_id} for product in products]


@api.route("/user/cart", methods=["POST"])
@auth_required("token")
def add_to_cart():
    id = request.json.get("id", None)

    if not id or not db.session.get(Product, id):
        return {"message": "product not found", "code": "ERROR0012"}, 404
    
    cart = Cart.query.filter_by(user_id=current_user.id,
                                product_id=id).first()
    if not cart:
        cart = Cart(user_id=current_user.id,
                    product_id=id,
                    units=1)
        db.session.add(cart)
    else:
        cart.units += 1
    db.session.commit()

    return {"message": "Added to the cart successfully"}, 200


@api.route("/user/cart")
@auth_required("token")
def get_cart():
    items = Cart.query.filter_by(user_id=current_user.id).all()
    return [{"id": item.id,
             "units": item.units,
             "product_id": item.product.id,
             "name": item.product.name,
             "category": item.product.category_id,
             "rate": item.product.rate,
             "stock": item.product.stock} for item in items]


@api.route("/user/cart", methods=["DELETE"])
@auth_required("token")
def remove_cart_item():
    id = request.json.get("id", None)
    
    cart = db.session.get(Cart, id)
    if not cart:
       return {"message": "item not found", "code": "ERROR0013"}, 404
    else:
        cart.units -= 1
        if cart.units <= 0:
            db.session.delete(cart)
    db.session.commit()

    return {"message": "Added to the cart successfully"}, 200


@api.route("/user/buy", methods=["GET"])
@auth_required("token")
def make_purchase():
    items = Cart.query.filter_by(user_id=current_user.id).all()

    for item in items:
        if item.units > item.product.stock:
            return {"message": "Invlalid number of units", "code": "ERROR0014"}, 400
    
    for item in items:
        item.product.stock -= item.units
        db.session.delete(item)

    db.session.commit()
    return {"message": "Puchased items successfully"}, 200


from dep.celery import add
from celery.result import AsyncResult

@api.route("/")
def check():
    return add.delay(1, 0).id

@api.route("/task/<string:id>")
def status(id):
    return AsyncResult(id).status

@api.route("/result/<string:id>")
def result(id):
    return str(AsyncResult(id).result)