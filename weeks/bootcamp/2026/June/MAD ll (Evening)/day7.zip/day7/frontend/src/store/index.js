import { createStore } from "vuex";

export default createStore({
    state() {
        return {
            user: {
                token: null,
                roles: []
            },
            alerts: [],
            categories: [],
            managerCategories: [],
            CategoryProduct: [],
            units:[
                 "kg", "g", "mg", "km","m", "cm", "mm", "L", "mL",
            ],
            searchResults: [],
        }
    },
    mutations: {
        setUser(state, value) {
            localStorage.setItem("user", JSON.stringify(value))
            state.user = value;
        },
        addAlert(state, value) {
            state.alerts.push(value)
        },
        removeAlert(state, idx) {
            state.alerts = state.alerts.filter((v, i) => i != idx)
        },
        setCategories(state, value) {
            state.categories = value
        },
        setManagerCategories(state, value) {
            state.managerCategories = value
        },
        setCategoryProduct(state, value) {
            state.CategoryProduct = value
        },
        setSearchResults(state, value){
            state.searchResults = value
        }
    },
    getters: {
        getUser(state) {
            return state.user
        },
        getRoles(state) {
            return state.user["roles"]
        },
        getToken(state) {
            return state.user["token"]
        },
        getAlerts(state) {
            return state.alerts
        },
        getCategories(state) {
            return state.categories
        },
        getManagerCategories(state) {
            return state.managerCategories
        },
        getAllCategories(state) {
            let result = []
            state.categories.forEach(element => {
                let item = Object.assign({ temp: false }, element)
                item["category_id"] = item["id"]
                item["id"] = null
                result.push(item)
            });
            state.managerCategories.forEach(element => {
                result.push(Object.assign({ temp: true }, element))
            });
            return result
        },
        getCategoryProduct(state) {
            return state.CategoryProduct
        },
        getUnits(state){
            return state.units
        },
        getSearchResults(state){
            return state.searchResults
        }
    },
    actions: {
        getCategories(context) {
            fetch(import.meta.env.VITE_SERVER + "category", {
                method: "GET",
                headers: {
                    "Authentication-Token": context.getters.getToken
                },
            }).then(r => {
                if (r.status == 200) {
                    r.json().then(x => context.commit("setCategories", x))
                }
            })
        },
        getManagerCategories(context) {
            fetch(import.meta.env.VITE_SERVER + "manager/category", {
                method: "GET",
                headers: {
                    "Authentication-Token": context.getters.getToken
                },
            }).then(r => {
                if (r.status == 200) {
                    r.json().then(x => context.commit("setManagerCategories", x))
                }
            })
        },
        getAllCategories(context) {
            context.dispatch("getCategories")
            context.dispatch("getManagerCategories")
        },
        getCategoryProducts(context, id) {
            fetch(import.meta.env.VITE_SERVER + `category/${id}/product`, {
                headers: {
                    "Authentication-token": context.getters.getToken
                }
            }).then(r => {
                if (r.status == 200) {
                    r.json().then(x => {
                        context.commit("setCategoryProduct", x)
                    })
                }
            })
        }
    }
})