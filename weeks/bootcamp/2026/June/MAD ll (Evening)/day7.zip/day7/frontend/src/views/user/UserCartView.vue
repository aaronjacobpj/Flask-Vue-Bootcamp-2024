<template>
    <div class="row">
        <div class="col-8" style="border-right: 1px solid !important; height: 100vh;">
            <div class="row ms-3" v-for="item in cart" style="border-bottom: 1px solid rgb(207, 207, 207);">
                <div class="col">
                    <h5>{{ item["name"] }}</h5>
                    <span class="card-subtitle">
                        {{ categories[item["category"]]["name"] }}
                    </span>
                    <br>
                    <span>Rate: {{ item["rate"] }}</span>
                    <br>
                    <span>Units: {{ item["units"] }}</span>
                    <br>
                    <span>Total: {{ item["rate"] * item["units"] }}</span>
                    <br>
                    <button class="btn" style="color: red;" @click="removeItems(item.id)"
                     v-if="item['units'] > item['stock']">
                        Remove items
                    </button>
                    <span class="invalid-feedback" style="display: block;" 
                        v-if="item['units'] > item['stock']">
                        Can only buy {{ item['stock'] }} items.
                    </span>
                </div>
            </div>
        </div>
        <div class="col-4">
            <h3>Summary</h3>
            <div class="row">
                <span> Total items Brought: {{ cart.length }}</span>
            </div>
            <div class="row">
                <h6>Total: {{ cart.map(x => x["rate"] * x["units"]).reduce((a, b) => a+b, 0)}} </h6>
            </div>
            <div class="row m-1">
                <button class="btn btn-primary" style="width: 100%;" @click="purchase"
                :disabled="!purchaseable">
                    Buy
                </button>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                cart: []
            }
        },
        created() {
            this.$store.dispatch("getCategories")
            this.getCart()
        },
        methods: {
            getCart() {
                fetch(import.meta.env.VITE_SERVER + "user/cart", {
                    method: "GET",
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    },
                }).then(r => {
                    if (r.status == 200) {
                        r.json().then(x => this.cart = x)
                    }
                })
            },
            removeItems(id){
                fetch(import.meta.env.VITE_SERVER+"user/cart", {
                    method: "DELETE",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify({id:id})
                }).then(r =>{
                    if(r.status == 200)
                        this.$store.commit("addAlert", "Removed Item from the cart")
                        this.$store.dispatch("getCategories")
                })
            },
            purchase(){
                fetch(import.meta.env.VITE_SERVER+"user/buy", {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(r =>{
                    if(r.status == 200)
                        this.$store.commit("addAlert", "Purchase successful")
                        this.$store.dispatch("getCategories")
                })
            }
        },
        computed: {
            categories() {
                let result = {}
                this.$store.getters.getCategories.forEach(x => {
                    result[x["id"]] = x
                })
                return result
            },
            purchaseable(){
                return this.cart.filter(x => x["units"] > x["stock"]).length == 0
            }
        }
    }
</script>