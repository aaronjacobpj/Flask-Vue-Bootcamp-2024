<template>
    <div class="row d-flex">
        <div class="col-6">
            <div class="mb-3 ms-4">
                <label for="formGroupExampleInput" class="form-label">Search</label>
                <select class="form-select" v-model="form.q" v-if="form.type.match('category')">
                    <option value="">Select a Category</option>
                    <option :value="category.id" v-for="category in $store.getters.getCategories">{{ category["name"] }}
                    </option>
                </select>
                <input v-else :type="types[form.type]" class="form-control" id="formGroupExampleInput"
                    placeholder="Query" v-model="form.q">
            </div>
        </div>
        <div class="col-3">
            <div class="mb-3">
                <label for="formGroupExampleInput" class="form-label">Search</label>
                <select class="form-select" v-model="form.type">
                    <option value="product">Product</option>
                    <option value="category">Category</option>
                    <option value="ratelq">Rate less than</option>
                    <option value="rategq">Rate greater than</option>
                </select>
            </div>
        </div>
        <div class="col-3">
            <div class="mb-3 mx-2">
                <label for="formGroupExampleInput" class="form-label" style="visibility: hidden;">Submit</label>
                <button class="form-control btn btn-primary" @click="getProducts">Search</button>
            </div>
        </div>
    </div>
    <div class="container-fluid d-flex flex-wrap">
        <div class="card col-12 col-sm-2 mx-2 my-2" v-for="product in $store.getters.getSearchResults">
            <div class="card-body">
                <h4>{{ product["name"] }}</h4>
                <span class="card-subtitle mb-3 ext-body-secondary">{{ categories[product.category_id]["name"] }}</span>
                <br>
                <span>Price: </span>
                <span style="color: rgb(186, 51, 51)">
                    {{ product.rate }}/{{ $store.getters.getUnits[product.metric-1] }}
                </span>
                <br>
                <button class="btn" style="background-color: #CFE2ff;width: 100%;" @click="addtoCart(product)">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor"
                        class="bi bi-cart-plus" viewBox="0 0 16 16">
                        <path
                            d="M9 5.5a.5.5 0 0 0-1 0V7H6.5a.5.5 0 0 0 0 1H8v1.5a.5.5 0 0 0 1 0V8h1.5a.5.5 0 0 0 0-1H9z" />
                        <path
                            d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1zm3.915 10L3.102 4h10.796l-1.313 7zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0m7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0" />
                    </svg>
                </button>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        created() {
            this.$store.dispatch("getCategories")
            this.getProducts()
        },
        data() {
            return {
                form: {
                    q: "",
                    type: "product",
                },
                types: {
                    product: "text",
                    category: "text",
                    ratelq: "number",
                    rategq: "number"
                },
            }
        },
        methods: {
            getProducts() {
                let search = new URLSearchParams();

                for (let type in this.types)
                    if (type.match(this.form.type))
                        search.append(type, this.form.q)

                let url = new URL(import.meta.env.VITE_SERVER + "search?" + search.toString())

                fetch(url, {
                    method: "GET",
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    },
                }).then(r => {
                    if (r.status == 200) {
                        r.json().then(x => this.$store.commit("setSearchResults", x))
                    }
                })
            },
            addtoCart(product){
                fetch(import.meta.env.VITE_SERVER+"user/cart", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify({id:product.id})
                }).then(r =>{
                    if(r.status == 200)
                        this.$store.commit("addAlert", "Added Item to the cart")
                })
            }
        },
        computed: {
            categories() {
                let result = {}
                this.$store.getters.getCategories.forEach(x => {
                    result[x["id"]] = x
                })
                return result
            },
        }
    }
</script>