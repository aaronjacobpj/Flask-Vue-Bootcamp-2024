from celery import shared_task
from dep.models import Product, User, Role
from dep.utils import METRICS
from flask import render_template
from email.message import EmailMessage
from email.mime.image import MIMEImage

import csv
import os
import smtplib


@shared_task(bind=True)
def export(self):
    products = Product.query.all()
    
    field = ["product_id", "name", "category_id", 
             "category", "rate", "stock", "metric"]

    with open(os.path.join("exports", self.request.id), "w") as file:
        writer = csv.DictWriter(file, fieldnames=field)
        writer.writeheader()
        for product in products:
            writer.writerow({
             "product_id": product.id,
             "name": product.name,
             "category_id": product.category_id,
             "category": product.category.name,
             "rate": product.rate,
             "stock": product.stock,
             "metric": product.metric})
        

@shared_task
def daily_reminder():
    
    users = User.query.all()

    server = smtplib.SMTP("localhost", 1025)

    for user in users:
        if user.has_role("user"):
            server.sendmail(msg="Come back we miss you!...", 
                                from_addr="noreply@example.com", 
                                to_addrs=user.email)
            

@shared_task
def monthly_reminder():
    products = Product.query.all()
    content = render_template("report.html", 
                           products=products,
                           metrics=METRICS)
    
    # with open(os.path.join("exports", "image.png"), "rb") as file:
    #     image = file.read()

    # file = MIMEImage(image)
    # file.add_header('Content-Disposition', 'attachment; filename="flower.png"')
    
    server = smtplib.SMTP("localhost", 1025)

    message = EmailMessage()
    for user in User.query.all():
        if user.has_role("manager"):
            message["To"] = user.email
            message["From"] = "report.@example.com"
            message["Subject"] = "Monthly Report"
            message.add_alternative(content, subtype="html")
            # message.attach(file)

            server.send_message(message)