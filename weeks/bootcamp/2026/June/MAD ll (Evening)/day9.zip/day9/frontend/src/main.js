import './assets/main.css'
import "bootstrap/dist/css/bootstrap.css"
import "bootstrap/dist/js/bootstrap.js"

import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import VueApexCharts from 'vue3-apexcharts'


const app = createApp(App)

app.use(router)
app.use(store)
app.use(VueApexCharts)

app.component('apexchart', VueApexCharts)
app.mount('#app')
