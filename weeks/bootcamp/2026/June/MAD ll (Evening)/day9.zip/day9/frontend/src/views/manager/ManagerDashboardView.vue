<template>
    <apexchart width="500" type="bar" :options="options" :series="series"></apexchart>
</template>
<script>
    export default {
        data() {
            return {
                categories:[] ,
                data: []
            }
        },
        created(){
            this.getData()
        },
        methods:{
            getData(){
                fetch(import.meta.env.VITE_SERVER+"chart", {
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(r =>{
                    if(r.status == 200){
                        r.json().then(x =>{
                                this.categories = x["product"]
                                this.data = x["stock"]
                        })
                    }
                })
            }
        },
        computed:{
            options(){
                return {
                    chart: {
                        id: 'vuechart-example'
                    },
                    xaxis: {
                        categories: this.categories
                    }
                }
            },
            series(){
                return [{
                    name: 'series-1',
                    data: this.data
                }]
            }
        }
    }
</script>