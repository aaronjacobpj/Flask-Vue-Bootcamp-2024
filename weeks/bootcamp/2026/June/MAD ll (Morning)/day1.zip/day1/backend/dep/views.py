from flask import current_app as app
from flask import Blueprint, request
from flask_security import current_user, login_user
from werkzeug.security import check_password_hash


api = Blueprint("views", __name__)


@api.route("/admin", methods=["POST"])
def admin_login():
    email = request.json.get("email", "")
    password = request.json.get("password", "")

    admin = app.security.datastore.find_user(email=email)

    if admin is None or not admin.has_role("admin") or not check_password_hash(admin.password, password):
        return {"message": "Invalid username or password", "code": "ERROR0001"}, 404
    

    login_user(admin)
    return {"token": admin.get_auth_token(), "roles": admin.get_roles()}
