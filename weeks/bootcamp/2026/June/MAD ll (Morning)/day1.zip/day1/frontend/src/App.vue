<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <router-view></router-view>  
</template>

<style>

</style>