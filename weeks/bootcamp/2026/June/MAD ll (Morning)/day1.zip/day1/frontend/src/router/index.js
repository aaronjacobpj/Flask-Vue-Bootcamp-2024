import { createRouter, createWebHistory } from 'vue-router'
import LoginView from '../views/LoginView.vue'
import AdminLayoutView from "@/views/admin/AdminLayoutView.vue"
import AdminLoginView from "@/views/admin/AdminLoginView.vue"

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: LoginView,
    },
    {
      path: "/admin",
      name: "admin",
      component: AdminLayoutView,
      children: [
        {
          path: "",
          name: "admin-login",
          component: AdminLoginView
        }
      ]
    }
  ],
})

export default router
