from flask import current_app as app
from flask import Blueprint, request
from flask_security import current_user, login_user, roles_required, roles_accepted
from werkzeug.security import check_password_hash, generate_password_hash
import re

from dep.models import db

api = Blueprint("views", __name__)


@api.route("/signin", methods=["POST"])
def user_login():
    email = request.json.get("email", "")
    password = request.json.get("password", "")

    user = app.security.datastore.find_user(email=email)

    if user is None or not check_password_hash(user.password, password):
        return {"message": "Invalid username or password", "code": "ERROR0001"}, 404

    login_user(user)
    return {"token": user.get_auth_token(), "roles": user.get_roles()}


@api.route("/manager/signup", methods=["POST"])
@roles_accepted("admin")
def signup_manager():
    name = request.json.get("name", "")
    email = request.json.get("email", "")
    password = request.json.get("password", "")

    user = app.security.datastore.find_user(email=email)

    if user:
        return {"message": "email already exist", "code": "ERROR0002"}, 409
    
    if not email or not re.match(r"\w+[@]\w+\.[a-z]+", email):
        return {"message": "Invalid email.", "code": "ERROR0003"}, 400
    
    if not name:
        return {"message": "name required.", "code": "ERROR0004"}, 400
    
    if not password:
        return {"message": "Invalid password", "code": "ERROR0005"}, 400
    
    user = app.security.datastore.create_user(name=name, 
                                              email=email,
                                              password=generate_password_hash(password))
    role = app.security.datastore.find_role("manager")
    user.roles.append(role)
    db.session.commit()

    return {"message": "Create user successfully."}, 201