<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <router-view></router-view>  
</template>

<script>
export default {
  created(){
    const empty = this.$store.getters.getUser
    let item = localStorage.getItem("user")
    item = (item)? item : JSON.stringify(empty)
    item = JSON.parse(item)
    this.$store.commit("setUser", item);
  }

}
</script>