import { createRouter, createWebHistory } from 'vue-router'
import LoginView from '../views/LoginView.vue'
import AdminLayoutView from "@/views/admin/AdminLayoutView.vue"
import AdminLoginView from "@/views/admin/AdminLoginView.vue"
import AdminDashboardView from "@/views/admin/AdminDashboardView.vue"
import AdminCreateManagerView from "@/views/admin/AdminCreateManagerView.vue"
import UserLayoutView from "@/views/user/UserLayoutView.vue"
import UserLoginView from "@/views/user/UserLoginView.vue"
import UserSignupView from "@/views/user/UserSignupView.vue"

import store from '@/store'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: LoginView,
    },
    {
      path: "/admin",
      name: "admin",
      component: AdminLayoutView,
      beforeEnter(to, from){
        if(!to.name.match("admin-login") && !store.getters.getRoles.includes("admin"))
          return {name: "admin-login"}
      },
      children: [
        {
          path: "",
          name: "admin-login",
          component: AdminLoginView
        },
        {
          path: "home",
          name: "admin-dashboard",
          component: AdminDashboardView
        },
        {
          path: "create/manager",
          name: "admin-create-manager",
          component: AdminCreateManagerView
        }
      ]
    },
    {
      path: "/user",
      name: "user",
      component: UserLayoutView,
      beforeEnter(to, from){
        if(!to.name.match("user-login") && !store.getters.getRoles.includes("user"))
          return {name: "user-login"}
      },
      children: [
        {
          path: "",
          name: "user-login",
          component: UserLoginView
        },
        {
          path: "signup",
          name: "user-signup",
          component: UserSignupView
        }
      ]
    }
  ],
})

export default router
