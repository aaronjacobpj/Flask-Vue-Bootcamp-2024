<script setup>
</script>
<template>
    <div class="container-fluid d-flex justify-content-center align-items-center" style="height: 100vh;">
      <div class="card" style="height: fit-content;">
        <div class="card-body">
          <h3 class="card-title" align="center">Sign up</h3>
          <form @submit.prevent="login">
            <div class="mb-3">
              <label for="username-input" class="form-label">Full Name</label>
              <input type="text" class="form-control" id="username-input" placeholder="Harry Potter" v-model="form.name">
              <div class="invalid-feedback" style="display:block">{{ error["name"] }}</div>
            </div>
            <div class="mb-3">
              <label for="username-input" class="form-label">Email</label>
              <input type="email" class="form-control" id="username-input" placeholder="abc@example.com" v-model="form.email">
              <div class="invalid-feedback" style="display:block">{{ error["email"] }}</div>
            </div>
            <div class="mb-3">
              <label for="password-input" class="form-label">Password</label>
              <input type="text" class="form-control" id="password-input" placeholder="password" v-model="form.password">
              <div class="invalid-feedback" style="display:block">{{ error["password"] }}</div>
            </div>
            <div class="mb-3 d-flex justify-content-center">
              <input type="submit" class="btn btn-primary" value="Sign in">
            </div>
          </form>
        </div>
      </div>
    </div>
</template>
<script>
  export default {
    data(){
      return {
            form: {
                name: "",
                email: "",
                password: "",
            },
            error: {
                name: "",
                email: "",
                password: "",
            }
      }
    },
    methods: {
      login(){

        if(!this.validate())
            return
        fetch(import.meta.env.VITE_SERVER+"user/signup", {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify(this.form)
        }).then(r =>{
          if (r.status == 409){
            r.json().then(x => this.error["email"] = x.message)
          }
          if(r.status == 400){
            r.json(x => {
                if(x["code"] == "ERROR003"){
                    this.error["email"] = x.message
                }
                else if(x["code"] == "ERROR004"){
                    this.error["name"] = x.message
                }
                else if(x["code"] == "ERROR005"){
                    this.error["password"] = x.message
                }
            })
          }
          if (r.status == 201){
            this.$router.push({name: "user-login"})
          }
        })
      },
      validate(){
        this.error = {
                name: "",
                email: "",
                password: "",
        }
        let form = this.form
        if(!form.name){
            this.error["name"] = "name required";
            return false
        }
        if (!form.email){
            this.error["email"] = "Invalid email"
            return false 
        }
        if (!form.password){
            this.error["password"] = "Can't be empty" 
            return false 
        }
        if (form.password.length < 3){
            this.error["password"] = "password should have atleast 3 characters." 
            return false 
        }
        return true
      }
    }
  }
</script>