from flask import current_app as app
from flask import Blueprint, request
from flask_security import current_user, login_user, roles_required, roles_accepted, auth_required
from werkzeug.security import check_password_hash, generate_password_hash
import re

from dep.models import db, Category, ManagerCategory, Cart, Product

api = Blueprint("views", __name__)


@api.route("/signin", methods=["POST"])
def user_login():
    email = request.json.get("email", "")
    password = request.json.get("password", "")

    user = app.security.datastore.find_user(email=email)

    if user is None or not check_password_hash(user.password, password):
        return {"message": "Invalid username or password", "code": "ERROR0001"}, 404

    login_user(user)
    return {"token": user.get_auth_token(), "roles": user.get_roles()}


@api.route("/manager/signup", methods=["POST"])
@roles_accepted("admin")
def signup_manager():
    name = request.json.get("name", "")
    email = request.json.get("email", "")
    password = request.json.get("password", "")

    user = app.security.datastore.find_user(email=email)

    if user:
        return {"message": "email already exist", "code": "ERROR0002"}, 409
    
    if not email or not re.match(r"\w+[@]\w+\.[a-z]+", email):
        return {"message": "Invalid email.", "code": "ERROR0003"}, 400
    
    if not name:
        return {"message": "name required.", "code": "ERROR0004"}, 400
    
    if not password:
        return {"message": "Invalid password", "code": "ERROR0005"}, 400
    
    user = app.security.datastore.create_user(name=name, 
                                              email=email,
                                              password=generate_password_hash(password))
    role = app.security.datastore.find_role("manager")
    user.roles.append(role)
    db.session.commit()

    return {"message": "Create user successfully."}, 201

@api.route("/user/signup", methods=["POST"])
def signup_user():
    name = request.json.get("name", "")
    email = request.json.get("email", "")
    password = request.json.get("password", "")

    user = app.security.datastore.find_user(email=email)

    if user:
        return {"message": "email already exist", "code": "ERROR0002"}, 409
    
    if not email or not re.match(r"\w+[@]\w+\.[a-z]+", email):
        return {"message": "Invalid email.", "code": "ERROR0003"}, 400
    
    if not name:
        return {"message": "name required.", "code": "ERROR0004"}, 400
    
    if not password:
        return {"message": "Invalid password", "code": "ERROR0005"}, 400
    
    user = app.security.datastore.create_user(name=name, 
                                              email=email,
                                              password=generate_password_hash(password))
    role = app.security.datastore.find_role("manager")
    user.roles.append(role)
    db.session.commit()

    return {"message": "Create user successfully."}, 201


@api.route("/admin/category", methods=["PUT"])
@roles_accepted("admin")
def create_category():
    name = request.json.get("name", "")

    if not name:
        return {"message": "name required.", "code": "ERROR0004"}, 400
    
    category = Category.query.filter_by(name=name).first()

    if category:
        return {"message": "category already exist.", "code": "ERROR0006"}, 409
    
    category = Category(name=name)
    db.session.add(category)
    db.session.commit()

    return {"message": "Created category successfully."}, 201


@api.route("/categories")
@auth_required("token")
def get_categories():
    categories = Category.query.all()

    return [{"id": category.id, 
             "name": category.name} 
             for category in categories]


@api.route("/admin/category", methods=["DELETE"])
@roles_accepted("admin")
def delete_categories():
    id = request.json.get("id", None)

    if not id:
        return {"message": "category not found", "code": "ERROR007"}, 404
    
    category = db.session.get(Category, id)
    if not category:
        return {"message": "category not found", "code": "ERROR007"}, 404
    
    db.session.delete(category)
    db.session.commit()

    return {"message": "deleted category successfully"}

@api.route("/admin/category", methods=["POST"])
@roles_accepted("admin")
def update_category():
    name = request.json.get("name", "")
    id = request.json.get("id", None)

    if not id:
        return {"message": "category not found", "code": "ERROR007"}, 404
    
    if not name:
        return {"message": "name required.", "code": "ERROR0004"}, 400
    
    category = Category.query.filter_by(name=name).first()

    if category:
        return {"message": "category already exist.", "code": "ERROR0006"}, 409
    
    category = db.session.get(Category, id)
    if not category:
        return {"message": "category not found", "code": "ERROR007"}, 404
    
    category.name = name
    db.session.commit()

    return {"message": "Created category successfully."}, 200