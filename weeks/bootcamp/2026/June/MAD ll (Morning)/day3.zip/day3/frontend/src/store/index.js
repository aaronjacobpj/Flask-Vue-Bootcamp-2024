import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            user: {
                token: null,
                roles: [],
            },
            categories: []
        }
    },
    mutations: {
        setUser(state, value){
            localStorage.setItem("user", JSON.stringify(value));
            state.user = value;
        },
        setCategories(state, value){
            state.categories = value
        }
    },
    getters: {
        getUser(state){
            return state.user
        },
        getRoles(state){
            return state.user["roles"]
        },
        getToken(state){
            return state.user["token"]
        },
        getCategories(state){
            return state.categories
        }
    },
    actions: {
        getCategories(context){
            fetch(import.meta.env.VITE_SERVER+"categories", {
                headers: {
                    "Authentication-Token": context.getters.getToken
                }
            }).then(r => {
                if(r.status == 200){
                    r.json().then(x => context.commit("setCategories", x))
                }
            })
        }
    }
});