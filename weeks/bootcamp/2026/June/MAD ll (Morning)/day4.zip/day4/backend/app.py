from flask import Flask
from flask_security import Security, SQLAlchemyUserDatastore
from werkzeug.security import generate_password_hash
import os
from flask_cors import CORS

from dep.models import db, User, Role
from dep.views import api

def create_app():
    app = Flask(__name__)
    CORS(app)

    # Generate a nice key using secrets.token_urlsafe()
    app.config['SECRET_KEY'] = os.environ.get("SECRET_KEY", 'pf9Wkove4IKEAXvy-cQkeDPhv9Cb3Ag-wyJILbq_dFw')
    # Generate a good salt for password hashing using: secrets.SystemRandom().getrandbits(128)
    app.config['SECURITY_PASSWORD_SALT'] = os.environ.get("SECURITY_PASSWORD_SALT", '146585145368132386173505678016728509634')


    # Use an in-memory db
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///model.db'
    # As of Flask-SQLAlchemy 2.4.0 it is easy to pass in options directly to the
    # underlying engine. This option makes sure that DB connections from the
    # pool are still valid. Important for entire application since
    # many DBaaS options automatically close idle connections.
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False


    #Initialising the database
    db.init_app(app)

    # Setup Flask-Security
    user_datastore = SQLAlchemyUserDatastore(db, User, Role)
    app.security = Security(app, user_datastore)

    with app.app_context():
        db.create_all()

        if not app.security.datastore.find_role("admin"):
            alice = app.security.datastore.create_user(name="Alice", 
                                                       email="alice@example.com", 
                                                       password=generate_password_hash("alice"))
            admin = app.security.datastore.create_role(name="admin")
            manager = app.security.datastore.create_role(name="manager")
            user = app.security.datastore.create_role(name="user")
            db.session.flush()
            alice.roles.append(admin)

        db.session.commit()

    # Initialise the routes
    app.register_blueprint(api)

    return app