<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <div class="alert alert-success alert-dismissible fade show" 
   v-for="(alert, i) in $store.getters.getAlerts" role="alert">
    {{ alert }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
  <router-view></router-view>  
</template>

<script>
export default {
  created(){
    const empty = this.$store.getters.getUser
    let item = localStorage.getItem("user")
    item = (item)? item : JSON.stringify(empty)
    item = JSON.parse(item)
    this.$store.commit("setUser", item);
  }

}
</script>