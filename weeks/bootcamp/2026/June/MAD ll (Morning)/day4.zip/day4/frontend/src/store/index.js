import { createStore } from "vuex";

export default createStore({
    state(){
        return {
            user: {
                token: null,
                roles: [],
            },
            categories: [],
            managerCategories: [],
            alerts: []
        }
    },
    mutations: {
        setUser(state, value){
            localStorage.setItem("user", JSON.stringify(value));
            state.user = value;
        },
        setCategories(state, value){
            state.categories = value
        },
        addAlert(state, value){
            state.alerts.push(value)
        },
        removeAlert(state, idx){
            state.alerts = state.alerts.filter(x, i => i != idx)
        },
        setManagerCategories(state, value){
            state.managerCategories = value;
        }
    },
    getters: {
        getUser(state){
            return state.user
        },
        getRoles(state){
            return state.user["roles"]
        },
        getToken(state){
            return state.user["token"]
        },
        getCategories(state){
            return state.categories
        },
        getAlerts(state){
            return state.alerts
        },
        getCombinedCategories(state){
            let result = JSON.parse(JSON.stringify(state.categories))
            let maps = {}
            state.managerCategories.forEach(element => {
                maps[element.category_id] = element
            });
            let added = {}
            result.forEach(x =>{
                if (x["id"] in maps){
                    x["manager"] = maps[x["id"]];
                    added[x["id"]] = true
                }
            });
            state.managerCategories.forEach(element => {
                if(!(element.category_id in added)){
                    result.push(Object.assign({temp: true}, element));
                }
            })
            return result
            
        }
    },
    actions: {
        getCategories(context){
            fetch(import.meta.env.VITE_SERVER+"categories", {
                headers: {
                    "Authentication-Token": context.getters.getToken
                }
            }).then(r => {
                if(r.status == 200){
                    r.json().then(x => context.commit("setCategories", x))
                }
            })
        },
        getManagerCategories(context){
            fetch(import.meta.env.VITE_SERVER+"/manager/categories", {
                headers: {
                    "Authentication-Token": context.getters.getToken
                }
            }).then(r => {
                if(r.status == 200){
                    r.json().then(x => context.commit("setManagerCategories", x))
                }
            })
        },
        fetchAllCategories(context){
            context.dispatch("getCategories")
            context.dispatch("getManagerCategories")
        }
    }
});