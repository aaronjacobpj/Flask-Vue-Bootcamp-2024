<template>
    <table class="table table-striped">
        <tbody>
            <tr>
                <td>
                    <div class="mb-3">
                        <label for="username-input" class="form-label">Category Name</label>
                        <input type="text" class="form-control" id="username-input" placeholder="Cosmetics" v-model="form.name">
                        <div class="invalid-feedback" style="display:block">{{ error["name"] }}</div>
                    </div>
                </td>
                <td>
                    <div class="mb-3">
                        <label for="password-input" class="form-label" style="visibility: hidden;">Submit</label>
                        <input @click="addCategory" type="submit" class="form-control btn btn-primary" value="Add Categories">
                        <div class="invalid-feedback" style="display:block">{{ error["password"] }}</div>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
    <table class="table my-6">
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Aproval</th>
            </tr>
        </thead>
        <tbody>
            <tr v-for="category in $store.getters.getCombinedCategories" >
            <th scope="row">{{ category.id }}</th>
            <td>
              <span style="text-decoration: line-through;" v-if="category.delete">{{ category.name }}</span>
              <span v-else>{{ category.name }}</span>

            </td>
            <td> {{(category.temp)? "Waiting" : "Approved" }}</td>
            <td>
                <button class="btn btn-warning" @click="chooseEdit(category)"
                data-bs-toggle="modal" data-bs-target="#exampleModal">
                    Edit
                </button>
            </td>
            <td>
                <button class="btn btn-danger" @click="choosedelete(category)">Delete</button>
            </td>
            </tr>
        </tbody>
    </table>
    <div class="modal fade" id="exampleModal" tabindex="-1" 
        aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                    <div class="mb-3">
                        <label for="username-input" class="form-label">Category Name</label>
                        <input type="text" class="form-control" id="username-input" placeholder="Cosmetics" v-model="editForm.name">
                        <div class="invalid-feedback" style="display:block">{{ editFormError["name"] }}</div>
                        <div class="valid-feedback" style="display:block">{{ editFormError["success"] }}</div>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" @click="updateCategory">Save changes</button>
            </div>
            </div>
        </div>
    </div>
</template>
<script>
  export default {
    data(){
      return {
            form: {
                name: "",
            },
            error: {
                name: "",
            },
            category: {
                id: null,
                name: "",
                temp: false,
                manager:{
                  id: null,
                  name: "",
                  category_id: null
                }
            },
            editForm: {
                id: null,
                name: ""
            },
            editFormError: {
                name: null,
                success: null
            },
            hideEditForm: true
            
      }
    },
    created(){
        this.$store.dispatch("fetchAllCategories")
    },
    methods: {
      addCategory(){

        if(!this.validate())
            return
        fetch(import.meta.env.VITE_SERVER+"manager/category", {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            "Authentication-Token": this.$store.getters.getToken
          },
          body: JSON.stringify(this.form)
        }).then(r =>{
          if (r.status == 409){
            r.json().then(x => this.error["name"] = x.message)
          }
          if(r.status == 400){
            r.json(x => {
                if(x["code"] == "ERROR006"){
                    this.error["name"] = x.message
                }
            })
          }
          if (r.status == 201){
            this.$store.dispatch("getManagerCategories")
          }
        })
      },
      validate(){
        this.error = {
                name: "",
        }
        let form = this.form
        if(!form.name){
            this.error["name"] = "name required";
            return false
        }
        return true
      },
      deleteCategory(id){
        fetch(import.meta.env.VITE_SERVER+"manager/category", {
          method: "DELETE",
          headers: {
            "Content-Type": "application/json",
            "Authentication-Token": this.$store.getters.getToken
          },
          body: JSON.stringify({id:id})
        }).then(x =>{
            if(x.status == 200)
                this.$store.dispatch("getManagerCategories")
        })
      },
      editValidate(){
        this.error = {
                name: "",
        }
        let form = this.editForm
        if(!form.name){
            this.editFormError["name"] = "name required";
            return false
        }
        return true
      },
      updateCategory(){
        this.hideEditForm = false
        if(!this.editValidate())
            return
        fetch(import.meta.env.VITE_SERVER+"manager/category", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authentication-Token": this.$store.getters.getToken
          },
          body: JSON.stringify(this.editForm)
        }).then(r =>{
          if (r.status == 409){
            r.json().then(x => this.editFormError["name"] = x.message)
          }
          if(r.status == 400){
            r.json(x => {
                if(x["code"] == "ERROR006"){
                    this.editFormError["name"] = x.message
                }
            })
          }
          if (r.status == 200){
            this.$store.dispatch("getManagerCategories")
            r.json().then(x => this.editFormError["success"] = x.message)
          }
        })
      },
      updateAdminCategories(category){

      },
      chooseEdit(category){
        this.category = Object.assign({}, category)
        if(category.temp){
          this.editForm["id"] = category["id"]
          this.editForm["name"] = category["name"]
        }
        else{
          
        }
      },
      chooseUpdate(){
        if(this.editForm.temp == true){
          this.updateCategory()
        }
      },
      choosedelete(category){
        this.category=category
        if(category["temp"]){
          this.deleteCategory(category["id"])
        }
        else{
          this.deleteAdminCategory(category["id"])
        }
      },
      deleteAdminCategory(id){
        fetch(import.meta.env.VITE_SERVER+"manager/category/final", {
            method: "DELETE",
            headers: {
              "Content-Type": "application/json",
              "Authentication-Token": this.$store.getters.getToken
            },
            body: JSON.stringify({id:id})
          }).then(x =>{
              if(x.status == 200)
                  this.$store.dispatch("getCategories")
          })
      }
    }
  }
</script>