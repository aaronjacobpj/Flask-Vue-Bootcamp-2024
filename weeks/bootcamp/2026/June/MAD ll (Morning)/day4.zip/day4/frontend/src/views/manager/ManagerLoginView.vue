<script setup>
</script>
<template>
    <div class="container-fluid d-flex justify-content-center align-items-center" style="height: 100vh;">
      <div class="card" style="height: fit-content;">
        <div class="card-body">
          <h3 class="card-title" align="center">Login</h3>
          <form @submit.prevent="login">
            <div class="mb-3">
              <label for="username-input" class="form-label">Email</label>
              <input type="email" class="form-control" id="username-input" placeholder="abc@example.com" v-model="username">
              <div class="invalid-feedback" style="display:block">{{ message }}</div>
            </div>
            <div class="mb-3">
              <label for="password-input" class="form-label">Password</label>
              <input type="text" class="form-control" id="password-input" placeholder="password" v-model="password">
              <div class="invalid-feedback" style="display:block">{{ message }}</div>
            </div>
            <div class="mb-3 d-flex justify-content-center">
              <input type="submit" class="btn btn-primary" value="Sign in">
            </div>
          </form>
        </div>
      </div>
    </div>
</template>
<script>
  export default {
    data(){
      return {
        username: "",
        password: "",
        message: ""
      }
    },
    methods: {
      login(){
        this.message = ""
        fetch(import.meta.env.VITE_SERVER+"signin", {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({email:this.username, password:this.password})
        }).then(r =>{
          if (r.status == 404){
            r.json().then(x => this.message = x.message)
          }
          if (r.status == 200){
            r.json().then(x=> this.$store.commit("setUser", x))
            this.$router.push({name: "manager-home"})
          }
        })
      }
    }
  }
</script>