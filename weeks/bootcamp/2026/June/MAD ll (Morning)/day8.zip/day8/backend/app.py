from flask import Flask
from flask_security import Security, SQLAlchemyUserDatastore
from werkzeug.security import generate_password_hash
import os
from flask_cors import CORS
from celery import Celery, Task
from celery.schedules import crontab

from dep.cache import cache
from dep.models import db, User, Role
from dep.views import api
from dep.celery import daily_reminder, monthly_reminder


def celery_init_app(app: Flask) -> Celery:
    class FlaskTask(Task):
        def __call__(self, *args: object, **kwargs: object) -> object:
            with app.app_context():
                return self.run(*args, **kwargs)

    celery_app = Celery(app.name, task_cls=FlaskTask)
    celery_app.config_from_object(app.config["CELERY"])
    celery_app.set_default()
    app.extensions["celery"] = celery_app
    return celery_app


def create_app():
    app = Flask(__name__)
    CORS(app)

    # Generate a nice key using secrets.token_urlsafe()
    app.config['SECRET_KEY'] = os.environ.get("SECRET_KEY", 'pf9Wkove4IKEAXvy-cQkeDPhv9Cb3Ag-wyJILbq_dFw')
    # Generate a good salt for password hashing using: secrets.SystemRandom().getrandbits(128)
    app.config['SECURITY_PASSWORD_SALT'] = os.environ.get("SECURITY_PASSWORD_SALT", '146585145368132386173505678016728509634')


    # Use an in-memory db
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///model.db'
    # As of Flask-SQLAlchemy 2.4.0 it is easy to pass in options directly to the
    # underlying engine. This option makes sure that DB connections from the
    # pool are still valid. Important for entire application since
    # many DBaaS options automatically close idle connections.
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    app.config["CELERY"] = dict(
        broker_url="redis://localhost:6379/0",
        result_backend="redis://localhost:6379/1",
    )

    app.config["CACHE_TYPE"] = "RedisCache"
    app.config["CACHE_REDIS_URL"] = "redis://localhost:6379/2"


    #Initialising the database
    db.init_app(app)

    #Initialise caching
    cache.init_app(app)

    # Setup Flask-Security
    user_datastore = SQLAlchemyUserDatastore(db, User, Role)
    app.security = Security(app, user_datastore)

    with app.app_context():
        db.create_all()

        if not app.security.datastore.find_role("admin"):
            alice = app.security.datastore.create_user(name="Alice", 
                                                       email="alice@example.com", 
                                                       password=generate_password_hash("alice"))
            admin = app.security.datastore.create_role(name="admin")
            manager = app.security.datastore.create_role(name="manager")
            user = app.security.datastore.create_role(name="user")
            db.session.flush()
            alice.roles.append(admin)

        db.session.commit()

    celery = celery_init_app(app)

    # Initialise the routes
    app.register_blueprint(api)

    return app, celery


app, celery = create_app()


@celery.on_after_configure.connect
def setup_periodic_tasks(sender: Celery, **kwargs):
    sender.add_periodic_task(10, 
                             daily_reminder.s(), 
                             name="task1")
    sender.add_periodic_task(10, 
                             monthly_reminder.s(), 
                             name="task2")
    sender.add_periodic_task(crontab(minute="*"),
                            monthly_reminder.s(), 
                            name="task3")

    