from celery import shared_task
import csv
import os
from smtplib import SMTP
from email.message import EmailMessage
from flask import render_template

from dep.models import Product, User


@shared_task(bind=True)
def export(self):

    products = Product.query.all()

    field = ["id", "name", "category",
    "category_id", "rate", "stock", "metric"]

    with open(os.path.join("exports", self.request.id), "w") as file:
        writer = csv.DictWriter(file, fieldnames=field)
        writer.writeheader()

        for product in products:
            writer.writerow({
                "id": product.id,
                "name": product.name,
                "category_id": product.category_id,
                "category": product.category.name,
                "rate": product.rate,
                "stock": product.unit,
                "metric": product.metric,
            })


@shared_task
def monthly_reminder():
    server = SMTP("localhost", 1025)

    products = Product.query.all()

    for user in User.query.all():
        if not user.has_role("manager"):
            continue
        
        mail = EmailMessage()
        mail["FROM"] = "noreply@example.com"
        mail["To"] = user.email
        mail["Subject"] = "Monthly Report"
        mail.add_alternative(render_template("report.html",
                                             products=products),
                            subtype="html")
        server.send_message(mail)


@shared_task
def daily_reminder():
    server = SMTP("localhost", 1025)

    for user in User.query.all():
        if not user.has_role("user"):
            continue
        
        mail = EmailMessage()
        mail["FROM"] = "noreply@example.com"
        mail["To"] = user.email
        mail["Subject"] = "Daily Reminder"
        mail.set_content("Hi,\n We miss you...")
        server.send_message(mail)