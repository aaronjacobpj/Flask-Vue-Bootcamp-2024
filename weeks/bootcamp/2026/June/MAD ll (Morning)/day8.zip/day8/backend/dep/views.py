from flask import current_app as app
from flask import Blueprint, request, send_file
from flask_security import current_user, login_user, roles_required, roles_accepted, auth_required
from werkzeug.security import check_password_hash, generate_password_hash
from sqlalchemy import or_
import re
import os
from celery.result import AsyncResult
from dep.cache import cache

from dep.models import db, Category, ManagerCategory, Cart, Product
from dep.celery import export

api = Blueprint("views", __name__)


@api.route("/signin", methods=["POST"])
def user_login():
    email = request.json.get("email", "")
    password = request.json.get("password", "")

    user = app.security.datastore.find_user(email=email)

    if user is None or not check_password_hash(user.password, password):
        return {"message": "Invalid username or password", "code": "ERROR0001"}, 404

    login_user(user)
    return {"token": user.get_auth_token(), "roles": user.get_roles()}


@api.route("/manager/signup", methods=["POST"])
@roles_accepted("admin")
def signup_manager():
    name = request.json.get("name", "")
    email = request.json.get("email", "")
    password = request.json.get("password", "")

    user = app.security.datastore.find_user(email=email)

    if user:
        return {"message": "email already exist", "code": "ERROR0002"}, 409
    
    if not email or not re.match(r"\w+[@]\w+\.[a-z]+", email):
        return {"message": "Invalid email.", "code": "ERROR0003"}, 400
    
    if not name:
        return {"message": "name required.", "code": "ERROR0004"}, 400
    
    if not password:
        return {"message": "Invalid password", "code": "ERROR0005"}, 400
    
    user = app.security.datastore.create_user(name=name, 
                                              email=email,
                                              password=generate_password_hash(password))
    role = app.security.datastore.find_role("manager")
    user.roles.append(role)
    db.session.commit()

    return {"message": "Create user successfully."}, 201

@api.route("/user/signup", methods=["POST"])
def signup_user():
    name = request.json.get("name", "")
    email = request.json.get("email", "")
    password = request.json.get("password", "")

    user = app.security.datastore.find_user(email=email)

    if user:
        return {"message": "email already exist", "code": "ERROR0002"}, 409
    
    if not email or not re.match(r"\w+[@]\w+\.[a-z]+", email):
        return {"message": "Invalid email.", "code": "ERROR0003"}, 400
    
    if not name:
        return {"message": "name required.", "code": "ERROR0004"}, 400
    
    if not password:
        return {"message": "Invalid password", "code": "ERROR0005"}, 400
    
    user = app.security.datastore.create_user(name=name, 
                                              email=email,
                                              password=generate_password_hash(password))
    role = app.security.datastore.find_role("user")
    user.roles.append(role)
    db.session.commit()

    return {"message": "Create user successfully."}, 201


@api.route("/admin/category", methods=["PUT"])
@roles_accepted("admin")
def create_category():
    name = request.json.get("name", "")

    if not name:
        return {"message": "name required.", "code": "ERROR0004"}, 400
    
    category = Category.query.filter_by(name=name).first()

    if category:
        return {"message": "category already exist.", "code": "ERROR0006"}, 409
    
    category = Category(name=name)
    db.session.add(category)
    db.session.commit()

    return {"message": "Created category successfully."}, 201


@api.route("/categories")
@auth_required("token")
@cache.cached(timeout=10)
def get_categories():
    categories = Category.query.all()

    return [{"id": category.id, 
            "name": category.name,
            "delete": category.delete} 
             for category in categories]


@api.route("/admin/category", methods=["DELETE"])
@roles_accepted("admin")
def delete_categories():
    id = request.json.get("id", None)

    if not id:
        return {"message": "category not found", "code": "ERROR007"}, 404
    
    category = db.session.get(Category, id)
    if not category:
        return {"message": "category not found", "code": "ERROR007"}, 404
    
    db.session.delete(category)
    db.session.commit()

    return {"message": "deleted category successfully"}

@api.route("/admin/category", methods=["POST"])
@roles_accepted("admin")
def update_category():
    name = request.json.get("name", "")
    id = request.json.get("id", None)

    if not id:
        return {"message": "category not found", "code": "ERROR007"}, 404
    
    if not name:
        return {"message": "name required.", "code": "ERROR0004"}, 400
    
    category = Category.query.filter_by(name=name).first()

    if category:
        return {"message": "category already exist.", "code": "ERROR0006"}, 409
    
    category = db.session.get(Category, id)
    if not category:
        return {"message": "category not found", "code": "ERROR007"}, 404
    
    category.name = name
    db.session.commit()

    return {"message": "Created category successfully."}, 200


@api.route("/manager/category", methods=["PUT"])
@roles_accepted("manager")
def create_manager_category():
    name = request.json.get("name", "")

    if not name:
        return {"message": "name required.", "code": "ERROR0004"}, 400
    
    category = Category.query.filter_by(name=name).first()

    if category or ManagerCategory.query.filter_by(name=name).first():
        return {"message": "category already exist.", "code": "ERROR0006"}, 409
    
    category = ManagerCategory(name=name)
    db.session.add(category)
    db.session.commit()

    return {"message": "Created category successfully."}, 201


@api.route("/manager/categories")
@roles_accepted("admin", "manager")
def get_manager_categories():
    categories = ManagerCategory.query.all()

    return [{"id": category.id, 
             "name": category.name,
             "category_id": category.category_id} 
             for category in categories]


@api.route("/manager/category", methods=["POST"])
@roles_accepted("manager")
def update_manager_category():
    name = request.json.get("name", "")
    id = request.json.get("id", None)
    category_id = request.json.get("category_id", None)
    
    if not name:
        return {"message": "name required.", "code": "ERROR0004"}, 400
    
    category = Category.query.filter_by(name=name).first()

    if category or ManagerCategory.query.filter_by(name=name).first():
        return {"message": "category already exist.", "code": "ERROR0006"}, 409
    
    category = db.session.get(ManagerCategory, id)
    if not category:
        category = ManagerCategory(name=name)
        category.category_id = category_id
        db.session.add(category)
    else:
        category.name = name

    db.session.commit()

    return {"message": "Created category successfully."}, 200


@api.route("/manager/category", methods=["DELETE"])
@roles_accepted("manager")
def delete_manager_categories():
    id = request.json.get("id", None)

    if not id:
        return {"message": "category not found", "code": "ERROR007"}, 404
    
    category = db.session.get(ManagerCategory, id)
    if not category:
        return {"message": "category not found", "code": "ERROR007"}, 404
    
    db.session.delete(category)
    db.session.commit()

    return {"message": "deleted category successfully"}


@api.route("/manager/category/final", methods=["DELETE"])
@roles_accepted("manager")
def delete_final_categories():
    id = request.json.get("id", None)

    if not id:
        return {"message": "category not found", "code": "ERROR007"}, 404
    
    category = db.session.get(Category, id)
    if not category:
        return {"message": "category not found", "code": "ERROR007"}, 404
    
    category.delete = True
    db.session.commit()

    return {"message": "Asked for approval successfully"}


@api.route("/admin/category/approve", methods=["POST"])
@roles_accepted("admin")
def approve_category():
    id = request.json.get("id")
    category_id = request.json.get("category_id")

    
    if id and not category_id:
        category = db.session.get(ManagerCategory, id)
        entry = Category(name=category.name)
        db.session.delete(category)
        db.session.add(entry)

    elif category_id:
        category = ManagerCategory.query.filter_by(category_id=category_id).first()
        entry = db.session.get(Category, category_id)
        if category:
            entry.name = category.name
            db.session.delete(category)
        elif entry.delete:
            db.session.delete(entry)
    else:
        return {"message": "invalid request"}, 400

    db.session.commit()
    return {"message": "updated category successfully"}, 200


@api.route("/admin/category/reject", methods=["POST"])
@roles_accepted("admin")
def reject_category():
    id = request.json.get("id")
    category_id = request.json.get("category_id")

    category = ManagerCategory.query.filter(or_(ManagerCategory.id == id,
                                                ManagerCategory.category_id==category_id)).all()
    if category:
        for each in category:
            db.session.delete(each)

    category = db.session.get(Category, category_id)
    if category and category.delete:
        category.delete = False
    db.session.commit()
    return {"message": "updated category successfully"}, 200


@api.route("/category/<int:id>/product", methods=["PUT"])
@roles_accepted("manager")
def create_product(id):
    if not id:
        return {"message": "category not found", "code": "ERROR007"}, 404
    
    category = db.session.get(Category, id)
    if not category:
        return {"message": "category not found", "code": "ERROR007"}, 404
    
    form = request.json

    name = form.get("name", None)
    metric = form.get("metric", None)
    units = form.get("units", None)
    rate = form.get("rate", None)

    if not name:
        return {"message": "name required.", "code": "ERROR0004"}, 400
    
    if not isinstance(metric, int) or metric < 1:
        return {"message": "invalid metric", "code": "ERROR0008"}, 400
    
    elif not isinstance(units, int) or units < 0:
        return {"message": "invalid units", "code": "ERROR0009"}, 400
    
    elif not isinstance(rate, (int, float)) or rate < 0:
        return {"message": "invalid rate", "code": "ERROR0010"}, 400
    
    product = Product(name=name,
                      metric=metric,
                      unit=units,
                      rate=rate,
                      category_id=id)
    db.session.add(product)
    db.session.commit()

    return {"message": "Created Product Successfully."}, 201


@api.route("/category/<int:id>/products")
@auth_required("token")
def get_products(id):
    products = Product.query.filter_by(category_id=id).all()
    return [{"id": product.id,
             "name": product.name,
             "metric": product.metric,
             "rate": product.rate,
             "units": product.unit,
             "category_id": product.category_id
             }for product in products ]


@api.route("/product/<int:id>", methods=["DELETE"])
@roles_accepted("manager")
def delete_products(id):

    product = db.session.get(Product, id)
    if not product:
        return {"message": "Product not found", "code": 'ERROR0011'}, 404
    
    db.session.delete(product)
    db.session.commit()

    return {"message": "Delete Product Successfully."}, 200


@api.route("/product/<int:id>", methods=["POST"])
@roles_accepted("manager")
def update_product(id):

    category_id = request.json.get("category_id")

    product = db.session.get(Product, id)
    if not product:
        return {"message": "Product not found", "code": 'ERROR0011'}, 404
    
    if not category_id:
        return {"message": "category not found", "code": "ERROR007"}, 404
    
    category = db.session.get(Category, category_id)
    if not category:
        return {"message": "category not found", "code": "ERROR007"}, 404
    
    form = request.json

    name = form.get("name", None)
    metric = form.get("metric", None)
    units = form.get("units", None)
    rate = form.get("rate", None)

    if not name:
        return {"message": "name required.", "code": "ERROR0004"}, 400
    
    if not isinstance(metric, int) or metric < 1:
        return {"message": "invalid metric", "code": "ERROR0008"}, 400
    
    elif not isinstance(units, int) or units < 0:
        return {"message": "invalid units", "code": "ERROR0009"}, 400
    
    elif not isinstance(rate, (int, float)) or rate < 0:
        return {"message": "invalid rate", "code": "ERROR0010"}, 400
    
    product.name=name
    product.metric=metric
    product.unit=units
    product.rate=rate
    product.category_id=category_id
    db.session.commit()

    return {"message": "Updated Product Successfully."}, 200


@api.route("/products")
def search_products():
    product = request.args.get("q", "")
    category = request.args.get("category", "")

    categories = list(map(lambda x: x[0],
                     db.session.query(Category.id)
                     .filter(Category.name.ilike(f"%{category}%")).all()))

    products = Product.query.filter(Product.name.like(f"%{product}%"),
                                    Product.category_id.in_(categories)).all()
    
    return [{"id": product.id,
             "name": product.name,
             "category_id": product.category_id,
             "rate": product.rate,
             "stock": product.unit,
             "metric": product.metric} for product in products]


@api.route("/product/<int:id>/cart")
@auth_required("token")
def add_to_cart(id):
    product = db.session.get(Product, id)
    if not product:
        return {"message": "Product not found", "code": 'ERROR0011'}, 404
    
    item = Cart.query.filter_by(user_id=current_user.id,
                                product_id=product.id).first()
    
    if item:
        item.unit += 1
    else:
        item = Cart(user_id=current_user.id,
                    product_id=product.id,
                    unit=1)
        db.session.add(item)

    db.session.commit()

    return {"message": "added item to cart."}, 200
        

@api.route("/cart")
def get_cart():

    items = Cart.query.filter_by(user_id=current_user.id).all()

    return[{"id": item.id,
            "unit": item.unit,
            "product-id": item.product.id,
             "name": item.product.name,
             "category_id": item.product.category_id,
             "rate": item.product.rate,
             "stock": item.product.unit,
             "metric": item.product.metric} for item in items]


@api.route("/cart/remove/<int:id>")
@auth_required("token")
def remove_cart_item(id):
    product = db.session.get(Cart, id)

    print(product)
    if not product or not product.user_id == current_user.id:
        return {"message": "item not found"}, 404
    
    print(product)
    product.unit -= 1

    if product.unit <= 0:
        db.session.delete(product)

    db.session.commit()
    return {"message": "request successful"}, 200


@api.route("/buy")
def user_buy():

    items = Cart.query.filter_by(user_id=current_user.id).all()

    for item in items:
        if item.unit <= item.product.unit:
            item.product.unit -= item.unit
            db.session.delete(item)

    db.session.commit()
    return {"message": "request successful"}, 200


@api.route("/export")
def create_export():
    result = export.delay()
    return {"id": result.id}

@api.route("/export/<id>")
def export_status(id):
    result = AsyncResult(id)
    return {"status": result.status}

@api.route("/export/<id>/download")
def export_download(id):
    result = AsyncResult(id)
    if result.status == "SUCCESS":
        return send_file(os.path.join("exports",
                                      id),
                        download_name=id+".csv",
                        as_attachment=True)


@api.route("/chart")
def render_chart():
    products = []
    stocks = []
    for product in Product.query.all():
        products.append(product.name)
        stocks.append(product.unit)

    return {"products": products,
            "stocks": stocks}