import { createRouter, createWebHistory } from 'vue-router'
import LoginView from '../views/LoginView.vue'
import AdminLayoutView from "@/views/admin/AdminLayoutView.vue"
import AdminLoginView from "@/views/admin/AdminLoginView.vue"
import AdminDashboardView from "@/views/admin/AdminDashboardView.vue"
import AdminCreateManagerView from "@/views/admin/AdminCreateManagerView.vue"
import AdminCategoryView from "@/views/admin/AdminCategoryView.vue"
import UserLayoutView from "@/views/user/UserLayoutView.vue"
import UserLoginView from "@/views/user/UserLoginView.vue"
import UserSignupView from "@/views/user/UserSignupView.vue"
import UserHomeView from "@/views/user/UserHomeView.vue"
import UserCartView from "@/views/user/UserCartView.vue"
import ManagerLayoutView from "@/views/manager/ManagerLayoutView.vue"
import ManagerLoginView from "@/views/manager/ManagerLoginView.vue"
import ManagerCategoryView from "@/views/manager/ManagerCategoryView.vue"
import ManagerDashboardView from "@/views/manager/ManagerDashboardView.vue"
import ManagerProductView from "@/views/manager/ManagerProductView.vue"

import store from '@/store'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: LoginView,
    },
    {
      path: "/admin",
      name: "admin",
      component: AdminLayoutView,
      beforeEnter(to, from) {
        if (!to.name.match("admin-login") && !store.getters.getRoles.includes("admin"))
          return { name: "admin-login" }
      },
      children: [
        {
          path: "",
          name: "admin-login",
          component: AdminLoginView
        },
        {
          path: "home",
          name: "admin-dashboard",
          component: AdminDashboardView
        },
        {
          path: "create/manager",
          name: "admin-create-manager",
          component: AdminCreateManagerView
        },
        {
          path: "create/category",
          name: "admin-create-category",
          component: AdminCategoryView
        }
      ]
    },
    {
      path: "/user",
      name: "user",
      component: UserLayoutView,
      beforeEnter(to, from) {
        if (!["user-login", "user-signup"].includes(to.name) &&
          !store.getters.getRoles.includes("user"))
          return { name: "user-login" }
      },
      children: [
        {
          path: "",
          name: "user-login",
          component: UserLoginView
        },
        {
          path: "signup",
          name: "user-signup",
          component: UserSignupView
        },
        {
          path: "home",
          name: "user-home",
          component: UserHomeView
        },
        {
          path: "cart",
          name: "user-cart",
          component: UserCartView
        }
      ]
    },
    {
      path: "/manager",
      name: "manager",
      component: ManagerLayoutView,
      beforeEnter(to, from) {
        if (!to.name.match("manager-login") && !store.getters.getRoles.includes("manager"))
          return { name: "manager-login" }
      },
      children: [
        {
          path: "",
          name: "manager-login",
          component: ManagerLoginView
        },
        {
          path: "home",
          name: "manager-home",
          component: ManagerDashboardView
        },
        {
          path: "category",
          name: "manager-category",
          component: ManagerCategoryView
        },
        {
          path: ":id/product",
          name: "manager-product",
          component: ManagerProductView,
          props: true
        }
      ]
    }
  ],
})

export default router
