import { createStore } from "vuex";

export default createStore({
    state() {
        return {
            user: {
                token: null,
                roles: [],
            },
            categories: [],
            managerCategories: [],
            alerts: [],
            metrics: ["mg", "g", "kg", "mm", "cm", "m", "mL", "L",
            ],
            categoryProducts: []
        }
    },
    mutations: {
        setUser(state, value) {
            localStorage.setItem("user", JSON.stringify(value));
            state.user = value;
        },
        setCategories(state, value) {
            state.categories = value
        },
        addAlert(state, value) {
            state.alerts.push(value)
        },
        removeAlert(state, idx) {
            state.alerts = state.alerts.filter(x, i => i != idx)
        },
        setManagerCategories(state, value) {
            state.managerCategories = value;
        },
        setCategoryProducts(state, value){
            state.categoryProducts = value
        }
    },
    getters: {
        getUser(state) {
            return state.user
        },
        getRoles(state) {
            return state.user["roles"]
        },
        getToken(state) {
            return state.user["token"]
        },
        getCategories(state) {
            return state.categories
        },
        getAlerts(state) {
            return state.alerts
        },
        getManagerCategories(state) {
            return state.managerCategories
        },
        getCombinedCategories(state) {
            let result = state.categories.map(x => {
                x = Object.assign({}, x)
                x["category_id"] = x["id"]
                x["id"] = null
                x["temp"] = false
                return x
            })
            state.managerCategories.forEach(x => {
                x = Object.assign({}, x)
                x["temp"] = true
                result.push(x)
            })
            return result
        },
        getMetrics(state) {
            return state.metrics
        },
        getCategoryProducts(state){
            return state.categoryProducts
        }
    },
    actions: {
        getCategories(context) {
            fetch(import.meta.env.VITE_SERVER + "categories", {
                headers: {
                    "Authentication-Token": context.getters.getToken
                }
            }).then(r => {
                if (r.status == 200) {
                    r.json().then(x => context.commit("setCategories", x))
                }
            })
        },
        getManagerCategories(context) {
            fetch(import.meta.env.VITE_SERVER + "/manager/categories", {
                headers: {
                    "Authentication-Token": context.getters.getToken
                }
            }).then(r => {
                if (r.status == 200) {
                    r.json().then(x => context.commit("setManagerCategories", x))
                }
            })
        },
        fetchAllCategories(context) {
            context.dispatch("getCategories")
            context.dispatch("getManagerCategories")
        },
        getCategoryProducts(context, id) {
            fetch(import.meta.env.VITE_SERVER + `category/${id}/products`, {
                headers: {
                    "Authentication-Token": context.getters.getToken
                }
            }).then(r => {
                if (r.status == 200) {
                    r.json().then(x => context.commit("setCategoryProducts", x))
                }
            })
        }
    }
});