<script setup>
    import { RouterLink, RouterView } from "vue-router"
</script>
<template>
    <nav class="navbar navbar-expand-lg bg-body-tertiary" v-show="$store.getters.getRoles.includes('manager')">
        <div class="container-fluid">
            <RouterLink class="navbar-brand" to="/manager/home">Manager</RouterLink>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
                aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <RouterLink class="nav-link" :to="{name: 'manager-category'}">Category</RouterLink>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" @click="createExport">Export</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <router-view></router-view>
</template>
<script>
    export default {
        data() {
            return {
                id: null
            }
        },
        methods: {
            createExport() {
                fetch(import.meta.env.VITE_SERVER + `export`, {
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(r => {
                    if (r.status == 200) {
                        r.json().then(x =>{ 
                            this.id = x.id
                            this.exportStatus()
                        })

                    }
                })
            },
            exportStatus() {
                fetch(import.meta.env.VITE_SERVER + `export/`+this.id, {
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(r => {
                    if (r.status == 200) {
                        r.json().then(x => {
                            if(["PENDING", "STARTED"].includes(x["status"]))
                                setTimeout(this.exportStatus(), 1000)
                            else if(x["status"].match("SUCCESS"))
                                open(import.meta.env.VITE_SERVER+"export/"+this.id+"/download")
                        })
                    }
                })
            },
        }
    }
</script>