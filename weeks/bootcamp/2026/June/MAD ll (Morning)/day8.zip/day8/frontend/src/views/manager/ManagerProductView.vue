<template>
    <div class="row">
        <div class="col ms-2">
            <div class="mb-3">
                <label for="formGroupExampleInput" class="form-label">Name</label>
                <input type="text" class="form-control" id="formGroupExampleInput" v-model="form.name"
                    placeholder="Carrots">
            </div>
            <div class="invalid-feedback" style="display: block;">
                {{ error["name"] }}
            </div>
        </div>
        <!-- <div class="col">
            <div class="mb-3">
                <label for="formGroupExampleInput" class="form-label">Category</label>
                <select class="form-select" v-model="form.category">
                    <option value="null">Select a Category</option>
                    <option :value="category['id']" v-for="(category, i) in $store.getters.getCategories">
                        {{ category['name'] }}
                    </option>
                </select>
                <div class="invalid-feedback" style="display: block;">
                    {{ error["category"] }}
                </div>
            </div>
        </div> -->
        <div class="col">
            <div class="mb-3">
                <label for="formGroupExampleInput" class="form-label">Metric</label>
                <select class="form-select" v-model="form.metric">
                    <option value="null">Select a unit</option>
                    <option :value="i+1" v-for="(metric, i) in $store.getters.getMetrics">
                        {{ metric }}
                    </option>
                </select>
                <div class="invalid-feedback" style="display: block;">
                    {{ error["metric"] }}
                </div>
            </div>
        </div>
        <div class="col">
            <div class="mb-3">
                <label for="formGroupExampleInput" class="form-label">Stock</label>
                <input type="number" class="form-control" id="formGroupExampleInput" v-model="form.units"
                    placeholder="Example input placeholder">
                <div class="invalid-feedback" style="display: block;">
                    {{ error["units"] }}
                </div>
            </div>
        </div>
        <div class="col">
            <div class="mb-3">
                <label for="formGroupExampleInput" class="form-label">rate</label>
                <input type="number" class="form-control" id="formGroupExampleInput" v-model="form.rate"
                    placeholder="Example input placeholder">
            </div>
            <div class="invalid-feedback" style="display: block;">
                {{ error["rate"] }}
            </div>
        </div>
        <div class="col me-3">
            <div class="mb-3">
                <label for="formGroupExampleInput" class="form-label" style="visibility: hidden;">
                    Submit
                </label>
                <input type="button" class="form-control btn btn-primary" value="Submit" @click="addProduct">
            </div>
        </div>
    </div>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Category</th>
                <th scope="col">Metric</th>
                <th scope="col">Stock</th>
                <th scope="col">rate</th>
            </tr>
        </thead>
        <tbody>
            <tr v-for="product in $store.getters.getCategoryProducts">
                <th scope="row">1</th>
                <td>{{ product["name"] }}</td>
                <td>{{ categories[product["category_id"]] }}</td>
                <td>{{ $store.getters.getMetrics[product['metric']-1] }}</td>
                <td>{{ product["units"] }}</td>
                <td>{{ product["rate"] }}</td>
                <td>
                    <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal"
                        @click="this.editForm=product">
                        Edit
                    </button>
                </td>
                <td>
                    <button class="btn btn-danger" @click="deleteProduct(product['id'])">Delete</button>
                </td>
            </tr>
        </tbody>
    </table>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col ms-2">
                            <div class="mb-3">
                                <label for="formGroupExampleInput" class="form-label">Name</label>
                                <input type="text" class="form-control" id="formGroupExampleInput"
                                    v-model="editForm.name" placeholder="Carrots">
                            </div>
                            <div class="invalid-feedback" style="display: block;">
                                {{ errorEditForm["name"] }}
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="mb-3">
                                <label for="formGroupExampleInput" class="form-label">Category</label>
                                <select class="form-select" v-model="editForm.category_id">
                                    <option value="null">Select a Category</option>
                                    <option :value="category['id']"
                                        v-for="(category, i) in $store.getters.getCategories">
                                        {{ category['name'] }}
                                    </option>
                                </select>
                                <div class="invalid-feedback" style="display: block;">
                                    {{ errorEditForm["category"] }}
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="mb-3">
                                <label for="formGroupExampleInput" class="form-label">Metric</label>
                                <select class="form-select" v-model="editForm.metric">
                                    <option value="null">Select a unit</option>
                                    <option :value="i+1" v-for="(metric, i) in $store.getters.getMetrics">
                                        {{ metric }}
                                    </option>
                                </select>
                                <div class="invalid-feedback" style="display: block;">
                                    {{ errorEditForm["metric"] }}
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="mb-3">
                                <label for="formGroupExampleInput" class="form-label">Stock</label>
                                <input type="number" class="form-control" id="formGroupExampleInput"
                                    v-model="editForm.units" placeholder="Example input placeholder">
                                <div class="invalid-feedback" style="display: block;">
                                    {{ errorEditForm["units"] }}
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="mb-3">
                                <label for="formGroupExampleInput" class="form-label">rate</label>
                                <input type="number" class="form-control" id="formGroupExampleInput"
                                    v-model="editForm.rate" placeholder="Example input placeholder">
                            </div>
                            <div class="invalid-feedback" style="display: block;">
                                {{ errorEditForm["rate"] }}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" @click="updateProduct">Save changes</button>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        props: ["id"],
        created() {
            this.$store.dispatch("getCategories")
            this.$store.dispatch("getCategoryProducts", this.id)
        },
        data() {
            return {
                form: {
                    name: null,
                    category: null,
                    metric: null,
                    units: null,
                    rate: null
                },
                error: {
                    name: null,
                    category: null,
                    metric: null,
                    units: null,
                    rate: null
                },
                editForm: {
                    id: null,
                    name: null,
                    category: null,
                    metric: null,
                    units: null,
                    rate: null
                },
                errorEditForm: {
                    name: null,
                    category: null,
                    metric: null,
                    units: null,
                    rate: null
                }
            }
        },
        methods: {
            addProduct() {
                this.error = {
                    name: null,
                    category: null,
                    metric: null,
                    units: null,
                    rate: null
                }
                let id = this.form["category"]
                fetch(import.meta.env.VITE_SERVER + `/category/${this.id}/product`, {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify(this.form)
                }).then(r => {
                    if (r.status == 404) {
                        this.error["category"] = "Category not found"
                    }
                    else if (r.status == 400) {
                        r.json().then(x => {
                            if (x["code"] == "ERROR0004")
                                this.error["name"] = x.message
                            else if (x["code"] == "ERROR0008")
                                this.error["metric"] = x.message
                            else if (x["code"] == "ERROR0009")
                                this.error["units"] = x.message
                            else if (x["code"] == "ERROR0010")
                                this.error["rate"] = x.message
                        })
                    }
                    else if (r.status == 201) {
                        this.$store.commit("addAlert", "Created product successfully")
                        this.$store.dispatch("getCategoryProducts", this.id)
                    }
                })
            },
            deleteProduct(pid) {
                fetch(import.meta.env.VITE_SERVER + `product/${pid}`, {
                    method: "DELETE",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(r => {
                    if (r.status == 200) {
                        this.$store.commit("addAlert", "Deleted product successfully")
                        this.$store.dispatch("getCategoryProducts", this.id)
                    }
                })
            },
            updateProduct() {
                this.error = {
                    name: null,
                    category: null,
                    metric: null,
                    units: null,
                    rate: null
                }
                let id = this.editForm["id"]
                fetch(import.meta.env.VITE_SERVER + `/product/${id}`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authentication-Token": this.$store.getters.getToken
                    },
                    body: JSON.stringify(this.editForm)
                }).then(r => {
                    if (r.status == 404) {
                        this.errorEditForm["category"] = "Category not found"
                    }
                    else if (r.status == 400) {
                        r.json().then(x => {
                            if (x["code"] == "ERROR0004")
                                this.errorEditForm["name"] = x.message
                            else if (x["code"] == "ERROR0008")
                                this.errorEditForm["metric"] = x.message
                            else if (x["code"] == "ERROR0009")
                                this.errorEditForm["units"] = x.message
                            else if (x["code"] == "ERROR0010")
                                this.errorEditForm["rate"] = x.message
                        })
                    }
                    else if (r.status == 200) {
                        this.$store.commit("addAlert", "Updated product successfully")
                        this.$store.dispatch("getCategoryProducts", this.id)
                    }
                })
            }
        },
        computed: {
            categories() {
                let result = {}
                this.$store.getters.getCategories.forEach(x => {
                    result[x["id"]] = x["name"]
                })
                return result
            }
        }
    }
</script>