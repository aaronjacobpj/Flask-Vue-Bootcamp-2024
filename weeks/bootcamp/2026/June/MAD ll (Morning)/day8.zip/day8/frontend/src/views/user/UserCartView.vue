<script setup>
</script>
<template>
    <div class="row">
        <div class="col-9" style="border-right:1px solid grey; height: 100vh;">
            <div class="row my-3" v-for="item in items" style="border-bottom: 1px solid rgb(174, 172, 172);">
                <h5> {{ item.name }}</h5>
                <span>Rs. {{ item.rate }} / {{ $store.getters.getMetrics[item.metric-1] }}</span>
                <span style="color: red;" v-if="item.unit > item.stock">
                    You can only buy {{ item.stock }} items
                </span>
                <span>Units: {{ item.unit }} </span>
                <span>Total: {{ item.unit * item.rate }} </span>
                <button class="btn" style="color: red;" @click="removeItem(item.id)">
                    Remove item
                </button>
            </div>
        </div>
        <div class="col-3">
            <h4>Summary</h4>
            <span>Total : {{ items.map(x => x["unit"]*x["rate"]).reduce((a, b) => a+b, 0) }}</span>
            <br>
            <button class="btn btn-primary" style="width: 100%;" @click="buy">
                Buy
            </button>
        </div>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                items: []
            }
        },
        created() {
            this.getItems()
        },
        methods: {
            getItems() {
                fetch(import.meta.env.VITE_SERVER + "cart", {
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(r => {
                    if (r.status == 200) {
                        r.json().then(x => this.items = x)
                    }
                })
            },
            removeItem(id) {
                fetch(import.meta.env.VITE_SERVER + "cart/remove/" + id, {
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(r => {
                    if (r.status == 200) {
                        this.$store.commit("addAlert", "Removed item from cart")
                        this.getItems()
                    }
                })
            },
            buy() {
                fetch(import.meta.env.VITE_SERVER + "buy", {
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(r => {
                    if (r.status == 200) {
                        this.getItems()
                        this.$store.commit("addAlert", "Request successful")

                    }
                })
            },
        }
    }
</script>