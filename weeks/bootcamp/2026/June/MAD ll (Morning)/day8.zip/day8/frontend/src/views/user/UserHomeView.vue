<template>
    <div class="row">
        <div class="col-6">
            <div class="mb-3 ms-2">
                <label for="formGroupExampleInput" class="form-label">Example label</label>
                <input type="text" class="form-control" id="formGroupExampleInput"
                    placeholder="Example input placeholder" v-model="query">
            </div>
        </div>
        <div class="col-3">
            <div class="mb-3 ms-2">
                <label for="formGroupExampleInput" class="form-label">Example label</label>
                <select class="form-select" v-model="type">
                    <option value="q">Product</option>
                    <option value="category">Category</option>
                </select>
            </div>
        </div>
        <div class="col-3">
            <div class="mb-3 me-2">
                <label for="formGroupExampleInput" class="form-label" style="visibility: hidden;">Example label</label>
                <input type="submit" class="form-control btn btn-primary" 
                @click="search" value="Search">
            </div>
        </div>
    </div>
    <div class="container-fluid d-flex flex-wrap">
        <div class="card col-2 ms-2" v-for="product in products">
            <div class="card-body">
                <h5>{{ product.name }}</h5>
                <span>Rs. {{ product.rate }} / {{ $store.getters.getMetrics[product.metric-1] }}</span>
                <br>
                <button class="btn btn-primary my-1" @click="addtoCart(product.id)">Add to Cart</button>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                query: "",
                type: "q",
                products: []
            }
        },
        created(){
            this.search()
        },
        methods: {
            search() {
                let query = new URLSearchParams();
                query.append(this.type, this.query)
                fetch(import.meta.env.VITE_SERVER + `products?`+query.toString(), {
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(r => {
                    if (r.status == 200) {
                        r.json().then(x => this.products = x)
                    }
                })
            },
            addtoCart(id){
                fetch(import.meta.env.VITE_SERVER + `product/${id}/cart?`, {
                    headers: {
                        "Authentication-Token": this.$store.getters.getToken
                    }
                }).then(r => {
                    if (r.status == 200) {
                        r.json().then(x => this.$store.commit("addAlert", "Added item to cart"))
                    }
                })
            }
        }
    }
</script>