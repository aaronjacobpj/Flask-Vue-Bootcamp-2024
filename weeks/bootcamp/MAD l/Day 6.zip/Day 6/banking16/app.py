from flask import Flask


def create_app():

    from werkzeug.security import generate_password_hash
    from models import db, User

    app = Flask(__name__)

    app.config["SECRET_KEY"] = "asdfghjrtyuixcvbn"
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///model.db"

    db.init_app(app)

    with app.app_context():
        db.create_all()

    from views import api

    app.register_blueprint(api)

    with app.app_context():
        if not User.query.filter_by(email="grace@example.com").first():
            user = User(firstname="Grace",
                        lastname="Turner",
                        email="grace@example.com",
                        password=generate_password_hash("admin"),
                        balance=0,
                        role="admin")
            db.session.add(user)
            db.session.commit()

    return app

app = create_app()
