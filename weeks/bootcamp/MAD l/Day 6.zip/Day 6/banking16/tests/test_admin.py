from tests.config import client, app, admin


def test_admin_created(admin):
    assert admin.firstname == "Grace"