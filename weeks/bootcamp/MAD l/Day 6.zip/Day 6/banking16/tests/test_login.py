from tests.config import app, client, admin


def test_login(client, admin):
    response = client.post("/signin", data={
        "email": admin.email,
        "password": "admin"
    },follow_redirects=True)

    assert response.status_code == 200


def test_invalid_credentials(client, admin):
    response = client.post("/signin", data={
        "email": admin.email+"dsins",
        "password": "admin"
    },follow_redirects=True)
    
    assert "Invalid email or password" in response.text


def test_get_login_page(client):
    response = client.get("/signin")

    assert 'action="/signin"' in response.text

