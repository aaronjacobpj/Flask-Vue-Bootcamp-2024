from flask import Flask, render_template, request
from models import db, Review


app = Flask(__name__)

app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///model.db"

db.init_app(app)

with app.app_context():
    db.create_all()

@app.route("/", methods=["GET", "POST"])
def review():
    if request.method == "GET":
        reviews = Review.query.all()

        return render_template("index.html", reviews=reviews)
    
    elif request.method == "POST":

        rating = request.form.get("rating", type=int)
        review = request.form.get("review")

        if not review:
            return render_template("index.html", 
                                    invalid_review=True)

        if not isinstance(rating, int) or not 1 <= rating <= 5:
            return render_template("index.html", 
                                    invalid_rating=True)
        
        review = Review(rating=rating,
                        review=review)
        db.session.add(review)
        db.session.commit()

        reviews = Review.query.all()

        return render_template("index.html", reviews=reviews)
