from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class Review(db.Model):

    id = db.Column(db.Integer(), primary_key=True)
    rating = db.Column(db.Numeric())
    review = db.Column(db.String())
    