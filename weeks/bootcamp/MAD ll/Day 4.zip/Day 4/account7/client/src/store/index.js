import { createStore } from "vuex";

export default createStore({
    state()
    {
        var roles = []
        var token = null
        if(sessionStorage.getItem("roles")){
            roles = sessionStorage.getItem("roles")
            token = sessionStorage.getItem("token")
        }
        return{
            URL: "http://127.0.0.1:5000/api/",
            roles: roles,
            token: token,
            profile: {},
            statement: [],
            graph: [],
            deposits: []
        }
    },
    getters:{
        getRoles(state)
        {
            return state.roles;
        },
        getProfile(state)
        {
            return state.profile;
        },
        getToken(state)
        {
            return state.token;
        },
        getStatement(state)
        {
            return state.statement;
        },
        getGraph(state){
            return state.graph;
        },
        getDeposits(state)
        {
            return state.deposits;
        }
    },
    mutations:{
        setRoles(state, value)
        {
            sessionStorage.setItem("roles", value);
            state.roles = value;
        },
        setToken(state, value)
        {
            sessionStorage.setItem("token", value);
            state.token = value;
        },
        clearSession(state)
        {
            state.roles = [];
            state.token = null;
            sessionStorage.removeItem("token");
            sessionStorage.removeItem("roles");
        },
        setProfile(state, value)
        {
            state.profile = value;
        },
        setStatement(state, value)
        {
            state.statement = value;
        },
        setGraph(state, value)
        {
            state.graph = value;
        },
        setDeposit(state, value)
        {
            state.deposits = value
        }
    },
    actions:{
        setProfile({commit, state})
        {
            fetch(state.URL+"user/profile",{
                headers:{
                    "Authentication-Token": state.token
                }
            }).then(response=>{
                if(response.status == 200)
                {
                    return response.json()
                }
                else
                {
                    return {}
                }
            }).then(value=>{
                commit("setProfile", value);
            })
        },
        getStatement({commit, state})
        {
            fetch(state.URL+"user/statement",{
                headers:{
                    "Authentication-Token": state.token
                }
            }).then(response=>{
                if(response.status == 200)
                {
                    return response.json()
                }
                else
                {
                    return []
                }
            }).then(value=>{
                commit("setStatement", value);
            })
        },
        getGraph({commit, state})
        {
            fetch(state.URL+"admin/graph",{
                headers:{
                    "Authentication-Token": state.token
                }
            }).then(response=>{
                if(response.status == 200)
                {
                    return response.json()
                }
                else
                {
                    return []
                }
            }).then(value=>{
                commit("setGraph", value);
            })
        },
        getDeposits({commit, state})
        {
            fetch(state.URL+"admin/deposit",{
                headers:{
                    "Authentication-Token": state.token
                }
            }).then(response=>{
                if(response.status == 200)
                {
                    return response.json()
                }
                else
                {
                    return []
                }
            }).then(value=>{
                commit("setDeposit", value);
            })
        }
    }
})