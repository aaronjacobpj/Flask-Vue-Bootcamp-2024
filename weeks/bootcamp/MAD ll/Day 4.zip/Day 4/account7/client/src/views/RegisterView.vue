<script setup>
    import router from "@/router";
</script>
<template>
    <div class="container-fluid" id="form-container">
        <div class="card">
            <div class="card-body">
                <h3 class="card-title" align="center">Register</h3>
                <form @submit="register">
                    <div class="row">
                        <div class="col">
                            <label for="fullname-input" class="form-label">Full Name</label>
                            <input type="text" class="form-control" placeholder="Full Name" 
                                id="fullname-input" aria-label="Full Name" v-model="fullname"
                                @focusout="validate_fullname">
                            <div class="valid-feedback" v-if="fullname != null" :style="{display: valid['fullname']}">
                                Looks good!
                            </div>
                            <div class="invalid-feedback" :style="{display: error['fullname']}">
                                Please type your full name.
                            </div>
                        </div>
                        <div class="col">
                            <label for="email-input" class="form-label">Email</label>
                            <input type="email" class="form-control" placeholder="Email" id="email-input" 
                             v-model="email" aria-label="Email">
                             <div class="invalid-feedback" :style="{display: error['email']}">
                                Please type a valid email.
                            </div>
                            <div class="invalid-feedback" :style="{display: error['exist']}">
                                Email already exist
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <label for="password-input" class="form-label">Password</label>
                            <input type="password" class="form-control" placeholder="Password" id="password-input" 
                                v-model="password" aria-label="Password">
                            <div class="invalid-feedback" :style="{display: error['password']}">
                                Please type a valid password.
                            </div>
                        </div>
                        <div class="col">
                            <label for="re-password-input" class="form-label">Password</label>
                            <input type="password" class="form-control" placeholder="Password" id="re-password-input" 
                                v-model="repassword" aria-label="Password">
                            <div class="invalid-feedback" :style="{display: error['password']}">
                                Please type a valid password.
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col" style="padding: 10px;display: flex;justify-content: center;">
                            <input type="submit" class="btn btn-primary" value="Signin" aria-label="Signin">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>
<script>
    export default
    {
        data(){
            return{
                email: null,
                password: null,
                repassword: null,
                fullname: null,
                error: {
                    email: "none",
                    fullname: "none",
                    password: "none",
                    exist: "none"
                },
                valid: {
                    email: "none",
                    fullname: "none",
                }
            }
        },
        methods: {
            validate_fullname()
            {                    
                this.valid["fullname"] = "none";
                this.error["fullname"] = "none";

                if(this.fullname != null && this.fullname.length > 2){
                    this.valid["fullname"] = "block";
                    return true;
                }
                else{
                    this.error["fullname"] = "block";
                    return false;
                }
            },
            register(event){
                this.error["exist"] = "none"
                event.preventDefault();
                if(this.validate_fullname()){
                    fetch("http://127.0.0.1:5000/api/register",
                    {
                        method: "POST",
                        headers: 
                        {
                            "Content-Type": "application/json",
                        },
                        body: JSON.stringify({
                            email: this.email,
                            password: this.password,
                            fullname: this.fullname
                        })
                    }).then(response=>{
                        if(response.status == 201){
                            router.push({name: "signin"})
                        }
                        else if(response.status == 400){
                            return response.json()
                        }
                        else if(response.status == 409){
                            this.error["exist"] = "block"
                        }
                    }).then(response=>{
                        console.log(response)
                        if(!response["email"]){
                            this.error["email"] = "block"
                        }
                        if(!response["password"]){
                            this.error["password"] = "block"
                        }
                        if(!response["fullname"]){
                            this.error["fullname"] = "block"
                            this.valid["fullname"] = "none"
                        }
                        console.log(this.error)
                    })
                }
            }
        }
    }
</script>
<style scoped>
    #form-container{
        width: 100%;
        height: 90vh;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .row{
        padding: 8px;
    }
</style>