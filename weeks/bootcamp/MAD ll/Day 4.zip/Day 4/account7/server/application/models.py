from flask_sqlalchemy import SQLAlchemy
from flask_security import UserMixin, RoleMixin


db = SQLAlchemy()


class User(db.Model, UserMixin):
    
    __tablename__ = "user"
    id = db.Column(db.Integer(), primary_key=True, nullable=False)
    fullname = db.Column(db.String(), nullable=False)
    email = db.Column(db.String(), unique=True, nullable=False)
    password = db.Column(db.String(), nullable=False)
    balance = db.Column(db.Integer(), nullable=False)
    active = db.Column(db.Boolean())
    authenticated = db.Column(db.Boolean())
    fs_uniquifier = db.Column(db.String(64), unique=True, nullable=False)
    roles = db.relationship('Role', secondary='roles_users',
                         backref=db.backref('users', lazy='dynamic'))


class Role(db.Model, RoleMixin):

    __tablename__ = "role"
    id = db.Column(db.Integer(), primary_key=True, nullable=False)
    name = db.Column(db.String(), unique=True, nullable=False)


class UserRoles(db.Model):

    __tablename__ = "roles_users"
    id = db.Column(db.Integer(), primary_key=True, nullable=False)
    role_id = db.Column(db.Integer(), db.ForeignKey("role.id"), nullable=False)
    user_id = db.Column(db.Integer(), db.ForeignKey("user.id"), nullable=False)


class DepositType(db.Model):
    
    __tablename__ = "deposit_type"
    id = db.Column(db.Integer(), primary_key=True, nullable=False)
    type = db.Column(db.String(), nullable=False)
    interest_rate = db.Column(db.Float(), nullable=False) 
    days = db.Column(db.Integer(), nullable=False) 


class Deposit(db.Model):

    __tablename__ = "deposit"
    id = db.Column(db.Integer(), primary_key=True, nullable=False)
    user_id = db.Column(db.Integer(), db.ForeignKey("user.id"), nullable=False)
    date = db.Column(db.Date(), nullable=False)
    amount = db.Column(db.Integer(), nullable=False) 
    type = db.Column(db.Integer(), db.ForeignKey("deposit_type.id"), nullable=False)


class Transaction(db.Model):

    __tablename__ = "transaction"
    id = db.Column(db.Integer(), primary_key=True, nullable=False)
    user_id = db.Column(db.Integer(), db.ForeignKey("user.id"), nullable=False)
    receiver_id = db.Column(db.Integer(), db.ForeignKey("user.id"))
    type = db.Column(db.String(), nullable=False)
    amount = db.Column(db.Integer(), nullable=False) 
    date = db.Column(db.Date(), nullable=False)
