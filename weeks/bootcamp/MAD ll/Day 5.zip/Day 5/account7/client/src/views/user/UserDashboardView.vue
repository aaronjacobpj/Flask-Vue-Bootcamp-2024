<script setup>
    import store from "@/store"
</script>
<template>
    <div class="container-fluid" id="dashboard-container">
        <div class="section-container">
            <div class="card section">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <h5 class="card-title">
                                {{ store.getters.getProfile["fullname"] }}
                            </h5>
                        </div>
                        <div class="col">
                            <h6 class="card-subtitle mb-2 text-body-secondary">
                                Balance: {{ store.getters.getProfile["balance"] }}
                            </h6>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <h6 class="card-subtitle mb-2 text-body-secondary">
                                {{ store.getters.getProfile["email"] }}
                            </h6>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card section">
                <div class="card-body">
                    <h5 class="card-title">
                        Add Money
                    </h5>
                    <form @submit="add_money">
                        <div class="row" style="display: flex; align-items: center;">
                            <div class="col">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text" id="inputGroup-sizing-lg">Amount</span>
                                    <input type="number" min="0" class="form-control" v-model="amount"
                                    aria-label="Amount to invest" aria-describedby="inputGroup-sizing-lg">
                                </div>
                            </div>
                            <div class="col">
                                <input type="submit" class="btn btn-primary" value="Add">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <div class="invalid-feedback" :style="{display: error['deposit']}">
                                    Please enter a valid amount.
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="card section">
                <div class="card-body">
                    <h5 class="card-title">
                        Withdraw Money
                    </h5>
                    <form @submit="withdraw_money">
                        <div class="row" style="display: flex; align-items: center;">
                            <div class="col">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text" id="inputGroup-sizing-lg">Amount</span>
                                    <input type="number" min="0" class="form-control" v-model="withdraw"
                                    aria-label="Amount to invest" aria-describedby="inputGroup-sizing-lg">
                                </div>
                            </div>
                            <div class="col">
                                <input type="submit" class="btn btn-primary" value="Withdraw">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <div class="invalid-feedback" :style="{display: error['withdraw']}">
                                    Please enter a valid amount.
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <div class="invalid-feedback" :style="{display: error['limit']}">
                                    Reached maximum limit.
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="card section">
                <div class="card-body">
                    <h5 class="card-title">
                        Transfer Money
                    </h5>
                    <form @submit="transfer">
                        <div class="row" style="display: flex; align-items: center;">
                            <div class="col">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text" id="inputGroup-sizing-lg">Email</span>
                                    <input type="email" min="0" class="form-control" v-model="email"
                                    aria-label="Email of the user" aria-describedby="inputGroup-sizing-lg">
                                </div>
                            </div>
                            <div class="col">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text" id="inputGroup-sizing-lg">Amount</span>
                                    <input type="text" min="0" class="form-control" v-model="transfer_amount"
                                    aria-label="transfer amount" aria-describedby="inputGroup-sizing-lg">
                                </div>
                            </div>
                            <div class="col">
                                <input type="submit" class="btn btn-primary" value="Transfer"/>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <div class="invalid-feedback" :style="{display:error['email']}">
                                    please provide a valid mail.
                                </div>
                                <div class="valid-feedback" :style="{display:valid['transfer_amount']}">
                                    Transfered amount successfully
                                </div>
                            </div>
                            <div class="col">
                                <div class="invalid-feedback" :style="{display:error['transfer_amount']}">
                                    please provide a valid amount.
                                </div>
                            </div>
                            <div class="col"></div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="card section">
                <div class="card-body">
                    <h5 class="card-title">
                        Create a deposit
                    </h5>
                    <form @submit="create_deposit">
                        <div class="row" style="display: flex; align-items: center;">
                            <div class="col">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text" id="inputGroup-sizing-lg">Amount</span>
                                    <input type="text" min="0" class="form-control" v-model="deposit_amount"
                                    aria-label="transfer amount" aria-describedby="inputGroup-sizing-lg">
                                </div>
                            </div>
                            <div class="col" style="display: flex; align-items: center;">
                                <select class="form-select" aria-label="Deposit type select" v-model="deposit_id">
                                    <option selected disabled>Open this select menu</option>
                                    <option :value="deposit.id" v-for="deposit in store.getters.getDeposits">
                                        {{ deposit.type }}
                                    </option>
                                </select>
                            </div>
                            <div class="col">
                                <input type="submit" class="btn btn-primary" value="Deposit"/>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <div class="invalid-feedback" :style="{display:error['deposit_amount']}">
                                    please provide a amount.
                                </div>
                                <div class="valid-feedback" :style="{display:valid['valid_deposit']}">
                                    Created deposit successfully
                                </div>
                            </div>
                            <div class="col">
                                <div class="invalid-feedback" :style="{display:error['deposit_id']}">
                                    please select a valid deposit.
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default{
        data()
        {
            return{
                amount: null,
                withdraw: null,
                email: null,
                transfer_amount: null,
                deposit_amount: null,
                deposit_id: null,
                error:{
                    deposit: "none",
                    withdraw: "none",
                    email: "none",
                    transfer_amount: "none",
                    deposit_amount: "none",
                    deposit_id: "none",
                },
                valid:{
                    transfer_amount: "none",
                    valid_deposit: "none"
                }
            }
        },
        created()
        {
            store.dispatch("setProfile");
            store.dispatch("getDeposits")
        },
        methods:{
            add_money(event){
                event.preventDefault();

                this.error["deposit"] = "none";

                if(this.amount){
                    fetch(store.state.URL+"user/add-money",{
                        method: "POST",
                        headers:{
                            "Content-Type": "application/json",
                            "Authentication-Token": store.getters.getToken,
                        },
                        body: JSON.stringify({amount: this.amount})
                    }).then(response=>{
                        if(response.status == 200){
                            store.dispatch("setProfile");
                        }
                        else if(response.status == 400)
                        {
                            this.error["deposit"] = "block"
                        }
                    })
                }
            },
            withdraw_money(event)
            {
                event.preventDefault();

                this.error["withdraw"] = "none";
                this.error["limit"] = "none";

                if(this.withdraw){
                    fetch(store.state.URL+"user/withdraw-money",{
                        method: "POST",
                        headers:{
                            "Content-Type": "application/json",
                            "Authentication-Token": store.getters.getToken,
                        },
                        body: JSON.stringify({amount: this.withdraw})
                    }).then(response=>{
                        if(response.status == 200){
                            store.dispatch("setProfile");
                        }
                        else if(response.status == 400)
                        {
                            this.error["withdraw"] = "block"
                        }
                        else if (response.status == 406)
                        {
                            this.error["limit"] = "block"
                        }
                    })
                }
            },
            transfer(event)
            {
                event.preventDefault();

                this.error["email"] = "none";
                this.error["transfer_amount"] = "none";
                this.valid["transfer_amount"] = "none";

                if(this.email && this.transfer_amount)
                {
                    fetch(store.state.URL+"user/transfer",{
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            "Authentication-Token": store.getters.getToken
                        },
                        body: JSON.stringify({email: this.email, 
                            amount: this.transfer_amount})
                    }).then(response =>{
                        if(response.status == 200)
                        {
                            this.valid["transfer_amount"] = "block"
                        }
                        else if (response.status == 400)
                        {
                            this.error["email"] = "block"
                        }
                        else if(response.status == 406)
                        {
                            this.error["transfer_amount"] = "block"
                        }
                    })
                }
            },
            create_deposit(event)
            {
                event.preventDefault();
                this.error["deposit_id"] = "none"
                this.error["deposit_amount"] = "none"
                this.valid["valid_deposit"] = "none"

                if(this.deposit_amount && this.deposit_id)
                {
                    fetch(store.state.URL+"user/deposit",{
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            "Authentication-Token": store.getters.getToken
                        },
                        body: JSON.stringify({"deposit-id": this.deposit_id, 
                            amount: this.deposit_amount})
                    }).then(response =>{
                        if(response.status == 200)
                        {
                            this.valid["valid_deposit"] = "block"
                        }
                        else if (response.status == 400)
                        {
                            this.error["deposit_id"] = "block"
                        }
                        else if(response.status == 406)
                        {
                            this.error["deposit_amount"] = "block"
                        }
                    })
                }
            }
        }
    }
</script>
<style scoped>
    #dashboard-container{
        display: flex;
        justify-content: center;
    }
    .section-container{
        width: 80%;
        margin-top: 10px;
    }
    .section{
        margin-top: 10px;
    }
</style>