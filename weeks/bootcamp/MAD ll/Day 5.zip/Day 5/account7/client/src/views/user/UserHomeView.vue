<script setup>
    import Navbar from "@/components/user/Navbar.vue";
    import { RouterView } from "vue-router";
</script>
<template>
    <Navbar/>
    <RouterView/>
</template>