from flask import Flask
from flask_cors import CORS
from flask_security import SQLAlchemyUserDatastore, Security
from werkzeug.security import generate_password_hash


def create_app():

    from application.models import db, User, Role, UserRoles

    app = Flask(__name__)
    CORS(app)

    app.config["SECRET_KEY"] = "sdfcgvhbjertg9oikjhrfg"
    app.config["SECURITY_PASSWORD_SALT"] = "veasyufehalwnfijr"
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///model.db"


    datastore = SQLAlchemyUserDatastore(db, User, Role)
    app.security = Security(app, datastore)
    db.init_app(app)

    from application.views import api

    app.register_blueprint(api)

    with app.app_context():
        db.create_all()

        if not Role.query.filter_by(name="admin").first():
            app.security.datastore.create_role(name="admin")
            app.security.datastore.create_role(name="user")
            db.session.flush()

            app.security.datastore.create_user(fullname="Grace Watchman",
                                           email="grace.watchman@example.com", 
                                           password=generate_password_hash("grace"),
                                           balance=0)
            db.session.flush()

            admin = app.security.datastore.find_user(email="grace.watchman@example.com")
            role = app.security.datastore.find_role("admin")
            
            admin_role = UserRoles(user_id=admin.id, role_id=role.id)
            db.session.add(admin_role)
            db.session.commit()
            print("Done!")

    return app


app = create_app()
