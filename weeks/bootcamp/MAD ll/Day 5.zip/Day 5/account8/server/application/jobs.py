import os


from celery import Celery, shared_task
from celery.schedules import crontab
import requests

from flask import current_app 

from .models import User


app = Celery(broker = 'redis://localhost:6379/0',
            backend = 'redis://localhost:6379/1',
            broker_connection_retry_on_startup=True
            )


@app.on_after_configure.connect
def setup_periodic_tasks(sender, **kwargs):
    # Calls test('hello') every 10 seconds.
    # sender.add_periodic_task(10.0, hello_world.s(), name='add every 10')
    sender.add_periodic_task(crontab(minute="*"), 
                            hello_world.s(), 
                            name='add every 1 minute')



@app.task
def hello_world():
    requests.post(os.environ.get("GSPACE"),json={"text": "Hello from a Python script!"})
    

@app.task
def export(user_id):
    user = User.query.filter_by(id=user_id).first()
    return "Hello"