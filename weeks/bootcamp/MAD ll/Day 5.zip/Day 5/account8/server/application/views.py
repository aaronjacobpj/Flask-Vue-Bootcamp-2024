from flask import Blueprint, request
from flask import current_app as app
from flask_security import login_user, auth_required, current_user
from flask_security import roles_required
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import func

from celery.result import AsyncResult
import datetime

from .models import db, UserRoles, Transaction, DepositType, Deposit
from .jobs import export
from .jobs import app as celery_app


api = Blueprint("api", __name__, url_prefix="/api")


@api.route("/register", methods=["POST"])
def register():
    if request.method == "POST":
        email = request.json.get("email")
        fullname = request.json.get("fullname")
        password = request.json.get("password")

        response = {}
        if not email:
            response["email"] = False
        else:
            response["email"] = True
        
        if not fullname:
            response["fullname"] = False
        else:
            response["fullname"] = True

        if not password:
            response["password"] = False
        else:
            response["password"] = True

        if not response["email"] or not response["fullname"] or not response["password"]:
            return response, 400
        
        if app.security.datastore.find_user(email=email):
            response["exist"] = True
            return response, 409
    
        app.security.datastore.create_user(fullname=fullname,
                                           email=email, 
                                           password=generate_password_hash(password),
                                           balance=1000)
        db.session.flush()

        user = app.security.datastore.find_user(email=email)
        role = app.security.datastore.find_role(role="user")

        user_role = UserRoles(user_id=user.id, role_id=role.id)
        transaction = Transaction(user_id=current_user.id,
                type="DEPOSIT",
                amount=1000,
                date=datetime.date.today())
        db.session.add(transaction)
        db.session.add(user_role)
        db.session.commit()

        return {"message": "Request successful"}, 201




@api.route("/signin", methods=["POST"])
def signin():
    if request.method == "POST":

        email = request.json.get("email")
        password = request.json.get("password")

        user = app.security.datastore.find_user(email=email)

        if not user or not check_password_hash(user.password, password):
            return {"message": "User not found!"}, 404
        else:
            login_user(user)
            roles = []
            for role in current_user.roles:
                roles.append(role.name)

            return {"roles": roles, "token": current_user.get_auth_token()}
        

@api.route("/user/profile")
@auth_required("token")
def user_profile():

    today = datetime.date.today()
    month = datetime.date(year=today.year,
                            month=today.month,
                            day=1)
    
    if  500 >= current_user.balance > 100:
        if not Transaction.query.filter(Transaction.date >= month)\
            .filter_by(type="BALANCE-PENALTY", user_id=current_user.id).first():

            current_user.balance -= 100
            transaction = Transaction(user_id=current_user.id,
                                    type="BALANCE-PENALTY",
                                    amount=100,
                                    date=today)
            db.session.add(transaction)
            db.session.commit()

    return {
        "fullname": current_user.fullname,
        "email": current_user.email,
        "balance": current_user.balance
    }

@api.route("/user/add-money", methods=["POST"])
@auth_required("token")
def user_add_money():
    if request.method == "POST":
        amount = request.json.get("amount", int)
        
        if isinstance(amount, int):

            current_user.balance += amount
            transaction = Transaction(user_id=current_user.id,
                            type="DEPOSIT",
                            amount=amount,
                            date=datetime.date.today())
            db.session.add(transaction)
            db.session.commit()
            return {"message": "Rquest successful"}
        
        return {"message": "Invalid amount"}, 400
    

@api.route("/user/withdraw-money", methods=["POST"])
@auth_required("token")
def user_withdraw_money():
    if request.method == "POST":
        amount = request.json.get("amount", int)
        
        # check if the user input is avlid
        if not isinstance(amount, int) or amount > current_user.balance:
            return {"message": "Invalid amount"}, 400
        
        today = datetime.date.today()
        month = datetime.date(year=today.year,
                              month=today.month,
                              day=1)

        # Check if number of withdrawal transaction done by the use in the current month
        # is less than five else return error otherwise deduct and update trasaction
        if Transaction.query.filter(Transaction.date >= month)\
            .filter_by(type="WITHDRAW", user_id=current_user.id).count() >= 5:
            return {"message": "Reached maximum time you can withdraw per month"}, 406

        current_user.balance -= amount
        transaction = Transaction(user_id=current_user.id,
                                    type="WITHDRAW",
                                    amount=amount,
                                    date=today)
        db.session.add(transaction)
        db.session.commit()
        return {"message": "Rquest successful"}
        

@api.route("/user/statement")
@auth_required("token")
def user_statement():
    transactions = Transaction.query.filter_by(user_id=current_user.id).all()
    result = []
    for transaction in transactions:
        result.append({
            "user-id": transaction.user_id,
            "receiver-id": transaction.receiver_id,
            "type": transaction.type,
            "amount": transaction.amount,
            "date": transaction.date
        })

    return result


@api.route("/user/transfer", methods=["POST"])
@auth_required("token")
def user_money_transfer():
    email = request.json.get("email")
    amount = request.json.get("amount")

    if not email:
        return {"message": "invalid email"}, 400
    
    if not amount.isnumeric():
        return {"message": "invalid amount"}, 406
    
    user = app.security.datastore.find_user(email=email)

    if not user or user.id == current_user.id:
        return {"message": "invalid email"}, 400
    
    transaction = Transaction(user_id=current_user.id,
                              receiver_id=user.id,
                              type="TRANSFER",
                              amount=int(amount),
                              date=datetime.date.today()
                            )
    amount = int(amount)
    current_user.balance -= amount
    user.balance += amount
    db.session.add(transaction)
    db.session.commit()

    return {"message": "request successful"}, 200


@api.route("admin/graph")
@auth_required("token")
@roles_required("admin")
def admin_graph():
    transactions = db.session.query(func.sum(Transaction.amount),
                                    Transaction.date).filter_by(
                                        type="DEPOSIT",
                                    ).group_by(Transaction.date).all()
    result = [["Date", "Amount"]]
    for amount, date in transactions:
        result.append([date.strftime("%Y-%m-%d"),
                       amount])
        
    return result


@api.route("admin/deposit", methods=["GET", "POST"])
@auth_required("token")
def admin_deposit_create():
    
    if request.method == "GET":
        result = []
        for each in DepositType.query.all():
            result.append({"id": each.id,
                           "type": each.type,
                           "interest": each.interest_rate,
                           "days": each.days})
            
        return result


    if request.method == "POST" and "admin" in current_user.roles:
        name = request.json.get("name")
        interest = request.json.get("interest")
        days = request.json.get("days")


        if not name or DepositType.query.filter_by(type=name).first():
            return {"message": "invalid name"}, 409
        
        if not interest.replace(".", "", 1).isdigit():
            return {"message": "invalid interest"}, 406
        

        elif not isinstance(days, int):
            return {"message": "invalid days"}, 400
        
        deposit = DepositType(type=name,
                            interest_rate=interest,
                            days=days)
        db.session.add(deposit)
        db.session.commit()

        return {"message": "Request successful"}, 201
    

@api.route("admin/deposit/<int:deposit_id>/edit", methods=["POST"])
@auth_required("token")
@roles_required("admin")
def admin_deposit_edit(deposit_id):

    deposit = DepositType.query.filter_by(id=deposit_id).first()

    name = request.json.get("name")
    interest = request.json.get("interest")
    days = request.json.get("days")

    duplicate = DepositType.query.filter_by(type=name).first()

    if not name or not duplicate.id == deposit.id:
        return {"message": "invalid name"}, 409
    
    if not isinstance(interest, (int, float)) and not interest.replace(".", "", 1).isdigit():
        return {"message": "invalid interest"}, 406
    

    elif not isinstance(days, int):
        return {"message": "invalid days"}, 400
    
    deposit.name = name
    deposit.interest_rate = interest
    deposit.days = days
    db.session.commit()

    return {"message": "Request successful"}, 201


@api.route("admin/deposit/<int:deposit_id>/delete", methods=["DELETE"])
@auth_required("token")
@roles_required("admin")
def admin_deposit_delete(deposit_id):
    deposit = DepositType.query.filter_by(id=deposit_id).first()

    if deposit:
        db.session.delete(deposit)
        db.session.commit()

        return {"message": "Request successful"}, 200
    
    return {"message": "Deposit not found"}, 404


@api.route("user/deposit", methods=["POST"])
@auth_required("token")
@roles_required("user")
def create_user_deposit():
    deposit_id = request.json.get("deposit-id")
    amount = request.json.get("amount")

    if not amount.isnumeric():
        return {"message": "invalid amount"}, 406
    
    if not isinstance(deposit_id, int):
        return {"message": "invalid deposit"}, 400
    
    amount = int(amount)

    if amount < 0:
        return {"message": "invalid amount"}, 406
    
    deposit = DepositType.query.filter_by(id=deposit_id).first()

    if not deposit:
        return {"message": "invalid deposit"}, 400
    
    user_deposit = Deposit(user_id=current_user.id,
                           type=deposit.id,
                           date=datetime.date.today(),
                           amount=amount)
    db.session.add(user_deposit)
    db.session.commit()

    return {"message": "Request succesful"}, 200


@api.route("admin/deposit/monitor")
@auth_required("token")
@roles_required("admin")
def admin_deposit_monitor():
    deposits = DepositType.query.all()

    result = []
    for deposit in deposits:
        selection = []
        for each in deposit.deposits:
            selection.append({"id": each.id,
                              "user-name": each.user.fullname,
                              "deposit-date": each.date,
                              "deposit-amount": each.amount,
                              })
            
        result.append({"name": deposit.type,
                       "users": selection})
        
    return result


@api.route("/jobs/export")
@auth_required("token")
def create_user_statement_export():
    result =  export.delay(current_user.id)
    return result.task_id


@api.route("/jobs/export/<string:task_id>")
@auth_required("token")
def check_user_statement_export(task_id):
    result =  AsyncResult(id=task_id,
                          app=celery_app)
    return result.status