import pytest
from app import create_app

from application.models import User, Role, UserRoles


@pytest.fixture()
def app():
    app = create_app()
    app.config.update({
        "TESTING": True,
        "SQLALCHEMY_DATABASE_URI": "sqlite:///model.db"
    })

    # other setup can go here

    yield app

    # clean up / reset resources here


@pytest.fixture()
def client(app):
    return app.test_client()


@pytest.fixture()
def runner(app):
    return app.test_cli_runner()


@pytest.fixture()
def admin(app):
    with app.app_context():
        user = User.query.filter(Role.id==UserRoles.role_id,
                                 UserRoles.user_id==User.id,
                                 Role.name=="admin").first()
        
    return user
