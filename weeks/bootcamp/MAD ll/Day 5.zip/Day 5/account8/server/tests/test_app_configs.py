from .config import admin, app, client

from application.models import Role

def test_admin(admin):
    assert admin.email == "grace.watchman@example.com"


def test_roles(app):

    with app.app_context():
        assert Role.query.filter_by(name="admin").first()
        assert Role.query.filter_by(name="user").first()