<script setup>
    import store from "@/store"
</script>
<template>
        <div class="container-fluid" id="dashboard-container">
            <div class="section-container">
                <div class="card section">
                    <div class="card-body">
                        <div id="curve_chart" style="width: 100%; height: 60vh"></div>
                    </div>
                </div>
            </div>
        </div>
</template>
<script>
    export default{
        data()
        {
            return {

            }
        },
        created()
        {
            google.charts.load('current', {'packages':['corechart']});
            store.dispatch("getGraph");
        },
        mounted()
        {
            google.charts.setOnLoadCallback(this.drawchart);
        },
        methods:{
            drawchart(){
                var data = google.visualization.arrayToDataTable(
                    store.getters.getGraph
                );

                var options = {
                title: 'User Deposit',
                curveType: 'function',
                legend: { position: 'bottom' }
                };

                var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

                chart.draw(data, options);
            }
        }
    }
</script>