<script setup>
    import store from "@/store"
    import { RouterLink } from "vue-router"
</script>
<template>
    <div class="container-fluid" id="dashboard-container">
        <div class="section-container">
            <div class="card section" v-for="deposit in deposits">
                <div class="card-body">
                    <h5 class="card-title">{{ deposit["name"] }}</h5>
                    <table class="table">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">User</th>
                            <th scope="col">Date</th>
                            <th scope="col">Amount</th>
                            <th colspan="2"></th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr v-for="user, index in deposit['users']">
                            <th scope="row">{{ index + 1 }}</th>
                            <td>{{ user["user-name"] }}</td>
                            <td>{{ parsedate(user["deposit-date"]) }}</td>
                            <td>{{ user["deposit-amount"] }}</td>
                          </tr>
                        </tbody>
                      </table>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default{
        data()
        {
            return{
                deposits: []
            }
        },
        created(){
            fetch(store.state.URL+"admin/deposit/monitor",{
                    method: "GET",
                    headers:{
                        "Authentication-Token": store.getters.getToken
                    }
            }).then(response=>{
                if(response.status == 200){
                    return response.json()
                }
                else{
                    return []
                }
            }).then(response=>{
                this.deposits = response;
            })
        },
        methods:{
            delete_deposit(deposit_id)
            {
                fetch(store.state.URL+`admin/deposit/${deposit_id}/delete`,{
                    method: "DELETE",
                    headers:{
                        "Authentication-Token": store.getters.getToken
                    }
                }).then(response=>{
                    store.dispatch("getDeposits");
                })
            },
            parsedate(value){
                var date = new Date(value);
                return `${date.getDate()}-${date.getMonth()}-${date.getFullYear()}`
            }
        }
    }
</script>