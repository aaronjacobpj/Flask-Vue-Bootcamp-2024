<script setup>
    import store from "@/store"
</script>
<template>
    <div class="container-fluid" id="dashboard-container">
        <div class="section-container">
            <div class="card section">
                <div class="card-body">
                    <h5 class="card-title">Edit Deposit</h5>
                    <form @submit="edit_deposit">
                        <div class="row">
                            <div class="col">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text" id="inputGroup-sizing-lg">Name</span>
                                    <input type="text" class="form-control" aria-label="Deposit name input" 
                                    aria-describedby="inputGroup-sizing-lg" v-model="name">
                                </div>
                            </div>
                            <div class="col">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text" id="inputGroup-sizing-lg">Interest</span>
                                    <input type="text" class="form-control" aria-label="Interest rate input"
                                    aria-describedby="inputGroup-sizing-lg" v-model="interest">
                                </div>
                            </div>
                            <div class="col">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text" id="inputGroup-sizing-lg">Days</span>
                                    <input type="number" class="form-control" aria-label="Days input" 
                                    aria-describedby="inputGroup-sizing-lg" v-model="days">
                                </div>
                            </div>
                            <div class="col" style="display: flex;align-items: center;">
                                <input type="submit" class="btn btn-primary" value="Submit">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <div class="invalid-feedback" :style="{display: error['name']}">
                                    Invalid name
                                </div>
                                <div class="valid-feedback" :style="{display: valid['response']}">
                                    Request successful
                                </div>
                            </div>
                            <div class="col">
                                <div class="invalid-feedback" :style="{display: error['interest']}">
                                    Invalid interest
                                </div>
                            </div>
                            <div class="col">
                                <div class="invalid-feedback" :style="{display: error['days']}">
                                    Invalid days
                                </div>
                            </div>
                            <div class="col"></div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default{
        props: ["id"],
        data()
        {
            return{
                interest: null,
                name: null,
                days: null,
                error:{
                    interest: "none",
                    name: "none",
                    days: "none",
                },
                valid:{
                    response: "none"
                }
            }
        },
        created()
        {

            fetch(store.state.URL+"admin/deposit",{
                headers:{
                    "Authentication-Token": store.getters.getToken
                }
            }).then(response=>{
                if(response.status == 200)
                {
                    return response.json()
                }
                else
                {
                    return []
                }
            }).then(value=>{
                var deposit = value.filter(each =>{
                    return each["id"] == this.id
                })[0]
                this.name = deposit["type"];
                this.interest = deposit["interest"];
                this.days = deposit["days"]
            })

            
        },
        methods:{
            edit_deposit(event)
            {
                event.preventDefault();
                this.error = {
                    interest: "none",
                    name: "none",
                    days: "none",
                }
                this.valid = {
                    response: "none"
                }
                if(this.name && this.days != null && this.interest)
                {
                    fetch(store.state.URL+`admin/deposit/${this.id}/edit`,{
                        method: "POST",
                        headers:{
                            "Content-Type": "application/json",
                            "Authentication-Token": store.getters.getToken
                        },
                        body:JSON.stringify({name:this.name,
                            interest: this.interest,
                            days:this.days
                            })
                    }).then(response =>{
                        if(response.status == 201)
                        {
                            this.valid["response"] = "block"
                        }
                        else if (response.status == 409)
                        {
                            this.error["name"] = "block"
                        }
                        else if(response.status == 406)
                        {
                            this.error["interest"] = "block"
                        }
                        else if(response.status == 400)
                        {
                            this.error["days"] = "block"
                        }

                    })
                }
            }
        }
    }
</script>