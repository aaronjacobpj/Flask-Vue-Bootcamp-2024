<script setup>
    import store from "@/store"
    import { RouterLink } from "vue-router"
</script>
<template>
    <div class="container-fluid" id="dashboard-container">
        <div class="section-container">
            <div class="card section">
                <div class="card-body">
                    <h5 class="card-title">Deposit Details</h5>
                    <table class="table">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">Deposit</th>
                            <th scope="col">Interest</th>
                            <th scope="col">Days</th>
                            <th colspan="2"></th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr v-for="deposit, index in store.getters.getDeposits">
                            <th scope="row">{{ index + 1 }}</th>
                            <td>{{ deposit["type"] }}</td>
                            <td>{{ deposit["interest"] }}</td>
                            <td>{{ deposit["days"] }}</td>
                            <td>
                                <RouterLink :to="{name: 'admin-deposit-edit', params:{id: deposit['id']}}" 
                                    style="text-decoration: none; color: inherit;">
                                    <button class="btn btn-light">
                                        Edit
                                    </button>
                                </RouterLink>
                            </td>
                            <td>
                                <RouterLink to="#" style="text-decoration: none; color: inherit;">
                                    <button class="btn btn-outline-danger" @click="delete_deposit(deposit['id'])">
                                        Delete
                                    </button>
                                </RouterLink>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default{
        data()
        {
            return{

            }
        },
        created(){
            store.dispatch("getDeposits")
        },
        methods:{
            delete_deposit(deposit_id)
            {
                fetch(store.state.URL+`admin/deposit/${deposit_id}/delete`,{
                    method: "DELETE",
                    headers:{
                        "Authentication-Token": store.getters.getToken
                    }
                }).then(response=>{
                    store.dispatch("getDeposits");
                })
            }
        }
    }
</script>