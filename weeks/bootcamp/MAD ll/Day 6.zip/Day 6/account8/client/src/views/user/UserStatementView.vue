<script setup>
    import store from "@/store"
</script>
<template>
    <div class="container-fluid" id="dashboard-container">
        <div class="section-container">
            <div class="card section">
                <div class="card-body">
                    <h5 class="card-title">
                        Account Statement
                    </h5>
                    <table class="table">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">User ID</th>
                            <th scope="col">Receiver ID</th>
                            <th scope="col">Type</th>
                            <th scope="col">Amount</th>
                            <th scope="col">Date</th>
                        </tr>
                        </thead>
                        <tbody>
                          <tr v-for="(row, index) in statement">
                            <th scope="row">{{ index + 1 }}</th>
                            <td>{{ row["user-id"] }}</td>
                            <td>{{ row["receiver-id"] }}</td>
                            <td>{{ row["type"] }}</td>
                            <td>{{ row["amount"] }}</td>
                            <td>{{ parseDate(row["date"]) }}</td>
                          </tr>
                        </tbody>
                      </table>
                </div>
            </div>
            <div class="card section">
                <div class="card-body">
                    <h5 class="card-title">
                        Filter Statement
                    </h5>
                    <div class="row" style="display: flex; align-items: center;">
                        <div class="col">
                            <div class="input-group input-group-sm mb-3">
                                <span class="input-group-text" id="inputGroup-sizing-sm">Start Date</span>
                                <input type="date" class="form-control" aria-label="Start Date input" 
                                    aria-describedby="inputGroup-sizing-sm" v-model="startdate">
                            </div>                              
                        </div>
                        <div class="col">
                            <div class="input-group input-group-sm mb-3">
                                <span class="input-group-text" id="inputGroup-sizing-sm">End Date</span>
                                <input type="date" class="form-control" aria-label="End Date input" 
                                    aria-describedby="inputGroup-sizing-sm" v-model="enddate">
                            </div>                              
                        </div>
                        <div class="col">
                            <input type="button" @click="reset" class="btn btn-primary" value="Reset">
                        </div>
                    </div>
                </div>
            </div>
            <div class="card section">
                <div class="card-body">
                    <h5 class="card-title">
                        Export Job
                    </h5>
                    <form @submit="create_export">
                        <div class="row" style="display: flex; align-items: center;">
                            <div class="col">
                                <div class="input-group input-group-sm mb-3">
                                    <span class="input-group-text" id="inputGroup-sizing-sm">Start Date</span>
                                    <input type="date" class="form-control" aria-label="Start Date input" 
                                        aria-describedby="inputGroup-sizing-sm" v-model="exportStartDate">
                                </div>                              
                            </div>
                            <div class="col">
                                <div class="input-group input-group-sm mb-3">
                                    <span class="input-group-text" id="inputGroup-sizing-sm">End Date</span>
                                    <input type="date" class="form-control" aria-label="End Date input" 
                                        aria-describedby="inputGroup-sizing-sm" v-model="exportEndDate">
                                </div>                              
                            </div>
                            <div class="col">
                                <input type="submit" class="btn btn-primary" value="Reset">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default{
        data()
        {
            return{
                months: ['January', 'February', 'March', 'April', 
                'May', 'June', 'July', 'August', 'September', 
                'October', 'November', 'December'],
                startdate: null,
                enddate: null,
                exportStartDate: null,
                exportEndDate: null,
                checkTask: null,
                task_id: null
            }
        },
        created(){
            store.dispatch("getStatement")
        },
        methods:{
            parseDate(value){
                var date = new Date(value);
                return `${date.getDate()} ${this.months[date.getUTCMonth()]} ${date.getFullYear()}`
            },
            reset(){
                this.startdate = null,
                this.enddate = null
            },
            create_export(event){

                event.preventDefault();

                if(this.exportStartDate && this.exportEndDate)
                {
                    fetch(store.state.URL.replace("/api/", "/")+"jobs/export",{
                        headers:{
                            "Authentication-Token": store.getters.getToken
                        }
                    }).then(response=>{
                        if(response.status == 200)
                        {
                            return response.json()
                        }
                        else
                        {
                            return []
                        }
                    }).then(value=>{
                        this.checkTask = setInterval(()=>{
                            this.check_export_state(value["task-id"])
                        }, 1000)
                    })
                }
            },
            check_export_state(id){
                fetch(store.state.URL.replace("/api/", "/")+"jobs/export/"+id,{
                        headers:{
                            "Authentication-Token": store.getters.getToken
                        }
                    }).then(response=>{
                        if(response.status == 200)
                        {
                            return response.text()
                        }
                        else
                        {
                            return "";
                        }
                    }).then(value=>{
                        if("SUCCESS" == value){
                            clearInterval(this.checkTask);
                            this.download_export(id);
                        }
                    })
            },
            download_export(id){
                open("http://127.0.0.1:5000/jobs/result/"+id+"?auth_token="+store.getters.getToken)
            }
        },
        computed:{
            statement(){
                var result = store.getters.getStatement;
                var startdate = new Date(this.startdate).getTime();
                var enddate = new Date(this.enddate).getTime();

                if(this.startdate && this.enddate){

                    result = result.filter(each =>{
                        var date = new Date(each["date"]).getTime() 
                        if (startdate <= date && date <= enddate)
                        {
                            return true
                        }
                        else
                        {
                            return false
                        }
                    })
                }
                return result
            }
        }
    }
</script>
<style scoped>
    #dashboard-container{
        display: flex;
        justify-content: center;
    }
    .section-container{
        width: 80%;
        margin-top: 10px;
    }
    .section{
        margin-top: 10px;
    }
</style>