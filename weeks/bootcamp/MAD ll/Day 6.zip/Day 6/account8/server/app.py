from flask import Flask, render_template, send_file
from flask_cors import CORS
from flask_security import SQLAlchemyUserDatastore, Security, auth_required, current_user
from werkzeug.security import generate_password_hash


from io import BytesIO

from celery import Celery
from celery.result import AsyncResult

from application.models import db, User, Role, UserRoles, Transaction


def create_app():

    app = Flask(__name__)
    CORS(app)

    app.config["SECRET_KEY"] = "sdfcgvhbjertg9oikjhrfg"
    app.config["SECURITY_PASSWORD_SALT"] = "veasyufehalwnfijr"
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///model.db"


    datastore = SQLAlchemyUserDatastore(db, User, Role)
    app.security = Security(app, datastore)
    db.init_app(app)

    from application.views import api

    app.register_blueprint(api)

    with app.app_context():
        db.create_all()

        if not Role.query.filter_by(name="admin").first():
            app.security.datastore.create_role(name="admin")
            app.security.datastore.create_role(name="user")
            db.session.flush()

            app.security.datastore.create_user(fullname="Grace Watchman",
                                           email="grace.watchman@example.com", 
                                           password=generate_password_hash("grace"),
                                           balance=0)
            db.session.flush()

            admin = app.security.datastore.find_user(email="grace.watchman@example.com")
            role = app.security.datastore.find_role("admin")
            
            admin_role = UserRoles(user_id=admin.id, role_id=role.id)
            db.session.add(admin_role)
            db.session.commit()
            print("Done!")

    return app



app = create_app()

celery = Celery(broker = 'redis://localhost:6379/0',
             backend = 'redis://localhost:6379/1',
             broker_connection_retry_on_startup=True
            )


@celery.task
def export(user_id):
    with app.app_context():
        transactions = Transaction.query.filter_by(user_id=user_id).all()

        result = render_template("statement.html", transactions=transactions)
    return result



@app.route("/jobs/export")
@auth_required("token")
def create_user_statement_export():
    result =  export.delay(current_user.id)
    return {"task-id": result.task_id}



@app.route("/jobs/export/<string:task_id>")
@auth_required("token")
def check_user_statement_export(task_id):
    result =  AsyncResult(id=task_id,
                          app=celery)
    return result.status

@app.route("/jobs/result/<string:task_id>")
@auth_required("token")
def get_export_result(task_id):
    result =  AsyncResult(id=task_id,
                          app=celery)
    
    content = BytesIO(result.result.encode())
    content.seek(0)
    return send_file(content,
              download_name="export.html",
              as_attachment=True
              )