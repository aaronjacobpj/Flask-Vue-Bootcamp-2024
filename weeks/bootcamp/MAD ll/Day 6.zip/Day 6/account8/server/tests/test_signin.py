from .config import app, client, admin


def test_valid_signin(client, admin):

    response = client.post("/api/signin", json={"email": admin.email,
                                                "password": "grace"})
    
    assert response.status_code == 200


def test_valid_signin(client, admin):

    response = client.post("/api/signin", json={"email": admin.email,
                                                "password": ""})
    
    assert response.status_code == 404

def test_valid_signin_reponse(client, admin):

    response = client.post("/api/signin", json={"email": admin.email,
                                                "password": "grace"})
    
    assert "token" in response.json
    assert "roles" in response.json
    assert response.json.get("roles") != []