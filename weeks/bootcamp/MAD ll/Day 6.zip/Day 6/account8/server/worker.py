from celery import Celery
from celery.schedules import crontab
from celery.result import AsyncResult


from application.models import User


app = Celery(broker = 'redis://localhost:6379/0',
             backend = 'redis://localhost:6379/1',
             broker_connection_retry_on_startup=True
            )

from app import create_app

flask = create_app()


@app.task
def export(user_id):
    with flask.app_context():
        user = User.query.filter_by(id=user_id).first()
    return "Hello"


result = export.delay(1)

print(AsyncResult(result.id, app=app).status)