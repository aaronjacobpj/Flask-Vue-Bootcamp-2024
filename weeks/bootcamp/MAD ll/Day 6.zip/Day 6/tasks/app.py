from flask import Flask
from celery import Celery
from models import db, Reviews
from celery.result import AsyncResult



app = Flask(__name__)

celery = Celery(broker = 'redis://localhost:6379/0',
            backend = 'redis://localhost:6379/1',
            broker_connection_retry_on_startup=True
            )


app.config["SECRET_KEY"] = "sdfcgvhbjertg9oikjhrfg"
app.config["SECURITY_PASSWORD_SALT"] = "veasyufehalwnfijr"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///model.db"

db.init_app(app)

with app.app_context():
    db.create_all()

@celery.task
def export():
    result = []
    with app.app_context():
        reviews  = Reviews.query.all()

    for review in reviews:
        result.append({"id": review.id, "review": review.review})

    return result


@app.route("/")
def index():
    result = export.delay()
    return result.id


@app.route("/<string:job_id>")
def status(job_id):
    return AsyncResult(id=job_id, app=celery).status


@app.route("/result/<string:job_id>")
def result(job_id):
    return AsyncResult(id=job_id, app=celery).result