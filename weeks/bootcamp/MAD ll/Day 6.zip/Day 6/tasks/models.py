from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()


class Reviews(db.Model):

    __tablename__ = "review"
    id = db.Column(db.Integer(), primary_key=True)
    review = db.Column(db.String())

    